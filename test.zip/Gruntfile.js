module.exports = function (grunt) {

    grunt.initConfig({
        shell: {
            "build-proxy-alpine": {
                command: "npm run build-alpine"
            }
        },

        /**
         * Run `grunt watch` to build proxy for alpine
         */
        watch: {
            src: {
                files: ['proxy/client/src/**/*.js', 'proxy/client/src/**/*.ejs'],
                tasks: ["shell:build-proxy-alpine"],
                options: {
                    debounceDelay: 500
                }
            }
        }
    });

    grunt.loadNpmTasks('grunt-shell');
    grunt.loadNpmTasks('grunt-contrib-watch');
};

