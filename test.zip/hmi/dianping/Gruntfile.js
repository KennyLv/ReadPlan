module.exports = function(grunt) {
    "use strict";

    grunt.file.expand('../node_modules/grunt-*/tasks').forEach(grunt.loadTasks);

    var platform = grunt.option("platform") || "vp2c";
    var version = process.env.dianping ? ['', process.env.dianping] :
            (process.env.versions || "").match(/dianping=([^;]+)/),
        manifestVersion = version ? version[1] : "0.0.0";

    var checkCircularDependencies = function (data) {
        var madge = require("madge"),
            circular = madge([data.path], {
                format: "amd",
                optimized: true
            }).circular(),
            isCyclic = circular.getArray().length;

        if (isCyclic) {
            circular.getArray().forEach(function (path) {
                path.forEach(function (module, idx) {
                    if (idx) {
                        process.stdout.write(" -> ");
                    }
                    process.stdout.write(module);
                });
                process.stdout.write("\n");
            });
            grunt.fail.fatal("Circular dependencies detected");
        }
    };

    var config = grunt.initConfig({

        app: grunt.file.readJSON("../platform/" + platform + "/hmiapps/dianping/resources/app.json"),
        version: "<%= app.version %>",

        buildFolder: "../dist",

        moduleName: "dianping",
        moduleFileName: "app.js",
        moduleFolder: "<%= buildFolder %>/<%= moduleName %>",
        moduleMetadata: 'metadata',

        jshint: {
            options: {
                jshintrc: "../.jshintrc",
                ignores: [
                    "src/vendor/**"
                ]
            },
            all: [
                "src/**/*.js"
            ]
        },

        copy: {
            resources: {
                files: [
                    {
                        expand: true,
                        cwd: "../platform/" + platform + "/hmiapps/<%= moduleName %>/",
                        src: "di.js",
                        dest: "src/"
                    }, {
                        expand: true,
                        cwd: "../platform/" + platform + "/hmiapps/<%= moduleName %>/resources/",
                        src: ["**"],
                        dest: "<%= moduleFolder %>/"
                    }
                ]
            },
            release: {
                flatten: true,
                expand: true,
                src: [
                    "<%= moduleFolder %>.zip",
                    "../platform/" + platform + "/hmiapps/<%= moduleName %>/<%= moduleMetadata %>/*"
                ],
                dest: "<%= moduleFolder %>/"
            }
        },

        replace: {
            release: {
                src: ["<%= moduleFolder %>/MANIFEST.txt"],
                overwrite: true,
                replacements: [{
                    from: "<VERSION>",
                    to: manifestVersion
                }]
            }
        },

        requirejs: {
            release: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    optimize: "uglify"
                }
            },
            dev: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    generateSourceMaps: true,
                    optimize: "none"
                }
            }
        },

        compress: {
            module: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %>.zip",
                    mode: "zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= buildFolder %>/",
                    src: "<%= moduleName %>/**"
                }]
            },
            release: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %><%= version %>.zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= moduleFolder %>",
                    src: "**"
                }]
            }
        },

        karma: {
            options: {
                configFile: "../karma.conf.js"
            },
            unit: {
                options: {
                    // list of files / patterns to load in the browser
                    files: [
                        {pattern: 'node_modules/es5-shim/es5-shim.js', included: false},
                        {pattern: 'platform/core/**/*.js', included: false},
                        {pattern: 'common/**/*.js', included: false},
                        {pattern: 'dianping/src/**/*.js', included: false},
                        {pattern: 'dianping/spec/unit/*.spec.js', included: false},
                        "dianping/test-main.js"
                    ]
                }
            }
        }

    });

    grunt.registerTask("clean", function () {
        var path = require('path');
        return grunt.file.delete(path.join(config.buildFolder, config.moduleName), {force: true});
    });

    grunt.registerTask("cleanAfter", function () {
        var path = require('path');
        return grunt.file.delete(path.join(config.buildFolder, config.moduleName).concat('.zip'), {force: true});
    });

    grunt.registerTask("default", ["release"]);
    grunt.registerTask("release", [
        "jshint", "copy:resources", "requirejs:release", "compress:module",
        "clean", "copy:release", "replace:release", "compress:release", "clean", "cleanAfter"
    ]);
    grunt.registerTask("release-pretty", [
        "jshint", "copy:resources", "requirejs:dev", "compress:module",
        "clean", "copy:release", "replace:release", "compress:release", "clean", "cleanAfter"
    ]);
    grunt.registerTask("dev", ["jshint", "copy:resources", "requirejs:dev"]);
};
