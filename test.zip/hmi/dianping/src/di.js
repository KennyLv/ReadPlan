define('dianping/di', [], function () {
    'use strict';

    var Dic = require('aq/di'),
        aq = require('aq/dic'),
        display = [aq.get('display')];
//    var appManager = aq.get('appManager');


    return new Dic({
        'appName': aq.get('appManager').getCurrentApplicationName(),
        'config': {
            module: require('dianping/config')
        },
        'policy': {
            module: aq.get('policy')
        },
        'backend': function () {
            var BackendModel = require('dianping/models/backend');
            if (!this.registry.backendModel) {
                this.registry.backendModel = new BackendModel(
                    this.get('choreo'),
                    this.get('config')
                );
            }

            return this.registry.backendModel;
        },
        'navigation': function () {
            return aq.get('navigation');
        },
        'choreo': function () {
            var Choreo = require('aq/api/choreo');

            if (!this.registry.choreo) {
                this.registry.choreo = new Choreo(
                    aq.get('transport'),
                    aq.get('profile')
                );
            }

            return this.registry.choreo;
        },
        'router': function () {
            var Router = require('dianping/router');

            if (!this.registry.router) {
                this.registry.router = new Router({
                    dic: this,
                    backend: this.get('backend'),
                    homeMenu: this.get('controller/menu')
                });
            }

            return this.registry.router;
        },
        'controller/base': function () {
            var Base = require('dianping/controllers/common/base');
            return (this.registry['controller/base'] = new Base({
                navigation: this.get('navigation'),
                policy: this.get('policy'),
                popup: this.get('Popup'),
                config: this.get('config')
            }));
        },
        
        'controller/menu': function () {
            var Menu = require('dianping/controllers/menu');
            return (this.registry['controller/menu'] = new Menu({
                menu: this.get('views/menu'),
                policy: this.get('policy'),
                config: this.get('config')
            }));
        },
        'controller/results': function () {
            var Results = require('dianping/controllers/results');
            return (this.registry['controller/results'] = new Results({
                backend: this.get('backend'),
                view: this.get('views/results'),
                config: this.get('config'),
                popup: this.get('Popup'),
                policy: this.get('policy')
            }));
        },
        'controller/categories': function () {
            var Categories = require('dianping/controllers/categories');
            return (this.registry['controller/categories'] = new Categories({
                config: this.get('config'),
                categories: this.get('views/categories'),
                policy: this.get('policy')
            }));
        },
        'controller/favorites': function () {
            var Favorites = require('dianping/controllers/favorites');
            return (this.registry['controller/favorites'] = new Favorites({
                backend: this.get('backend'),
                view: this.get('views/favorites'),
                config: this.get('config'),
                navigation:this.get('navigation'),
                popup: this.get('Popup'),
                policy: this.get('policy')
            }));
        },
        'controller/detail': function () {
            var Detail = require('dianping/controllers/detail');
            return (this.registry['controller/detail'] = new Detail({
                detailScreen: this.get('views/detail'),
                config: this.get('config'),
                policy: this.get('policy')
            }));
        },
        'views/menu': function () {
            var Menu = require('dianping/views/menu');
            return (this.registry['views/menu'] = new Menu(
                    aq.get('display'),
                    this.get('config'),
                    aq.get('constants')));
        },
        'views/results': function () {
            var Results = require('dianping/views/results');
            return (this.registry['views/results'] = new Results(
                     aq.get('display'),
                     this.get('config'),
                     this.get('backend'),
                     aq.get('constants')));
        },
        'views/categories': function () {
            var Categories = require('dianping/views/categories');
            return (this.registry['views/categories'] = new Categories(
                    aq.get('display'),
                    this.get('config'),
                    aq.get('constants')));
        },
        'views/favorites': function () {
            var FavoritesView = require('dianping/views/favorites');
            return (this.registry['views/favorites'] = new FavoritesView(
                    aq.get('display'), 
                    this.get('config'),
                    aq.get('constants')));
        },
        'views/detail': function () {
            var DetailView = require('dianping/views/detail');
            return (this.registry['views/detail'] = new DetailView(
                    aq.get('display'),
                    this.get('config'),
                    this.get('backend'),
                    aq.get('constants')));
        },
        Popup: {
            module: require('dianping/views/common/popup'),
            dependencies: display
        }
    });
});