define('dianping/config', [], function () {
    'use strict';
    
    return {
        cacheData: {},
        //NOTE: name for international, search params only support Chinese
        //So in menu page,you will find "value:{category: this.config.CATEGORIES[0].params}"
        //Before you modify, please check 
        CATEGORIES: [
                     {
                         name: 'category_names_cate',
                         params:"美食"
                     },
                     {
                         name: 'category_names_entertainment',
                         params:"休闲娱乐"
                     },
                     {
                         name: 'category_names_shopping',
                         params:"购物"
                     },
                     {
                         name: 'category_names_movie',
                         params:"电影院"
                     },
                     {
                         name: 'category_names_beauty',
                         params:"丽人"
                     },
                     {
                         name: 'category_names_marry_goods',
                         params:"结婚"
                     },
                     {
                         name: 'category_names_kid_goods',
                         params:"亲子"
                     },
                     {
                         name: 'category_names_materials',
                         params:"家居建材"
                     },
                     {
                         name: 'category_names_sports_fitness',
                         params:"运动健身"
                     },
                     {
                         name: 'category_names_hotel',
                         params:"酒店"
                     },
                     {
                         name: 'category_names_automotive',
                         params:"汽车服务"
                     },
                     {
                         name: 'category_names_living_services',
                         params:"生活服务"
                     }
                     ],
        linesPerPage: 5,
        listItemId: 101,
        policyHistory: {}
    };
});