define('dianping/router', ['aq/eventEmitter'], function (EventEmitter) {
	'use strict';

	return EventEmitter.extend({

		init: function (options) {

		    this.routes = {
				'show:menu': this.goToMenu,
				'show:categories': this.goToCategories,
				'show:results': this.goToResultsList,
				'show:favorites': this.goToFavorites,
				'show:detail': this.goToDetail,
				'show:popup': this.goToPopup,
				'close': this._onClose,
				'suspend': this._onSuspend
		    };

		    this.dic = options.dic;
		    this.backend = options.backend;
		},

		start: function () {
		    //TODO bind here at least navigation events
		    this.goToMenu();
		},

		navigate: function (name) {
		    if (this.routes[name]) {
			this.stopListening();
			this.routes[name].apply(this, Array.prototype.slice.call(arguments, 1));
		    }
		},

		/**
		 * To be called from outside (from appEntry point)
		 */
		suspend: function () {
		    this._unbindErrorEvents();
		    this.stopListening();
		},

		/**
		 * To be called from outside (from appEntry point)
		 */
		close: function () {
		    this.suspend();
		},

		/**
		 * Unbind events to avoid triggering while running another application
		 * @private
		 */
		_unbindErrorEvents: function () {
		    //this.backend.off('show:errorStatus');
		    //this.backend.commandControl.off('error');
		},

		_onSuspend: function () {
		    this.trigger('suspend');
		},

		_onClose: function () {
		    this.trigger('close');
		},

		onError: function () {
		    //FIXME implement
		},

		goToMenu: function () {
		    var controller = this.dic.get('controller/menu');

		    this.listenTo(controller, 'all', this.navigate);
		    controller.start();
		},

		goToCategories: function (data) {
		    var controller = this.dic.get('controller/categories');
		    this.listenTo(controller, 'all', this.navigate);
		    controller.start(data);
		},
		
		goToFavorites: function () {
		    var controller = this.dic.get('controller/favorites');
		    this.listenTo(controller, 'all', this.navigate);
		    controller.start();
		},
		
		goToResultsList: function (data) {
		    var controller = this.dic.get('controller/results');
		    this.listenTo(controller, 'all', this.navigate);
		    controller.start(data);
		},

		goToDetail: function (data) {
		    var controller = this.dic.get('controller/detail');
		    this.listenTo(controller, 'all', this.navigate);
		    controller.start(data);
		},

		goToPopup: function () {
		    var controller = this.dic.get('controller/base');
		    this.listenTo(controller, 'all', this.navigate);
		    controller.start();
		}
	});

});