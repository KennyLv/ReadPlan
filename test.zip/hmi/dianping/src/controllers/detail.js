define('dianping/controllers/detail', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    
    return EventEmitter.extend({

        init: function (options) {
            this.view = options.detailScreen;
            this.config=options.config;
            this.policy = options.policy;
        },
        
        start: function (data) {
            this.config.cacheData.POI.resultsPageNo=data.resultsPageNo;
            this.showDetailScreen(data);
            this.startListening();
        },
        
        startListening: function () {
            this.stopListening();
            this.listenTo(this.view, this.view.events.goBack, this.goBack);
            this.listenTo(this.view, this.view.events.goToCall, this.goToCall);
            this.listenTo(this.view, this.view.events.goToNavigate, this.goToNavigate);
            this.listenTo(this.view, this.view.events.goToKeyBoard, this.goToKeyBoard);
            this.listenTo(this.view, this.view.events.showDetailScreen, this.showDetailScreen);
        },
        
        suspend: function() {
            this.stopListening();
        },
        
        onSuspend: function () {
            this.trigger('suspend');
        },
        
        close: function() {
            this.stopListening();
        },
        
        showDetailScreen: function (data) {
            this.config.data = data;
            var template = this.view.generateTemplate(data);
            template = this.policy.generateTemplateWithPolicy(template);
            this.view.render(template);
        },
        
        goBack: function() {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:detail';
                this.config.policyHistory.data = this.config.data;
                this.trigger('show:popup');
            }else{
                this.trigger('show:results',this.config.cacheData.POI);
            }
        },
        
        goToCall: function(data) {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:detail';
                this.config.policyHistory.data = this.config.data;
                this.trigger('show:popup');
            }else{
                console.log("goToCall===============",data);
            }
        },

        goToNavigate: function(data) {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:detail';
                this.config.policyHistory.data = this.config.data;
                this.trigger('show:popup');
            }else{
                console.log("goToNavigate===============",data);
            }
        },
        
        goToKeyBoard: function() {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:detail';
                this.config.policyHistory.data = this.config.data;
                this.trigger('show:popup');
            }else{
                console.log("Go to keyword,then return keyword. NOTE:&");
                var datas={"keyword":"永和"};
                this.trigger('show:results',datas);
            }
        },
    });
});