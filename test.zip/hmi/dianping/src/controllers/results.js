define('dianping/controllers/results', ['aq/eventEmitter','aq/utils'], function (EventEmitter) {
	'use strict';

	return EventEmitter.extend({

		init: function (options) {
		    this.view = options.view;
		    this.backend = options.backend;
		    this.config=options.config;
		    this.Popup = options.popup;
		    this.policy = options.policy;
		},

		start: function (data) {
		    this.showResultsScreen(data);
		    this.startListening();
		},

		startListening: function () {
		    this.stopListening();
		    this.listenTo(this.view, this.view.events.goBack, this.goBack);
		    this.listenTo(this.view, this.view.events.goToResultsList, this.goToResultsList);
		    this.listenTo(this.view, this.view.events.goToResultDetail, this.goToResultDetail);
		    this.listenTo(this.view, this.view.events.goToFilterByCategory, this.goToFilterByCategory);
		    this.listenTo(this.view, this.view.events.scrollDown, this.scrollDown);
		    this.listenTo(this.view, this.view.events.scrollUp, this.scrollUp);
		    this.listenTo(this.view, this.view.events.showScreen, this.showScreen);
		},

		suspend: function() {
		    this.stopListening();
		},

		onSuspend: function () {
		    this.trigger('suspend');
		},

		close: function() {
		    this.stopListening();
		},

		showResultsScreen: function (data) {
		    /*
		    //for policy
		    this.config.data = data;
		    //filter category
		    if(data.childCategory){
			var datas=this.getDatasByCCategory(data.childCategory);
			this.getPageData(datas,this.config.cacheData.POI);
		    }else{
			this.config.cacheData.POI=data;
			var category=data.category?data.category:'';
			var query=data.query?data.query:'';
			var latitude=this.config.cacheData.latitude;
			var longitude=this.config.cacheData.longitude;
			var sort=data.sort?data.sort:0;
			//ToDo:Need to handle get current location.
			var requestData={
				"category":category,
				"latitude":latitude,
				"longitude":longitude,
				"query": query,
				"sort": sort
			};*/
			/*var result=this.backend.getSearchResultsList(requestData);
			result.done(function (resp){
			    var datas=resp.pois ? resp.pois : {};
			    var _datas = datas.slice(0);
			    _datas=_datas.map(function(content){
				content.avgRating=(_.random(0,10)/2.0);
				return content;
			    });
			    if(sort===1){
				datas = _datas.sort(this.secondSortByDistance);
			    }else{
				datas=_datas;
			    }
			    this.resultsList=datas;
			    this.getPageData(datas,data);
			}.bind(this)).fail(function (data){
			    this.showPopup(data.responseJSON);
			}.bind(this));*/
			
		    this.showScreen(resultsData);
		},
		/*
		getPageData: function(datas,data){
		    var linesPerPage=this.config.linesPerPage;
		    var resultsData={};
		    if(datas.length>0){
			resultsData.currPage=data.resultsPageNo?data.resultsPageNo:1;
			resultsData.totalPage=Math.ceil(datas.length/linesPerPage);
			resultsData.refreshHighlight=data.resultsPageNo?false:true;
			resultsData.up=resultsData.currPage>1?false:true;
			resultsData.down=resultsData.currPage<resultsData.totalPage?false:true;
			resultsData.pageData=datas.slice(
				(resultsData.currPage-1)*5,resultsData.currPage*5);
			resultsData.pageSize=resultsData.pageData.length;
		    }
		    else
		    {
			resultsData.pageSize=0;
			resultsData.currPage=0;
			resultsData.totalPage=0;
			resultsData.up=true;
			resultsData.down=true;
			resultsData.pageData={};
		    }
		    resultsData.category=data.category;
		    resultsData.query=data.query;
		    resultsData.sort=data.sort?data.sort:0;
		    resultsData.backButtonEvent=data.backButtonEvent;
		    this.resultsData=resultsData;
		    this.showScreen(resultsData);
		},*/
		showScreen: function(data){
		    /*
		    this.config.data.resultsPageNo = data.currPage;
		    if(data.refreshHighlight){
			data.refreshHighlight=false;
			this.view.resetHLDatas();
		    }*/
		    var template = this.view.generateTemplate(data);
		    template = this.policy.generateTemplateWithPolicy(template);
		    this.view.render(template);
		},
		retry:function(){
		    this.showResultsScreen(this.config.data);
		},
		goBack: function() {
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			this.config.data.resultsPageNo = 1;
			var categoryPageNo=this.config.cacheData.POI.categoryPageNo;
			if(categoryPageNo){
			    this.trigger(this.config.cacheData.POI.backButtonEvent,categoryPageNo);
			}
			else{
			    this.trigger(this.config.cacheData.POI.backButtonEvent);
			}
		    }
		},

		goToResultsList: function(data){
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			this.showResultsScreen(data);
		    }
		},
		goToResultDetail:function(data){
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			this.trigger('show:detail',data);
		    }
		},
		goToFilterByCategory: function(){
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			var childCategories=this.getChildrenCategories();
			this.trigger('show:childCategories',childCategories);
		    }
		},
		scrollDown: function(){
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			this.scroll('down');
		    }
		},
		scrollUp: function(){
		    if(this.policy.checkClickExceed()){
			this.config.policyHistory.backButtonEvent = 'show:results';
			this.config.policyHistory.data = this.config.data;
			this.trigger('show:popup');
		    }else{
			this.scroll('up');
		    }
		},
		scroll: function(direction){
		    this.stopListening();
		    var resultsData=this.resultsData;
		    if("down"===direction){
			if(resultsData.currPage<resultsData.totalPage){
			    resultsData.currPage=resultsData.currPage+1;
			}
		    }
		    else{
			if(resultsData.currPage>1){
			    resultsData.currPage=resultsData.currPage-1;
			}
		    }
		    resultsData.pageData=this.resultsList.slice(
			    (resultsData.currPage-1)*5,resultsData.currPage*5);
		    resultsData.down=resultsData.currPage<resultsData.totalPage?false:true;
		    resultsData.up=resultsData.currPage>1?false:true;
		    resultsData.pageSize=resultsData.pageData.length;
		    this.resultsData=resultsData;
		    this.showScreen(resultsData);
		    this.startListening();
		},
		secondSortByDistance: function (a,b){
			var diff=b.avgRating-a.avgRating;
			if(diff===0){
			    return a.distance-b.distance;
			}
			else{
			    return diff;
			}
		},
		//get childCategories from interface datas
		getChildrenCategories: function(){
		    var childCategories=[];
		    var _datas=this.resultsList.slice(0);
		    _datas.map(function(content){
			if(content.categories!==null){
			    childCategories=childCategories.concat(content.categories);
			}
		    });
		    childCategories=_.union(childCategories);
		    return childCategories;
		},
		//get Datas from interface datas fitler by selected childCategory
		getDatasByCCategory: function(childCategory){
		    var results=[];
		    var _datas=this.resultsList.slice(0);
		    _datas.map(function(content){
			if(content.categories!==null){
			    var temp=_.intersection(content.categories,[childCategory]);
			    if(temp.length>0){
				results.push(content);
			    }
			}
		    });
		    return results;
		},
		showPopup: function (info) {
		    var popup = new this.Popup(),
			title = info.code,
			text = info.description;
		    popup.render({
				title: title,
				text: text,
				buttons: [popup.buttons.exit,popup.buttons.retry]
		    });
		    
		    this.listenToOnce(popup.display, popup.events.retry, this.retry);
		    this.listenToOnce(popup.display, popup.events.close, this.goBack);
		},

	});
});
