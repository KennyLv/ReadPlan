define('dianping/controllers/menu', ['aq/eventEmitter'], function (EventEmitter) {
	'use strict';
	//    var aq = require('aq/dic');
	return EventEmitter.extend({

		init: function (options) {
		    //text buffer for keyboard search
		    this.buffer = '';
		    this.view = options.menu;
		    this.policy = options.policy;
		    this.config = options.config;
		    this.policy.requestPolicy();
		},

		start: function () {
		    this.showHomeScreen();
		    this.startListening();
		},

		startListening: function () {
		    //this.showHomeScreen();
		    // controls from menu screen
		    this.listenTo(this.view, this.view.events.goToCategories, this.goToCategories);
		    this.listenTo(this.view, this.view.events.goToFavorites, this.goToFavorites);
		    this.listenTo(this.view, this.view.events.goToResultList, this.goToResultList);
		    this.listenTo(this.view, this.view.events.showHomeScreen, this.showHomeScreen);
		},

		suspend: function () {
		    this.stopListening();
		},

		onSuspend: function () {
		    this.trigger('suspend');
		},

		goBack: function () {
		    this.trigger('suspend');
		    this.view.display.resetScreen();
		},

		showHomeScreen: function () {
		    var template = this.view.generateTemplate();
		    template = this.policy.generateTemplateWithPolicy(template);
		    this.view.render(template);
		},


		goToCategories: function () {
		
		    if(this.policy.checkClickExceed()){
				this.config.policyHistory.backButtonEvent = 'show:menu';
				this.config.policyHistory.data = null;
				this.trigger('show:popup');
		    }else{
				this.stopListening();
				this.trigger('show:categories');
		    }
		},
		
		goToResultList: function (data) {
		    if(this.policy.checkClickExceed()){
				this.config.policyHistory.backButtonEvent = 'show:menu';
				this.config.policyHistory.data = null;
				this.trigger('show:popup');
		    }else{
				this.stopListening();
				/*
				//TODO : loading...
				//TODO : start Search ...
				this.trigger('show:search');
				var resp = {
					backButtonEvent:'show:menu',
					query:'美食'
				};
				*/
				this.trigger('show:results', data);
		    }
		},
		
		goToFavorites: function () {
		    if(this.policy.checkClickExceed()){
				this.config.policyHistory.backButtonEvent = 'show:menu';
				this.config.policyHistory.data = null;
				this.trigger('show:popup');
		    }else{
				this.stopListening();
				this.trigger('show:favorites');
		    }
		}
	});
});