define('dianping/controllers/common/base', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({
        init: function (options) {
            this.navigation = options.navigation;
            this.policy = options.policy;
            this.Popup = options.popup;
            this.config = options.config;
        },
        
        start: function () {
            this.showPopup();
            this.startListening();
        },

        startListening: function () {
            this.navigation.on(this.navigation.events.vehicleState, this.onVehicleStateChanged, this);
        },

        showPopup: function () {
            var popup = new this.Popup(),
                text = "Pay attention while you are driving";
            popup.render({
                text: text
            });
        },
        
        onVehicleStateChanged:function (data){
            if(data.state === "stopped"){
                this.policy.setClickCounter(0);
                this.goBack();
            }
        },
        
        goBack: function () {
            var backButtonEvent = this.config.policyHistory.backButtonEvent;
            var data = this.config.policyHistory.data;
            if(data){
                this.trigger(backButtonEvent, data);
            }else{
                this.trigger(backButtonEvent);
            }
        }
    });
});
