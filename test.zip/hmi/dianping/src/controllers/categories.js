define('dianping/controllers/categories', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    
    return EventEmitter.extend({

        init: function (options) {
            this.view = options.categories;
            this.config=options.config;
            this.policy = options.policy;
        },
        
        start: function (para) {
            this.showCategoriesScreen(para);
            this.startListening();
        },
        
        startListening: function () {
            this.stopListening();
            this.listenTo(this.view, this.view.events.goToResultsList, this.goToResultsList);
            this.listenTo(this.view, this.view.events.goBack, this.goBack);
            this.listenTo(this.view, this.view.events.scrollDown, this.scrollDown);
            this.listenTo(this.view, this.view.events.scrollUp, this.scrollUp);
            this.listenTo(this.view, this.view.events.showScreen, this.showScreen);
        },
        
        suspend: function() {
            this.stopListening();
        },
        
        onSuspend: function () {
            this.trigger('suspend');
        },
        
        close: function() {
            this.stopListening();
        },
        
        showCategoriesScreen: function (categoryPageNo) {
            var datas=this.config.CATEGORIES;
            //var linesPerPage=this.config.linesPerPage;
            var categoryData={};
            if(datas.length>0){
                categoryData.currPage=categoryPageNo?categoryPageNo:1;
                /*categoryData.refreshHighlight=categoryPageNo?false:true;
                categoryData.totalPage=Math.ceil(datas.length/linesPerPage);
                categoryData.up=categoryData.currPage>1?false:true;
                categoryData.down=categoryData.currPage<categoryData.totalPage?false:true;*/
                categoryData.pageData=datas.slice((categoryData.currPage-1)*5,categoryData.currPage*5);
                //categoryData.pageSize=categoryData.pageData.length;
            }else{
                /*categoryData.pageSize=0;
                categoryData.currPage=0;
                categoryData.totalPage=0;
                categoryData.up=true;
                categoryData.down=true;
                categoryData.pageData={};*/
            }
            this.categoryData=categoryData;
            this.showScreen(categoryData);
        },
	
        showScreen: function(data){
            /*this.config.currPage = data.currPage;
            if(data.refreshHighlight){
                data.refreshHighlight=false;
                this.view.resetHLDatas();
            }*/
            var template = this.view.generateTemplate(data);
            template = this.policy.generateTemplateWithPolicy(template);
            this.view.render(template);
        },
        goBack: function() {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:categories';
                this.config.policyHistory.data = this.config.currPage;
                this.trigger('show:popup');
            }else{
                this.config.currPage = 1;
                this.trigger('show:menu');
            }
        },
        
        goToResultsList: function(data){
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:categories';
                this.config.policyHistory.data = this.config.currPage;
                this.trigger('show:popup');
            }else{
                data.backButtonEvent = 'show:categories';
                this.trigger('show:results',data);
            }
        },
        scrollDown: function(){
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:categories';
                this.config.policyHistory.data = this.config.currPage;
                this.trigger('show:popup');
            }else{
                this.scroll('down');
            }
        },
        scrollUp: function(){
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:categories';
                this.config.policyHistory.data = this.config.currPage;
                this.trigger('show:popup');
            }else{
                this.scroll('up');
            }
        },
        scroll: function(direction){
            this.stopListening();
            var categoryData=this.categoryData;
            if("down"===direction){
                if(categoryData.currPage<categoryData.totalPage){
                    categoryData.currPage=categoryData.currPage+1;
                }
            }else{
                if(categoryData.currPage>1){
                    categoryData.currPage=categoryData.currPage-1;
                }
            }
            categoryData.pageData=this.config.CATEGORIES.slice(
                    (categoryData.currPage-1)*5,categoryData.currPage*5);
            categoryData.down=categoryData.currPage<categoryData.totalPage?false:true;
            categoryData.up=categoryData.currPage>1?false:true;
            categoryData.pageSize=categoryData.pageData.length;
            this.categoryData=categoryData;
            this.showScreen(categoryData);
            this.startListening();
        }
    });
});