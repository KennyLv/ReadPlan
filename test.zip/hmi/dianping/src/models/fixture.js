define('dianping/models/fixture', [], function () {

	POIS : {
	    "pois": [
			{
			    "name": "���Ǻ����������",
			    "latitude": 31.182503,
			    "longitude": 121.42582,
			    "distance": 179,
			    "reviewCount": 4324,
			    "avgRating": 5.0,
			    "addr": "�������ɽ��·2006��",
			    "tel": "021-64371252",
			    "categories": [
					"��ʽ���",
					"����"
			    ],
			    "photoUrl": "http://i2.dpfile.com/pc/6216d48d7b410f80fe8a14d81d54a8f0(278x200)/thumb.jpg"
			},{
			    "name": "LOFT����",
			    "latitude": 31.182503,
			    "longitude": 121.42582,
			    "distance": 179,
			    "reviewCount": 4324,
			    "avgRating": 5.0,
			    "addr": "�������ɽ��·2006��",
			    "tel": "021-64371252",
			    "categories": [
					"���",
					"����"
			    ],
			    "photoUrl": "http://i2.dpfile.com/pc/6216d48d7b410f80fe8a14d81d54a8f0(278x200)/thumb.jpg"
			}
	    ],
	    "totalCount": 40
	},

	CATEGORIES: [
		{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_cate',
			params:"��ʳ"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_entertainment',
			params:"��������"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_shopping',
			params:"����"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_movie',
			params:"��ӰԺ"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_beauty',
			params:"����"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_marry_goods',
			params:"���"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_kid_goods',
			params:"����"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_materials',
			params:"�Ҿӽ���"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_sports_fitness',
			params:"�˶�����"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_hotel',
			params:"�Ƶ�"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_automotive',
			params:"��������"
		},{
			icon: 'file:///dianping/images/preview-1.png',
			name: 'category_names_living_services',
			params:"�������"
		}
	]

}