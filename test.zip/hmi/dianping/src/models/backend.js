/**
 * dianping model
 * Provide access to Choreo Dianping API.
 */
define('dianping/models/backend', ['shared/baseCloudService','aq/utils'], function (BaseCloudService,utils) {
    'use strict';

    return BaseCloudService.extend({
        
        init: function(choreo, config) {
            this._super(choreo, '1.0');

            this.appName = 'dianping';
            
            this.config = config;
        },
        
        getImagesFromCache: function(cache, userImgList, callback){
              var _cache = cache || {};
              var filterd = userImgList.filter(function(v){
                  return utils.getImageFromCache(_cache, v) ? false :true;
              });
              var self = this;
              filterd = _.uniq(filterd);
              if (filterd.length>0) {
                  return $.when(this.choreo.getExternalImagesByUrl(filterd, true))
                  .then(function (userImgs) {
                      _.each(filterd, function(imgUrl, v){
                          utils.storeImageToCache(_cache, imgUrl, userImgs[v]);
                      });
                      return callback(self.matchUpCachedData(_cache, userImgList));
                  });
              } else {
                  var dtd = $.Deferred();
                  dtd.resolve(callback(self.matchUpCachedData(_cache, userImgList)));
                  return dtd.promise();
              }
        },
        
        matchUpCachedData: function(cache, images){
                var result={};
              _.each(images, function(v){
                  var  val = utils.getImageFromCache(cache, v);
                  if (val) {
                      result[v]=val;
                  } 
              });
              return result;
        },
        
        getDataFromCache: function(cache, direction){
              var chachedData;
              var linesPerPage = this.appConfig.linesPerPage;
              if ('up' === direction) {
                //code
                chachedData = cache.data.slice(
                  (cache.pageNumber-2)*linesPerPage,
                  (cache.pageNumber-1)*linesPerPage
                );
                if (chachedData.length>0) {
                  cache.pageNumber--;
                }
              } else {
                chachedData = cache.data.slice(
                  (cache.pageNumber)*linesPerPage,
                  (cache.pageNumber+1)*linesPerPage
                );
                if (chachedData.length>0) {
                  cache.pageNumber++;
                }
              }
              
              return chachedData;
        },

        /**
         * Get all nearby Dianping objects by category
         *
         * @param  {number} categoryId
         *
         * @return {jQuery.Deferred}
         */
        getSearchResultsList: function(requestData) {
               var latitude=this.config.cacheData.latitude;
               var longitude=this.config.cacheData.longitude;
               latitude=latitude?latitude:31.98081;
               longitude=longitude?longitude:118.764252;
               var params={
                       "latitude":latitude,
                       "longitude":longitude,
                       "pageSize": 20,
                       "page": 1,
                       "sort": requestData.sort
               };
               if(requestData.category){
                   params.category=requestData.category;
               }
               else if(requestData.query){
                   params.query=requestData.query;
               }
               params = $.param(params); 
               return this.sendRequest('/search?'+params);
            }
    });
});