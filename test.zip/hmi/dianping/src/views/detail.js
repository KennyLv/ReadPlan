define('dianping/views/detail', ['dianping/views/common/baseView'], function (View) {
    'use strict';

    return View.extend({
        events: {
            goBack: 'goBack',
            onSuspend: 'onSuspend',
            goToCall:'goToCall',
            goToNavigate:'goToNavigate',
            goToKeyBoard:'goToKeyBoard',
            seekUp: 'seekUp',
            seekDown:"seekDown",
            showDetailScreen:'showDetailScreen'
        },

        images: {
            surface: 'file:///dianping/images/black-bg.png',
            back: 'file:///dianping/images/buttons/back.png',
            scrollUp: 'file:///dianping/images/buttons/scroll-up.png',
            scrollDown: 'file:///dianping/images/buttons/scroll-down.png',
            stars: {
                    "0": "file:///dianping/images/ratings/0.png",
                    "0.5": "file:///dianping/images/ratings/0.png",
                    "1": "file:///dianping/images/ratings/1.png",
                    "1.5": "file:///dianping/images/ratings/1.5.png",
                    "2": "file:///dianping/images/ratings/2.png",
                    "2.5": "file:///dianping/images/ratings/2.5.png",
                    "3": "file:///dianping/images/ratings/3.png",
                    "3.5": "file:///dianping/images/ratings/3.5.png",
                    "4": "file:///dianping/images/ratings/4.png",
                    "4.5": "file:///dianping/images/ratings/4.5.png",
                    "5": "file:///dianping/images/ratings/5.png"
            },
            logo: "file:///dianping/images/logo.png"
        },

        init: function (display, config, backend,constants) {
            this.template = {};
            this.display = display;
            this.backend = backend;
            this.constants = constants;
            this._super(config);
            if (this.baseEvents) {
                this.events = _.extend(this.events, this.baseEvents);
            }
            this.hl_button_index = -1;
        },


        render: function (template) {
            this.template = template;
            this.start();
            this.loadingImage(this.detailData);
        },

        start: function () {
            this.template.ignorePartialUpdate = true;
            this.display.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

        generateTemplate: function (data) {
            this.detailData=data;
            data=data.detail;
            var resp= {
                    templateId: 'Template6',
                    backgroundImage: this.images.surface,
                    loadingType: 3,
                    templateContent: {
                        title: 'Detail',
                        img01: {
                            image:this.images.logo,
                            tag:this.constants.POLICY_ACTIONS.IMAGE_POI_ICON
                        },
                        text01: {
                            text:data.name,
                            tag:this.constants.POLICY_ACTIONS.TEXT_POI_NAME
                        },
                        line02: {
                            text: data.reviewCount+"条点评",
                            image: this.getRatingsImage(data.avgRating),
                            tag:this.constants.POLICY_ACTIONS.TEXT_SHORT_DESCRIPTION
                        },
                        text03: {
                            text:this.getHandledDistance(data.distance)+"\n"+data.tel+'\n'+data.addr,
                            tag:this.constants.POLICY_ACTIONS.TEXT_LONG_DESCRIPTION
                        }
                    }
            };
            resp.templateContent.buttons=this.getButtons(data.tel,data.addr);
            return resp;
        },
        
        loadingImage: function (data) {
            var cache = this.config.cacheData.dianPingImages || {};
            this.config.cacheData.templateId = this.template.templateId;
            this.config.cacheData.data = data;
            $.when(this.backend.getImagesFromCache(cache,[data.photoUrl],function(image){
                var photoUrl=data.photoUrl;
                if(image[photoUrl]){
                    this.template.templateContent.img01.image=image[photoUrl];
                }
          }.bind(this))).then(function () {
              if(this.template.templateId === this.config.cacheData.templateId &&
                      data === this.config.cacheData.data){
                  this.start();
              }
          }.bind(this));
        },
        
        getHandledDistance: function(distance){
            if(distance<1000){
                return distance+"m";
            }
            else{
                return (distance/1000.0).toFixed(2)+"km";
            }
        },
        getRatingsImage: function (rating) {
            return this.images.stars[rating];
        },
        
        getButtons: function (phone,address) {
            var respButtons = {
                1: this.getBackButton(),
                2: this.getCallButton(phone),
                3: this.getNavigateButton(address),
                5: this.getScrollUpButton(),
                6: this.getScrollDownButton()
            };
            var buttons = [1,2,3,5,6];
            if(this.hl_button_index !== -1){
                var buttonIndex = buttons[this.hl_button_index];
                respButtons[buttonIndex].highlight = true;
            }
            return respButtons;
        },
        
        getBackButton: function (){
            return {
                image: this.images.back,
                action: this.events.goBack
            };
        },

        getCallButton: function(phone){
            return {
                text: "Call",
                action: this.events.goToCall,
                value: phone,
                stateEnabled: phone? true:false
            };
        },
        
        getNavigateButton: function(address){
            return {
                text: "Navigate",
                action: this.events.goToNavigate,
                value: address,
                stateEnabled: address? true:false
            };
        },
        
        getScrollUpButton: function () {
            return {
                image: this.images.scrollUp,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_UP
            };
        },
        getScrollDownButton: function () {
            return {
                image: this.images.scrollDown,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_DOWN
            };
        },
        goBack: function () {
            this.trigger(this.events.goBack);
        },
        
        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },
        goToCall: function(data){
            if(data&&data.value.length>0){
                var datas=data.value.split(',');
                var temp=datas[0];
                var phone=temp.replace(/[^0-9]/ig,"");
                this.trigger(this.events.goToCall,phone);
            }
        },
        goToNavigate: function(data){
            this.trigger(this.events.goToNavigate,data.value);
        },
        goToKeyBoard: function(){
            this.trigger(this.events.goToKeyBoard);
        },
        seekUp: function () {
            if(this.hl_button_index > 0){
                this.hl_button_index = this.hl_button_index - 1;
                this.trigger(this.events.showDetailScreen,this.detailData);
            }
        },
         
        seekDown: function () {
            if(this.hl_button_index < 5){
                this.hl_button_index = this.hl_button_index + 1;
                this.trigger(this.events.showDetailScreen,this.detailData);
            }
        }
    });
});