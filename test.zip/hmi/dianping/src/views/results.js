define('dianping/views/results', ['dianping/views/common/baseView'], function (View) {
    'use strict';

    return View.extend({
        events: {
            goBack: 'goBack',
            onSuspend: 'onSuspend',
            back : 'goBack',
            call:'call',
            addToFavorite:'addToFavorite',
            scrollDown: 'scrollDown',
            scrollUp: 'scrollUp',
            seekUp: 'seekUp',
            seekDown:"seekDown",
            showScreen:'showScreen'
        },

        images: {
            surface: 'file:///dianping/images/black-bg.png',
            back: 'file:///dianping/images/buttons/back.png',
            scrollUp: 'file:///dianping/images/buttons/scroll-up.png',
            scrollDown: 'file:///dianping/images/buttons/scroll-down.png',
            logo:'file:///dianping/images/logo.png',
            stars: {
                "0": "file:///dianping/images/ratings/0.png",
                "0.5": "file:///dianping/images/ratings/0.png",
                "1": "file:///dianping/images/ratings/1.png",
                "1.5": "file:///dianping/images/ratings/1.5.png",
                "2": "file:///dianping/images/ratings/2.png",
                "2.5": "file:///dianping/images/ratings/2.5.png",
                "3": "file:///dianping/images/ratings/3.png",
                "3.5": "file:///dianping/images/ratings/3.5.png",
                "4": "file:///dianping/images/ratings/4.png",
                "4.5": "file:///dianping/images/ratings/4.5.png",
                "5": "file:///dianping/images/ratings/5.png"
            }
        },

        init: function (display, config,backend,constants) {
            this.template = {};
            this.display = display;
            this.constants = constants;
            this._super(config);
            if (this.baseEvents) {
                this.events = _.extend(this.events, this.baseEvents);
            }
            this.backend = backend;
            this.resetHLDatas();
        },


        render: function (template) {
            this.template=template;
            this.start();
        },

        start: function () {
            if(this.resultsData.pageData.length>0){
                this.loadingLogos(this.resultsData);
            }
            this.template.ignorePartialUpdate = true;
            this.display.updateScreen(this.template);
            this.startListening();
        },
	
        goBack: function () {
            this.trigger(this.events.goBack);
        },
        
        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },
	

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

        generateTemplate: function (data) {
            this.resultsData=data;
            return {
                templateId: 'vp2c-9',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: data.query?data.query:data.category,
                    list: this.getItems(data),
                    buttons: this.getButtons(data)
                }
            };
        },
        
        loadingLogos:function(data){
            this.config.cacheData.dianPingImages = this.config.cacheData.dianPingImages || {};
            var cache = this.config.cacheData.dianPingImages || {};
            this.config.cacheData.templateId = this.template.templateId;
            this.config.cacheData.data = data;
            data.pageData.map(function (content,key) {
                var logo=cache[content.photoUrl];
                if(typeof(logo)==='undefined'){
                    $.when(this.backend.getImagesFromCache(cache,[content.photoUrl],function(logo){
                          var photoUrl=data.pageData[key].photoUrl;
                          if(logo[photoUrl]){
                              this.template.templateContent.list[key].image1.image=logo[photoUrl];
                          }
                    }.bind(this))).then(function () {
                        if(this.template.templateId === this.config.cacheData.templateId &&
                                data === this.config.cacheData.data){
                            this.start();
                        }
                    }.bind(this));
                }
            }.bind(this));
        },
        
        getItems: function(data){
            if(data.pageData.length>0){
                var resp;
                var cache = this.config.cacheData.dianPingImages || {};
                var items = data.pageData.map(function(content, key){
                    var logo=cache[content.photoUrl];
                    resp = {
                        text: {
                            text:content.name,
                            tag:this.constants.POLICY_ACTIONS.TEXT_POI_NAME
                        },
                        image1: {
                            image:(logo?logo:this.images.logo),
                            tag:this.constants.POLICY_ACTIONS.IMAGE_POI_ICON
                        },
                        text2:{
                            text:this.getHandledDistance(content.distance),
                            tag:this.constants.POLICY_ACTIONS.TEXT_DISTANCE
                        },
                        image2:{
                            image:this.getRatingsImage(content.avgRating),
                            tag:this.constants.POLICY_ACTIONS.IMAGE_RATINGS
                        },
                        action: this.events.goToResultDetail,
                        value: content
                    };
                    if(key===this.hl_list_index){
                        resp.highlight = true;
                    }
                    return resp;
                }.bind(this));
                return items;
            }
            else{
                return [{text: {text:$.t('notice.no_results')}}];
            }
        },
        
        getHandledDistance: function(distance){
            if(distance<1000){
                return distance+"m";
            }
            else{
                return (distance/1000.0).toFixed(2)+"km";
            }
        },
        
        getRatingsImage: function (rating) {
            return this.images.stars[rating];
        },
        getButtons: function (data) {
            var respButtons = {
                1: this.getBackButton(),
                2: this.getFitlerByCategory(),
                3: this.getSortByButton(data,0),
                4: this.getSortByButton(data,1),
                5: this.getScrollUpButton(data.up),
                6: this.getScrollDownButton(data.down),
            };
            var buttons = [1,2,3,4,5,6];
            if(this.hl_button_index !== -1){
                var buttonIndex = buttons[this.hl_button_index];
                respButtons[buttonIndex].highlight = true;
            }
            return respButtons;
        },
        
        getBackButton: function (){
            return {
                image: this.images.back,
                action: this.events.goBack
            };
        },

	
        getScrollUpButton: function (disableScrollUp) {
            return {
                image: this.images.scrollUp,
                text: "Up", 
                action: "scrollUp",
                stateEnabled: disableScrollUp? false : true,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_UP
            };
        },
	
        getScrollDownButton: function (disableScrollDown) {
            return {
                image: this.images.scrollDown,
                text: "Down",
                action: "scrollDown",
                stateEnabled: disableScrollDown? false : true,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_DOWN
            };
        },
	
        scrollDown: function(){
            this.resetHLDatas();
            this.trigger(this.events.scrollDown);
        },
        
        scrollUp: function(){
            this.resetHLDatas();
            this.trigger(this.events.scrollUp);
        },
	
        seekUp: function () {
            var resultsData= this.resultsData;
            if(this.hl_type ==='button'){
                //into list
                if(this.hl_button_index===0){
                    if(resultsData.totalPage>0){
                        this.hl_type ='list';
                        this.hl_button_index =-1;
                        this.hl_list_index = resultsData.pageSize-1;
                        this.trigger(this.events.showScreen,resultsData);
                    }
                }
                else{
                    this.hl_button_index = this.hl_button_index - 1;
                    this.trigger(this.events.showScreen,resultsData);
                }
               
            }
            //into previous page
            else if(this.hl_list_index===0&&resultsData.currPage>1)
            {
                 this.trigger(this.events.scrollUp);
                 this.hl_type = "list";
                 this.hl_button_index = -1;
                 this.hl_list_index = this.config.linesPerPage-1;
                 resultsData=this.resultsData;
                 this.trigger(this.events.showScreen,resultsData);
            }
            else
            {
                if(this.hl_list_index>0){
                    this.hl_list_index = this.hl_list_index - 1;
                    this.trigger(this.events.showScreen,resultsData);
                }
            }
        },
        seekDown: function(){
            var resultsData= this.resultsData;
            //last button can't render
            if(this.hl_button_index<5){
                if(this.hl_type ==='list'){
                    if(resultsData.totalPage===0){
                        this.hl_list_index = -1;
                        this.hl_type = 'button';
                        this.hl_button_index = 0;
                    }
                    else if(resultsData.currPage===resultsData.totalPage){
                        //Is the last list item
                        if(this.hl_list_index===(resultsData.pageSize-1)){
                            this.hl_list_index = -1;
                            this.hl_type = 'button';
                            this.hl_button_index = 0;
                        }
                        else
                        {
                            this.hl_list_index = this.hl_list_index+1;
                        }
                    }
                   //Into the next page
                    else if(this.hl_list_index===(this.config.linesPerPage-1)){
                        this.trigger(this.events.scrollDown);
                        this.hl_type = "list";
                        this.hl_list_index = 0;
                        this.hl_button_index = -1;
                    }
                    else
                    {
                        this.hl_list_index = this.hl_list_index+1;
                    }
                    
                }else{
                    this.hl_button_index = this.hl_button_index + 1;
                }
                this.trigger(this.events.showScreen,resultsData);
            }
        }
    });
});