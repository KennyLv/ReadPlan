define('dianping/views/categories', ['dianping/views/common/baseView'], function (View) {
    'use strict';

    return View.extend({
        events: {
            goBack: 'goBack',
            back : 'goBack',
            onSuspend: 'onSuspend',
            goToResultsList:'goToResultsList',
            scrollDown: 'scrollDown',
            scrollUp: 'scrollUp',
            seekUp: 'seekUp',
            seekDown:"seekDown",
            showScreen:'showScreen'
        },

        images: {
                surface: 'file:///dianping/images/black-bg.png',
                back: 'file:///dianping/images/buttons/back.png',
                scrollUp: 'file:///dianping/images/buttons/scroll-up.png',
                scrollDown: 'file:///dianping/images/buttons/scroll-down.png',
                logo0: 'file:///dianping/images/32x32.png',
                logo1: 'file:///dianping/images/logo.png',
                logo2: 'file:///dianping/images/logo.png',
                logo3: 'file:///dianping/images/logo.png',
                logo4: 'file:///dianping/images/logo.png',
                logo5: 'file:///dianping/images/logo.png',
                logo6: 'file:///dianping/images/logo.png',
                logo7: 'file:///dianping/images/logo.png',
                logo8: 'file:///dianping/images/logo.png',
                logo9: 'file:///dianping/images/logo.png',
                logo10: 'file:///dianping/images/logo.png',
                logo11: 'file:///dianping/images/logo.png',
                logo12: 'file:///dianping/images/logo.png'
        },

        init: function (display, config, constants) {
            this.template = {};
            this.display = display;
            this.constants =constants;
            this._super(config);
            if (this.baseEvents) {
                this.events = _.extend(this.events, this.baseEvents);
            }
            this.resetHLDatas();
        },


        render: function (template) {
            this.template=template;
            this.config.cacheData.templateId=this.template.templateId;
            this.start();
        },

        start: function () {
            this.template.ignorePartialUpdate = true;
            this.display.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

        generateTemplate: function (data) {
            this.categoryData=data;
            return {
                templateId: 'vp2c-3',
                backgroundImage: this.images.surface,
                templateContent: {
                    title: $.t('categories'),
                    list: this.getItems(data.pageData)
                }
            };
        },
        
        getItems: function(pageData){
          var items=  pageData.map(function(data,key){
              var resp= {
                    text: $.t(data.name),
                    /*image1: {
                        image:this.images["logo0"],
                        tag:this.constants.POLICY_ACTIONS.IMAGE_POI_ICON
                    },*/
		             image1: this.images["logo0"],
                    action: this.events.goToResultsList,
                    /*value: {
                          text: data.name,
                          tag:this.constants.POLICY_ACTIONS.TEXT_NAME
                    }*/
                    value: data.name
                };
              return resp;
          }.bind(this));
	  
	  console.log(items);
	  
          return items;
        },
        
        getButtons: function (up,down) {
            var respButtons = {
                1: this.getBackButton(),
                5: this.getScrollUpButton(up),
                6: this.getScrollDownButton(down),
            };
            var buttons = [1,5,6];
            if(this.hl_button_index !== -1){
                var buttonIndex = buttons[this.hl_button_index];
                respButtons[buttonIndex].highlight = true;
            }
            return respButtons;
        },
        
        getBackButton: function (){
            return {
                image: this.images.back,
                action: this.events.goBack
            };
        },

        getScrollUpButton: function (disableScrollUp) {
            return {
                image: this.images.scrollUp,
                text: "Up",
                action: "scrollUp",
                stateEnabled: disableScrollUp? false : true,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_UP
            };
        },
        getScrollDownButton: function (disableScrollDown) {
            return {
                image: this.images.scrollDown,
                text: "Down",
                action: "scrollDown",
                stateEnabled: disableScrollDown? false : true,
                tag:this.constants.POLICY_ACTIONS.BUTTON_PAGE_DOWN
            };
        },

        goBack: function () {
            this.trigger(this.events.goBack);
        },
        
        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },
        goToResultsList:function(data){
            //before into other page,set pageNo into config for back event to return right 
            var datas={"category":data.value,"categoryPageNo":this.categoryData.currPage};
            this.trigger(this.events.goToResultsList,datas);
        },
        scrollDown: function(){
            this.resetHLDatas();
            this.trigger(this.events.scrollDown);
        },
        
        scrollUp: function(){
            this.resetHLDatas();
            this.trigger(this.events.scrollUp);
        },
        resetHLDatas:function(){
            this.hl_type = "list";
            this.hl_list_index = -1;
            this.hl_button_index = -1;
        },
        seekUp: function () {
            var categoryData= this.categoryData;
            if(this.hl_type ==='button'){
                //into list
                if(this.hl_button_index===0){
                    if(categoryData.totalPage>0){
                        this.hl_type ='list';
                        this.hl_button_index =-1;
                        this.hl_list_index = categoryData.pageSize-1;
                        this.trigger(this.events.showScreen,categoryData);
                    }
                }
                else{
                    this.hl_button_index = this.hl_button_index - 1;
                    this.trigger(this.events.showScreen,categoryData);
                }
               
            }
            //into previous page
            else if(this.hl_list_index===0&&categoryData.currPage>1)
            {
                 this.trigger(this.events.scrollUp);
                 this.hl_type = "list";
                 this.hl_button_index = -1;
                 this.hl_list_index = this.config.linesPerPage-1;
                 categoryData=this.categoryData;
                 this.trigger(this.events.showScreen,categoryData);
            }
            else
            {
                if(this.hl_list_index>0){
                    this.hl_list_index = this.hl_list_index - 1;
                    this.trigger(this.events.showScreen,categoryData);
                }
            }
        },
        seekDown: function(){
            var categoryData= this.categoryData;
            //last button can't render
            if(this.hl_button_index<3){
                if(this.hl_type ==='list'){
                    if(categoryData.totalPage===0){
                        this.hl_list_index = -1;
                        this.hl_type = 'button';
                        this.hl_button_index = 0;
                    }
                    else if(categoryData.currPage===categoryData.totalPage){
                        //Is the last list item
                        if(this.hl_list_index===(categoryData.pageSize-1)){
                            this.hl_list_index = -1;
                            this.hl_type = 'button';
                            this.hl_button_index = 0;
                        }
                        else
                        {
                            this.hl_list_index = this.hl_list_index+1;
                        }
                    }
                   //Into the next page
                    else if(this.hl_list_index===(this.config.linesPerPage-1)){
                        this.trigger(this.events.scrollDown);
                        this.hl_type = "list";
                        this.hl_list_index = 0;
                        this.hl_button_index = -1;
                    }
                    else
                    {
                        this.hl_list_index = this.hl_list_index+1;
                    }
                    
                }else{
                    this.hl_button_index = this.hl_button_index + 1;
                }
                this.trigger(this.events.showScreen,categoryData);
            }
        }
        
    });
});