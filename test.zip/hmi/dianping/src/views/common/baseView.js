define('dianping/views/common/baseView', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({
        baseEvents: {
            enter: 'enter'
        },

        init: function (config) {
            this.template = {};
            this.config = config;
        },
        
        enter: function () {
            var lists = this.template.templateContent.list,
                buttons= this.template.templateContent.buttons || {},
                self = this,
                buttonId;
            if(lists && lists.length > 0){
                lists.map(function(list, key){
                    if(list.highlight){
                        buttonId = self.config.listItemId + key;
                    }
                  });
             }
             
             for(var i in buttons){
                 if(buttons[i].highlight && buttons[i].stateEnabled !==false){
                     buttonId = i;
                 }
             }
            if(buttonId){
                var data = {
                        content: {type:"buttonEvent",
                               data:{
                                buttonId: buttonId,
                                listItemId:0,
                                buttonType:"soft"
                               }
                 }
                };
                window.onNotification(JSON.stringify(data));
            }
        }
    });
});