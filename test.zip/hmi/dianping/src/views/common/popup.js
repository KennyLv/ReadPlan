define('dianping/views/common/popup', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        events: {
            close: 'close',
            retry: 'retry'
        },

        images: {
            close: 'file:///baidu/images/buttons/close.png',
            surface: 'file:///baidu/images/black-bg.png'
        },

        init: function (display) {
            this.initButtons();
            this.template = {};
            this.display = display;
        },

        initButtons: function () {
            this.buttons = {
                exit: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                },
                cancel: {
                    2: {
                        action: this.events.close,
                        text: $.t('buttons.cancel')
                    }
                },
                retry: {
                    2: {
                        action: this.events.retry,
                        text: $.t("buttons.retry")
                    }
                }
            };
        },

        render: function (options) {
            this.text = options.text;
            this.title = options.title;

            this.template = this.generateTemplate(options.buttons);
            this.display.updateScreen(this.template);

        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'Template4-B',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    text: this.text,
                    buttons: this.getButtons(buttons)
                }
            };
        }

    });
});