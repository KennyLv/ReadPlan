define('dianping/views/menu', ['dianping/views/common/baseView'], function (BaseView) {
    'use strict';

    return BaseView.extend({
		events: {
		    showHomeScreen:'showHomeScreen',
		    goToCategories: 'goToCategories',
		    goToFavorites: 'goToFavorites',
		    goToResultList : 'goToResultList',
		    onSuspend: 'onSuspend',
		    seekUp: 'seekUp',
		    seekDown:"seekDown",
		    back : 'goBack'
		},

        images: {
         //TODO
        },

        init: function (display, config,constants) {
            this.template = {};
            this.display = display;
            this.constants = constants;
            this._super(config);
            if (this.baseEvents) {
                this.events = _.extend(this.events, this.baseEvents);
            }
            this.hl_button_index = -1;
        },

        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },

        render: function (template) {
            this.template = template;
            this.config.cacheData.templateId=this.template.templateId;
            this.start();
        },

        start: function () {
            this.display.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

        generateTemplate: function () {
	
			return	{
				templateId: 'vp2c-3',
				backgroundImage: 'file:///templates/images/black-bg.png',
				templateContent: {
				    title: $.t('mainMenu'),
				    list: this.getItems()/*,
				    buttons: $.extend(true, {
						1: {
						    image: 'file:///templates/images/sidebtn_icon-back.png',
						    action: this.events.goBack
						}
				    }, buttons)*/
				}
			};
        },

        getItems: function(){
			return [
				{
					text: $.t('categories'),
					action: this.events.goToCategories
				},{
					text: $.t('favorites'),
					action: this.events.goToFavorites
				},{
					text: this.config.CATEGORIES[0].params,
					action: this.events.goToResultList,
					value: this.config.CATEGORIES[0].name
				},{
					text: this.config.CATEGORIES[1].params,
					action: this.events.goToResultList,
					value: this.config.CATEGORIES[1].name
				}
			];
        },
	
        goToCategories: function () {
            this.trigger(this.events.goToCategories);
        },
	
        goToFavorites: function () {
            this.trigger(this.events.goToFavorites);
        },

        goToResultList: function (data) {
            this.trigger(this.events.goToResultList, data);
        },
	
        seekUp: function () {
            if(this.hl_button_index > 0){
                this.hl_button_index = this.hl_button_index - 1;
                this.trigger(this.events.showHomeScreen);
            }
        },
         
        seekDown: function () {
            if(this.hl_button_index < 7){
                this.hl_button_index = this.hl_button_index + 1;
                this.trigger(this.events.showHomeScreen);
            }
        }
    });
});