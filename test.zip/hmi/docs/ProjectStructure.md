# HMI and Platform project layouts

In order to support different platform some refactoring has been done.  
As a result, `platform` is not a git submodule anymore, but instead a regular directory and part of `hmiapps` project.  
New repository is named `tbp-hmiapps`, where _TBP_ stands for __T__emplate __B__ased __P__latform.


## HMI Applications

HMI Application is an set of JS files which contain only business logic of the application.
All graphics and configs are basically platform dependant, 
thus should not be part of HMI sources, instead they leave inside platform/{PLATFORM}/hmiapps/{APP_NAME} directory, 
see details in the next section.

![HMI Apps + Platform project directory layout](images/hmi_apps_directory_layout.png)  

On the screen shot above one may see new directories layout for HMI application.  
Each application lives in its own directory (just like it was before), e.g.: "pandora", "slacker", "templates".  
There are also common for all application files, those are in __common/__ folder:

![Common model and view](images/common_app_classes.png)

One thing that should be noted though is a __config.js__ file inside the __view__ directory.  
This config files is copied from the platform specific directory.
Basically this file contain some platform specific configuration, like "buttonBrandings", 
more information about this in next sections.  

## Platform

![Structure of directories to customize hmi app for platform specific needs](images/platform_customization_for_apps.png)

Screenshot above shows the layout inside the `platform` directory,
which needed to support customization of each hmi application for each particular platform.  
A customization for `vp4` platform, `pandora` application in particular, is being shown on the picture.

Under customization we assume changing some view or controller, by extending from the base one,
found in the hmi application sources directory.  
So, if you need to overwrite some methods from lets say a `list.js` view file, then you have do next things:  

1. put a file with overrides, e.g. "list.js" into `views` directory
2. extend local `list` module from the base `list` module which you want to overwrite
3. update path to module inside `di.js` with:

```javascript
    List: {
        module: require('pandora/../../platform/vp4/hmiapps/pandora/views/list'),
        dependencies: display
    },
```
where `pandora` is actually a package name defined in `requirejs.config.js` file inside `pandora` app directory. 
    
_What is `di.js` and why is it here?_ one may ask.
This is _Dependency Injection Container_ specifying services used in application.   
It actually should be inside application `src` directory during build process, 
but at the same time `di.js` file can contain paths specific to the platform currently being built.  
This happens when we have to extend some class from base HMI app one. 
That is why `di.js` file is being copied from `platform/{PLATFORM}/hmiapps/{HMI_APP}` directory to the right place.

Next, there is a global for all applications, but specific for particular platform, config file (namely `config.js`).  
In such config file you may keep configs for buttons size or other elements size, for example 'buttonsBranding'.


# Extending HMI Apps functionality
Basically, very often it will require to extend (overwrite) views 
because different platform may require different buttons or changed button location on each screen.
Sometimes though, even controller or model has to be extended.


# Build process
During build process grunt has to build platform first, then each application found in the root directory.
This is done intentionally, because hmi apps depend on platform code.
Before building each application, important files, __di.js__ and hmiapps' __config.js__, 
will be copied from platform specific directory to each application `src` directory.  
Also, static resources, like images and manifest (for Release builds only) will be copied to the __dist/__ directory.
In such way different images for different platforms could be supported.
