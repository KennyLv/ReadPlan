Slacker handset application

- Application wireframes/requirements can be found here - https://airbiq.atlassian.net/wiki/display/SVP2C/VP2C+Slacker+Requirements
- Application images can be found here - https://airbiq.atlassian.net/wiki/display/SVP2C/VPC2+Application+Art

- API documentation can be found here - https://airbiq.atlassian.net/wiki/download/attachments/24215706/Slacker_Airbiquity_Commands%20-%20v8.docx?version=1&modificationDate=1397522767683&api=v2

- 3rd party application can be found here - https://airbiq.atlassian.net/wiki/download/attachments/7504241/SlackerRadio_v5.99.376.rar?api=v2
