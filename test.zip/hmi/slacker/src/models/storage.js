define(['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        storage: {},
        length: 0,

        /**
         *
         * @param item {object}
         * item.trackName
         * item.artistName
         * item.trackID,
         * item.image,
         *
         */
        push: function (item) {
            if (!(item.trackID in this.storage)) {
                item.index = this.length++;
                this.storage[item.trackID] = item;
            }
        },

        clear: function () {
            this.storage = {};
            this.length = 0;
        },

        /**
         * @param trackId
         * @returns trackData that was playing before currently playing track or undefined if no track found
         */
        getPrevious: function (trackId) {
            var prevIndex = this._index(trackId) - 1;
            return _.find(this.storage, function (item) {
                return item.index === prevIndex;
            });
        },


        /**
         * @param trackId
         * @param image - image payload
         */
        setImage: function (trackId, image) {
            if (this.storage[trackId]) {
                this.storage[trackId].image = image;
            }
        },

        /**
         * @param trackId
         * @returns index of currently playing track
         * @private
         */
        _index: function (trackId) {
            return this.storage[trackId] && this.storage[trackId].index;
        }
    });

});