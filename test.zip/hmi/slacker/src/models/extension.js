define(['slacker/models/constants', 'slacker/models/player', 'aq/dic'], function (Constants, Player, aq) {
    'use strict';

    var Logger = aq.get('Logger'),
        logger = new Logger('med', 'WEB_VIEW', '[Slacker]');

    logger.log('Slacker EXTENSION MODEL loaded');

    return Player.extend({

        /**
         * My Music command list
         */
        myMusicCommandList: [
            Constants.API_COMMANDS.GET_RECENTLY_PLAYED,
            Constants.API_COMMANDS.GET_MY_STATIONS,
            Constants.API_COMMANDS.GET_MY_PLAYLISTS,
            Constants.API_COMMANDS.GET_BOOKMARKED_ALBUMS,
            Constants.API_COMMANDS.GET_BOOKMARKED_ARTISTS,
            Constants.API_COMMANDS.GET_BOOKMARKED_STATIONS
        ],

        /**
         * 'Slacker stations' menu item
         */
        slackerStationsList: [],


        /**
         * 'My music' menu item
         */
        myMusicList: [],

        /**
         * Bookmarked Station Set
         * Each element is a an object of view {id: stationId, name: stationName}
         *
         * @var List
         */
        bookmarkedStations: [],

        userSubscriptionLevel: null,

        // workaround is needed for CV-2034
        // TODO remove it once Slacker will implement
        // a proper response handling to HMI
        MAX_INIT_TRIES: 3,
        // workaround is needed for CV-2034
        // TODO remove it once Slacker will implement
        // a proper response handling to HMI
        _initTryCount: 0,

        init: function(options) {
            this._super({constants: Constants});
            this.commandControl = new options.commandControl();
            this.trackStorage = options.trackStorage;

            _.extend(this.events, { onGetSubscriptionLevel:"GetSubscriptionLevel"});
        },

        start: function() {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.commandControl, event, this[method].bind(this));
                }
            }, this);
        },


        sendData: function (dataToSend) {
            var deferred = $.Deferred();

            this.commandControl.sendCommand(dataToSend)
                    .done(function (data) {
                        logger.log('DONE :' + JSON.stringify(data));
                        if (data.success === 'false') {
                            deferred.reject(data);
                            this.handleError(data);
                        } else {
                            deferred.resolve(data);
                        }
                    }.bind(this)).fail(function (data) {
                        deferred.reject(data);
                        this.handleError(data);
                    }.bind(this));

            return deferred;
        },

        close: function() {
            this.stopListening();
        },


        //TODO switch to using msgID
        //fix needed on IOS 3rd party (msgIDs are different now no way to catch error)
        /**
         * @param error {
         *  control: 'command name',
         *  msgID: 'specific error ID',
         *  msg: 'error msg for Slacker'
         * }
         */
        handleError: function(error) {
            // workaround is needed for CV-2034
            // TODO remove it once Slacker will implement
            // a proper response handling to HMI
            if ( !this.isUserRegistered() &&
                (error.msgID === this.ERROR_MSG_IDS.HUP_SYNC_ERROR ||
                error.msgID === this.NOTIFICATIONS.CONNECTION_GEOFENCE ||
                error.error.code === 170000 )){

                if (this._initTryCount < this.MAX_INIT_TRIES) {
                    this._initTryCount++;
                    return;
                }
                else {
                    this._initTryCount = 0;
                }
            }

            switch (true) {
                case (this.API_COMMANDS.SKIP === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.SKIP_LIMIT_ERROR, delay: this.DELAY.SHORT});
                    break;
                case (this.API_COMMANDS.FAVORITE === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.FAVORITE_ERROR});
                    break;
                case (this.API_COMMANDS.UNFAVORITE === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.UNFAVORITE_ERROR});
                    break;
                case (this.API_COMMANDS.GET_SUBSCRIPTION_LEVEL === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.SUBSCRIPTION_ERROR});
                    break;
                case (this.API_COMMANDS.SET_FAVORITE_SONGS === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.NO_FAVORITES_ERROR, delay: this.DELAY.SHORT});
                    break;
                case (this.API_COMMANDS.GET_PLAY_STATE === error.control):
                    error = _.extend(error, {error_code: this.ERRORS.PLAY_STATE_ERROR});
                    break;
                case (error.msgID ===  this.ERROR_MSG_IDS.STATION_NOT_PLAYABLE):
                    error = _.extend(error, {error_code: this.ERRORS.STATION_NOT_PLAYABLE});
                    break;
                case (error.msgID ===  this.ERROR_MSG_IDS.STATION_PENDING_BOOKMARKED):
                    error = _.extend(error, {error_code: this.ERRORS.STATION_PENDING_BOOKMARKED});
                    break;
                case (error.msgID ===  this.ERROR_MSG_IDS.STATION_ALREADY_BOOKMARKED):
                    error = _.extend(error, {error_code: this.ERRORS.STATION_ALREADY_BOOKMARKED});
                    break;
                case (error.msgID ===  this.ERROR_MSG_IDS.NO_TRACK_TO_PAUSE):
                    error = _.extend(error, {error_code: this.ERRORS.NO_TRACK_TO_PAUSE,
                        delay: this.DELAY.SHORT,
                        mainAction: this.goToHomeScreen.bind(this)});
                    break;
                case (''):
                    error = _.extend(error, {error_code: this.ERRORS.SERVICE_UNAVAILABLE});
                    break;

                default:
                    error = _.extend(error, {error_code: this.ERRORS.GENERIC_ERROR});
            }

            this.trigger('error', error);
        },

        getSubscriptionLevel: function () {
            logger.log('Trying to GET_SUBSCRIPTION_LEVEL');
            return this.sendData({
                "control": this.API_COMMANDS.GET_SUBSCRIPTION_LEVEL
            }).done(this.onSubscription.bind(this)
            ).fail(function() {
                // workaround is needed for CV-2034
                // TODO remove it once Slacker will implement
                // a proper response handling to HMI
                if(this._initTryCount < this.MAX_INIT_TRIES) {
                    logger.log('Retrying to GET_SUBSCRIPTION_LEVEL . try # ' + this._initTryCount);
                    this.getSubscriptionLevel();
                }
            }.bind(this));
        },

        onSubscription : function (data) {
            logger.log('RESOLVED :' + JSON.stringify(data));
            this._initTryCount = 0;
            this.userSubscriptionLevel = data.subscriptionLevel;
            this.trigger(this.events.onGetSubscriptionLevel);
        },

        /**
         * User subscription level
         *  -1 – Error (Invalid level)
         *  0 – Anonymous
         *  1 – Free Registered User (Basic)
         *  5 – Plus Registered User
         *  10 – Premium Registered User
         *
         * @returns {boolean}
         */
        isUserRegistered: function () {
            return this.userSubscriptionLevel > 0;
        },

        isPremiumUser: function () {
            return this.userSubscriptionLevel === this.SUBSCRIPTIONLEVELS.PREMIUM;
        },

        isBasicUser: function () {
            return this.userSubscriptionLevel === this.SUBSCRIPTIONLEVELS.BASIC;
        },

        isPlusUser: function () {
            return this.userSubscriptionLevel === this.SUBSCRIPTIONLEVELS.PLUS;
        },

        getStationsList: function () {
            this.sendData({
                "control": this.API_COMMANDS.GET_STATION_LIST
            }).done(this.onStationsList.bind(this));
        },

        onStationsList: function (data) {
            this.processStations(data.stations);
            this.trigger('update:stationsList', this.slackerStationsList);
        },

        processStations: function (stations) {
            this.slackerStationsList = [];
            _.each(stations, function (station) {
                var stationObj =  {},
                    name = Object.keys(station)[0];
                stationObj.name = name;
                stationObj.items = station[name];
                this.slackerStationsList.push(stationObj);
            }, this);
        },

        getAllMyMusicData: function () {
            this.commandControl.when(this.myMusicCommandList).done(this.onAllMyMusicData.bind(this));
        },

        onAllMyMusicData: function () {
            this.trigger("update:myMusicData", _.toArray(arguments));
        }
    });
});
