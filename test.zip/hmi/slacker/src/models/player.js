define(['common/model/model', 'aq/dic'], function (BaseModel, aq) {
    'use strict';

    var ProgressCounter = aq.get('progressCounter'),
        progressCounter = new ProgressCounter();

    return BaseModel.extend({

        /**
         * async events object
         */
        events : {
            'goToHomeScreen':   'goToHomeScreen',
            'TrackStart' :      'onTrackStart',
            'SongRated' :       'onSongRated',
            'CurrentImage':     'onCurrentImageUpdate',
            'OnDeckImage' :     'onNextImageUpdate',
            'image/jpeg' :      'onImagePayload',
            //IOS fix
            'image/jpg' :       'onImagePayload',
            'AsyncMsg' :        'updateTrackData',
            'generic_error' :   'onGenericError',
            'StationBookmarked': 'onStationBookmarked',
            //system events
            'unmute': 'unmute',
            'mute': 'mute'
        },

        playerEvents: {
            play: 'player:Play',
            pause: 'player:Pause',
            update: 'player:Update'
        },

        stationEvents: {
            bookmark: 'station:onBookmark'
        },

        banIds: {
            banTrack:  'bansong',
            banArtist: 'banartist'
        },

        stationData: {},

        init: function(options) {
            this._super(options);
            this.API_COMMANDS = options.constants.API_COMMANDS;
            this.STATION_IMG_SIZE = options.constants.STATION_IMG_SIZE;
            this.PLAYING_STATES = options.constants.PLAYING_STATES;
            this.SUBSCRIPTIONLEVELS = options.constants.SUBSCRIPTIONLEVELS;
            this.SONG_TYPE = options.constants.SONG_TYPE;
            this.SUBSCRIPTIONLEVELS = options.constants.SUBSCRIPTIONLEVELS;
            this.ERRORS = options.constants.ERRORS;
            this.DELAY = options.constants.DELAY;
            this.NOTIFICATIONS = options.constants.ASYNC_NOTIFICATIONS;
            this.ERROR_MSG_IDS = options.constants.ERROR_MSG_IDS;
        },

        getPlayingState: function () {
            return this.sendData({
                "control": this.API_COMMANDS.GET_PLAY_STATE
            }).done(this.onPlayingState.bind(this));
        },


        reset: function () {
            this._data = {};
            this.resetProgressCounter();
            this.trigger('reset');
        },

        /**
         *
         * @param data
         */
        onPlayingState: function (data) {
            //ignore playState === 'error' since it is possible to play another station or event current track
            // on ios trackID may be returned in this data and it is needed for app's start
            this.set({
                playState:  data.playState,
                //Adnroid is sending trackID and ios is sending trackId
                //TODO: remove when Slacker solves the issue
                trackID:    this.get('trackID') ||
                    data.trackID || data.trackId
            });

            this.trigger(this.playerEvents.update);
        },

        /**
         * Setting radio station
         * @param station.id - type of station
         * could be playlist, stations
         */
        setStation: function (station) {
            //setting playlist
            if (station.id.search(/^playlists/) !== -1) {
                return this._setPlayList(station);
            } else {
                //setting any station except playlist
                return this._setStation(station);
            }
        },

        _setStation: function (station) {
            //TODO done and fail
            var data = {
                "control" : this.API_COMMANDS.SET_STATION,
                "id" : station.id
            };

            if (this.STATION_IMG_SIZE) {
                data.stationImgSize = this.STATION_IMG_SIZE;
            }

            return this.sendData(data).done(this.onStationChanged.bind(this, station));
        },

        // TODO: done and fail
        _setPlayList: function (playlist) {
            return this.sendData( {
                "control" : this.API_COMMANDS.SET_PLAYLIST,
                "id" : playlist.id
            }).done(this.onStationChanged.bind(this, playlist));
        },

        onStationChanged: function (station) {
            // Mark station as bookmarked if found in a list of bookmarked stations retrieved on app start
            var isBookmarked = !!_.find(this.bookmarkedStations, function (aStation) {
                return aStation.id === station.id;
            });
            if (this.getStationId() !== station.id) {
                this.reset();
            }
            //update playing state while trying to play the same station which is currently paused
            this.getPlayingState();
            //clear storage on change station to imitate Slacker station playlist
            this.setStationName(station.name);
            this.setStationId(station.id);

            this.set('isBookmarked', isBookmarked);

            this.trackStorage.clear();
        },

        // TODO: done and fail
        setFavoriteSongs: function () {
            return this.sendData({
                "control" : this.API_COMMANDS.SET_FAVORITE_SONGS
            }).done(this.onFavoriteSongs.bind(this));
        },

        onFavoriteSongs: function () {
            this.trackStorage.clear();
            //update playing state while trying to play the same station which is currently paused
            this.getPlayingState();
            //No station name while playing favorite songs
            this.setStationName("Favorite Songs");
        },

        onTrackStart: function (data) {
            // valid only if onDeckImage is set (exception is only first playing song)
            var onDeckImage = this.get('onDeckImage'),
                stationName = this.get('stationName'),
                stationId = this.get('stationId'),
                currentImage = this.get('currentImage'),
                previousBtnClicked = this.get('playPrevious'),
                trackName = this.get('trackName'),
                neededImage = (trackName === data.trackName || _.isUndefined(onDeckImage) ) ?
                    currentImage : onDeckImage;

            if (previousBtnClicked && trackName !== data.trackName) {
                neededImage = "";
            }

            // Mark station as bookmarked if found in a list of bookmarked stations retrieved on app start
            var isBookmarked = !!_.find(this.bookmarkedStations, function (aStation) {
                return aStation.id === stationId;
            });

            // reset previous track data
            this.reset();

            this.set(_.extend(data, {
                playState: this.PLAYING_STATES.PLAY_STATE_PLAYING,
                currentImage: neededImage,
                stationName: stationName,
                stationId: stationId,
                onDeckImage: onDeckImage,
                isBookmarked: isBookmarked
            }));

            // store track info on TrackStart event
            // onDeckImage is current image for all songs except the one which playing first
            //olicensed > 0 indicates that track can be played using trackID attr
            if (this.isSong() && this.get('olicensed') > 0) {
                this.trackStorage.push({
                    artistName: this.get('artistName'),
                    trackName: this.get('trackName'),
                    trackID: this.get('trackID'),
                    image: neededImage
                });
            }

            if (_.isFinite(+data.lengthSecs)) {
                progressCounter.start({
                    elapsedTime: 0,
                    totalTime: data.lengthSecs
                });
            } else {
                this.resetProgressCounter();
            }
        },

        resetProgressCounter : function() {
            progressCounter.reset();
        },


        onSongRated: function (songRating) {
            this.set("rating", songRating.rating);
        },

        /**
         * Song rating
         * @returns Number
         * possible values 0, 100 , -100
         */
        getSongRating: function() {
            return this.get('rating');
        },

        /**
         * Next song image
         * @returns {String | null}
         */
        getOnDeckImage: function () {
            return this.get('onDeckImage') || null;
        },

        /**
         * Current song Image
         * @returns {String|null}
         */
        getCurrentImage: function () {
            return this.get('currentImage') || null;
        },

        /**
         * Song duration
         * @returns {*|number}
         */
        getDuration: function () {
            return progressCounter.getTotalTime() || 0;
        },

        /**
         * Song elapsed time
         * @returns {*|number}
         */
        getElapsedTime: function() {
            return progressCounter.getElapsedTime() || 0;
        },

        /**
         * trigger update:CurrentImage after getting OnDeckImage payload
         * @param imagePayload  - image (base64)
         */
        onImagePayload: function (imagePayload) {
            //todo fix it somehow
            if (this.get('event') === 'CurrentImage') {
                this.set('currentImage', imagePayload);
                this.trackStorage.setImage(this.get('trackID'), imagePayload);
            } else {
                this.set('onDeckImage', imagePayload);
            }
        },

        /**
         * Update track data on AsyncMsg event or process critical notification if it is known
         * trackData {
         *      trackID: number,
         *      positionSecs: number,
         *      lengthSecs: number,
         *      playState: string
         * }
         */
        updateTrackData: function (trackData) {
            if (trackData.msgID in _.invert(this.NOTIFICATIONS)) {
                this._onNotification(trackData);
            } else {
                //TODO trackID is not correct on IOS (remove after fix from 3rd party Slacker)
                //so that not able to play prev song on IOS
                if (trackData.trackID) {
                    if (this.get('trackID')) {
                        delete trackData.trackID;
                    }
                }
                this.set(trackData);
            }

            if (_.isFinite((+trackData.lengthSecs) * (+trackData.positionSecs))) {
                progressCounter.update({
                    elapsedTime: +trackData.positionSecs,
                    totalTime: +trackData.lengthSecs
                });
            }
        },

        isTrackPlayable: function () {
            return +this.get('lengthSecs') > 0 || +this.get('trackID') > 0;
        },

        /**
         * triggering error on critical Slacker notification
         *
         * @param notification {object}
         * notification.msgID - notification msg id (see constants.js)
         *
         * @private
         */
        _onNotification: function (notification) {
            switch (notification.msgID) {
                case (this.NOTIFICATIONS.NO_NETWORK):
                    this.trigger('error', {error_code: this.ERRORS.NETWORK_NOT_AVAILABLE,
                        delay: this.DELAY.SHORT,
                        mainAction: this.getPlayingState.bind(this)});
                    break;
                case (this.NOTIFICATIONS.FAILED_CONNECTION):
                    this.trigger('error', {error_code: this.ERRORS.NETWORK_NOT_AVAILABLE});
                    break;
                case (this.NOTIFICATIONS.CONNECTION_GEOFENCE):
                    if(this.isUserRegistered()) {
                        this.trigger('error', {error_code: this.ERRORS.CONNECTION_GEOFENCE});
                    }
                    break;
                case (this.NOTIFICATIONS.SHARED_ACCOUNT):
                    this.trigger('error', {error_code: this.ERRORS.SHARED_ACCOUNT});
                    break;
                case (this.NOTIFICATIONS.ASYNC_EXHAUSTED):
                    this.trigger('error', {error_code: this.ERRORS.ASYNC_EXHAUSTED,
                        mainAction: this.goToHomeScreen.bind(this)});
                    break;
            }
        },

        /**
         * store CurrentImage event name to wait for payload
         */
        onCurrentImageUpdate: function (data) {
            this.set('event', data.event);
        },

        /**
         * store OnDeckImage event name response to wait for payload
         *
         */
        onNextImageUpdate: function (data) {
            this.set('event', data.event);
        },

        play: function () {
            this.sendData({
                control:  this.API_COMMANDS.PLAY
            }).done(this.onPlayPause.bind(this));
            progressCounter.on();
        },

        pause: function () {
            this.sendData({
                control: this.isLiveStream() ? this.API_COMMANDS.STOP : this.API_COMMANDS.PAUSE
            }).done(this.onPlayPause.bind(this));
            progressCounter.off();
        },

        skip: function () {
            return this.sendData({
                control: this.API_COMMANDS.SKIP
            }).done(this.onSkip.bind(this));
        },

        /**
         *
         * @param data - object
         *
         */
        onSkip: function (data) {
            //todo refactor handle no skips for basic user only including pressing on hard seekUp
            if (this.getSkipsLeft() === 0 && !this.get('canSkip')) {
                data.success = 'false';
                this.handleError(data);
            }
        },

        previous: function () {
            if(this.isPremiumUser()){
                this.sendData({
                    control: this.API_COMMANDS.PREVIOUS
                }).done(this.onPrevious.bind(this));
            }
        },

        onPrevious: function () {
            this.set('playPrevious', true);
        },

        favorite: function (control) {
            this.sendData({
                control: control
            }).done(this.onFavorite.bind(this));
        },

        onFavorite: function () {
            //TODO
            // possible issue: when skip limit reached and you ban the track/artist
            // track can be favorited again without enabling ban artist/tack buttons in popup2
            //
            // possible solution: reset here this._data.trackIsBanned and this._data.artistIsBanned
        },

        bookmark: function () {
            this.sendData({
                control: this.API_COMMANDS.BOOKMARK,
                id: this.getStationId()
            });
        },

        /**
         * Add current station to local cache of bookmarked stations
         *
         * @return void
         */
        addToBookmarkedStations: function () {
            // just construct a simple object
            // which looks like any element of the list returned from call to GetBookmarkedStations Slacker API
            var aStation = {
                id: this.getStationId(),
                name: this.getStationName()
            };
            this.bookmarkedStations.push(aStation);
        },

        unBookmark: function () {
            this.sendData({
                control: this.API_COMMANDS.UNBOOKMARK,
                id: this.getStationId()
            });
        },

        /**
         * Re-writes a list of bookmarked stations by filtering out a station which has been unbookmarked
         *
         * @param stationId {Integer}
         *
         * @return void
         */
        removeFromBookmarkedStations: function (stationId) {
            this.bookmarkedStations = _.filter(this.bookmarkedStations, function (aStation) {
                return aStation.id !== stationId;
            });
        },

        onStationBookmarked: function (content) {
            this.set('isBookmarked', content.bookmarked && content.bookmarked === "true");

            // Update local storage of bookmarked stations
            if (this.isBookmarked()) {
                this.addToBookmarkedStations();
            } else {
                this.removeFromBookmarkedStations(this.getStationId());
            }

            this.trigger(this.stationEvents.bookmark);
        },

        isBookmarked: function () {
            return !!this.get('isBookmarked');
        },

        /**
         * Is used only once on the app start and track is playing (there is no track data provided)
         */
        getTrackInfo: function () {
            this.sendData({
                control: this.API_COMMANDS.GET_CURRENT_TRACK_INFO
            }).done(this.onTrackInfo.bind(this));
        },

        onTrackInfo: function (data) {
            if (data.trackID) {
                data.songType = 'song';
            }
            this.set(data);
        },

        /**
         * @param control - banTrack or BanArtist
         */
        ban: function (control) {
            return this.sendData({control: control}
                ).done(this.onBanSuccess.bind(this)
                ).fail(this.handleError.bind(this));
        },

        onBanSuccess: function (data) {
            var banId = data.control.toLowerCase();
            if (banId === this.banIds.banTrack) {
                this._data.trackIsBanned = banId;
            }
            else if (banId === this.banIds.banArtist) {
                this._data.artistIsBanned = banId;
            }
            else {
                throw new Error('[SLACKER][MODEL][PLAYER] Unknow banId passed');
            }
        },

        playPrevTrack: function () {
            var prevTrack = this.getPrevSong();

            return this.sendData({
                control: this.API_COMMANDS.PLAY,
                trackID: prevTrack.trackID
            }).done(function () {
                    this.set('onDeckImage', prevTrack.image);
                }.bind(this));
        },

        getPrevSong: function () {
            return this.trackStorage.getPrevious(this.get('trackID'));
        },

        /**
         * @param data
         * data.control 'Play' or 'Pause'
         */
        onPlayPause: function (data) {
            this.set({
                'playState': (data.control === this.API_COMMANDS.PAUSE || data.control === this.API_COMMANDS.STOP) ?
                    this.PLAYING_STATES.PLAY_STATE_PAUSED :
                    this.PLAYING_STATES.PLAY_STATE_PLAYING
            });
        },

        isPlaying: function ()  {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_PLAYING;
        },

        isPaused: function () {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_PAUSED;
        },

        isError: function () {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_ERROR;
        },

        isTransitioning: function () {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_TRANSITIONING;
        },

        isInitializing: function () {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_INITIALIZING;
        },

        isIdle: function () {
            return this.get('playState') === this.PLAYING_STATES.PLAY_STATE_IDLE;

        },

        isLiveStream: function () {
            return this.get('songType') === this.SONG_TYPE.LIVE_STREAM;
        },

        isArtistBanned: function() {
            return this._data.artistIsBanned === this.banIds.banArtist;
        },

        isTrackBanned: function() {
            return this._data.trackIsBanned === this.banIds.banTrack;
        },

        canSkip: function () {
            return this.get('canSkip');
        },

        /**
         * Hom many skips left (only for basic users)
         * @returns {Number}
         */
        getSkipsLeft: function () {
            return this.get('skips');
        },

        isAudioAd: function () {
            return this.get('songType') === this.SONG_TYPE.AD;
        },

        isAudioNews: function () {
            return this.get('songType') === this.SONG_TYPE.NEWS;
        },

        isSong: function () {
            return this.get('songType') === this.SONG_TYPE.SONG;
        },

        isDjMode: function () {
            return this.get('songType') === this.SONG_TYPE.DJ_MODE;
        },

        setStationName: function (stationName) {
            this.set('stationName', stationName);
        },

        getStationName: function () {
            var stationName = this.get('stationName');
            return stationName ? stationName : '';
        },

        setStationId: function (stationId) {
            this.set('stationId', stationId);
        },

        getStationId: function () {
            var stationId = this.get('stationId');
            return stationId ? stationId : '';
        },

        /**
         * Next track name to play
         * @returns String
         */
        getNextTrackName: function () {
            return this.get('ondeckTrackName') ? this.get('ondeckTrackName') : '';
        },


        /**
         * Next Artist to play
         * @returns String
         */
        getNextArtistName: function () {
            return this.get('ondeckArtist') ? this.get('ondeckArtist') : '';
        },

        /**
         * Currently playing track name
         * @returns String
         */
        getTrackName: function () {
            return this.get('trackName') ? this.get('trackName') : '';
        },

        hasNextTrackInfo: function () {
            return !_.isUndefined(this.get('ondeckTrackName')) && !_.isUndefined(this.get('ondeckArtist'));
        },

        /**
         * Currently playing artist name
         * @returns String
         */
        getArtistName: function () {
            return this.get('artistName') ? this.get('artistName') : '';
        },


        /**
         * Handle generic message in commandControl.js
         * @param error (object)
         * error.error_code = 2 to map to language resources
         * error.success = false
         */
        onGenericError: function (error) {
            this.trigger('error', error);
        },

        goToHomeScreen: function () {
            this.set({'playState': this.PLAYING_STATES.PLAY_STATE_ERROR});
            this.trigger('goToHomeScreen');
        },

        unmute: function() {
            //TODO getPlayingState is only here because playing state
            // could be out dated due current "AVRCP" implementation.
            // remove this call when we can rely on player state in this scenario
            this.getPlayingState().done(function(){
                if(this.isPaused()){
                    this.play();
                }
            }.bind(this));
        },

        mute: function() {
            //TODO getPlayingState is only here because playing state
            // could be out dated due current "AVRCP" implementation.
            // remove this call when we can rely on player state in this scenario
            this.getPlayingState().done(function(){
                if(this.isPlaying()){
                    this.pause();
                }
            }.bind(this));
        }
    });
});
