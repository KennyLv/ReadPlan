define(function () {
    'use strict';

    return {

        /**
         * Slacker playing states
         */
        PLAYING_STATES: {
            PLAY_STATE_IDLE : 'Idle',
            PLAY_STATE_PLAYING : 'Playing',
            PLAY_STATE_PAUSED : 'Paused',
            PLAY_STATE_ERROR : 'Error',
            PLAY_STATE_TRANSITIONING : 'Transitioning',
            PLAY_STATE_INITIALIZING: 'Initializing'
        },

        /**
         * Slacker Api commands
         */
        API_COMMANDS: {
            GET_PLAY_STATE : 'GetPlayState',
            GET_SUBSCRIPTION_LEVEL : 'GetSubscriptionLevel',
            GET_STATION_LIST : 'GetStationList',
            GET_BOOKMARKED_STATIONS : 'GetBookmarkedStations',
            GET_BOOKMARKED_ALBUMS : 'GetBookmarkedAlbums',
            GET_BOOKMARKED_ARTISTS : 'GetBookmarkedArtists',
            GET_RECENTLY_PLAYED : 'GetRecentlyPlayed',
            GET_MY_STATIONS : 'GetMyStations',
            GET_MY_PLAYLISTS : 'GetMyPlaylists',
            GET_CACHED_ALBUMS : 'GetCachedAlbums',
            GET_CURRENT_TRACK_INFO: 'GetArtist',

            SET_FAVORITE_SONGS: 'SetMyFavoriteSongs',
            SET_PLAYLIST : 'SetMyPlayList',
            SET_STATION : 'SetStation',

            PLAY : 'Play',
            PAUSE : 'Pause',
            STOP : 'Stop',
            SKIP : 'Skip',
            PREVIOUS : 'Prev',
            FAVORITE : 'Favorite',
            BOOKMARK : 'BookmarkStation',
            UNBOOKMARK : 'UnbookmarkStation',
            UNFAVORITE : 'Unfavorite',
            BAN_SONG : 'BanSong',
            UNBAN_SONG : 'UnbanSong',
            BAN_ARTIST : 'BanArtist'
        },

        /**
         *Slacker SongType
         *
         */
        SONG_TYPE : {
            SONG : 'song',
            NEWS : 'news',
            LIVE_STREAM : 'livestream',
            AD : null,
            DJ_MODE: ''
        },

        /**
         * User subscription level
         *  -1 – Error (Invalid level)
         *  0 – Anonymous
         *  1 – Free Registered User (Basic)
         *  5 – Plus Registered User
         *  10 – Premium Registered User
         */
        SUBSCRIPTIONLEVELS: {
            ERROR: -1,
            ANONYMOUS: 0,
            BASIC: 1,
            PLUS: 5,
            PREMIUM: 10
        },


        /**
         * Notification map (async critical notification msgID)
         *
         * NO_NETWORK and FAILED_CONNECTION - no internet connection
         * SHARED_ACCOUNT - Account is accessed by two users or more
         * CONNECTION_GEOFENCE - not able to play stations
         */
        ASYNC_NOTIFICATIONS : {
            NO_NETWORK :'connection_site_down',
            FAILED_CONNECTION : 'connection_failed',
            CONNECTION_GEOFENCE: 'connection_geofence',
            SHARED_ACCOUNT: 'async_bump',
            SHARED_ACCOUNT_IOS: 'MSG_ID_BUMPED',
            ASYNC_EXHAUSTED: 'async_exhausted'
        },

        /**
         * sync msgID errors map
         */
        ERROR_MSG_IDS: {
            STATION_NOT_PLAYABLE: 'sync_set_station_station_not_playable',
            NO_TRACK_TO_PAUSE: 'sync_cannot_pause',
            HUP_SYNC_ERROR: 'sync_unrecognized_sync_command',
            STATION_ALREADY_BOOKMARKED: 'sync_bookmark_station_already_bookmarked',
            STATION_PENDING_BOOKMARKED: 'sync_bookmark_station_pending_bookmarked'
        },

        /**
         * Errors map to distinguish slacker errors and display appropriate messages
         */
        ERRORS: {
            GENERIC_ERROR: 1,
            NETWORK_NOT_AVAILABLE: 2,
            SKIP_LIMIT_ERROR: 3,
            FAVORITE_ERROR: 4,
            SUBSCRIPTION_ERROR: 5,
            SERVICE_UNAVAILABLE: 6,
            CONNECTION_GEOFENCE: 7,
            NO_FAVORITES_ERROR: 8,
            PLAY_STATE_ERROR: 9,
            SHARED_ACCOUNT: 10,
            UNFAVORITE_ERROR: 11,
            STATION_NOT_PLAYABLE:12,
            NO_TRACK_TO_PAUSE: 13,
            STATION_ALREADY_BOOKMARKED: 14,
            STATION_PENDING_BOOKMARKED: 15,
            ASYNC_EXHAUSTED: 16
        },

        /**
         * Delay map
         */
         DELAY: {
            SHORT: 3000,
            LONG: 10000
         }
    };

});
