define(['aq/eventEmitter', 'aq/dic'], function (EventEmitter, aq) {
    'use strict';

    var Logger = aq.get('Logger'),
        logger = new Logger('med', 'WEB_VIEW', '[Slacker]');

    logger.log('Slacker ROUTER loaded');

    return EventEmitter.extend({

        init: function (options) {

            this.routes = {
                'show:slackerStations': this.goToSlackerStations,
                'show:homeScreen': this.goToHomeScreen,
                'show:playerScreen': this.goToPlayer,
                'show:myMusic' : this.goToMyMusic,
                'close': this._onClose,
                'suspend': this._onSuspend
            };

            this.dic = options.dic;
            this.model = options.model;
            this.Splash = options.SplashScreen;
            this.Popup1 = options.Popup1;
            this.display = options.display;
        },

        start: function () {
            this.model.commandControl.abortApplicationRequests();

            this.listenTo(this.model, 'error', this.onError.bind(this));
            this.showSplashScreen();

            this.model.start();
            this.listenToOnce(this.model, this.model.events.onGetSubscriptionLevel,
                this.onUserSubscriptionUpdate.bind(this));

            this.model.getSubscriptionLevel();
        },

        onError: function (error) {
            this._showErrorPopUp(error);
        },

        _showErrorPopUp: function (error) {
            var popup = new this.Popup1();
            popup.render({
                title: $.t(['error', error.error_code, 'title'].join('.')),
                text: $.t(['error', error.error_code, 'text'].join('.')),
                buttons: [popup.buttons.ok]
            });
            this.listenToOnce(popup.display, popup.events.close, this._onClose);
        },

        initSession: function () {
            this.listenTo(this.model, {
                'show:stationCreate': this.goToCreateStation,
                'show:stationList': this.goToMyStations,
                'show:playerScreen': this.goToPlayer,
                'update:playState' : this.goToHomeScreen
            });

            // TODO: move to the model
            this.model.commandControl.when([this.model.API_COMMANDS.GET_BOOKMARKED_STATIONS])
                .done(function (content) {
                    // Keep the list locally cached because prior to render "Now Playing" screen we have to now
                    // in which state "Bookmark" button should be rendered - either Selected or Enabled.
                    // Slacker does not provide us with such information within Track Info data.
                    if (content.bookmarked_stations) {
                        logger.log({ 'BookmarkedStationsCount': content.bookmarked_stations.count });
                        this.model.bookmarkedStations = content.bookmarked_stations;
                    }

                    // FIXME: Maybe it is a risky to do this stuff in a callback for async GetBookmarkedStations...
                    this.model.getPlayingState().done(function() {
                        this.goToHomeScreen();
                        // no data provided by API if track is playing initially so that call getTrackInfo CV-1277
                        if (this.model.isTrackPlayable()) {
                            if (this.model.isPlaying() || this.model.isPaused()) {
                                this.model.getTrackInfo();
                            }
                            if (this.model.isPaused()) {
    //TODO: check what happens with StationID after calling
    //Play API and how the process of executing this call looks like
    //in case when we force-stopped app while playing LIVE
    //(what station should be returned in that case,
    //because documentation does not give complete answer on this)
                                this.model.play();
                            }
                        }
                    }.bind(this));
                }.bind(this));
        },

        showSplashScreen: function () {
            this.splash = this.splash || new this.Splash();
            this.splash.render();
        },

        onUserSubscriptionUpdate: function () {
            logger.log('onUserSubscriptionUpdate');
            if (!this.model.isUserRegistered()) {
                logger.log('onUserSubscriptionUpdate : user is not registered');
                this._showErrorPopUp({error_code: 5});
            } else {
                logger.log('onUserSubscriptionUpdate : user is registered');
                this.initSession();
            }
        },

        navigate: function (name) {
            if (this.routes[name]) {
                this.stopListening();
                this.routes[name].apply(this, Array.prototype.slice.call(arguments, 1));
            }
        },

        /**
         * To be called from outside (from appEntry point)
         */
        suspend: function () {
            this.stopListening();
        },

        /**
         * To be called from outside (from appEntry point)
         */
        close: function () {
            this.suspend();
            if (this.model.isPlaying()) {
                this.model.pause();
            }
        },

        _onSuspend: function () {
            this.trigger('suspend');
        },

        _onClose: function () {
            this.trigger('close');
        },

        goToMyMusic: function () {
            // CV-2529
            // iOs Slacker can not_update
            // HMI with playState change
            // that's why we need to request it
            this.model.getPlayingState();
            var controller = this.dic.get('controller/myMusic');

            this.listenTo(controller, 'all', this.navigate);
            controller.start();
        },

        goToHomeScreen: function () {
            // CV-2529
            // iOs Slacker can not_update
            // HMI with playState change
            // that's why we need to request it
            this.model.getPlayingState();
            var controller = this.dic.get('controller/home');

            this.listenTo(controller, 'all', this.navigate);
            controller.start();
        },

        goToSlackerStations: function (options) {
            // CV-2529
            // iOs Slacker can not_update
            // HMI with playState change
            // that's why we need to request it
            this.model.getPlayingState();
            var controller = this.dic.get('controller/allStations');

            this.listenTo(controller, 'all', this.navigate);
            controller.start(options);
        },

        goToPlayer: function (options) {
            var controller = this.dic.get('controller/player');

            this.listenTo(controller, 'all', this.navigate);
            controller.start(options);
        }

    });

});
