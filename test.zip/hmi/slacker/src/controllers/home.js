define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (options) {
            this.model = options.model;
            this.homeView = options.HomeScreen;
        },

        start: function () {
            this.showHomeScreen();
            this.startListening();
        },

        startListening: function () {
            this.stopListening();

            this.listenTo(this.view, this.view.events.goToPlayer, this.onGoToPlayer);
            this.listenTo(this.view, this.view.events.goToMyMusic, this.onGoToMyMusic);
            this.listenTo(this.view, this.view.events.goToSlackerStations, this.onGoToSlackerStations);
            this.listenTo(this.model, 'update:homeScreen', this.showHomeScreen);

            this.listenToOnce(this.model, 'player:Update', this.showHomeScreen);
        },

        suspend: function () {
            this.stopListening();
        },

        onSuspend: function () {
            this.trigger('suspend');
        },

        onGoToPlayer: function () {
            this.stopListening();
            this.trigger('show:playerScreen');
        },

        showHomeScreen: function () {
            this.view = this.view || new this.homeView(this.model);
            this.view.render();
        },

        onGoToMyMusic: function () {
            this.stopListening();
            this.trigger('show:myMusic');
        },

        onGoToSlackerStations: function () {
            this.stopListening();
            this.trigger("show:slackerStations");
        }

    });

});