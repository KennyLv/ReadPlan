define(['slacker/controllers/main/controller'], function (BaseController) {
    'use strict';

    return BaseController.extend({

        init: function (options) {
            this._super();
            this.model = options.model;
            this.Player = options.Player;
            this.Popup1 = options.Popup1;
            this.Popup2 = options.Popup2;
        },

        start: function (options) {
            options = options || {};
            this.DELAY = this.model.DELAY;
            this.mainAction(options);
            this.startListening();
        },

        startListening: function () {
            this.listenTo(this.player, this.player.events.onSuspend, this.onSuspend);
            this.listenTo(this.player, this.player.events.goToHomeScreen, this.onGoToHomeScreen);
            this.listenTo(this.player, this.player.events.play, this.onPlay);
            this.listenTo(this.player, this.player.events.pause, this.onPause);
            this.listenTo(this.player, this.player.events.ban, this.onBan);
            this.listenTo(this.player, this.player.events.previousSong, this.onPrevSongModal);
            this.listenTo(this.player, this.player.events.nextSong, this.onNextSongModal);

            this.listenTo(this.model, 'changed', this.mainAction);
            this.listenTo(this.model, 'error', this.handleError);
        },

        onSuspend: function () {
            this.stopListening();
            this.trigger('suspend');
        },

        suspend: function () {
            this.stopListening();
        },

        close: function () {
            this.stopListening();
        },

        onGoToHomeScreen: function () {
            this.stopListening();
            this.trigger('show:homeScreen');
        },

        onPlay: function () {
            this.model.play();
        },

        onPause: function () {
            this.model.pause();
        },

        onBan: function () {
            var popup = new this.Popup2(this.model),
                trackName = this.model.getTrackName(),
                artistName = this.model.getArtistName();

            popup.render({
                labels: [$.t('popups.ban'), trackName, artistName],
                buttons: [popup.buttons.close, popup.buttons.banArtist, popup.buttons.banTrack],
                delay: this.DELAY.LONG,
                image: this.model.getCurrentImage()
            });
            this.listenToOnce(popup.display, popup.events.close, this.mainAction);
            this.listenTo(popup.display, popup.events.banArtist, this.ban);
            this.listenTo(popup.display, popup.events.banTrack, this.ban);
        },

        ban: function (data) {
            this.model.ban(data.value).done(this.mainAction.bind(this));
        },

        onPrevSongModal: function (data) {
            var popup = new this.Popup2(this.model),
                trackName = data.value.trackName,
                artistName = data.value.artist,
                image = data.value.image;

            popup.render({
                labels: [$.t('popups.prev') , trackName, artistName],
                buttons: [popup.buttons.close, popup.buttons.previous],
                delay: this.DELAY.LONG,
                image: image
            });

            this.listenToOnce(popup.display, popup.events.close, this.mainAction);
            this.listenTo(popup.display, popup.events.previous, this.onPrevNextSong);
        },

        onNextSongModal: function (data) {
            var popup = new this.Popup2(this.model),
                isBasicUser = this.model.isBasicUser(),
                trackName = isBasicUser ? $.t('popups.nextSongBasicUser.track') :
                    this.model.isPlusUser() ? '' : data.value.trackName,
                artistName = isBasicUser ? $.t('popups.nextSongBasicUser.artist') : data.value.artist;

            popup.render({
                labels: [ $.t('popups.next'), trackName, artistName],
                buttons: [popup.buttons.close, popup.buttons.next],
                image: isBasicUser ? null : this.model.getOnDeckImage(),
                delay: this.DELAY.LONG
            });

            this.listenTo(popup.display, popup.events.close, this.mainAction);
            this.listenTo(popup.display, popup.events.next, this.onPrevNextSong);
        },

        /**
         * @param song.value {string}
         * if Next - skip to next track,
         * else - play current track from the beginning
         */
        onPrevNextSong: function (song) {
            if (song.value === 'Next') {
                this.model.skip().done(this.mainAction.bind(this));
            } else {
                this.model.playPrevTrack().done(this.mainAction.bind(this));
            }
        },

        _statusRequested: false,
        /**
         * render player view
         * mainAction is used in BaseController to handle errors
         */
        mainAction: function () {
            this.player = this.player || new this.Player(this.model);
            this.player.render();
        }
    });
});
