define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';


    return EventEmitter.extend({

        init: function () {

        },

        handleError: function (error) {
            this.errorPopup = this.errorPopup || new this.Popup1();
            this.errorPopup.render({
                title: $.t(['error', error.error_code, 'title'].join('.')),
                text: $.t(['error', error.error_code, 'text'].join('.')),
                buttons: [this.errorPopup.buttons.ok],
                delay: error.delay
            });
            this.listenTo(this.errorPopup.display, this.errorPopup.events.close,
                error.mainAction ? error.mainAction : this.mainAction);
        }

    });
});
