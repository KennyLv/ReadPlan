define(['slacker/controllers/main/controller'], function (BaseController) {
    'use strict';


    return BaseController.extend({

        init: function (options) {
            this._super();
            this.model = options.model;
            this.List = options.List;
            this.Popup1 = options.Popup1;
        },

        start: function () {
            this.mainAction();
            this.startListening();
        },

        startListening: function () {
            this.listenTo(this.model, 'update:stationsList', this.updateSlackerStations);
            this.listenTo(this.model, 'error', this.handleError);
            this.listenTo(this.model, this.model.playerEvents.update, this._updateView.bind(this));
        },

        suspend: function () {
            this.stopListening();
        },

        onSuspend: function () {
            this.trigger('suspend');
        },

        close: function () {
            this.stopListening();
        },

        goToPlayer: function () {
            this.stopListening();
            this.trigger('show:playerScreen');
        },

        _updateView: function() {
            if (this._stations) {
              this.updateSlackerStations(this._stations);
            }
            else {
                this.mainAction();
            }
        },

        /**
         * render 'All stations' list
         * mainAction is used in BaseController to handle errors
         */
        mainAction: function () {
            this.model.getStationsList();
            this.stationsList = this.stationsList || new this.List(this.model);
            this.stationsList.setTitle($.t('stationsList.title'));
            this.stationsList.render({items: [{"name" : $.t('loading')}]});
            this.listenToOnce(this.stationsList, this.stationsList.events.goBack, this.onGoToHomeScreen);
            this.listenToOnce(this.stationsList, this.stationsList.events.player, this.goToPlayer);
        },

        updateSlackerStations: function (stations) {
            this._stations = stations;
            this.stationsList.setTitle($.t('stationsList.title'));
            this.stationsList.render({items: stations });
            this.listenTo(this.stationsList, this.stationsList.events.goBack, this.onGoToHomeScreen);
            this.listenTo(this.stationsList, this.stationsList.events.select, this.onSelectStation);
            this.listenTo(this.stationsList, this.stationsList.events.player, this.goToPlayer);
        },

        onSelectStation: function (selectedStat) {
            this.selectedStation = this.selectedStation || new this.List(this.model);
            this.selectedStation.setTitle(selectedStat.value.name);
            this.selectedStation.render({items: selectedStat.value.items });
            this.listenTo(this.selectedStation, this.selectedStation.events.goBack,
                this.stationsList.renderPrevious.bind(this.stationsList));
            this.listenTo(this.selectedStation, this.selectedStation.events.select, this.selectStation);
            this.listenTo(this.selectedStation, this.selectedStation.events.player, this.goToPlayer);
        },

        onGoToHomeScreen: function () {
            this.stopListening();
            this.trigger('show:homeScreen');
        },

        selectStation: function (subCategory) {
            this.model.setStation(subCategory.value)
                .done(this.goToPlayer.bind(this));
        }

    });
});
