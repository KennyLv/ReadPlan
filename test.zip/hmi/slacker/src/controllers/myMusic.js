define([
    'slacker/config/myMusicConfig',
    'slacker/controllers/main/controller'
], function (myMusicConfig, BaseController) {
    'use strict';


    return BaseController.extend({


        init: function (options) {
            this._super();
            this.model = options.model;
            this.List = options.List;
            this.Popup1 = options.Popup1;
            //should be done through method call
            // to avoid translation issues
            // regarding invalid app.json not being updated
            // form previous app
            this.myMusicConfig = options.MyMusicConfig.getMyMusicConfig();
        },

        /**
         * max number of recently played tracks to display in Recently played category
         */
        MAX_RECENTLY_PLAYED_LENGTH: 20,

        start: function () {
            this.mainAction();
            this.startListening();
        },

        startListening: function () {
            this.listenTo(this.model, 'update:myMusicData', this.updateMyMusicList);
            this.listenTo(this.model, 'error', this.handleError);
            this.listenTo(this.model, this.model.playerEvents.update, this._updateView.bind(this));
        },

        suspend: function () {
            this.stopListening();
        },

        onSuspend: function () {
            this.trigger('suspend');
        },

        close: function () {
            this.stopListening();
        },

        goToPlayer: function () {
            this.stopListening();
            this.trigger('show:playerScreen');
        },

        _updateView: function() {
            if (this._myMusicList) {
              this.updateMyMusicList(this._myMusicList);
            }
            else {
                this.mainAction();
            }
        },

        /**
         * render Slacker stations list
         * mainAction is used in BaseController to handle errors
         */
        mainAction: function () {
            this.model.getAllMyMusicData();
            this.myMusicList = this.myMusicList || new this.List(this.model);
            this.myMusicList.setTitle($.t('myMusicList.title'));
            this.myMusicList.render({items: [{"name" : $.t('loading')}]});
        },

        updateMyMusicList: function (myMusicList) {

            var playFavoriteEvent = 'playFavorite';
            this._myMusicList = myMusicList;
            myMusicList = this._processMyMusicList(myMusicList);
            myMusicList.unshift({
                name: $.t('myMusicList.FavoriteSongs'),
                items: [],
                usePlayIcon: true
            });
            this.myMusicList.setTitle($.t('myMusicList.title'));
            this.myMusicList.render({items: myMusicList, event:playFavoriteEvent});
            this.listenTo(this.myMusicList.display, playFavoriteEvent, this.onPlayFavoriteRequest);
            this.listenTo(this.myMusicList, this.myMusicList.events.goBack, this.onGoToHomeScreen);
            this.listenTo(this.myMusicList, this.myMusicList.events.select, this.onSelectMyMusicCategory);
            this.listenTo(this.myMusicList, this.myMusicList.events.player, this.goToPlayer);
        },

        _processMyMusicList: function (myMusicList) {
            return myMusicList.filter(function(musicCategory) {
                var items = [],
                    key;
                try {
                    key = this.myMusicConfig[musicCategory.control].key;
                    items = musicCategory[key];

                    return (musicCategory.success !== 'false' && items.length > 0);
                } catch (e) {
                    return false;
                }
            }, this)
                .map(function (musicCategory) {
                    var key = this.myMusicConfig[musicCategory.control].key,
                        title = this.myMusicConfig[musicCategory.control].title,
                        items = musicCategory[key];
                    return {
                        name: title,
                        items: items,
                        key: key
                    };
                }, this);
        },

        onGoToHomeScreen: function () {
            this.stopListening();
            this.trigger('show:homeScreen');
        },

        onSelectMyMusicCategory: function (category) {
            var listTitle = category.value.name;
            this.subCategoryList = this.subCategoryList || new this.List(this.model);
            //According to spec on Recently Played list, show max 20 items.
            if(category.value.key === this.myMusicConfig.GetRecentlyPlayed.key &&
               category.value.items.length > this.MAX_RECENTLY_PLAYED_LENGTH){
                category.value.items.splice(this.MAX_RECENTLY_PLAYED_LENGTH);
            }

            this.subCategoryList.setTitle(listTitle);
            this.subCategoryList.render({
                items: category.value.items,
                //My Stations key is used to display alpha jump only for this list
                categoryKey: category.value.key
            });
            this.listenTo(this.subCategoryList, this.subCategoryList.events.select,
                this.onSelectMyMusicSubCategory);
            this.listenTo(this.subCategoryList, this.subCategoryList.events.goBack,
                this.myMusicList.renderPrevious.bind(this.myMusicList));
            this.listenTo(this.subCategoryList, this.subCategoryList.events.player, this.goToPlayer);
        },

        onSelectMyMusicSubCategory: function (subcategory) {
            this.model.setStation(subcategory.value)
                .done( this.goToPlayer.bind(this));
        },

        onPlayFavoriteRequest: function () {
            this.model.setFavoriteSongs()
                .done(this.goToPlayer.bind(this));
        }
    });
});
