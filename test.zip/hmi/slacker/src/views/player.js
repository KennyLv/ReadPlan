define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        events: {
            goToHomeScreen: 'goToHomeScreen',
            likeSong: 'likeSong',
            ban: 'ban',
            skipSong: 'skipSong',
            previous: 'previous',
            bookmark: 'bookmark',
            unBookmark: 'unBookmark',
            play: 'play',
            pause: 'pause',
            source: 'source',
            previousSong: 'previousSong',
            nextSong: 'nextSong'
        },

        images: {
            surface: 'file:///slacker/images/surface.png',
            header: 'file:///slacker/images/player/header.png',
            default_art: 'file:///slacker/images/player/default_art.png',
            player_home_btn: 'file:///slacker/images/player/player_btn_home.png',
            play: 'file:///slacker/images/player/player_btn_play.png',
            playDisabled: 'file:///slacker/images/player/player_btn_play_disabled.png',
            pause:  'file:///slacker/images/player/player_btn_pause.png',
            pauseDisabled:  'file:///slacker/images/player/player_btn_pause_disabled.png',
            skip: 'file:///slacker/images/player/player_btn_next.png',
            skipDisabled: 'file:///slacker/images/player/player_btn_next_disabled.png',
            skipZeroDisabled: 'file:///slacker/images/player/skip/0_disabled.png',
            skipLimited: 'file:///slacker/images/player/skip/<%= skipNumber %>.png',
            favorite:  'file:///slacker/images/player/player_btn_favorite_unselected.png',
            favoriteSelected:  'file:///slacker/images/player/player_btn_favorite_selected.png',
            favoriteDisabled:  'file:///slacker/images/player/player_btn_favorite_disabled.png',
            previous: 'file:///slacker/images/player/player_btn_prev.png',
            previousDisabled: 'file:///slacker/images/player/player_btn_prev_disabled.png',
            ban:  'file:///slacker/images/player/player_btn_ban_unselected.png',
            banSelected:  'file:///slacker/images/player/player_btn_ban_selected.png',
            banDisabled:  'file:///slacker/images/player/player_btn_ban_disabled.png',
            source: 'file:///slacker/images/player/source.png',
            nextSong: 'file:///slacker/images/player/player_btn_next_song.png',
            nextSongDisabled: 'file:///slacker/images/player/player_btn_next_song_disabled.png',
            previousSong: 'file:///slacker/images/player/player_btn_prev_song.png',
            previousSongDisabled: 'file:///slacker/images/player/player_btn_prev_song_disabled.png'
        },

        init: function (options, model) {
            this.stationInfo = null;

            this.template = {};
            this.model = model;
            this.API_COMMANDS = model.API_COMMANDS;
            this.display = options.display;
            this.config = options.config;

            this._super(options.display, {useButtonsBranding: true});
            this.updateTrackInfo();

            this.model.on('goToHomeScreen', this.goToHomeScreen, this);
            this.model.on('changed', this.updateTrackInfo, this);
        },

        updateTrackInfo: function () {
            this.isPremiumUser = this.model.isPremiumUser();
            this.isBasicUser =  this.model.isBasicUser();
            this.isAudioAd = this.model.isAudioAd();
            this.isDjMode = this.model.isDjMode();
            this.isAudioNews = this.model.isAudioNews();
            this.isPaused = this.model.isPaused();
            this.isError = this.model.isError();
            this.isIdle = this.model.isIdle();
            this.isPlaying = this.model.isPlaying();
            this.isSong = this.model.isSong();
            this.favoriteRating = this.model.getSongRating();
        },

        source: function () {
            this.display.showMediaSourceScreen();
        },

        _render: function (options) {
            options = options || {};
            this.template = this.generateTemplate(options);
            this.start();
        },

        start: function () {
            this.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);

            this.bindScrollEvent();
            this.listenToOnce(this.display, this.display.getBackButtonEventName(), this.onBackButtonPressed.bind(this));
            this.listenToOnce(this.display, this.display.getScrollEventName(), this.goToHomeScreen.bind(this));
            this.listenToOnce(this.display, this.display.getEnterEventName(), this.goToHomeScreen.bind(this));
            this.listenToOnce(this.display, this.display.getSeekUpEventName(), this.onSeekUpPressed.bind(this));
            this.listenToOnce(this.display, this.display.getSeekDownEventName(), this.onSeekDownPressed.bind(this));
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-6',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header
                    },
                    buttons: this.getButtons(),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: this.getProgressBar()
                }
            };
        },

        getText: function () {
            return _.extend(
                this.getStationName(),
                this.getTrackAndArtistNames()
            );
        },

        getStationName: function () {
            return {
                1: {
                    text: this.model.getStationName()
                }
            };
        },

        getTrackAndArtistNames: function () {
            return  {
                2: {
                    text: this.model.getTrackName()
                },
                3: {
                    text: this.model.getArtistName()
                }
            };
        },

        getButtons: function () {
            return _.extend(this._getUserBarButtons(), {
                7: this.getSourceButton(),
                8: this.getPrevSongButton(),
                9: this.getNextSongButton()
            });
        },

        _getUserBarButtons: function () {
            return this.isPremiumUser ? this._getPremiumUserBarButtons() : this._getBasicUserBarButtons();
        },

        _getBasicUserBarButtons: function () {
            return {
                1: this.getHomeButton(),
                2: this.getPlayToggleButton(),
                3: this.getSkipButton(),
                4: this.getFavoriteButton(),
                5: this.getBanButton()
            };
        },

        _getPremiumUserBarButtons: function () {
            return {
                1: this.getHomeButton(),
                2: this.getPrevButton(),
                3: this.getPlayToggleButton(),
                4: this.getSkipButton(),
                5: this.getFavoriteButton(),
                6: this.getBanButton()
            };
        },

        getSourceButton: function () {
            return {
                image: {
                    normal: this.images.source,
                    pressed: 0
                },
                action: this.events.source
            };
        },

        getHomeButton: function () {
            return {
                image: {
                    normal: this.images.player_home_btn,
                    pressed: 0
                },
                action: this.events.goToHomeScreen
            };
        },

        getPrevButton: function () {
            return !this._isPrevSongAvailable() ? {
                image: {
                    normal: this.images.previousDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: this.images.previous,
                    pressed: 0
                },
                action: this.events.previous
            };
        },

        getSkipButton: function () {
            var skipsLeft = this.model.getSkipsLeft(),
                canSkip = this.model.canSkip(),
                stateEnabled = true,
                skipImage;

            if (this.isBasicUser && skipsLeft >= 0) {
                skipImage =  _.template(this.images.skipLimited, {skipNumber: skipsLeft});
            } else if (!this.isBasicUser && canSkip) {
                skipImage = this.images.skip;
            } else {
                stateEnabled = false;
                skipImage = this.images.skipDisabled;
            }

            return this.isAudioAd ? {
                image: {
                    normal: this.images.skipDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: skipImage,
                    pressed: 0
                },
                stateEnabled: stateEnabled,
                action: this.events.skipSong
            };
        },

        getPlayToggleButton: function () {

            return this.isAudioAd ? {
                image: {
                    normal: this.images.pauseDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: (this.isPaused || this.isIdle || this.isError) ? this.images.play : this.images.pause,
                    pressed: 0
                },
                action: this.isPlaying ? this.events.pause : this.events.play
            };
        },

        getFavoriteButton: function () {
            var isFavorite = this.favoriteRating > 0;

            return (!this.isSong) ? {
                image: {
                    normal: this.images.favoriteDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: isFavorite ? this.images.favoriteSelected : this.images.favorite,
                    pressed: 0
                },
                action: this.events.likeSong,
                value: isFavorite ?  this.API_COMMANDS.UNFAVORITE :  this.API_COMMANDS.FAVORITE
            };
        },

        getBanButton: function () {
            var banImg = this.favoriteRating < 0 ? this.images.banSelected : this.images.ban;

            return (!this.isSong) ? {
                image: {
                    normal: this.images.banDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: banImg,
                    pressed: 0
                },
                action: this.events.ban
            };
        },

        getBookmarkButton: function () {
            throw new Error("Implement in Platform specific View");
        },

        getPrevSongButton: function () {
            var prevTrack = this.model.getPrevSong();

            return !this._isPrevSongAvailable() ? {
                image: {
                    normal: this.images.previousSongDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: prevTrack ? this.images.previousSong : this.images.previousSongDisabled,
                    pressed: 0
                },
                action: prevTrack ? this.events.previousSong : '',
                stateEnabled : prevTrack ? true : false,
                value: prevTrack ? {
                    song: 'Prev',
                    trackName: prevTrack.trackName,
                    artist: prevTrack.artistName,
                    image: prevTrack.image ? prevTrack.image : this.images.default_art
                } : ''
            };
        },

        getNextSongButton: function () {
            var trackName = this.model.getNextTrackName(),
                artist = this.model.getNextArtistName(),
                hasNextTrackInfo = this.model.hasNextTrackInfo();

            return this.isAudioAd ? {
                image: {
                    normal: this.images.nextSongDisabled,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: hasNextTrackInfo ?  this.images.nextSong : this.images.nextSongDisabled,
                    pressed: 0
                },
                action: hasNextTrackInfo ? this.events.nextSong : '',
                stateEnabled: hasNextTrackInfo ? true : false,
                value: {song: 'Next', trackName: trackName, artist: artist}
            };
        },

        getProgressBar: function () {
            var duration = this.model.getDuration(),
                elapsed = this.model.getElapsedTime();

            return (_.isNumber(duration) && _.isNumber(elapsed) && elapsed !== duration && duration > 0) ? {
                total: duration,
                elapsed: elapsed,
                color: '#CD5718',
                active:  this.model.isPlaying()
            } : {};

        },

        getImages: function () {
            var currentImage = this.model.getCurrentImage();

            return {
                1: this.isAudioAd ? this.images.default_art : currentImage ? currentImage : this.images.default_art,
                2: this.images.default_art
            };
        },

        /**
         * On scroll/enter hardware controls interaction
         */
        goToHomeScreen: function () {
            this.unbindScrollEvent();
            this.trigger(this.events.goToHomeScreen);
        },

        /**
         * On home hardware button click
         */
        onBackButtonPressed: function () {
            if (this._isPrevSongAvailable()) {
                this.unbindScrollEvent();
                this.trigger(this.events.goToHomeScreen);
            }
        },

        /**
         * On heart click
         */
        likeSong: function (control) {
            this.model.favorite(control.value);
            this.trigger('likeSong');
        },

        /**
         * On ban click
         */
        ban: function () {
            this.trigger('ban');
        },

        /**
         * On bookmark click
         */
        bookmark: function () {
            this.model.bookmark();
            this.trigger('station:bookmarked');
        },

        /**
         * On bookmark click
         */
        unBookmark: function () {
            this.model.unBookmark();
            this.trigger('station:unBookmarked');
        },

        /**
         * On skip track click
         */
        skipSong: function () {
            this.model.skip();
            this.trigger('skipSong');
        },

        /**
         * On seekUp hard button pressed
         */
        onSeekUpPressed: function () {
            this.skipSong();
        },

        /**
         * On seekDown hard button pressed
         */
        onSeekDownPressed: function () {
            this.previous();
        },

        previous: function () {
            this.model.previous();
        },

        /**
         * On play click
         */
        play: function () {
            this.trigger('play');
        },

        /**
         * On pause click
         */
        pause: function () {
            this.trigger('pause');
        },

        nextSong: function (data) {
            this.trigger('nextSong', data);
        },

        previousSong: function (data) {
            this.trigger('previousSong', data);
        },

        _isPrevSongAvailable: function () {
            return !(this.isAudioAd || this.isDjMode || this.isAudioNews);
        }
    });
});
