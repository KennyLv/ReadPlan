define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({
        events: {
            goToSlackerStations: 'goToSlackerStations',
            goToMyMusic: 'goToMyMusic',
            goToPlayer: 'goToPlayer',
            onSuspend: 'onSuspend'
        },

        images: {
            surface: 'file:///slacker/images/surface.png',
            logo: 'file:///slacker/images/home-logo.png',
            play: 'file:///slacker/images/general/nowPlaying.png',
            play_disabled: 'file:///slacker/images/general/nowPlaying_disabled.png'
        },

        init: function (options, model) {
            this.template = {};
            this.model = model;
            this._super(options.display, {useButtonsBranding: true});

            this.config = options.config;
        },

        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },

        _render: function () {
            this.template = this.generateTemplate();
            this.start();
        },

        start: function () {
            this.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-5',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.logo
                    },
                    buttons: this.getButtons()
                }
            };
        },

        getButtons: function () {
            return {
                4: this.getPlayingBtn(),
                5: this.getMyMusicBtn(),
                6: this.getSlackerStationsBtn()
            };
        },

        getSlackerStationsBtn: function () {
            return {
                text: $.t('homeScreen.buttons.recentStations'),
                action: this.events.goToSlackerStations
            };
        },

        getMyMusicBtn: function() {
            return {
                text: $.t('homeScreen.buttons.myMusic'),
                action: this.events.goToMyMusic
            };
        },

        getPlayingBtn: function() {
            var isPlaying = this.model.isPlaying() || this.model.isPaused() || false;
            return {
                text : $.t('nowPlaying'),
                stateEnabled: isPlaying,
                image: isPlaying ? this.images.play : this.images.play_disabled,
                action: this.events.goToPlayer
            };
        },

        goToMyMusic: function() {
            this.trigger(this.events.goToMyMusic);
        },

        goToPlayer: function() {
            this.trigger(this.events.goToPlayer);
        },

        goToSlackerStations: function () {
            this.trigger(this.events.goToSlackerStations);
        }
    });
});