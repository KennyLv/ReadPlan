define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        events: {
            close: 'close'
        },

        images: {
            close: 'file:///slacker/images/close_btn.png',
            surface: 'file:///slacker/images/surface.png'
        },

        init: function (options) {
            this.initButtons();
            this.template = {};
            this._super(options.display, {useButtonsBranding: true});

            this.config = options.config;
        },

        initButtons: function () {
            this.buttons = {

                ok: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                },

                cancel: {
                    3: {
                        action: this.events.close,
                        text: $.t('buttons.cancel')
                    }
                }

            };
        },

        _render: function (options) {
            this.text = options.text;
            this.title = options.title;
            if (options.delay) {
                _.delay(this._triggerClose.bind(this), options.delay);
            }

            this.template = this.generateTemplate(options.buttons);
            this.updateScreen(this.template);
        },

        _triggerClose: function () {
            this.display.trigger(this.events.close);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp2c-1',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }

    });
});