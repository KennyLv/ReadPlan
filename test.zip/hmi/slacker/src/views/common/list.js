define(['common/view/baseListView'], function (BaseListView) {
    'use strict';

    return BaseListView.extend({

        events: {
            goBack: 'goBack',
            select: 'select',
            player: 'player',
            onAlphaJump: 'onAlphaJump'
        },

        images: {
            back: 'file:///slacker/images/general/btn_back.png',
            backDisabled: 'file:///slacker/images/general/btn_back_disabled.png',
            folder: 'file:///slacker/images/list/icon_folder.png',
            player: 'file:///slacker/images/list/sidebtn_icon-now_playing.png',
            playerDisabled: 'file:///slacker/images/list/sidebtn_icon-now_playing_disabled.png',
            surface: 'file:///slacker/images/surface.png',
            playIcon: 'file:///slacker/images/list/icon_play.png',
            alphaJump: 'file:///slacker/images/list/sidebtn_icon-alpha_jump.png',
            keyboardPressedId1: 'file:///slacker/images/buttons/pressed/56x56.png',
            keyboardPressedId2: 'file:///slacker/images/buttons/pressed/75x52.png'
        },

        init: function (options, model) {
            this._super(options.display, model);
            this.template = {};

            this.config = options.config;
        },

        _render: function (options) {
            options = options || {};
            //enable alpha jump only for My Stations list
            this.showAlphaJumpBtn = (options.categoryKey === 'mystations' && options.items.length > 4);
            this.template = this.generateTemplate(options);
            this.updateScreen(this.template);
            this.startListening();
        },

        showKeyboard: function() {
            this._super(this.images.keyboardPressedId1, this.images.keyboardPressedId2);
        },

        renderPrevious: function () {
            this.updateScreen(this.template);
            this.startListening();
        },

        setTitle: function (title) {
            this.title = title;
        },

        generateTemplate: function (options) {
            var listItems = this.getItems(options),
                selectedListItem = _.isNumber(this.getSelectedListItem()) && this.getSelectedListItem();

            if (selectedListItem && listItems.length >= selectedListItem) {
                listItems.activeListItem = selectedListItem;
            }

            return {
                templateId: 'vp2c-3',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: {
                        text: this.title || ''
                    },
                    list: listItems,
                    buttons: this.getButtons()
                }
            };
        },

        /**
         *
         * @param items {Array}
         * @param options {Object}
         * @returns {Array}
         */
        getItems: function (options) {
            options = options || {};
            var items = _.isArray(options.items) ? options.items : [];
            return items.map(function (item) {
                var name = item.name;
                item.hasChildren = false;
                if (item.items){
                    item.hasChildren = item.items.length > 0;
                }

                return {
                    text: item.name,
                    image1: this.getItemLeftImage(item),
                    image2: this.getItemRightImage(),
                    action: (options.event && !item.hasChildren) ? options.event : this.events.select,
                    value: {
                        name: name,
                        items: item.items,
                        id: item.id,
                        key : item.key
                    }
                };
            }, this);
        },

        getItemLeftImage: function (item) {
            return item.hasChildren ? this.images.folder : item.usePlayIcon ? this.images.playIcon : 0;
        },

        getItemRightImage: function () {
            return 0;
        },

        getButtons: function () {
            var buttons = {
                1: this.getBackButton(),
                4: this.getNowPlayingButton()
            };
            if (this.showAlphaJumpBtn) {
                buttons[10] = this.getABCJumpButton();
            }
            return buttons;
        },

        getBackButton: function () {
            this.isBackBtnDisabled = false;
            return {
                image: {
                    normal: this.isBackBtnDisabled ? this.images.backDisabled : this.images.back
                },
                action: this.events.goBack,
                stateEnabled: !this.isBackBtnDisabled
            };
        },

        getNowPlayingButton: function () {
            var isStationPlaying = this.model.isPlaying() || this.model.isPaused() || false;
            return {
                image: {
                    normal: isStationPlaying ? this.images.player : this.images.playerDisabled
                },
                action: this.events.player,
                stateEnabled: isStationPlaying
            };
        },

        getABCJumpButton: function () {
            return {
                image: {
                    normal: this.images.alphaJump
                },
                action: this.events.onAlphaJump
            };
        },

        player: function (item) {
            this.trigger('player', item);
        },

        select: function (item) {
            this.trigger('select', item);
        },

        goBack: function (item) {
            this.stopListening();
            this.trigger('goBack', item);
        }

    });
});
