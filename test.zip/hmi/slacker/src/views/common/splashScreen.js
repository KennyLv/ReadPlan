define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        images: {
            slacker: 'file:///slacker/images/splash-screen.png',
            surface: 'file:///slacker/images/black-bg-32-bit.png'
        },

        init: function (options) {
            this.display = options.display;
        },

        render: function () {
            this.template = this.generateTemplate();
            this.display.updateScreen(this.template);
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-8',
                systemHeader: true,
                loadingType: 3,
                backgroundImage: this.images.surface,
                templateContent: {
                    main: {
                        text: {
                            1: $.t('connecting')
                        },
                        images: {
                            1 : this.images.slacker
                        }
                    }
                }
            };
        }

    });
});