define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        events: {
            close: 'close',
            previous: 'previous',
            next: 'next',
            banTrack: 'banTrack',
            banArtist: 'banArtist'
        },

        images: {
            close: 'file:///slacker/images/close_btn.png',
            surface: 'file:///slacker/images/surface.png',
            previous: 'file:///slacker/images/player/player_btn_prev.png',
            previousDisabled: 'file:///slacker/images/player/player_btn_prev_disabled.png',
            next: 'file:///slacker/images/player/player_btn_next.png',
            defaultArt: 'file:///slacker/images/player/default_art.png',
            skipLimited: 'file:///slacker/images/player/skip/<%= skipNumber %>.png',
            skipDisabled: 'file:///slacker/images/player/player_btn_next_disabled.png',
            skipZeroDisabled: 'file:///slacker/images/player/skip/0_disabled.png'
        },

        init: function (options, model) {
            this.template = {};
            this._super(options.display, {useButtonsBranding: true});
            this.model = model;
            this.display = options.display;
            this.config = options.config;
            this.API_COMMANDS = model.API_COMMANDS;
            this.initButtons();
        },

        initButtons: function () {

            var skipsLeft = this.model.getSkipsLeft(),
                canSkip = this.model.canSkip(),
                nextImage = this.model.isBasicUser() ?
                    _.template(this.images.skipLimited, {skipNumber: skipsLeft}) :
                    this.images.next,
                isArtistBanEnabled = !this.model.isArtistBanned(),
                isTrackBanEnabled = !this.model.isTrackBanned(),
                isPremiumUser = this.model.isPremiumUser();


            this.buttons = {

                close: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                },

                previous: {
                    2: {
                        action: isPremiumUser ? this.events.previous : '',
                        stateEnabled:  isPremiumUser ? true : false,
                        image: {
                            "normal" : isPremiumUser ? this.images.previous : this.images.previousDisabled
                        },
                        value: 'Prev'
                    }
                },

                next: {
                    2: {
                        action: this.events.next,
                        stateEnabled: canSkip,
                        image: {
                            "normal" : canSkip ? nextImage : (this.model.isBasicUser() ?
                                this.images.skipZeroDisabled : this.images.skipDisabled )
                        },
                        value: 'Next'
                    }
                },

                banTrack: {
                    3: {
                        action: isTrackBanEnabled ? this.events.banTrack : this.events.close,
                        stateEnabled: isTrackBanEnabled,
                        text: $.t('popups.buttons.banTrack'),
                        value: this.API_COMMANDS.BAN_SONG
                    }
                },
                banArtist: {
                    4: {
                        action: isArtistBanEnabled ? this.events.banArtist : this.events.close,
                        stateEnabled: isArtistBanEnabled,
                        text: $.t('popups.buttons.banArtist'),
                        value: this.API_COMMANDS.BAN_ARTIST
                    }
                }

            };
        },

        _render: function (options) {
            options = options || {};
            if (options.delay) {
                _.delay(this._triggerClose.bind(this), options.delay);
            }

            this.template = this.generateTemplate(options);
            this.updateScreen(this.template);
        },

        _triggerClose: function () {
            this.display.trigger(this.events.close);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        /**
         *
         * @param labels
         * @example ['label1', 'label2']
         */
        getLabels: function (labels) {
            return labels.reduce(function (memo, value, key) {
                memo[key + 1] = value;
                return memo;
            }, {});
        },

        generateTemplate: function (options) {
            return {
                templateId: 'vp2c-7',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    main: {
                        text: this.getLabels(options.labels),
                        images: {
                            1: options.image ? options.image : this.images.defaultArt
                        }

                    },
                    buttons: this.getButtons(options.buttons)
                }
            };
        }

    });
});