define(['slacker_di', 'aq/dic', 'aq/mixins/events'], function (dic, aq, events) {
    'use strict';

    var Logger = aq.get('Logger'),
        logger = new Logger('med', 'WEB_VIEW', '[Slacker]');

    logger.log('Slacker loaded');

    var app = _.extend({

        init: function () {
            this.audioFocus = aq.get('audio');
            this.router = dic.get('router');
            this.router.on('close', this._close, this);
            this.router.on('suspend', this._suspend, this);
            return this;
        },

        start: function () {
            this.audioFocus.on('audioFocus', this.onAudioFocus, this);
            this.audioFocus.focus();
        },
        
        onAudioFocus: function(data){
            if(data.status){
                this.audioFocus.off('audioFocus');
                this.router.start();
            }
        },

        /**
         * To be called from outside (from appManager)
         */
        onSuspend: function () {
            // invoke suspend method in all created modules by this application
            this.audioFocus.off('audioFocus');
            dic.suspend();
        },

        _suspend: function () {
            // notify appManager to suspend this application and show home screen
            this.trigger('suspend');
        },

        /**
         * To be called from outside (from appManager)
         */
        onClose: function () {
            // invoke close method in all created modules by this application
            dic.close();
        },

        _close: function () {
            // notify appManager to close this application and show home screen
            this.trigger('close');
        }

    }, events);

    return app.init();
});