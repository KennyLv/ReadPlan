define(['slacker/models/constants'], function (Constants) {
    'use strict';

    var apiCommands = Constants.API_COMMANDS;

    var myMusicConfig = {

        getMyMusicConfig: function() {
            var myMusicConfig = {};

            myMusicConfig[apiCommands.GET_RECENTLY_PLAYED] = {
                key : 'recently_played',
                title: $.t('myMusicList.RecentlyPlayed')
            };

            myMusicConfig[apiCommands.GET_MY_STATIONS] = {
                key : 'mystations',
                title: $.t('myMusicList.MyStations')
            };

            myMusicConfig[apiCommands.GET_MY_PLAYLISTS] = {
                key : 'myplaylist',
                title: $.t('myMusicList.MyPlaylists')
            };

            myMusicConfig[apiCommands.GET_BOOKMARKED_ARTISTS] = {
                key :"bookmarked_artists",
                title: $.t('myMusicList.BookmarkedArtists')
            };

            myMusicConfig[apiCommands.GET_BOOKMARKED_ALBUMS] = {
                key : 'bookmarked_albums',
                title: $.t('myMusicList.BookmarkedAlbums')
            };

            myMusicConfig[apiCommands.GET_BOOKMARKED_STATIONS] = {
                key : 'bookmarked_stations',
                title: $.t('myMusicList.BookmarkedStations')
            };

            return myMusicConfig;
        }
    };

    return myMusicConfig;
});
