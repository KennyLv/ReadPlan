define(function () {
    'use strict';

    return {
        appName: 'slacker'
    };

});