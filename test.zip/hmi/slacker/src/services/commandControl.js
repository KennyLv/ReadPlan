define(['aq/api/commandControl', 'slacker/models/constants', 'aq/constants'],
    function (CommandControl, Constants, platformConstants) {
    'use strict';

    var ERROR_CODES = {
        GENERIC_ERROR: 173000
    };

    return CommandControl.extend({

        systemEvents: {
            buttonEvent:  'buttonEvent'
        },

        init: function (transport, FrameHandler) {
            this.FrameHandler = FrameHandler;
            this.appName = "com.slacker.radio.Slacker";
            this.contentType = "application/JSON";
            this._initTransport(transport);
            this.ERRORS = Constants.ERRORS;
        },

        stopListening: function () {
            // todo
        },

        /**
         * trigger content-type (example 'image/jpeg') in case of payload
         * @param content
         * @param response
         */
        onAsyncEvent: function (content, response) {
            var event = content.event ||
                (response.headers && (
                    response.headers['content-type'] || response.headers['Content-Type']
                ));
            this.trigger(event, content);
        },

        handleNotification: function (notification, response) {
            //todo fix if
            if (response && response.headers &&
                (((response.headers['App-Name'] || response.headers['app-name']) === this.appName.toLowerCase()) ||
                    ((response.headers['App-Name'] || response.headers['app-name']) === this.appName))) {
                this.onAsyncEvent(response.content, response);
            } else if (notification.error && notification.error.code === ERROR_CODES.GENERIC_ERROR) {
                //todo handle MEHA not installed error
                this.trigger('generic_error',
                    {
                        error_code: this.ERRORS.SERVICE_UNAVAILABLE,
                        success: 'false',
                        control: ''
                    });
            } else if (notification.control === 'GetPlayState') {
                response = this._serializeToAsyncEvent(notification);
                this.onAsyncEvent(response.content, response);
            } else if (response && response.content && response.content.type) {
                    var notificationName = response.content.type;
                    if (this.systemEvents[notificationName]) {
                        this._handleSystemNotification(notificationName, response);
                    }
                }
        },

        _handleSystemNotification: function(notificationName, response) {
            var buttonEventName = platformConstants.HARD_KEYS[response.content.data.buttonId];

            this.trigger(buttonEventName ? buttonEventName : notificationName, response.content.data);
        },

        /**
         * @param controlList (array) - Slacker api controls
         * @returns deffered object
         */
        when: function (controlList) {
            var deferredList = [];

            _.each(controlList, function (control) {
                deferredList.push(this.sendCommand({'control': control}));
            }, this);

            return $.when.apply(null, deferredList);
        },

        /**
         * Terminate all current requests for appName if specified or all current commands
         * May be used when application changes route or shutting down
         */
        abortApplicationRequests: function(){
            this._transport.abortRequests();
        },


        /*
        *
        * is needed for GetPlayState
        * can be extended in future to module
        *
        * @param {Object}
        *
        * {
        *  "lengthSecs": {Number},
        *  "positionSecs": {Number},
        *  "control": {String},
        *  "trackID": {Number},
        *  "playState": {String},
        *  "success": {String},
        * }
        */
        _serializeToAsyncEvent: function (data) {
            var returnObj = {};

            data.event = "AsyncMsg";
            returnObj.content = data;

            return returnObj;
        }
    });
});
