requirejs.config({

    baseUrl: "./",

    paths: {
        jquery: "../platform/core/lib/jquery/jquery"
    },

    findNestedDependencies: true,
    useStrict: true,
    removeCombined: true,
    skipSemiColonInsertion: true,

    // exclude
    // shared/utils, shared/thor_interface, aq and jquery because they are already included into AQ
    excludeList: [
        "aq",
        "shared/utils",
        "shared/thor_interface",
        "jquery"
    ],

    onBuildWrite: function (moduleName, path, contents) {
        var isExcluded = this.excludeList.some(function (path) {
            return new RegExp(path).test(moduleName);
        });
        return isExcluded ? "" : contents;
    },

    packages: [{
        name: "slacker",
        main: "app.js",
        location: "src"
    }, {
        name: "shared",
        location: "../platform/core/modules/shared"
    }, {
        name: "aq",
        location: "../platform/core/src"
    }, {
        name: 'common',
        location: '../common'
    }]
});
