Pandora handset application

- Application wireframes can be found here - https://airbiq.atlassian.net/wiki/download/attachments/20152642/VP2C%20Pandora%20wireframes_final_v1.pdf?api=v2

- API documentation can be found here - https://airbiq.atlassian.net/wiki/display/SVP2C/Pandora

- 3rd party application can be found here - https://www.dropbox.com/sh/qkf2w3abqiuvj36/rJmLUylgp6
