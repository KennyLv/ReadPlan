define(['aq', 'common/view/base'], function (aq, BaseView) {
    "use strict";

    describe("Demo Suit", function () {
        it("should work", function () {
            expect(true).to.be.true;
        });

        it('should see module', function () {
            expect(aq.title).to.eql('Works!');
        });
    });

    describe("Base View Class", function () {
        var aView,
            displayMock = {};
    
        beforeEach(function () {
            aView = new BaseView(displayMock);
        });
    
        it("should not apply brandings by default", function () {
            expect(aView.useButtonsBranding).to.be.true;
        });
    });
});
