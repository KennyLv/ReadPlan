define('pandora/router',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (options) {

            this.routes = {
                'show:stationCreate': this.goToCreateStation,
                'show:stationList': this.goToMyStations,
                'show:playerScreen': this.goToPlayer,
                'close': this._onClose,
                'suspend': this._onSuspend
            };

            this.dic = options.dic;
            this.model = options.model;
            this.Splash = options.SplashScreen;
        },

        start: function () {
            this.showSplashScreen();

            // expected to be fired on session start or resume
            this.listenTo(this.model, {
                'show:stationCreate': this.goToCreateStation,
                'show:stationList': this.goToMyStations,
                'show:playerScreen': this.goToPlayer,
                'show:errorStatus': this.onError.bind(this)
            });

            // try to resume session or start new one
            this.model.initSession();
            this.model.setPreloadStationList(false);
        },

        showSplashScreen: function () {
            this.splash = this.splash || new this.Splash();
            this.splash.render(this.showSplashScreenTimeoutPopup.bind(this));
        },

		showSplashScreenTimeoutPopup: function() {
			var code = 4, // generic error
				popup = new (this.dic.get('Popup'))(),
				buttons = [popup.buttons.exit];

			popup.render({
				title: $.t(['status', code, 'title'].join('.')),
				text: $.t(['status', code, 'text'].join('.')),
				buttons: buttons
			});

			this.listenToOnce(popup.display, popup.events.close, this._onClose);
		},

		clearSplashScreenTimeout: function () {
			if(this.splash) {
				this.splash.clearSplashTimeout();
			}
		},

        navigate: function (name) {
            if (this.routes[name]) {
                //unbind event on starting controller
                this.model.off('show:errorStatus');
                this.stopListening();
                this.routes[name].apply(this, Array.prototype.slice.call(arguments, 1));
            }
        },

        /**
         * To be called from outside (from appEntry point)
         */
        suspend: function () {
            this._unbindErrorEvents();
            this.stopListening();
        },

        /**
         * To be called from outside (from appEntry point)
         */
        close: function () {
            this.suspend();
            this.model.eventSessionTerminate();
        },

        /**
         * Unbind events to avoid triggering while running another application
         * @private
         */
        _unbindErrorEvents: function () {
            this.clearSplashScreenTimeout();
            this.model.off('show:errorStatus');
            this.model.commandControl.off('error');
            this.model.commandControl.off('headUnitConnectionState');
        },

        _onSuspend: function () {
            this.trigger('suspend');
        },

        _onClose: function () {
            this.trigger('close');
        },

        /**
         * Error status popup for unlogged user.
         * @param {string|number} code
         */
        onError: function (code) {
            var userNotLoggedIn = 9;
            if (+code !== userNotLoggedIn) {
                return;
            }

            var popup = new (this.dic.get('Popup'))(),
                buttons = [popup.buttons.exit];

            this.clearSplashScreenTimeout();

            // add additional button and disable accessory mode
            this.suspend();
            this.model.eventSessionTerminate();

            popup.render({
                title: $.t(['status', code, 'title'].join('.')),
                text: $.t(['status', code, 'text'].join('.')),
                buttons: buttons
            });

            this.listenToOnce(popup.display, popup.events.close, this._onClose);
        },

        goToCreateStation: function () {
            //on first launch when there are no stations
            //this route will be triggered first
            //omitting navigate() method with stopListening()
            //and if stopListening() was not called before going here
            //then on selecting any new station PandoraViewWrapper
            //will trigger 2 events 'show:stationList' and 'show:playerScreen'
            //which will lead to app crash,
            //because router is still listening to both routes
            this.stopListening();
            var controller = this.dic.get('controller/createStation');

			this.clearSplashScreenTimeout();

            /**
             * on station create - goToPlayer
             * on go back - goToMyStations
             * on cancel (no stations pop-up) - _onClose
             */
            this.listenTo(controller, 'all', this.navigate);
            controller.start();
        },

        goToMyStations: function () {
            var controller = this.dic.get('controller/myStations');

			this.clearSplashScreenTimeout();

            /**
             * on now playing,on go back - goToPlayer
             * on create station - goToCreateStation
             */
            this.listenTo(controller, 'all', this.navigate);
            controller.start();
        },

        goToPlayer: function (options) {
            var controller = this.dic.get('controller/player');

			this.clearSplashScreenTimeout();

            /**
             * on my stations - goToMyStations
             * on media source - _onSuspend
             */
            this.listenTo(controller, 'all', this.navigate);
            controller.start(options);
        }
    });

});