define('pandora/views/myStations',['pandora/views/common/list'], function (List) {
    'use strict';

    return List.extend({

        init: function (options, model) {

            this._super(options, model);

            this.events = _.extend({
                createStation: 'createStation',
                sortBy: 'onSortBy',
                removeStation: 'onRemoveStation',
                onAlphaJump: 'onAlphaJump'
            }, this.events);

            this.images = _.extend({
                // station icons
                shared: 'file:///pandora/images/stations/shared.png',
                shuffle: 'file:///pandora/images/stations/shuffle.png',
                active: 'file:///pandora/images/stations/playing.png',
                delete: 'file:///pandora/images/stations/delete.png',
                createStation: 'file:///pandora/images/stations/buttons/createStation.png',
                removeStation: 'file:///pandora/images/stations/buttons/removeStation.png',
                sortBy: 'file:///pandora/images/stations/buttons/sortBy/<%= code %>.png',
                alphaJump: 'file:///pandora/images/stations/sidebtn_icon-alpha_jump.png',
                alphaJumpDisabled: 'file:///pandora/images/stations/sidebtn_icon-alpha_jump_disabled.png'
            }, this.images);

            this.config = options.config;
        },

        _render: function (options) {
            options = options || {};
            if (options.items && !this._isThereInfoToDisplay(options.items))
            {
                return false;
            }

            this.isBackBtnDisabled = options.disableBackBtn || false;
            this.template = this.generateTemplate(options);

            if(this.updateScreen(this.template)) {
                // if we came here from player screen fetch stations manually
                if (this.model.getCurrentStatus() !== this.model.constants.status.PNDR_STATUS_NO_STATION_ACTIVE) {
                    this.model.eventStationList();
                }
            }

            this.startListening();
        },

        getButtons: function () {
            var buttons = this._super();
            return _.extend(buttons, {
                2: {
                    image: {
                        normal: this.images.createStation
                    },
                    action: this.events.createStation
                },
                3: {
                    image: {
                        normal: this.images.removeStation
                    },
                    action: this.events.removeStation
                },
                7: this.getSortOrderButton(),
                8: this.getABCJumpButton()
            });
        },

        getSortOrderButton: function () {
            //because there's no guarantee that pandora would not want to change it back
            var sortOrder = Number(!this._getSortOrder());
            return {
                image: {
                    normal: _.template(this.images.sortBy, {code: sortOrder})
                },
                action: this.events.sortBy
            };
        },

        getBackButton: function () {
            var isStationPlaying = this.model.isStationSet();
            return {
                image: {
                    normal: isStationPlaying ? this.images.back : this.images.backDisabled
                },
                action: this.events.goBack,
                stateEnabled: isStationPlaying
            };
        },

        getABCJumpButton: function () {
            var sortOrder = this._getSortOrder();
            var isEnabled = sortOrder === 1;
            return {
                image: {
                    normal: isEnabled ? this.images.alphaJump : this.images.alphaJumpDisabled
                },
                action: this.events.onAlphaJump,
                stateEnabled: isEnabled
            };
        },

        getItemRightImage: function (item, options) {
            return this._getStationIcon(item, options.active);
        },

        _getStationIcon: function (station, active) {
            active = _.isUndefined(active) ? null : active;

            return station.stationToken === active ? this.images.active :
                station.isShared ? this.images.shared :
                    station.isQuickMix ? this.images.shuffle : 0;
        },

        _getSortOrder: function () {
            return _.isNumber(this.model.getStationsOrder()) ? this.model.getStationsOrder() : 0;
        },

        player: function () {
            this.trigger('player');
        },

        createStation: function () {
            this.trigger('createStation');
        },

        sortBy: function () {
            this.trigger('onSortBy');
        },

        removeStation: function () {
            this.trigger('onRemoveStation');
        }
    });
});
