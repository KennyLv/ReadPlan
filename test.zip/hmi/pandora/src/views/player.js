define('pandora/views/player',['common/view/base', 'aq/dic'], function (View, aq) {
    'use strict';

    var ProgressCounter = aq.get('progressCounter'),
        progressCounter = new ProgressCounter();

    return View.extend({

        events: {
            goToMyStations: 'goToMyStations',
            likeSong: 'likeSong',
            dislikeSong: 'dislikeSong',
            skipSong: 'skipSong',
            bookmark: 'bookmark',
            play: 'play',
            pause: 'pause',
            source: 'source',
            onSuspend: 'onSuspend'
        },

        images: {
            surface: 'file:///pandora/images/surface.png',
            logo: 'file:///pandora/images/pandora.png',
            header: 'file:///pandora/images/player/header.png',
            shared: 'file:///pandora/images/stations/shared.png',
            shuffle: 'file:///pandora/images/stations/shuffle.png',
            thumbsUp: 'file:///pandora/images/player/tup/<%= code %>.png',
            thumbsDown: 'file:///pandora/images/player/tdown/<%= code %>.png',
            myStations: 'file:///pandora/images/player/stations.png',
            skip: 'file:///pandora/images/player/skip.png',
            skipDisabled: 'file:///pandora/images/player/skip_disabled.png',
            bookmarkSelected: 'file:///pandora/images/player/bookmark_selected.png',
            bookmarkUnselected: 'file:///pandora/images/player/bookmark_unselected.png',
            bookmarkDisabled: 'file:///pandora/images/player/bookmark_disabled.png',
            play: 'file:///pandora/images/player/play.png',
            pause: 'file:///pandora/images/player/pause.png',
            source: 'file:///pandora/images/player/source.png'
        },

        init: function (options, model) {
            this.stationInfo = null;
            this.trackInfo = null;
            this.isPlaying = model.isPlaying();
            this.template = {};
            this.display = options.display;
            this.model = model;

            // todo need to take attention
            model.on('update:trackInfo', this.setTrackInfo, this);
            model.on('update:activeStationInfo', this.setStationInfo, this);

            this._super(options.display, {useButtonsBranding: true});

            this.config = options.config;
        },

        onSuspend: function () {
            this.unbindScrollEvent();
            this.trigger(this.events.onSuspend);
        },

        suspend: function () {
            progressCounter.off();
        },

        _render: function (options) {
            options = options || {};
            this.template = this.generateTemplate(options);
            this.start();
        },

        start: function () {
            //returns true if template is uniq
            this.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {

            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);

            this.bindScrollEvent();

            this.listenToOnce(this.display, this.display.getScrollEventName(), this.goToMyStations);
            this.listenToOnce(this.display, this.display.getEnterEventName(), this.goToMyStations);
            this.listenToOnce(this.display, this.display.getSeekUpEventName(), this.onSeekUpPressed);
        },

        resetProgressCounter : function() {
            progressCounter.reset();
        },

        onSeekUpPressed: function(){
            this.skipSong();
        },

        setIsPlaying: function (isPlaying) {
            this.isPlaying = _.isBoolean(isPlaying) ? isPlaying : this.isPlaying;
        },

        setTrackInfo: function (info) {
            this.trackInfo = info;
            this.isPlaying = this.model.isPlaying();
            if(_.isFinite((+info.duration) * (+info.elapsed))) {
                progressCounter.start({
                    elapsedTime: info.elapsed,
                    totalTime: info.duration
                });
            } else {
                this.resetProgressCounter();
            }
        },

        setStationInfo: function (info) {
            if (this.stationInfo && !_.isEqual(this.stationInfo.stationId, info.stationId)) {
                this.resetProgressCounter();
            }
            this.stationInfo = info;
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-2',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header
                    },
                    buttons: _.extend(this.getButtons(), {
                        7: {
                            image: this.images.source,
                            action: this.events.source
                        }
                    }),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: this.getProgressBar()
                }
            };
        },

        getText: function () {
            return _.extend(
                this.getStationName(),
                this.getTrackAndArtistNames()
            );
        },

        getStationName: function () {
            return {
                1: {
                    text: this.stationInfo ? this.stationInfo.stationName : ''
                }
            };
        },

        getTrackAndArtistNames: function () {
            var isAudioAd = this.model.getTrackInfo() &&
                this.trackInfo && this.trackInfo.getIsAudioAd();
            return isAudioAd ? {
                2: {
                    text: ''
                },
                3: {
                    text: $.t('audioAddMessage')
                }
            } : {
                2: {
                    text: this.model.getTrackInfo() ? this.model.getTrackTitle() : ''
                },
                3: {
                    text: this.model.getTrackInfo() ? this.model.getArtistName() : $.t('loading')
                }
            };
        },

        getButtons: function () {
            return {
                1: this.getMyStationsButton(),
                2: this.getThumbUpButton(),
                3: this.getThumbDownButton(),
                4: this.getPlayToggleButton(),
                5: this.getSkipButton(),
                6: this.getBookmarkButton()
            };
        },

        getMyStationsButton: function () {
            return {
                image: {
                    normal: this.images.myStations
                },
                action: this.events.goToMyStations
            };
        },

        /**
         *
         * @returns {Object}
         */
        getThumbUpButton: function () {
            var rating = this.trackInfo ? (this.trackInfo.getAllowRating() && this.trackInfo.getRating()) : false;

            return _.isNumber(rating) ? {
                image: {
                    normal: _.template(this.images.thumbsUp, {code: 1 & rating}),
                    pressed: 0
                },
                action: this.events.likeSong
            } : {
                image: {
                    normal: _.template(this.images.thumbsUp, {code: 'disabled'}),
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        /**
         *
         * @return {Object}
         */
        getThumbDownButton: function () {
            var rating = this.trackInfo ?  (this.trackInfo.getAllowRating() && this.trackInfo.getRating()) : false;
            return _.isNumber(rating) ? {
                image: {
                    normal: _.template(this.images.thumbsDown, {code: 2 & rating}),
                    pressed: 0
                },
                action: this.events.dislikeSong
            } : {
                image: {
                    normal: _.template(this.images.thumbsDown, {code: 'disabled'}),
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        getSkipButton: function () {
            var isSkippEnabled = this.trackInfo ? this.trackInfo.getAllowSkip() : false;
            return {
                image: {
                    normal: isSkippEnabled ? this.images.skip : this.images.skipDisabled,
                    pressed: 0
                },
                action: this.events.skipSong,
                stateEnabled: isSkippEnabled
            };
        },

        getBookmarkButton: function () {
            var isBookmarkEnabled = this.trackInfo && this.trackInfo.getAllowBookmark();

            if (isBookmarkEnabled) {
                var isBookmarked = this.trackInfo.getIsTrackBookmarked();
                return {
                    image: {
                        normal: isBookmarked ? this.images.bookmarkSelected : this.images.bookmarkUnselected,
                        pressed: 0
                    },
                    action: this.events.bookmark,
                    stateEnabled: isBookmarkEnabled
                };
            }

            return {
                image: {
                    normal: this.images.bookmarkDisabled,
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        getProgressBar: function () {
            var duration = this.trackInfo && progressCounter.getTotalTime(),
                elapsed = this.trackInfo && progressCounter.getElapsedTime();

            return (_.isNumber(duration) && _.isNumber(elapsed) && elapsed !== duration) ? {
                total: duration,
                elapsed: elapsed,
                color: '#00ADEF',
                active: this.isPlaying
            } : {};

        },

        getPlayToggleButton: function () {
            var isPlaying = this.model.isPlaying();
            return {
                image: {
                    normal: isPlaying ? this.images.pause : this.images.play,
                    pressed: 0
                },
                action: isPlaying ? this.events.pause : this.events.play
            };
        },

        getImages: function () {
            var isAudioAd = this.trackInfo && this.trackInfo.getIsAudioAd();
            return {
                1: isAudioAd ? this.images.logo : (this.model.getAlbumArt() || this.images.logo),
                2: this.getStationTypeImage()
            };
        },

        getStationTypeImage: function () {
            var info = this.stationInfo || {};
            return info.isQuickMix ? this.images.shuffle :
                info.isShared ? this.images.shared : 0;
        },

        /**
         * On go to my station click
         */
        goToMyStations: function () {
            this.unbindScrollEvent();
            this.trigger(this.events.goToMyStations);
        },

        /**
         * On thumbs on click
         */
        likeSong: function () {
            this.trigger('likeSong');
            this.trackInfo.setRating(1);
            this.render();
        },

        /**
         * On thumbs down click
         */
        dislikeSong: function () {
            this.trigger('dislikeSong');
            this.trackInfo.setRating(2);
            this.render();
        },

        /**
         * On skip track click
         */
        skipSong: function () {
            this.trigger('skipSong');
        },

        /**
         * On add to bookmark click
         */
        bookmark: function () {
            this.trigger('bookmark');
            this.trackInfo.setIsTrackBookmarked(true);
            this.render();
        },

        /**
         * On play click
         */
        play: function () {
            this.isPlaying = true;
            this.trigger('play');
            progressCounter.on();
        },

        /**
         * On pause click
         */
        pause: function () {
            this.isPlaying = false;
            this.trigger('pause');
            progressCounter.off();
        },

        /**
         * On source button press
         * Go to source screen
         */
        source: function () {
            this.display.showMediaSourceScreen();
        },

        /**
         * switch to paused state on unknown or network error
         */
        toggleErrorState: function() {
            this.model.forcePausedState();
            progressCounter.off();
            this.isPlaying = false;
            this._render();
        }
    });
});