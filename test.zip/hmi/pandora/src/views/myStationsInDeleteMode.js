define('pandora/views/myStationsInDeleteMode',['pandora/views/myStations'], function (MyStations) {
    'use strict';

    return MyStations.extend({

        init: function (options, model) {
            this._super(options, model);

            this.events = _.extend({
                delete: 'onDelete'
            }, this.events);

            this.config = options.config;
        },

        getItems: function (items, options) {
            options.event = this.events.delete;
            return this._super(_.where(items, {isQuickMix: false}), options);
        },

        getItemRightImage: function () {
            return this.images.delete;
        },

        getBackButton: function () {
            return {
                image: {
                    normal: this.images.back
                },
                action: this.events.goBack
            };
        },

        getButtons: function () {
            return {
                1: this.getBackButton(),
                4: this.getNowPlayingButton(),
                7: this.getSortOrderButton(),
                8: this.getABCJumpButton()
            };
        },

        delete: function (item) {
            this.trigger(this.events.delete, item);
        }

    });
});
