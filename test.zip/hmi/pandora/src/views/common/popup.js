define('pandora/views/common/popup',['common/view/base'], function (View) {
    'use strict';

    return View.extend({

        events: {
            close: 'close',
            retry: 'retry',
            // todo rename createStation and deleteStation to confirm
            createStation: 'createStation',
            deleteStation: 'deleteStation'
        },

        images: {
            close: 'file:///pandora/images/close.png',
            surface: 'file:///pandora/images/surface.png'
        },

        init: function (options) {
            this.initButtons();
            this.template = {};
            this._super(options.display, { useButtonsBranding: true });

            this.config = options.config;
        },

        initButtons: function () {
            this.buttons = {

                exit: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                },

                retry: {
                    3: {
                        action: this.events.retry,
                        text: $.t('buttons.retry')
                    }
                },

                cancel: {
                    3: {
                        action: this.events.close,
                        text: $.t('buttons.cancel')
                    }
                },

                createStation: {
                    2: {
                        action: this.events.createStation,
                        text: $.t('buttons.next')
                    }
                },

                deleteStation: {
                    2: {
                        action: this.events.deleteStation,
                        text: $.t('buttons.delete')
                    }
                }

            };
        },

        _render: function (options) {
            this.text = options.text;
            this.title = options.title;

            this.template = this.generateTemplate(options.buttons);
            this.updateScreen(this.template);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp2c-1',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }

    });
});