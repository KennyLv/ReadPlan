define('pandora/views/common/list',['common/view/baseListView'], function (BaseListView) {
    'use strict';

    return BaseListView.extend({

        events: {
            goBack: 'goBack',
            select: 'select',
            player: 'player'
        },

        images: {
            back: 'file:///pandora/images/back.png',
            backDisabled: 'file:///pandora/images/back_disabled.png',
            folder: 'file:///pandora/images/folder.png',
            player: 'file:///pandora/images/stations/buttons/nowPlaying.png',
            playerDisabled: 'file:///pandora/images/stations/buttons/nowPlaying_disabled.png',
            surface: 'file:///pandora/images/surface.png',
            keyboardPressedId1: 'file:///pandora/images/buttons/pressed/56x56.png',
            keyboardPressedId2: 'file:///pandora/images/buttons/pressed/75x52.png'
        },

        init: function (options, model) {
            this._super(options.display, model);
            this.template = {};

            this.config = options.config;
        },

        _render: function (options) {
            options = options || {};
            if (options.items && !this._isThereInfoToDisplay(options.items))
            {
                return;
            }

            this.isBackBtnDisabled = options.disableBackBtn || false;
            this.template = this.generateTemplate(options);
            this.updateScreen(this.template);
            this.startListening();
        },

        showKeyboard: function() {
            this._super(this.images.keyboardPressedId1, this.images.keyboardPressedId2);
        },

        setTitle: function (title) {
            this.title = title;
        },

        generateTemplate: function (options) {
            var listItems = this.getItems(options.items, {active: options.activeStationToken}),
                selectedListItem = _.isNumber(this.getSelectedListItem()) && this.getSelectedListItem();

            if (selectedListItem && listItems.length >= selectedListItem) {
                listItems.activeListItem = selectedListItem;
            }

            return {
                templateId: 'vp2c-3',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: {
                        text: this.title || ''
                    },
                    list: listItems,
                    buttons: this.getButtons()
                }
            };
        },

        /**
         *
         * @param items {Array}
         * @param options {Object}
         * @returns {Array}
         */
        getItems: function (items, options) {
            items = _.isArray(items) ? items : [];

            return items.map(function (item) {
                return {
                    text: item.text,
                    image1: this.getItemLeftImage(item),
                    image2: this.getItemRightImage(item, options),
                    action: options.event || this.events.select,
                    value: item
                };
            }, this);
        },

        getItemLeftImage: function (item) {
            return item.hasChildren ? this.images.folder : 0;
        },

        getItemRightImage: function () {
            return 0;
        },

        getButtons: function () {
            return {
                1: this.getBackButton(),
                4: this.getNowPlayingButton()
            };
        },

        getBackButton: function () {
            return {
                image: {
                    normal: this.isBackBtnDisabled ? this.images.backDisabled : this.images.back
                },
                action: this.events.goBack,
                stateEnabled: !this.isBackBtnDisabled
            };
        },

        getNowPlayingButton: function () {
            var isStationPlaying = this.model.isStationSet();
            return {
                image: {
                    normal: isStationPlaying ? this.images.player : this.images.playerDisabled
                },
                action: this.events.player,
                stateEnabled: isStationPlaying
            };
        },

        player: function (item) {
            this.trigger('player', item);
        },

        select: function (item) {
            this.trigger('select', item);
        },

        goBack: function (item) {
            //checking if app back button is disabled while pressing hardware back button
            if (!this.isBackBtnDisabled) {
                this.trigger('goBack', item);
            }
        }

    });
});
