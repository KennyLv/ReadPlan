define('pandora/views/common/splashScreen',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        images: {
            pandora: 'file:///pandora/images/splash_screen.png',
            surface: 'file:///pandora/images/black-bg-32-bit.png'
        },

        init: function (options) {
            this.display = options.display;
        },

        render: function (timeoutCallback) {
            this.template = this.generateTemplate();
            this.display.updateScreen(this.template);

            if (typeof timeoutCallback === "function") {
                this.clearSplashTimeout();
                this.splashTimeout = setTimeout(timeoutCallback, 30 * 1000);
            }
        },

        clearSplashTimeout: function () {
            if (!this.splashTimeout) {
                return;
            }

            clearTimeout(this.splashTimeout);
            delete this.splashTimeout;
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-8',
                systemHeader: true,
                loadingType: 3,
                backgroundImage: this.images.surface,
                templateContent: {
                    main: {
                        text: {
                            1: $.t('connecting')
                        },
                        images: {
                            1: this.images.pandora
                        }
                    }
                }
            };
        }

    });
});