define('pandora/services/commandControl',['aq/api/commandControl', 'aq/constants'], function (CommandControl, constants) {
    'use strict';

    return CommandControl.extend({

        events: {
            headUnitConnectionState:   'headUnitConnectionState',
            buttonEvent:               'buttonEvent'
        },

        init: function (transport, FrameHandler) {
            this.FrameHandler = FrameHandler;
            this.appName = "pandora";
            this.contentTransferEncoding = "base64";
            this.contentType = "application/octet-stream";

            this._initTransport(transport);
        },

        /**
         * Required by PandoraLink
         * @param callbackObj
         */
        setCallback: function (callbackObj) {
            this.callbackObj = callbackObj;
        },

        /**
         * Required by PandoraLink
         * Start/Open the communication channel
         */
        startComm: function () {
            this.callbackObj.onOpen();
        },

        /**
         * Required by PandoraLink
         *
         * @param payload {Payload}
         */
        sendPayload: function (payload) {
            var frame = this.FrameHandler.frameBytesForPayload(payload);
            return this.sendCommand(frame);
        },

        sendCommand: function (frame) {
            var requestData = this.byte2HexString(frame);
            var data = this.hexToBase64(requestData);
            return this._super(data)
                .fail(function () {
                    this.trigger('error', 'no response');
                }.bind(this));
        },

        onAsyncEvent: function (data) {
            var payload = this.base64ToArray(data);
            this.callbackObj.onReceiveFrame(payload);
        },

        handleNotification: function (notification, response) {
            if (response) {
                if (response.headers &&
                    (response.headers['App-Name'] || response.headers['app-name']) === this.appName.toLowerCase()) {
                    this.onAsyncEvent(response.content.trim());
                }

                var notificationName = response.content && response.content.type;
                if (notificationName) {
                    if (this.events[notificationName]) {
                        this._handleSystemNotification(notificationName, response);
                    }
                }
            }
        },

        _handleSystemNotification: function(notificationName, response) {
            var buttonEventName = constants.HARD_KEYS[response.content.data.buttonId];

            this.trigger(buttonEventName ? buttonEventName : notificationName, response.content.data);
        },

        byte2HexString : function (array) {
            return _.map(array, function (item) {
                var hexString = parseInt(item, 10).toString(16);
                return (hexString.length < 2 ? "0" + hexString : hexString).toUpperCase();
            }).join(" ");
        },

        hexToBase64: function (str) {
            if( typeof str === "undefined" || str === null || str.length === 0 ) {
                return false;
            }
            if(_.isArray(str)) {
                str = str.join(" ");
            }

            return window.btoa(String.fromCharCode.apply(
                null,
                str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")
            ));
        },

        base64ToArray: function (str) {
            return window.atob(str).split("").map(function (item) {
                return item.charCodeAt(0);
            });
        }

    });
});