define('pandora/controllers/common/controller',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';


    return EventEmitter.extend({
        init: function (options) {
            this.Popup = options.Popup;
            this.model = options.model;
            this.constants = this.model.constants;
            this.mainAction = options.mainAction;

            this.ignore = {
                notice: [],
                status: [
                    this.constants.status.PNDR_STATUS_PLAYING,
                    this.constants.status.PNDR_STATUS_PAUSED
                ]
            };

            this.model.commandControl.on('error', function () {
                // todo use another error message
                var genericError = 4;
                this.handleError(genericError);
            }.bind(this));
        },

        /**
         * Handle notice from Pandora
         * @param {string|number}notificationCode
         * @param {object} [options]
         * @param {number} options.delay
         * @param {function} options.action
         */
        handleNotice: function (notificationCode, options) {
            if(this.ignore.notice.indexOf(+notificationCode) > -1) {
                return;
            }

            options = options || {};

            var title = $.t(['notice', notificationCode, 'title'].join('.'), {defaultValue: $.t('status.4.title')}),
                text = $.t(['notice', notificationCode, 'text'].join('.'), {defaultValue: $.t('status.4.text')});

            this.showPopup(title, text, options.delay, options.action);
        },

        /**
         * Handle status from Pandora
         * @param {string|number} errorCode
         * @param {object} [options]
         * @param {number} options.delay
         * @param {function} options.action
         */
        handleError: function (errorCode, options) {
            if(this.ignore.status.indexOf(+errorCode) > -1) {
                return;
            }

            options = options || {};

            var title = $.t(['status', errorCode, 'title'].join('.'), {defaultValue: $.t('status.4.title')}),
                text = $.t(['status', errorCode, 'text'].join('.'), {defaultValue: $.t('status.4.text')});

            this.showPopup(title, text, options.delay, options.action);
        },

        showPopup: function (title, text, delay, action) {
            var popup = new this.Popup();

            action = action || this.mainAction.bind(this);

            popup.render({
                title: title,
                text: text,
                buttons: [popup.buttons.exit]
            });

            this.listenToOnce(popup.display, popup.events.close, action);

            if (delay) {
                _.delay(action, delay);
            }

            return popup;
        }
    });
});
