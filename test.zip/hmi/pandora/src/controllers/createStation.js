/**
 *  Create station by genre(select genre category, select genre)
 *
 * - create station pop-up
 * - select genre category view
 * - select genre view
 */
define('pandora/controllers/createStation',['pandora/controllers/common/controller'], function (ErrorHandler) {
    'use strict';

    return ErrorHandler.extend({

        init: function (options) {
            this._super(_.extend(options, {
                mainAction: this.showGenreCategoriesList
            }));
            this.model = options.model;
            this.constants = this.model.constants;

            this.List = options.List;
            this.Popup = options.Popup;

            this.views = [];

            this.notificationHandlers = {};

            this.notificationHandlers[this.constants.notice.PNDR_NOTICE_STATION_LIMIT_REACHED] = function() {
                return {
                    delay : 3000,
                    action : this.onGoToMyStations.bind(this)
                };
            }.bind(this);
        },

        start: function () {
            if (this._stationsListIsEmpty()) {
                this.showCreateStationPopup();
            } else {
                this.showGenreCategoriesList();
            }
        },

        startListening: function () {
            this.stopListening();
            // genre categories just fetched, update the view
            this.listenToOnce(this.model, 'update:categoryList', this.updateGenreCategoriesList);

            // genres fetched, update the view
            this.listenToOnce(this.model, 'update:categoryStationList', this.updateGenreList);
            this.listenTo(this.model, {
                'show:notice': this.handleNotice,
                'show:errorStatus': this.handleError,
                'hide:stationList': this.showStationCreatedPopup
            });
        },

        handleNotice: function (notificationCode) {
            var options = this.notificationHandlers[notificationCode] && this.notificationHandlers[notificationCode]();
            this._super(notificationCode, options);
        },

        suspend: function () {
            this._resetLists();
        },

        onSuspend: function () {
            this.trigger('close');
        },

        close: function () {
            this._resetLists();
        },

        onGoToPlayer: function () {
            this._resetLists();
            this.trigger('show:playerScreen');
        },

        onGoToMyStations: function () {
            this._resetLists();
            this.trigger('show:stationList');
        },

        onSelectGenreCategory: function (options) {
            var index = options.value.key,
                title = options.value.text;

            this.showGenreList(title, index);
        },

        onSelectGenre: function (options) {
            var stationIndex = options.value.key,
                categoryIndex = options.value.categoryIndex;

            if (_.isNumber(categoryIndex) && _.isNumber(stationIndex)) {
                // later PandoraLink will fire hide:stationList and show:playerScreen
                // or notice in case when station limit reached
                this.model.createGenreStation(categoryIndex, stationIndex);
            }
        },

        showPopup: function (title, text) {
            var popup = this._super(title, text);
            if (popup) {
                // automatically close in 3 seconds
                _.delay(popup.display.trigger.bind(popup.display, popup.events.close), 3 * 1000);
            }
        },

        showStationCreatedPopup: function () {
            var popup = new this.Popup();
            popup.render({
                title: $.t('popups.stationCreated.title'),
                text: $.t('popups.stationCreated.text'),
                buttons: [popup.buttons.exit]
            });
            
            var onHide = function(){
                this.onGoToPlayer();
                this.model.getTrackInfoExtended();
            };
            
            this.listenToOnce(popup.display, popup.events.close, onHide.bind(this));

            // manually close the popup after 3 seconds
            _.delay(onHide.bind(this), 3000);
        },

        /**
         * Station create popup
         * This popup is shown if user have no stations
         */
        showCreateStationPopup: function () {
            var popup = new this.Popup();
            popup.render({
                title: $.t('popups.stationCreate.title'),
                text: $.t('popups.stationCreate.text'),
                buttons: [popup.buttons.createStation, popup.buttons.cancel]
            });
            this.listenToOnce(popup.display, popup.events.close, this.onSuspend);
            this.listenToOnce(popup.display, popup.events.createStation, this.showGenreCategoriesList);
        },

        /**
         * Create station from list of genre categories
         */
        showGenreCategoriesList: function () {
            this.categoryList = this.categoryList || new this.List(this.model);

            this.categoryList.setTitle($.t('listTitles.category'));
            this.categoryList.render({
                items: [{
                    hasChildren: false,
                    text: $.t('loading')
                }],
                disableBackBtn: this._stationsListIsEmpty()
            });

            this.startListening();
            this.listenTo(this.categoryList, this.categoryList.events.player, this.onGoToPlayer);
            this.listenTo(this.categoryList, this.categoryList.events.goBack, this.onGoToMyStations);

            // todo add caching for fetched items before
            // later PandoraLink will fire update:categoryList
            this.model.getAllGenreCategoryNames();
        },

        updateGenreCategoriesList: function (categories) {
            this.categoryList.render({
                items: categories.map(function (item, key) {
                    return {
                        text: item,
                        key: key,
                        hasChildren: true
                    };
                }),
                disableBackBtn: this._stationsListIsEmpty()
            });
            this.listenToOnce(this.categoryList, this.categoryList.events.select, this.onSelectGenreCategory);
        },

        /**
         * Create station from list of selected genre category
         */
        showGenreList: function (title, index) {
            this.categoryStationList = this.categoryStationList || new this.List(this.model);
            this.categoryStationList.setTitle(title);
            this.categoryStationList.render({items: [{
                hasChildren: false,
                text: $.t('loading')
            }]});

            this.stopListening();
            this.startListening();
            this.listenTo(
                this.categoryStationList, this.categoryStationList.events.player, this.onGoToPlayer
            );
            this.listenTo(
                this.categoryStationList, this.categoryStationList.events.goBack, this.showGenreCategoriesList
            );

            // todo add caching for fetched items before
            // later PandoraLink will fire update:categoryStationList
            this.model.getAllGenreStationNames(index);
        },

        updateGenreList: function (stations, categoryIndex) {
            this.categoryStationList.render({
                items: stations.map(function (item, key) {
                    return {
                        text: item,
                        key: key,
                        categoryIndex: categoryIndex,
                        hasChildren: false
                    };
                })
            });

            this.listenToOnce(this.categoryStationList, this.categoryStationList.events.select, this.onSelectGenre);
        },

        _resetLists: function () {
            this.stopListening();
            this.categoryStationList = null;
            this.categoryList = null;
        },

        _stationsListIsEmpty: function () {
            return this.model.getCurrentStatus() === this.constants.status.PNDR_STATUS_NO_STATIONS;
        }

    });
});