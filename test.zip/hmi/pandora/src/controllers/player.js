define('pandora/controllers/player',['pandora/controllers/common/controller'], function (ErrorHandler) {
    'use strict';

    return ErrorHandler.extend({

        init: function (options) {
            this._super(_.extend(options, {
                mainAction: this.showPlayer
            }));
            this.model = options.model;
            this.constants = this.model.constants;

            this.Player = options.Player;
            this.Popup = options.Popup;

            this.notificationHandlers = {};
            this.errorHandlers = {};

            this.notificationHandlers[this.constants.notice.PNDR_NOTICE_SKIP_LIMIT_REACHED] = function () {
                // no popup will be shown;
                if (this.isAudioAd()) {
                    return;
                }

                this.playerView.trackInfo.allowSkip = false;

                return {
                    delay: 3000,
                    action: this.showPlayer.bind(this)
                };
            }.bind(this);

            this.notificationHandlers[this.constants.notice.PNDR_NOTICE_ERROR_STATION_DOES_NOT_EXIST] = function () {
//TODO: investigate if we really need to set trackInfo.allowSkip = false here
                this.playerView.trackInfo.allowSkip = false;

                return {
                    delay: 3000,
                    action: this.onGoToMyStations.bind(this)
                };
            }.bind(this);

            this.errorHandlers[this.constants.status.PNDR_STATUS_INSUFFICIENT_CONNECTIVITY] = function () {
                return {
                    action: this.onNetworkError.bind(this)
                };
            }.bind(this);
        },

        start: function (options) {
            options = options || {};
            this.showPlayer(options);

            this.startListening();
        },

        startListening: function () {
            this.stopListening();

            this.listenTo(this.model, {
                // from time to time update track info (new track started after previous finished, skip, etc.)
                'update:trackInfo': this.updatePlayerView,
                // new album art just downloaded
                'update:albumArt': this.updatePlayerView,
                // active station info updated
                'update:activeStationInfo': this.updatePlayerView,
                // track bookmark updated
                'update:bookmark': this.updatePlayerView,
                // station deleted
                'update:stationDeleted': this.onStationDeleted,
                // playback changed
                'show:playerScreen': this.playbackChanged,
                // show notice pop-up
                'show:notice': this.handleNotice,
                'show:errorStatus': this.handleError
            });

            // controls from player screen
            this.listenTo(this.playerView, this.playerView.events.play, this.onPlay);
            this.listenTo(this.playerView, this.playerView.events.pause, this.onPause);
            this.listenTo(this.playerView, this.playerView.events.bookmark, this.onBookmark);
            this.listenTo(this.playerView, this.playerView.events.skipSong, this.onSkip);
            this.listenTo(this.playerView, this.playerView.events.likeSong, this.onLike);
            this.listenTo(this.playerView, this.playerView.events.dislikeSong, this.onDislike);
            this.listenToOnce(this.playerView, this.playerView.events.onSuspend, this.onSuspend);
            this.listenToOnce(this.playerView, this.playerView.events.goToMyStations, this.onGoToMyStations);
        },

        onStationDeleted: function(){
            this.handleNotice(this.constants.notice.PNDR_NOTICE_ERROR_STATION_DOES_NOT_EXIST);
        },

        onSuspend: function () {
            this.stopListening();
            this.trigger('suspend');
        },

        suspend: function () {
            if (this.playerView) this.playerView.suspend();
            this.stopListening();
        },

        close: function () {
            if (this.playerView) this.playerView.suspend();
            this.stopListening();
        },

        onGoToMyStations: function () {
            this.stopListening();
            this.trigger('show:stationList');
        },

        onPlay: function () {
            this.model.eventTrackPlay();
        },

        onPause: function () {
            this.model.eventTrackPause();
        },

        onSkip: function () {
            this.model.eventTrackSkip();
        },

        onLike: function () {
            this.model.eventTrackRatePositive();
        },

        onDislike: function () {
            this.model.eventTrackRateNegative();
        },

        onBookmark: function () {
            this.model.eventTrackBookmarkTrack();
        },

        handleNotice: function (notificationCode) {
            var options = this.notificationHandlers[notificationCode] && this.notificationHandlers[notificationCode]();
            this._super(notificationCode, options);
        },

        handleError: function (errorCode, options) {
            if (this.errorHandlers[errorCode]) {
                options = this.errorHandlers[errorCode]();
            }
            this._super(errorCode, options);
        },

        onNetworkError: function () {
            this.playerView.toggleErrorState();
        },

        showPlayer: function (options) {
            options = options || {};
            this.playerView = this.playerView || new this.Player(this.model);
            this.playerView.setIsPlaying(options.isPlaying);
            this.playerView.render();
        },

        updatePlayerView: function (data) {
            this.playerView.render(data);
        },

        playbackChanged: function (options) {
            this.playerView.render(options);
        },

        isAudioAd: function () {
            var trackInfo = this.playerView.trackInfo;
            return trackInfo && trackInfo.getIsAudioAd();
        }

    });
});