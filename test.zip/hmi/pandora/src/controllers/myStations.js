define('pandora/controllers/myStations',['pandora/controllers/common/controller'], function (ErrorHandler) {
    'use strict';

    return ErrorHandler.extend({

        init: function (options) {
            this._super(_.extend(options, {
                mainAction: this.showMyStations
            }));
            this.model = options.model;
            this.constants = this.model.constants;

            this.MyStaions = options.MyStations;
            this.MyStationsInDeleteMode = options.MyStationsInDeleteMode;
            this.Popup = options.Popup;
        },

        start: function () {
            this.showMyStations();

            // listen on updates from pandora API
            this.listenTo(this.model, {
                'update:stationList': this.updateStationList,
                // CV-1282: Back and Now Playing buttons stay disabled after internet connection was established
                'show:playerScreen': function () {
                    this.updateStationList(this.model.getStations());
                }.bind(this),
                'show:notice': this.handleNotice,
                'show:errorStatus': this.handleError
            });
        },

        startListening: function () {
            this.stopListening(this.view);
            // common
            this.listenTo(this.view, this.view.events.player, this.onGoToPlayer);
            this.listenTo(this.view, this.view.events.sortBy, this.onSortOrderChanged);

            // specific to my stations
            this.listenTo(this.view, this.view.events.createStation, this.onGoToCreateStation);
            this.listenTo(this.view, this.view.events.select, this.onStationSelected);
            this.listenTo(this.view, this.view.events.removeStation, this.showMyStationsInDeleteMode);

            // specific to my stations in delete mode
            this.listenTo(this.view, this.view.events.delete, this.onStationDelete);
        },

        suspend: function () {
            this.stopListening();
        },

        close: function () {
            this.stopListening();
        },

        onGoToPlayer: function () {
            this.stopListening();
            this.trigger('show:playerScreen');
        },

        onGoToCreateStation: function () {
            this.stopListening();
            this.trigger('show:stationCreate');
        },

        /**
         * Play music on station selection and go to player screen
         * @param item
         */
        onStationSelected: function (item) {
            if (item.value) {
                this.model.setActiveStationInfo(item.value);
                this.model.eventStationSelect(item.value.stationToken);
                this.onGoToPlayer();
            }
        },

        onStationDelete: function (item) {
            if (item.value) {
                var popup = new this.Popup();
                popup.render({
                    title: $.t('popups.stationDelete.title'),
                    text: item.value.stationName,
                    buttons: [popup.buttons.cancel, popup.buttons.deleteStation]
                });
                this.listenToOnce(popup.display,
                    popup.events.close, this.showMyStationsInDeleteMode);
                this.listenToOnce(popup.display,
                    popup.events.deleteStation,this.onStationDeleteConfirmed.bind(this, item.value));
            }
        },

        onStationDeleteConfirmed: function (station) {
            var stations = this.model.getStations().filter(function (item) {
                return item.stationToken !== station.stationToken;
            });
            this.model.eventStationDelete(station.stationToken);

            // if user deletes the last station the application should
            // show status popup that will offer to create the new station
            if (stations.length === 1) {
                this.model.setCurrentStatus(this.constants.status.PNDR_STATUS_NO_STATIONS);
                this.onGoToCreateStation();
                return;
            }

            // if the user deletes a station that is currently playing
            // the application should trigger playing the Shuffle All station
            if (this.model.getActiveStationToken() === station.stationToken) {
                var shuffleStation = _.findWhere(this.model.getStations(), {isQuickMix: true});
                this.model.setActiveStationInfo(shuffleStation);
                this.model.eventStationSelect(shuffleStation.stationToken);
            }
            else {
                this.showMyStationsInDeleteMode(stations);
            }
        },

        onSortOrderChanged: function () {
            this.model.eventStationsSort(Number(!this.model.getStationsOrder()));
        },

        onGoBackFromStations: function () {
            if (this.model.isStationSet()) {
                this.onGoToPlayer();
            }
        },

        onGoBackFromDeleteMode: function () {
            this.showMyStations();
        },

        showPopup: function (title, text) {
            var popup = this._super(title, text);
            if (popup) {
                // automatically close in 3 seconds
                _.delay(popup.display.trigger.bind(popup.display, popup.events.close), 3 * 1000);
            }
        },

        /**
         *  My station list
         *  Shown if there is no currently active/playing stations at startup
         *  or after user clicked on myStations button from player screen
         */
        showMyStations: function () {
            this.stopListening(this.view);

            this.view = new this.MyStaions(this.model);
            this.view.setTitle($.t('listTitles.myStations'));
            this.updateStationList(this.model.getStations());

            this.startListening();
            this.listenTo(this.view, this.view.events.goBack, this.onGoBackFromStations);
        },

        showMyStationsInDeleteMode: function (stations) {
            stations = _.isArray(stations) ? stations : this.model.getStations();
            this.stopListening(this.view);

            this.view = new this.MyStationsInDeleteMode(this.model);
            this.view.setTitle($.t('listTitles.myStationsInDeleteMode'));
            this.updateStationList(stations);

            this.startListening();
            this.listenTo(this.view, this.view.events.goBack, this.onGoBackFromDeleteMode);
        },

        updateStationList: function (stations) {
            this.view.render({
                items: this.getStationItems(stations),
                activeStationToken: this.model.getActiveStationToken()
            });
        },

        getStationItems: function (stations) {
            return (stations && stations.length) ? this.fetchEmpty(stations.map(function (item) {
                return _.extend(item, {
                    hasChildren: false,
                    text: item.stationName
                });
            })) : [{
                hasChildren: false,
                text: $.t('loading')
            }];
        },

        fetchEmpty: function (items) {
            var empty = items.filter(function (item) {
                return item.text === undefined;
            });
            if (empty.length) {
                _.each(empty, function (station) {
                    this.model.getStations().splice(this.model.getStationIndexByToken(station.stationToken), 1);
                }, this);
                this.model.eventStationList();
            }
            return items;
        }

    });
});