define('pandora/config',[],function () {
    'use strict';

    var PNDR_IMAGE_PNG = 2;

    return {
        appName: 'pandora',

        accessoryId: "2577B6F5",
        apiVersion: 3,

        imageType: PNDR_IMAGE_PNG,
        albumArtDimension: 75,

        // TODO Value of 0 indicates accessory not to receive/display station image data
        // TODO but pandora crashed if we use 0 as value
        stationArtDimension: 1,

        numStationsPerPage: 100,

        flags: 0
    };

});