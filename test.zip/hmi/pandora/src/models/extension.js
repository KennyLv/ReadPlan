/**
 * Pandora model
 * Incorporate PandoraLink and PandoraView.
 * Provide access to public PandoraLink API.
 */
define('pandora/models/extension',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        _elapsedPollingStatus: 0,

        events: {
            headUnitConnectionState:    'headUnitConnectionState',
            onUnMute:                     'unmute',
            onMute:                       'mute'
        },

        init: function(options){
            var cfg = options.config;
            var huInfo = {};

            try {
                huInfo = options.reportMetadata.metaReporters.baseMetaReporter.getHuInfo();
            } catch (e) {
                // TODO: Write the error into error log file.
            }

            this.vinNum = huInfo && huInfo.vin;
            // create PandoraView that do stuff more like a mediator
            this.mediator = new options.PandoraView(
                cfg.apiVersion, cfg.accessoryId, cfg.albumArtDimension, cfg.imageType,
                cfg.flags, cfg.stationArtDimension, cfg.numStationsPerPage, null, this.vinNum
            );

            // trigger events further
            this.mediator.on('all', function () {
                this.trigger.apply(this, arguments);
            }, this);

            this.pandora = options.PandoraLink;
            this.constants = this.pandora.resources;
            this.Payload = this.pandora.Payload;
            this.commands = this.constants.command.toCode;
            this.commandControl = new options.commandControl(this.pandora.FrameHandler);

            // extend by API from PandoraLink
            // init overridden by this extend
            _.extend(this, this.pandora.PandoraLink);
        },

        getVin: function(){
            return this.vinNum;
        },

        stopListening: function () {
            this.mediator.off();
            this.commandControl.off();
        },

        close: function() {
            this.commandControl.off();
        },

        startListening: function () {
            //TODO implements the right way for listeners binding
            // it should check the uniqueness of added callbacks

            //preventing duplicate listeners.
            this.commandControl.off();

            //system listens
            this.listenTo(this.commandControl,
                this.events.headUnitConnectionState,
                this.onConnectionStateChange);

            this.listenTo(this.commandControl, this.events.onMute, this.onMute);
            this.listenTo(this.commandControl, this.events.onUnMute, this.onUnMute);
        },

        initSession: function () {
            var logLevels = {NONE: 0, LOW: 1, HIGH: 3};
            this.init({
                logLevel: logLevels.LOW,
                communication: this.commandControl,
                view: this.mediator
            });

            this.startListening();
        },

        getTrackInfoExtended: function () {
            // is related to CV-2284
            // this particular call is only needed for getting elapsed time
            // we should request an additional API command call
            // from Pandora to get only track time by request (elapsed and duration)
            return this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_GET_TRACK_INFO_EXTENDED
            ]));
        },

        /**
         * Get all genre categories
         */
        getAllGenreCategoryNames: function () {
            this.commandControl.sendPayload(this.Payload.factory([this.commands.PNDR_GET_ALL_GENRE_CATEGORY_NAMES]));
        },

        /**
         * Get all genres from genre category
         * @param categoryIndex {Number}
         */
        getAllGenreStationNames: function (categoryIndex) {
            var MAX_COUNT = 0xff,
                START_INDEX = 0;

            this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_GET_GENRE_STATION_NAMES, categoryIndex, START_INDEX, MAX_COUNT
            ]));
        },

        /**
         * Create station by genre category and genre itself
         * @param categoryIndex {Number}
         * @param itemIndex {Number}
         */
        createGenreStation: function (categoryIndex, itemIndex) {
            this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_EVENT_SELECT_GENRE_STATION, categoryIndex, itemIndex
            ]));
        },

        /**
         * Save the current active station data
         * @param info
         */
        setActiveStationInfo: function (info) {
            this.mediator.setActiveStationInfo(info);
        },

        getStationIndexByToken: function (token) {
            var stations = this.getStations(),
                index = -1;
            _.some(stations, function (item, key) {
                if (item.stationToken === token) {
                    index = key;
                    return true;
                }
            });
            return index;
        },

        isStationSet: function () {
            return this.isPlaying() || this.isPaused();
        },

        isPlaying: function () {
            return this.getCurrentStatus() === this.constants.status.PNDR_STATUS_PLAYING;
        },

        isPaused: function () {
            return this.getCurrentStatus() === this.constants.status.PNDR_STATUS_PAUSED;
        },

        forcePausedState: function() {
            this.setCurrentStatus(this.constants.status.PNDR_STATUS_PAUSED);
        },

        onUnMute: function(){
            if (this.isPaused()) {
                this.play();
            }
        },

        onMute: function(){
            if (this.isPlaying()) {
                this.pause();
            }
        },

        pause: function() {
            this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_EVENT_TRACK_PAUSE
            ]));
        },

        play: function() {
            this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_EVENT_TRACK_PLAY
            ]));
        },

        onConnectionStateChange: function (data) {
            if (data.state === 'disconnected') {
                this.onHeadUnitDisconnected();
            }
        },

        onHeadUnitDisconnected: function() {
            //FIXME maybe leave only PNDR_SESSION_TERMINATE
            this.commandControl.sendPayload(this.Payload.factory([
                this.commands.PNDR_EVENT_TRACK_PAUSE
            ])).always(function() {
                this.commandControl.sendPayload(this.Payload.factory([
                    this.commands.PNDR_SESSION_TERMINATE
                ]));
            }.bind(this));
        }

    });
});