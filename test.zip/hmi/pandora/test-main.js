!function () {
    "use strict";

    var testFiles = [],
        TEST_REGEXP = /(?:\.s|S)pec\.js$/;

    var pathToModule = function (path) {
        return path.replace(/^\/base\/src/, 'pandora');
    };

    // Filter out other files except test ones
    Object.keys(window.__karma__.files).forEach(function (file) {
        if (TEST_REGEXP.test(file)) {
            // Normalize paths to RequireJS module names
            testFiles.push(pathToModule(file));
        }
    });
    
    require.config({
        // Karma serves files under /base, which is the `basePath` from Karma config file
        //baseUrl: "/base/src",
        baseUrl: "/base",

        paths: {
            jquery: "platform/core/lib/jquery/jquery",
            underscore: "platform/core/lib/underscore/underscore",
            uuid: "platform/core/lib/node-uuid/uuid",
            es5shim: "node_modules/es5-shim/es5-shim"
        },

        findNestedDependencies: true,
        useStrict: true,
        removeCombined: true,
        skipSemiColonInsertion: true,

        // exclude
        excludeList: [],

        // We have to add "../" to location of packages 
        packages: [{
            name: "pandora",
            main: "app.js",
            location: "pandora/src"
        }, {
            name: "shared",
            location: "platform/core/modules/shared"
        }, {
            name: "aq",
            location: "platform/core/src"
        }, {
            name: 'common',
            location: 'common'
        }],

        // ask Require.js to load all our tests
        deps: ["jquery", "underscore", "uuid", "es5shim"].concat(testFiles),

        // we have to kickoff jasmine, as it is asynchronous
        callback: window.__karma__.start
    });
}();
