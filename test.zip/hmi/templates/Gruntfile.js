module.exports = function(grunt) {
    "use strict";

    grunt.file.expand('../node_modules/grunt-*/tasks').forEach(grunt.loadTasks);

    var platform = grunt.option("platform") || "vp2c";
    var version = process.env.templates ? ['', process.env.templates] :
            (process.env.versions || "").match(/templates=([^;]+)/),
        manifestVersion = version ? version[1] : "0.0.0";

    var checkCircularDependencies = function (data) {
        var madge = require("madge"),
            circular = madge([data.path], {
                format: "amd",
                optimized: true
            }).circular(),
            isCyclic = circular.getArray().length;

        if (isCyclic) {
            circular.getArray().forEach(function (path) {
                path.forEach(function (module, idx) {
                    if (idx) {
                        process.stdout.write(" -> ");
                    }
                    process.stdout.write(module);
                });
                process.stdout.write("\n");
            });
            grunt.fail.fatal("Circular dependencies detected");
        }
    };

    var b2bConfig = {
            b2bRegions: {
                NORTH_AMERICA_USA: { text: 'United States',
                                     toProcess: process.env.us !== "false"},
                NORTH_AMERICA_CA:  { text: 'Canada',
                                     toProcess: process.env.ca !== "false"},
                MEXICO:            { text: 'Mexico',
                                     toProcess: process.env.mx !== "false"}
            },
            hupVersion: process.env.hupVersion || '2.0'
    };

    var config = grunt.initConfig({

        app: grunt.file.readJSON("../platform/" + platform + "/hmiapps/templates/resources/app.json"),
        version: "<%= app.version %>",
        appId: "<%= parseInt(app.appId, 10) %>",
        imageVersion: "<%= app.imageVersion %>",

        buildFolder: "../dist",

        moduleName: "templates",
        moduleFileName: "app.js",
        moduleFolder: "<%= buildFolder %>/<%= moduleName %>",
        moduleMetadata: 'metadata',

        jshint: {
            options: {
                jshintrc: "../.jshintrc"
            },
            all: [
                "src/**/*.js"
            ]
        },

        copy: {
            resources: {
                files: [
                    {
                        expand: true,
                        cwd: "../platform/" + platform + "/hmiapps/<%= moduleName %>/",
                        src: "di.js",
                        dest: "src/"
                    }, {
                        expand: true,
                        cwd: "../platform/" + platform + "/hmiapps/<%= moduleName %>/resources/",
                        src: ["**"],
                        dest: "<%= moduleFolder %>/"
                    }
                ]
            },
            release: {
                flatten: true,
                expand: true,
                src: [
                    "<%= moduleFolder %>.zip",
                    "../platform/" + platform + "/hmiapps/<%= moduleName %>/<%= moduleMetadata %>/*"
                ],
                dest: "<%= moduleFolder %>/"
            }
        },

        replace: {
            release: {
                src: ["<%= moduleFolder %>/MANIFEST.txt"],
                overwrite: true,
                replacements: [{
                    from: "<VERSION>",
                    to: manifestVersion
                },
                {
                    from: "<REGIONS_KEYS>",

                    to: function(match) {
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey);
                            }
                        }

                        return replaceWith.join(',')
                    }
                },
                {
                    from: "<REGIONS>",
                    to: function(match){
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions.hasOwnProperty(regionKey) &&
                                b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey + ':' + b2bConfig.b2bRegions[regionKey].text)
                            }
                        }

                        return replaceWith.join('\n');
                    }
                },
                {
                    from: "<HUP_VERSION>",
                    to: b2bConfig.hupVersion
                }]
            }
        },

        requirejs: {
            release: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    optimize: "uglify"
                }
            },
            dev: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    generateSourceMaps: true,
                    optimize: "none"
                }
            }
        },

        compress: {
            module: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %>.zip",
                    mode: "zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= buildFolder %>/",
                    src: "<%= moduleName %>/**"
                }]
            },
            release: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %><%= version %>.zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= moduleFolder %>",
                    src: "**"
                }]
            }
        }

    });

    grunt.registerTask("clean", function () {
        var path = require('path');
        return grunt.file.delete(path.join(config.buildFolder, config.moduleName), {force: true});
    });

    grunt.registerTask("cleanAfter", function () {
        var path = require('path');
        return grunt.file.delete(path.join(config.buildFolder, config.moduleName).concat('.zip'), {force: true});
    });

    grunt.registerTask("default", ["release"]);
    grunt.registerTask("release", [
        "jshint", "copy:resources", "requirejs:release", "compress:module",
        "clean", "copy:release", "replace:release", "compress:release", "clean", "cleanAfter"
    ]);
    grunt.registerTask("release-pretty", [
        "jshint", "copy:resources", "requirejs:dev", "compress:module",
        "clean", "copy:release", "replace:release", "compress:release", "clean", "cleanAfter"
    ]);
    grunt.registerTask("dev", ["jshint", "copy:resources", "requirejs:dev"]);
};
