define('templates/views/samples/keyboard',[],function () {
    'use strict';

    return {};
});