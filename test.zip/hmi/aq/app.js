/**
 * @license almond 0.2.9 Copyright (c) 2011-2014, The Dojo Foundation All Rights Reserved.
 * Available via the MIT or new BSD license.
 * see: http://github.com/jrburke/almond for details
 */
//Going sloppy to avoid 'use strict' string cost, but strict practices should
//be followed.
/*jslint sloppy: true */
/*global setTimeout: false */

var requirejs, require, define;
(function (undef) {
    var main, req, makeMap, handlers,
        defined = {},
        waiting = {},
        config = {},
        defining = {},
        hasOwn = Object.prototype.hasOwnProperty,
        aps = [].slice,
        jsSuffixRegExp = /\.js$/;

    function hasProp(obj, prop) {
        return hasOwn.call(obj, prop);
    }

    /**
     * Given a relative module name, like ./something, normalize it to
     * a real name that can be mapped to a path.
     * @param {String} name the relative name
     * @param {String} baseName a real name that the name arg is relative
     * to.
     * @returns {String} normalized name
     */
    function normalize(name, baseName) {
        var nameParts, nameSegment, mapValue, foundMap, lastIndex,
            foundI, foundStarMap, starI, i, j, part,
            baseParts = baseName && baseName.split("/"),
            map = config.map,
            starMap = (map && map['*']) || {};

        //Adjust any relative paths.
        if (name && name.charAt(0) === ".") {
            //If have a base name, try to normalize against it,
            //otherwise, assume it is a top-level require that will
            //be relative to baseUrl in the end.
            if (baseName) {
                //Convert baseName to array, and lop off the last part,
                //so that . matches that "directory" and not name of the baseName's
                //module. For instance, baseName of "one/two/three", maps to
                //"one/two/three.js", but we want the directory, "one/two" for
                //this normalization.
                baseParts = baseParts.slice(0, baseParts.length - 1);
                name = name.split('/');
                lastIndex = name.length - 1;

                // Node .js allowance:
                if (config.nodeIdCompat && jsSuffixRegExp.test(name[lastIndex])) {
                    name[lastIndex] = name[lastIndex].replace(jsSuffixRegExp, '');
                }

                name = baseParts.concat(name);

                //start trimDots
                for (i = 0; i < name.length; i += 1) {
                    part = name[i];
                    if (part === ".") {
                        name.splice(i, 1);
                        i -= 1;
                    } else if (part === "..") {
                        if (i === 1 && (name[2] === '..' || name[0] === '..')) {
                            //End of the line. Keep at least one non-dot
                            //path segment at the front so it can be mapped
                            //correctly to disk. Otherwise, there is likely
                            //no path mapping for a path starting with '..'.
                            //This can still fail, but catches the most reasonable
                            //uses of ..
                            break;
                        } else if (i > 0) {
                            name.splice(i - 1, 2);
                            i -= 2;
                        }
                    }
                }
                //end trimDots

                name = name.join("/");
            } else if (name.indexOf('./') === 0) {
                // No baseName, so this is ID is resolved relative
                // to baseUrl, pull off the leading dot.
                name = name.substring(2);
            }
        }

        //Apply map config if available.
        if ((baseParts || starMap) && map) {
            nameParts = name.split('/');

            for (i = nameParts.length; i > 0; i -= 1) {
                nameSegment = nameParts.slice(0, i).join("/");

                if (baseParts) {
                    //Find the longest baseName segment match in the config.
                    //So, do joins on the biggest to smallest lengths of baseParts.
                    for (j = baseParts.length; j > 0; j -= 1) {
                        mapValue = map[baseParts.slice(0, j).join('/')];

                        //baseName segment has  config, find if it has one for
                        //this name.
                        if (mapValue) {
                            mapValue = mapValue[nameSegment];
                            if (mapValue) {
                                //Match, update name to the new value.
                                foundMap = mapValue;
                                foundI = i;
                                break;
                            }
                        }
                    }
                }

                if (foundMap) {
                    break;
                }

                //Check for a star map match, but just hold on to it,
                //if there is a shorter segment match later in a matching
                //config, then favor over this star map.
                if (!foundStarMap && starMap && starMap[nameSegment]) {
                    foundStarMap = starMap[nameSegment];
                    starI = i;
                }
            }

            if (!foundMap && foundStarMap) {
                foundMap = foundStarMap;
                foundI = starI;
            }

            if (foundMap) {
                nameParts.splice(0, foundI, foundMap);
                name = nameParts.join('/');
            }
        }

        return name;
    }

    function makeRequire(relName, forceSync) {
        return function () {
            //A version of a require function that passes a moduleName
            //value for items that may need to
            //look up paths relative to the moduleName
            return req.apply(undef, aps.call(arguments, 0).concat([relName, forceSync]));
        };
    }

    function makeNormalize(relName) {
        return function (name) {
            return normalize(name, relName);
        };
    }

    function makeLoad(depName) {
        return function (value) {
            defined[depName] = value;
        };
    }

    function callDep(name) {
        if (hasProp(waiting, name)) {
            var args = waiting[name];
            delete waiting[name];
            defining[name] = true;
            main.apply(undef, args);
        }

        if (!hasProp(defined, name) && !hasProp(defining, name)) {
            throw new Error('No ' + name);
        }
        return defined[name];
    }

    //Turns a plugin!resource to [plugin, resource]
    //with the plugin being undefined if the name
    //did not have a plugin prefix.
    function splitPrefix(name) {
        var prefix,
            index = name ? name.indexOf('!') : -1;
        if (index > -1) {
            prefix = name.substring(0, index);
            name = name.substring(index + 1, name.length);
        }
        return [prefix, name];
    }

    /**
     * Makes a name map, normalizing the name, and using a plugin
     * for normalization if necessary. Grabs a ref to plugin
     * too, as an optimization.
     */
    makeMap = function (name, relName) {
        var plugin,
            parts = splitPrefix(name),
            prefix = parts[0];

        name = parts[1];

        if (prefix) {
            prefix = normalize(prefix, relName);
            plugin = callDep(prefix);
        }

        //Normalize according
        if (prefix) {
            if (plugin && plugin.normalize) {
                name = plugin.normalize(name, makeNormalize(relName));
            } else {
                name = normalize(name, relName);
            }
        } else {
            name = normalize(name, relName);
            parts = splitPrefix(name);
            prefix = parts[0];
            name = parts[1];
            if (prefix) {
                plugin = callDep(prefix);
            }
        }

        //Using ridiculous property names for space reasons
        return {
            f: prefix ? prefix + '!' + name : name, //fullName
            n: name,
            pr: prefix,
            p: plugin
        };
    };

    function makeConfig(name) {
        return function () {
            return (config && config.config && config.config[name]) || {};
        };
    }

    handlers = {
        require: function (name) {
            return makeRequire(name);
        },
        exports: function (name) {
            var e = defined[name];
            if (typeof e !== 'undefined') {
                return e;
            } else {
                return (defined[name] = {});
            }
        },
        module: function (name) {
            return {
                id: name,
                uri: '',
                exports: defined[name],
                config: makeConfig(name)
            };
        }
    };

    main = function (name, deps, callback, relName) {
        var cjsModule, depName, ret, map, i,
            args = [],
            callbackType = typeof callback,
            usingExports;

        //Use name if no relName
        relName = relName || name;

        //Call the callback to define the module, if necessary.
        if (callbackType === 'undefined' || callbackType === 'function') {
            //Pull out the defined dependencies and pass the ordered
            //values to the callback.
            //Default to [require, exports, module] if no deps
            deps = !deps.length && callback.length ? ['require', 'exports', 'module'] : deps;
            for (i = 0; i < deps.length; i += 1) {
                map = makeMap(deps[i], relName);
                depName = map.f;

                //Fast path CommonJS standard dependencies.
                if (depName === "require") {
                    args[i] = handlers.require(name);
                } else if (depName === "exports") {
                    //CommonJS module spec 1.1
                    args[i] = handlers.exports(name);
                    usingExports = true;
                } else if (depName === "module") {
                    //CommonJS module spec 1.1
                    cjsModule = args[i] = handlers.module(name);
                } else if (hasProp(defined, depName) ||
                           hasProp(waiting, depName) ||
                           hasProp(defining, depName)) {
                    args[i] = callDep(depName);
                } else if (map.p) {
                    map.p.load(map.n, makeRequire(relName, true), makeLoad(depName), {});
                    args[i] = defined[depName];
                } else {
                    throw new Error(name + ' missing ' + depName);
                }
            }

            ret = callback ? callback.apply(defined[name], args) : undefined;

            if (name) {
                //If setting exports via "module" is in play,
                //favor that over return value and exports. After that,
                //favor a non-undefined return value over exports use.
                if (cjsModule && cjsModule.exports !== undef &&
                        cjsModule.exports !== defined[name]) {
                    defined[name] = cjsModule.exports;
                } else if (ret !== undef || !usingExports) {
                    //Use the return value from the function.
                    defined[name] = ret;
                }
            }
        } else if (name) {
            //May just be an object definition for the module. Only
            //worry about defining if have a module name.
            defined[name] = callback;
        }
    };

    requirejs = require = req = function (deps, callback, relName, forceSync, alt) {
        if (typeof deps === "string") {
            if (handlers[deps]) {
                //callback in this case is really relName
                return handlers[deps](callback);
            }
            //Just return the module wanted. In this scenario, the
            //deps arg is the module name, and second arg (if passed)
            //is just the relName.
            //Normalize module name, if it contains . or ..
            return callDep(makeMap(deps, callback).f);
        } else if (!deps.splice) {
            //deps is a config object, not an array.
            config = deps;
            if (config.deps) {
                req(config.deps, config.callback);
            }
            if (!callback) {
                return;
            }

            if (callback.splice) {
                //callback is an array, which means it is a dependency list.
                //Adjust args if there are dependencies
                deps = callback;
                callback = relName;
                relName = null;
            } else {
                deps = undef;
            }
        }

        //Support require(['a'])
        callback = callback || function () {};

        //If relName is a function, it is an errback handler,
        //so remove it.
        if (typeof relName === 'function') {
            relName = forceSync;
            forceSync = alt;
        }

        //Simulate async callback;
        if (forceSync) {
            main(undef, deps, callback, relName);
        } else {
            //Using a non-zero value because of concern for what old browsers
            //do, and latest browsers "upgrade" to 4 if lower value is used:
            //http://www.whatwg.org/specs/web-apps/current-work/multipage/timers.html#dom-windowtimers-settimeout:
            //If want a value immediately, use require('id') instead -- something
            //that works in almond on the global level, but not guaranteed and
            //unlikely to work in other AMD implementations.
            setTimeout(function () {
                main(undef, deps, callback, relName);
            }, 4);
        }

        return req;
    };

    /**
     * Just drops the config on the floor, but returns req in case
     * the config return value is used.
     */
    req.config = function (cfg) {
        return req(cfg);
    };

    /**
     * Expose module registry for debugging and tooling
     */
    requirejs._defined = defined;

    define = function (name, deps, callback) {

        //This module may not have dependencies
        if (!deps.splice) {
            //deps is not an array, so probably means
            //an object literal or factory function for
            //the value. Adjust args.
            callback = deps;
            deps = [];
        }

        if (!hasProp(defined, name) && !hasProp(waiting, name)) {
            waiting[name] = [name, deps, callback];
        }
    };

    define.amd = {
        jQuery: true
    };
}());

define("almond", function(){});

/*!
 * jQuery JavaScript Library v2.1.1pre -attributes,-attributes/attr,-attributes/classes,-attributes/prop,-attributes/support,-attributes/val,-css,-css/addGetHookIf,-css/curCSS,-css/defaultDisplay,-css/hiddenVisibleSelectors,-css/support,-css/swap,-css/var/cssExpand,-css/var/getStyles,-css/var/isHidden,-css/var/rmargin,-css/var/rnumnonpx,-effects,-effects/animatedSelector,-effects/Tween,-dimensions,-offset,-manipulation,-manipulation/support,-manipulation/var/rcheckableType,-manipulation/_evalUrl,-traversing,-traversing/findFilter,-traversing/var/rneedsContext,-deprecated,-selector-native,-selector-sizzle,-wrap
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright 2005, 2014 jQuery Foundation, Inc. and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2014-03-11T13:45Z
 */

(function( global, factory ) {

	if ( typeof module === "object" && typeof module.exports === "object" ) {
		// For CommonJS and CommonJS-like environments where a proper window is present,
		// execute the factory and get jQuery
		// For environments that do not inherently posses a window with a document
		// (such as Node.js), expose a jQuery-making factory as module.exports
		// This accentuates the need for the creation of a real window
		// e.g. var jQuery = require("jquery")(window);
		// See ticket #14549 for more info
		module.exports = global.document ?
			factory( global, true ) :
			function( w ) {
				if ( !w.document ) {
					throw new Error( "jQuery requires a window with a document" );
				}
				return factory( w );
			};
	} else {
		factory( global );
	}

// Pass this if window is not defined yet
}(typeof window !== "undefined" ? window : this, function( window, noGlobal ) {

// Can't do this because several apps including ASP.NET trace
// the stack via arguments.caller.callee and Firefox dies if
// you try to trace through "use strict" call chains. (#13335)
// Support: Firefox 18+
//

var arr = [];

var slice = arr.slice;

var concat = arr.concat;

var push = arr.push;

var indexOf = arr.indexOf;

var class2type = {};

var toString = class2type.toString;

var hasOwn = class2type.hasOwnProperty;

var support = {};



var
	// Use the correct document accordingly with window argument (sandbox)
	document = window.document,

	version = "2.1.1pre -attributes,-attributes/attr,-attributes/classes,-attributes/prop,-attributes/support,-attributes/val,-css,-css/addGetHookIf,-css/curCSS,-css/defaultDisplay,-css/hiddenVisibleSelectors,-css/support,-css/swap,-css/var/cssExpand,-css/var/getStyles,-css/var/isHidden,-css/var/rmargin,-css/var/rnumnonpx,-effects,-effects/animatedSelector,-effects/Tween,-dimensions,-offset,-manipulation,-manipulation/support,-manipulation/var/rcheckableType,-manipulation/_evalUrl,-traversing,-traversing/findFilter,-traversing/var/rneedsContext,-deprecated,-selector-native,-selector-sizzle,-wrap",

	// Define a local copy of jQuery
	jQuery = function( selector, context ) {
		// The jQuery object is actually just the init constructor 'enhanced'
		// Need init if jQuery is called (just allow error to be thrown if not included)
		return new jQuery.fn.init( selector, context );
	},

	// Support: Android<4.1
	// Make sure we trim BOM and NBSP
	rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,

	// Matches dashed string for camelizing
	rmsPrefix = /^-ms-/,
	rdashAlpha = /-([\da-z])/gi,

	// Used by jQuery.camelCase as callback to replace()
	fcamelCase = function( all, letter ) {
		return letter.toUpperCase();
	};

jQuery.fn = jQuery.prototype = {
	// The current version of jQuery being used
	jquery: version,

	constructor: jQuery,

	// Start with an empty selector
	selector: "",

	// The default length of a jQuery object is 0
	length: 0,

	toArray: function() {
		return slice.call( this );
	},

	// Get the Nth element in the matched element set OR
	// Get the whole matched element set as a clean array
	get: function( num ) {
		return num != null ?

			// Return a 'clean' array
			( num < 0 ? this[ num + this.length ] : this[ num ] ) :

			// Return just the object
			slice.call( this );
	},

	// Take an array of elements and push it onto the stack
	// (returning the new matched element set)
	pushStack: function( elems ) {

		// Build a new jQuery matched element set
		var ret = jQuery.merge( this.constructor(), elems );

		// Add the old object onto the stack (as a reference)
		ret.prevObject = this;
		ret.context = this.context;

		// Return the newly-formed element set
		return ret;
	},

	// Execute a callback for every element in the matched set.
	// (You can seed the arguments with an array of args, but this is
	// only used internally.)
	each: function( callback, args ) {
		return jQuery.each( this, callback, args );
	},

	map: function( callback ) {
		return this.pushStack( jQuery.map(this, function( elem, i ) {
			return callback.call( elem, i, elem );
		}));
	},

	slice: function() {
		return this.pushStack( slice.apply( this, arguments ) );
	},

	first: function() {
		return this.eq( 0 );
	},

	last: function() {
		return this.eq( -1 );
	},

	eq: function( i ) {
		var len = this.length,
			j = +i + ( i < 0 ? len : 0 );
		return this.pushStack( j >= 0 && j < len ? [ this[j] ] : [] );
	},

	end: function() {
		return this.prevObject || this.constructor(null);
	},

	// For internal use only.
	// Behaves like an Array's method, not like a jQuery method.
	push: push,
	sort: arr.sort,
	splice: arr.splice
};

jQuery.extend = jQuery.fn.extend = function() {
	var options, name, src, copy, copyIsArray, clone,
		target = arguments[0] || {},
		i = 1,
		length = arguments.length,
		deep = false;

	// Handle a deep copy situation
	if ( typeof target === "boolean" ) {
		deep = target;

		// skip the boolean and the target
		target = arguments[ i ] || {};
		i++;
	}

	// Handle case when target is a string or something (possible in deep copy)
	if ( typeof target !== "object" && !jQuery.isFunction(target) ) {
		target = {};
	}

	// extend jQuery itself if only one argument is passed
	if ( i === length ) {
		target = this;
		i--;
	}

	for ( ; i < length; i++ ) {
		// Only deal with non-null/undefined values
		if ( (options = arguments[ i ]) != null ) {
			// Extend the base object
			for ( name in options ) {
				src = target[ name ];
				copy = options[ name ];

				// Prevent never-ending loop
				if ( target === copy ) {
					continue;
				}

				// Recurse if we're merging plain objects or arrays
				if ( deep && copy && ( jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy)) ) ) {
					if ( copyIsArray ) {
						copyIsArray = false;
						clone = src && jQuery.isArray(src) ? src : [];

					} else {
						clone = src && jQuery.isPlainObject(src) ? src : {};
					}

					// Never move original objects, clone them
					target[ name ] = jQuery.extend( deep, clone, copy );

				// Don't bring in undefined values
				} else if ( copy !== undefined ) {
					target[ name ] = copy;
				}
			}
		}
	}

	// Return the modified object
	return target;
};

jQuery.extend({
	// Unique for each copy of jQuery on the page
	expando: "jQuery" + ( version + Math.random() ).replace( /\D/g, "" ),

	// Assume jQuery is ready without the ready module
	isReady: true,

	error: function( msg ) {
		throw new Error( msg );
	},

	noop: function() {},

	// See test/unit/core.js for details concerning isFunction.
	// Since version 1.3, DOM methods and functions like alert
	// aren't supported. They return false on IE (#2968).
	isFunction: function( obj ) {
		return jQuery.type(obj) === "function";
	},

	isArray: Array.isArray,

	isWindow: function( obj ) {
		return obj != null && obj === obj.window;
	},

	isNumeric: function( obj ) {
		// parseFloat NaNs numeric-cast false positives (null|true|false|"")
		// ...but misinterprets leading-number strings, particularly hex literals ("0x...")
		// subtraction forces infinities to NaN
		return !jQuery.isArray( obj ) && obj - parseFloat( obj ) >= 0;
	},

	isPlainObject: function( obj ) {
		// Not plain objects:
		// - Any object or value whose internal [[Class]] property is not "[object Object]"
		// - DOM nodes
		// - window
		if ( jQuery.type( obj ) !== "object" || obj.nodeType || jQuery.isWindow( obj ) ) {
			return false;
		}

		if ( obj.constructor &&
				!hasOwn.call( obj.constructor.prototype, "isPrototypeOf" ) ) {
			return false;
		}

		// If the function hasn't returned already, we're confident that
		// |obj| is a plain object, created by {} or constructed with new Object
		return true;
	},

	isEmptyObject: function( obj ) {
		var name;
		for ( name in obj ) {
			return false;
		}
		return true;
	},

	type: function( obj ) {
		if ( obj == null ) {
			return obj + "";
		}
		// Support: Android < 4.0, iOS < 6 (functionish RegExp)
		return typeof obj === "object" || typeof obj === "function" ?
			class2type[ toString.call(obj) ] || "object" :
			typeof obj;
	},

	// Evaluates a script in a global context
	globalEval: function( code ) {
		var script,
			indirect = eval;

		code = jQuery.trim( code );

		if ( code ) {
			// If the code includes a valid, prologue position
			// strict mode pragma, execute code by injecting a
			// script tag into the document.
			if ( code.indexOf("use strict") === 1 ) {
				script = document.createElement("script");
				script.text = code;
				document.head.appendChild( script ).parentNode.removeChild( script );
			} else {
			// Otherwise, avoid the DOM node creation, insertion
			// and removal by using an indirect global eval
				indirect( code );
			}
		}
	},

	// Convert dashed to camelCase; used by the css and data modules
	// Microsoft forgot to hump their vendor prefix (#9572)
	camelCase: function( string ) {
		return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
	},

	nodeName: function( elem, name ) {
		return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();
	},

	// args is for internal usage only
	each: function( obj, callback, args ) {
		var value,
			i = 0,
			length = obj.length,
			isArray = isArraylike( obj );

		if ( args ) {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.apply( obj[ i ], args );

					if ( value === false ) {
						break;
					}
				}
			}

		// A special, fast, case for the most common use of each
		} else {
			if ( isArray ) {
				for ( ; i < length; i++ ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			} else {
				for ( i in obj ) {
					value = callback.call( obj[ i ], i, obj[ i ] );

					if ( value === false ) {
						break;
					}
				}
			}
		}

		return obj;
	},

	// Support: Android<4.1
	trim: function( text ) {
		return text == null ?
			"" :
			( text + "" ).replace( rtrim, "" );
	},

	// results is for internal usage only
	makeArray: function( arr, results ) {
		var ret = results || [];

		if ( arr != null ) {
			if ( isArraylike( Object(arr) ) ) {
				jQuery.merge( ret,
					typeof arr === "string" ?
					[ arr ] : arr
				);
			} else {
				push.call( ret, arr );
			}
		}

		return ret;
	},

	inArray: function( elem, arr, i ) {
		return arr == null ? -1 : indexOf.call( arr, elem, i );
	},

	merge: function( first, second ) {
		var len = +second.length,
			j = 0,
			i = first.length;

		for ( ; j < len; j++ ) {
			first[ i++ ] = second[ j ];
		}

		first.length = i;

		return first;
	},

	grep: function( elems, callback, invert ) {
		var callbackInverse,
			matches = [],
			i = 0,
			length = elems.length,
			callbackExpect = !invert;

		// Go through the array, only saving the items
		// that pass the validator function
		for ( ; i < length; i++ ) {
			callbackInverse = !callback( elems[ i ], i );
			if ( callbackInverse !== callbackExpect ) {
				matches.push( elems[ i ] );
			}
		}

		return matches;
	},

	// arg is for internal usage only
	map: function( elems, callback, arg ) {
		var value,
			i = 0,
			length = elems.length,
			isArray = isArraylike( elems ),
			ret = [];

		// Go through the array, translating each of the items to their new values
		if ( isArray ) {
			for ( ; i < length; i++ ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret.push( value );
				}
			}

		// Go through every key on the object,
		} else {
			for ( i in elems ) {
				value = callback( elems[ i ], i, arg );

				if ( value != null ) {
					ret.push( value );
				}
			}
		}

		// Flatten any nested arrays
		return concat.apply( [], ret );
	},

	// A global GUID counter for objects
	guid: 1,

	// Bind a function to a context, optionally partially applying any
	// arguments.
	proxy: function( fn, context ) {
		var tmp, args, proxy;

		if ( typeof context === "string" ) {
			tmp = fn[ context ];
			context = fn;
			fn = tmp;
		}

		// Quick check to determine if target is callable, in the spec
		// this throws a TypeError, but we will just return undefined.
		if ( !jQuery.isFunction( fn ) ) {
			return undefined;
		}

		// Simulated bind
		args = slice.call( arguments, 2 );
		proxy = function() {
			return fn.apply( context || this, args.concat( slice.call( arguments ) ) );
		};

		// Set the guid of unique handler to the same of original handler, so it can be removed
		proxy.guid = fn.guid = fn.guid || jQuery.guid++;

		return proxy;
	},

	now: Date.now,

	// jQuery.support is not used in Core but other projects attach their
	// properties to it so it needs to exist.
	support: support
});

// Populate the class2type map
jQuery.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(i, name) {
	class2type[ "[object " + name + "]" ] = name.toLowerCase();
});

function isArraylike( obj ) {
	var length = obj.length,
		type = jQuery.type( obj );

	if ( type === "function" || jQuery.isWindow( obj ) ) {
		return false;
	}

	if ( obj.nodeType === 1 && length ) {
		return true;
	}

	return type === "array" || length === 0 ||
		typeof length === "number" && length > 0 && ( length - 1 ) in obj;
}

var rsingleTag = (/^<(\w+)\s*\/?>(?:<\/\1>|)$/);

// Initialize a jQuery object


// A central reference to the root jQuery(document)
var rootjQuery,

	// A simple way to check for HTML strings
	// Prioritize #id over <tag> to avoid XSS via location.hash (#9521)
	// Strict HTML recognition (#11290: must start with <)
	rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,

	init = jQuery.fn.init = function( selector, context ) {
		var match, elem;

		// HANDLE: $(""), $(null), $(undefined), $(false)
		if ( !selector ) {
			return this;
		}

		// Handle HTML strings
		if ( typeof selector === "string" ) {
			if ( selector[0] === "<" && selector[ selector.length - 1 ] === ">" && selector.length >= 3 ) {
				// Assume that strings that start and end with <> are HTML and skip the regex check
				match = [ null, selector, null ];

			} else {
				match = rquickExpr.exec( selector );
			}

			// Match html or make sure no context is specified for #id
			if ( match && (match[1] || !context) ) {

				// HANDLE: $(html) -> $(array)
				if ( match[1] ) {
					context = context instanceof jQuery ? context[0] : context;

					// scripts is true for back-compat
					// Intentionally let the error be thrown if parseHTML is not present
					jQuery.merge( this, jQuery.parseHTML(
						match[1],
						context && context.nodeType ? context.ownerDocument || context : document,
						true
					) );

					// HANDLE: $(html, props)
					if ( rsingleTag.test( match[1] ) && jQuery.isPlainObject( context ) ) {
						for ( match in context ) {
							// Properties of context are called as methods if possible
							if ( jQuery.isFunction( this[ match ] ) ) {
								this[ match ]( context[ match ] );

							// ...and otherwise set as attributes
							} else {
								this.attr( match, context[ match ] );
							}
						}
					}

					return this;

				// HANDLE: $(#id)
				} else {
					elem = document.getElementById( match[2] );

					// Check parentNode to catch when Blackberry 4.6 returns
					// nodes that are no longer in the document #6963
					if ( elem && elem.parentNode ) {
						// Inject the element directly into the jQuery object
						this.length = 1;
						this[0] = elem;
					}

					this.context = document;
					this.selector = selector;
					return this;
				}

			// HANDLE: $(expr, $(...))
			} else if ( !context || context.jquery ) {
				return ( context || rootjQuery ).find( selector );

			// HANDLE: $(expr, context)
			// (which is just equivalent to: $(context).find(expr)
			} else {
				return this.constructor( context ).find( selector );
			}

		// HANDLE: $(DOMElement)
		} else if ( selector.nodeType ) {
			this.context = this[0] = selector;
			this.length = 1;
			return this;

		// HANDLE: $(function)
		// Shortcut for document ready
		} else if ( jQuery.isFunction( selector ) ) {
			return typeof rootjQuery.ready !== "undefined" ?
				rootjQuery.ready( selector ) :
				// Execute immediately if ready is not present
				selector( jQuery );
		}

		if ( selector.selector !== undefined ) {
			this.selector = selector.selector;
			this.context = selector.context;
		}

		return jQuery.makeArray( selector, this );
	};

// Give the init function the jQuery prototype for later instantiation
init.prototype = jQuery.fn;

// Initialize central reference
rootjQuery = jQuery( document );
var rnotwhite = (/\S+/g);



// String to Object options format cache
var optionsCache = {};

// Convert String-formatted options into Object-formatted ones and store in cache
function createOptions( options ) {
	var object = optionsCache[ options ] = {};
	jQuery.each( options.match( rnotwhite ) || [], function( _, flag ) {
		object[ flag ] = true;
	});
	return object;
}

/*
 * Create a callback list using the following parameters:
 *
 *	options: an optional list of space-separated options that will change how
 *			the callback list behaves or a more traditional option object
 *
 * By default a callback list will act like an event callback list and can be
 * "fired" multiple times.
 *
 * Possible options:
 *
 *	once:			will ensure the callback list can only be fired once (like a Deferred)
 *
 *	memory:			will keep track of previous values and will call any callback added
 *					after the list has been fired right away with the latest "memorized"
 *					values (like a Deferred)
 *
 *	unique:			will ensure a callback can only be added once (no duplicate in the list)
 *
 *	stopOnFalse:	interrupt callings when a callback returns false
 *
 */
jQuery.Callbacks = function( options ) {

	// Convert options from String-formatted to Object-formatted if needed
	// (we check in cache first)
	options = typeof options === "string" ?
		( optionsCache[ options ] || createOptions( options ) ) :
		jQuery.extend( {}, options );

	var // Last fire value (for non-forgettable lists)
		memory,
		// Flag to know if list was already fired
		fired,
		// Flag to know if list is currently firing
		firing,
		// First callback to fire (used internally by add and fireWith)
		firingStart,
		// End of the loop when firing
		firingLength,
		// Index of currently firing callback (modified by remove if needed)
		firingIndex,
		// Actual callback list
		list = [],
		// Stack of fire calls for repeatable lists
		stack = !options.once && [],
		// Fire callbacks
		fire = function( data ) {
			memory = options.memory && data;
			fired = true;
			firingIndex = firingStart || 0;
			firingStart = 0;
			firingLength = list.length;
			firing = true;
			for ( ; list && firingIndex < firingLength; firingIndex++ ) {
				if ( list[ firingIndex ].apply( data[ 0 ], data[ 1 ] ) === false && options.stopOnFalse ) {
					memory = false; // To prevent further calls using add
					break;
				}
			}
			firing = false;
			if ( list ) {
				if ( stack ) {
					if ( stack.length ) {
						fire( stack.shift() );
					}
				} else if ( memory ) {
					list = [];
				} else {
					self.disable();
				}
			}
		},
		// Actual Callbacks object
		self = {
			// Add a callback or a collection of callbacks to the list
			add: function() {
				if ( list ) {
					// First, we save the current length
					var start = list.length;
					(function add( args ) {
						jQuery.each( args, function( _, arg ) {
							var type = jQuery.type( arg );
							if ( type === "function" ) {
								if ( !options.unique || !self.has( arg ) ) {
									list.push( arg );
								}
							} else if ( arg && arg.length && type !== "string" ) {
								// Inspect recursively
								add( arg );
							}
						});
					})( arguments );
					// Do we need to add the callbacks to the
					// current firing batch?
					if ( firing ) {
						firingLength = list.length;
					// With memory, if we're not firing then
					// we should call right away
					} else if ( memory ) {
						firingStart = start;
						fire( memory );
					}
				}
				return this;
			},
			// Remove a callback from the list
			remove: function() {
				if ( list ) {
					jQuery.each( arguments, function( _, arg ) {
						var index;
						while ( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) {
							list.splice( index, 1 );
							// Handle firing indexes
							if ( firing ) {
								if ( index <= firingLength ) {
									firingLength--;
								}
								if ( index <= firingIndex ) {
									firingIndex--;
								}
							}
						}
					});
				}
				return this;
			},
			// Check if a given callback is in the list.
			// If no argument is given, return whether or not list has callbacks attached.
			has: function( fn ) {
				return fn ? jQuery.inArray( fn, list ) > -1 : !!( list && list.length );
			},
			// Remove all callbacks from the list
			empty: function() {
				list = [];
				firingLength = 0;
				return this;
			},
			// Have the list do nothing anymore
			disable: function() {
				list = stack = memory = undefined;
				return this;
			},
			// Is it disabled?
			disabled: function() {
				return !list;
			},
			// Lock the list in its current state
			lock: function() {
				stack = undefined;
				if ( !memory ) {
					self.disable();
				}
				return this;
			},
			// Is it locked?
			locked: function() {
				return !stack;
			},
			// Call all callbacks with the given context and arguments
			fireWith: function( context, args ) {
				if ( list && ( !fired || stack ) ) {
					args = args || [];
					args = [ context, args.slice ? args.slice() : args ];
					if ( firing ) {
						stack.push( args );
					} else {
						fire( args );
					}
				}
				return this;
			},
			// Call all the callbacks with the given arguments
			fire: function() {
				self.fireWith( this, arguments );
				return this;
			},
			// To know if the callbacks have already been called at least once
			fired: function() {
				return !!fired;
			}
		};

	return self;
};


jQuery.extend({

	Deferred: function( func ) {
		var tuples = [
				// action, add listener, listener list, final state
				[ "resolve", "done", jQuery.Callbacks("once memory"), "resolved" ],
				[ "reject", "fail", jQuery.Callbacks("once memory"), "rejected" ],
				[ "notify", "progress", jQuery.Callbacks("memory") ]
			],
			state = "pending",
			promise = {
				state: function() {
					return state;
				},
				always: function() {
					deferred.done( arguments ).fail( arguments );
					return this;
				},
				then: function( /* fnDone, fnFail, fnProgress */ ) {
					var fns = arguments;
					return jQuery.Deferred(function( newDefer ) {
						jQuery.each( tuples, function( i, tuple ) {
							var fn = jQuery.isFunction( fns[ i ] ) && fns[ i ];
							// deferred[ done | fail | progress ] for forwarding actions to newDefer
							deferred[ tuple[1] ](function() {
								var returned = fn && fn.apply( this, arguments );
								if ( returned && jQuery.isFunction( returned.promise ) ) {
									returned.promise()
										.done( newDefer.resolve )
										.fail( newDefer.reject )
										.progress( newDefer.notify );
								} else {
									newDefer[ tuple[ 0 ] + "With" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments );
								}
							});
						});
						fns = null;
					}).promise();
				},
				// Get a promise for this deferred
				// If obj is provided, the promise aspect is added to the object
				promise: function( obj ) {
					return obj != null ? jQuery.extend( obj, promise ) : promise;
				}
			},
			deferred = {};

		// Keep pipe for back-compat
		promise.pipe = promise.then;

		// Add list-specific methods
		jQuery.each( tuples, function( i, tuple ) {
			var list = tuple[ 2 ],
				stateString = tuple[ 3 ];

			// promise[ done | fail | progress ] = list.add
			promise[ tuple[1] ] = list.add;

			// Handle state
			if ( stateString ) {
				list.add(function() {
					// state = [ resolved | rejected ]
					state = stateString;

				// [ reject_list | resolve_list ].disable; progress_list.lock
				}, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock );
			}

			// deferred[ resolve | reject | notify ]
			deferred[ tuple[0] ] = function() {
				deferred[ tuple[0] + "With" ]( this === deferred ? promise : this, arguments );
				return this;
			};
			deferred[ tuple[0] + "With" ] = list.fireWith;
		});

		// Make the deferred a promise
		promise.promise( deferred );

		// Call given func if any
		if ( func ) {
			func.call( deferred, deferred );
		}

		// All done!
		return deferred;
	},

	// Deferred helper
	when: function( subordinate /* , ..., subordinateN */ ) {
		var i = 0,
			resolveValues = slice.call( arguments ),
			length = resolveValues.length,

			// the count of uncompleted subordinates
			remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,

			// the master Deferred. If resolveValues consist of only a single Deferred, just use that.
			deferred = remaining === 1 ? subordinate : jQuery.Deferred(),

			// Update function for both resolve and progress values
			updateFunc = function( i, contexts, values ) {
				return function( value ) {
					contexts[ i ] = this;
					values[ i ] = arguments.length > 1 ? slice.call( arguments ) : value;
					if ( values === progressValues ) {
						deferred.notifyWith( contexts, values );
					} else if ( !( --remaining ) ) {
						deferred.resolveWith( contexts, values );
					}
				};
			},

			progressValues, progressContexts, resolveContexts;

		// add listeners to Deferred subordinates; treat others as resolved
		if ( length > 1 ) {
			progressValues = new Array( length );
			progressContexts = new Array( length );
			resolveContexts = new Array( length );
			for ( ; i < length; i++ ) {
				if ( resolveValues[ i ] && jQuery.isFunction( resolveValues[ i ].promise ) ) {
					resolveValues[ i ].promise()
						.done( updateFunc( i, resolveContexts, resolveValues ) )
						.fail( deferred.reject )
						.progress( updateFunc( i, progressContexts, progressValues ) );
				} else {
					--remaining;
				}
			}
		}

		// if we're not waiting on anything, resolve the master
		if ( !remaining ) {
			deferred.resolveWith( resolveContexts, resolveValues );
		}

		return deferred.promise();
	}
});


// The deferred used on DOM ready
var readyList;

jQuery.fn.ready = function( fn ) {
	// Add the callback
	jQuery.ready.promise().done( fn );

	return this;
};

jQuery.extend({
	// Is the DOM ready to be used? Set to true once it occurs.
	isReady: false,

	// A counter to track how many items to wait for before
	// the ready event fires. See #6781
	readyWait: 1,

	// Hold (or release) the ready event
	holdReady: function( hold ) {
		if ( hold ) {
			jQuery.readyWait++;
		} else {
			jQuery.ready( true );
		}
	},

	// Handle when the DOM is ready
	ready: function( wait ) {

		// Abort if there are pending holds or we're already ready
		if ( wait === true ? --jQuery.readyWait : jQuery.isReady ) {
			return;
		}

		// Remember that the DOM is ready
		jQuery.isReady = true;

		// If a normal DOM Ready event fired, decrement, and wait if need be
		if ( wait !== true && --jQuery.readyWait > 0 ) {
			return;
		}

		// If there are functions bound, to execute
		readyList.resolveWith( document, [ jQuery ] );

		// Trigger any bound ready events
		if ( jQuery.fn.triggerHandler ) {
			jQuery( document ).triggerHandler( "ready" );
			jQuery( document ).off( "ready" );
		}
	}
});

/**
 * The ready event handler and self cleanup method
 */
function completed() {
	document.removeEventListener( "DOMContentLoaded", completed, false );
	window.removeEventListener( "load", completed, false );
	jQuery.ready();
}

jQuery.ready.promise = function( obj ) {
	if ( !readyList ) {

		readyList = jQuery.Deferred();

		// Catch cases where $(document).ready() is called after the browser event has already occurred.
		// we once tried to use readyState "interactive" here, but it caused issues like the one
		// discovered by ChrisS here: http://bugs.jquery.com/ticket/12282#comment:15
		if ( document.readyState === "complete" ) {
			// Handle it asynchronously to allow scripts the opportunity to delay ready
			setTimeout( jQuery.ready );

		} else {

			// Use the handy event callback
			document.addEventListener( "DOMContentLoaded", completed, false );

			// A fallback to window.onload, that will always work
			window.addEventListener( "load", completed, false );
		}
	}
	return readyList.promise( obj );
};

// Kick off the DOM ready check even if the user does not
jQuery.ready.promise();




// Multifunctional method to get and set values of a collection
// The value/s can optionally be executed if it's a function
var access = jQuery.access = function( elems, fn, key, value, chainable, emptyGet, raw ) {
	var i = 0,
		len = elems.length,
		bulk = key == null;

	// Sets many values
	if ( jQuery.type( key ) === "object" ) {
		chainable = true;
		for ( i in key ) {
			jQuery.access( elems, fn, i, key[i], true, emptyGet, raw );
		}

	// Sets one value
	} else if ( value !== undefined ) {
		chainable = true;

		if ( !jQuery.isFunction( value ) ) {
			raw = true;
		}

		if ( bulk ) {
			// Bulk operations run against the entire set
			if ( raw ) {
				fn.call( elems, value );
				fn = null;

			// ...except when executing function values
			} else {
				bulk = fn;
				fn = function( elem, key, value ) {
					return bulk.call( jQuery( elem ), value );
				};
			}
		}

		if ( fn ) {
			for ( ; i < len; i++ ) {
				fn( elems[i], key, raw ? value : value.call( elems[i], i, fn( elems[i], key ) ) );
			}
		}
	}

	return chainable ?
		elems :

		// Gets
		bulk ?
			fn.call( elems ) :
			len ? fn( elems[0], key ) : emptyGet;
};


/**
 * Determines whether an object can have data
 */
jQuery.acceptData = function( owner ) {
	// Accepts only:
	//  - Node
	//    - Node.ELEMENT_NODE
	//    - Node.DOCUMENT_NODE
	//  - Object
	//    - Any
	/* jshint -W018 */
	return owner.nodeType === 1 || owner.nodeType === 9 || !( +owner.nodeType );
};


function Data() {
	// Support: Android < 4,
	// Old WebKit does not have Object.preventExtensions/freeze method,
	// return new empty object instead with no [[set]] accessor
	Object.defineProperty( this.cache = {}, 0, {
		get: function() {
			return {};
		}
	});

	this.expando = jQuery.expando + Math.random();
}

Data.uid = 1;
Data.accepts = jQuery.acceptData;

Data.prototype = {
	key: function( owner ) {
		// We can accept data for non-element nodes in modern browsers,
		// but we should not, see #8335.
		// Always return the key for a frozen object.
		if ( !Data.accepts( owner ) ) {
			return 0;
		}

		var descriptor = {},
			// Check if the owner object already has a cache key
			unlock = owner[ this.expando ];

		// If not, create one
		if ( !unlock ) {
			unlock = Data.uid++;

			// Secure it in a non-enumerable, non-writable property
			try {
				descriptor[ this.expando ] = { value: unlock };
				Object.defineProperties( owner, descriptor );

			// Support: Android < 4
			// Fallback to a less secure definition
			} catch ( e ) {
				descriptor[ this.expando ] = unlock;
				jQuery.extend( owner, descriptor );
			}
		}

		// Ensure the cache object
		if ( !this.cache[ unlock ] ) {
			this.cache[ unlock ] = {};
		}

		return unlock;
	},
	set: function( owner, data, value ) {
		var prop,
			// There may be an unlock assigned to this node,
			// if there is no entry for this "owner", create one inline
			// and set the unlock as though an owner entry had always existed
			unlock = this.key( owner ),
			cache = this.cache[ unlock ];

		// Handle: [ owner, key, value ] args
		if ( typeof data === "string" ) {
			cache[ data ] = value;

		// Handle: [ owner, { properties } ] args
		} else {
			// Fresh assignments by object are shallow copied
			if ( jQuery.isEmptyObject( cache ) ) {
				jQuery.extend( this.cache[ unlock ], data );
			// Otherwise, copy the properties one-by-one to the cache object
			} else {
				for ( prop in data ) {
					cache[ prop ] = data[ prop ];
				}
			}
		}
		return cache;
	},
	get: function( owner, key ) {
		// Either a valid cache is found, or will be created.
		// New caches will be created and the unlock returned,
		// allowing direct access to the newly created
		// empty data object. A valid owner object must be provided.
		var cache = this.cache[ this.key( owner ) ];

		return key === undefined ?
			cache : cache[ key ];
	},
	access: function( owner, key, value ) {
		var stored;
		// In cases where either:
		//
		//   1. No key was specified
		//   2. A string key was specified, but no value provided
		//
		// Take the "read" path and allow the get method to determine
		// which value to return, respectively either:
		//
		//   1. The entire cache object
		//   2. The data stored at the key
		//
		if ( key === undefined ||
				((key && typeof key === "string") && value === undefined) ) {

			stored = this.get( owner, key );

			return stored !== undefined ?
				stored : this.get( owner, jQuery.camelCase(key) );
		}

		// [*]When the key is not a string, or both a key and value
		// are specified, set or extend (existing objects) with either:
		//
		//   1. An object of properties
		//   2. A key and value
		//
		this.set( owner, key, value );

		// Since the "set" path can have two possible entry points
		// return the expected data based on which path was taken[*]
		return value !== undefined ? value : key;
	},
	remove: function( owner, key ) {
		var i, name, camel,
			unlock = this.key( owner ),
			cache = this.cache[ unlock ];

		if ( key === undefined ) {
			this.cache[ unlock ] = {};

		} else {
			// Support array or space separated string of keys
			if ( jQuery.isArray( key ) ) {
				// If "name" is an array of keys...
				// When data is initially created, via ("key", "val") signature,
				// keys will be converted to camelCase.
				// Since there is no way to tell _how_ a key was added, remove
				// both plain key and camelCase key. #12786
				// This will only penalize the array argument path.
				name = key.concat( key.map( jQuery.camelCase ) );
			} else {
				camel = jQuery.camelCase( key );
				// Try the string as a key before any manipulation
				if ( key in cache ) {
					name = [ key, camel ];
				} else {
					// If a key with the spaces exists, use it.
					// Otherwise, create an array by matching non-whitespace
					name = camel;
					name = name in cache ?
						[ name ] : ( name.match( rnotwhite ) || [] );
				}
			}

			i = name.length;
			while ( i-- ) {
				delete cache[ name[ i ] ];
			}
		}
	},
	hasData: function( owner ) {
		return !jQuery.isEmptyObject(
			this.cache[ owner[ this.expando ] ] || {}
		);
	},
	discard: function( owner ) {
		if ( owner[ this.expando ] ) {
			delete this.cache[ owner[ this.expando ] ];
		}
	}
};
var data_priv = new Data();

var data_user = new Data();



/*
	Implementation Summary

	1. Enforce API surface and semantic compatibility with 1.9.x branch
	2. Improve the module's maintainability by reducing the storage
		paths to a single mechanism.
	3. Use the same single mechanism to support "private" and "user" data.
	4. _Never_ expose "private" data to user code (TODO: Drop _data, _removeData)
	5. Avoid exposing implementation details on user objects (eg. expando properties)
	6. Provide a clear path for implementation upgrade to WeakMap in 2014
*/
var rbrace = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
	rmultiDash = /([A-Z])/g;

function dataAttr( elem, key, data ) {
	var name;

	// If nothing was found internally, try to fetch any
	// data from the HTML5 data-* attribute
	if ( data === undefined && elem.nodeType === 1 ) {
		name = "data-" + key.replace( rmultiDash, "-$1" ).toLowerCase();
		data = elem.getAttribute( name );

		if ( typeof data === "string" ) {
			try {
				data = data === "true" ? true :
					data === "false" ? false :
					data === "null" ? null :
					// Only convert to a number if it doesn't change the string
					+data + "" === data ? +data :
					rbrace.test( data ) ? jQuery.parseJSON( data ) :
					data;
			} catch( e ) {}

			// Make sure we set the data so it isn't changed later
			data_user.set( elem, key, data );
		} else {
			data = undefined;
		}
	}
	return data;
}

jQuery.extend({
	hasData: function( elem ) {
		return data_user.hasData( elem ) || data_priv.hasData( elem );
	},

	data: function( elem, name, data ) {
		return data_user.access( elem, name, data );
	},

	removeData: function( elem, name ) {
		data_user.remove( elem, name );
	},

	// TODO: Now that all calls to _data and _removeData have been replaced
	// with direct calls to data_priv methods, these can be deprecated.
	_data: function( elem, name, data ) {
		return data_priv.access( elem, name, data );
	},

	_removeData: function( elem, name ) {
		data_priv.remove( elem, name );
	}
});

jQuery.fn.extend({
	data: function( key, value ) {
		var i, name, data,
			elem = this[ 0 ],
			attrs = elem && elem.attributes;

		// Gets all values
		if ( key === undefined ) {
			if ( this.length ) {
				data = data_user.get( elem );

				if ( elem.nodeType === 1 && !data_priv.get( elem, "hasDataAttrs" ) ) {
					i = attrs.length;
					while ( i-- ) {
						name = attrs[ i ].name;

						if ( name.indexOf( "data-" ) === 0 ) {
							name = jQuery.camelCase( name.slice(5) );
							dataAttr( elem, name, data[ name ] );
						}
					}
					data_priv.set( elem, "hasDataAttrs", true );
				}
			}

			return data;
		}

		// Sets multiple values
		if ( typeof key === "object" ) {
			return this.each(function() {
				data_user.set( this, key );
			});
		}

		return access( this, function( value ) {
			var data,
				camelKey = jQuery.camelCase( key );

			// The calling jQuery object (element matches) is not empty
			// (and therefore has an element appears at this[ 0 ]) and the
			// `value` parameter was not undefined. An empty jQuery object
			// will result in `undefined` for elem = this[ 0 ] which will
			// throw an exception if an attempt to read a data cache is made.
			if ( elem && value === undefined ) {
				// Attempt to get data from the cache
				// with the key as-is
				data = data_user.get( elem, key );
				if ( data !== undefined ) {
					return data;
				}

				// Attempt to get data from the cache
				// with the key camelized
				data = data_user.get( elem, camelKey );
				if ( data !== undefined ) {
					return data;
				}

				// Attempt to "discover" the data in
				// HTML5 custom data-* attrs
				data = dataAttr( elem, camelKey, undefined );
				if ( data !== undefined ) {
					return data;
				}

				// We tried really hard, but the data doesn't exist.
				return;
			}

			// Set the data...
			this.each(function() {
				// First, attempt to store a copy or reference of any
				// data that might've been store with a camelCased key.
				var data = data_user.get( this, camelKey );

				// For HTML5 data-* attribute interop, we have to
				// store property names with dashes in a camelCase form.
				// This might not apply to all properties...*
				data_user.set( this, camelKey, value );

				// *... In the case of properties that might _actually_
				// have dashes, we need to also store a copy of that
				// unchanged property.
				if ( key.indexOf("-") !== -1 && data !== undefined ) {
					data_user.set( this, key, value );
				}
			});
		}, null, value, arguments.length > 1, null, true );
	},

	removeData: function( key ) {
		return this.each(function() {
			data_user.remove( this, key );
		});
	}
});


jQuery.extend({
	queue: function( elem, type, data ) {
		var queue;

		if ( elem ) {
			type = ( type || "fx" ) + "queue";
			queue = data_priv.get( elem, type );

			// Speed up dequeue by getting out quickly if this is just a lookup
			if ( data ) {
				if ( !queue || jQuery.isArray( data ) ) {
					queue = data_priv.access( elem, type, jQuery.makeArray(data) );
				} else {
					queue.push( data );
				}
			}
			return queue || [];
		}
	},

	dequeue: function( elem, type ) {
		type = type || "fx";

		var queue = jQuery.queue( elem, type ),
			startLength = queue.length,
			fn = queue.shift(),
			hooks = jQuery._queueHooks( elem, type ),
			next = function() {
				jQuery.dequeue( elem, type );
			};

		// If the fx queue is dequeued, always remove the progress sentinel
		if ( fn === "inprogress" ) {
			fn = queue.shift();
			startLength--;
		}

		if ( fn ) {

			// Add a progress sentinel to prevent the fx queue from being
			// automatically dequeued
			if ( type === "fx" ) {
				queue.unshift( "inprogress" );
			}

			// clear up the last queue stop function
			delete hooks.stop;
			fn.call( elem, next, hooks );
		}

		if ( !startLength && hooks ) {
			hooks.empty.fire();
		}
	},

	// not intended for public consumption - generates a queueHooks object, or returns the current one
	_queueHooks: function( elem, type ) {
		var key = type + "queueHooks";
		return data_priv.get( elem, key ) || data_priv.access( elem, key, {
			empty: jQuery.Callbacks("once memory").add(function() {
				data_priv.remove( elem, [ type + "queue", key ] );
			})
		});
	}
});

jQuery.fn.extend({
	queue: function( type, data ) {
		var setter = 2;

		if ( typeof type !== "string" ) {
			data = type;
			type = "fx";
			setter--;
		}

		if ( arguments.length < setter ) {
			return jQuery.queue( this[0], type );
		}

		return data === undefined ?
			this :
			this.each(function() {
				var queue = jQuery.queue( this, type, data );

				// ensure a hooks for this queue
				jQuery._queueHooks( this, type );

				if ( type === "fx" && queue[0] !== "inprogress" ) {
					jQuery.dequeue( this, type );
				}
			});
	},
	dequeue: function( type ) {
		return this.each(function() {
			jQuery.dequeue( this, type );
		});
	},
	clearQueue: function( type ) {
		return this.queue( type || "fx", [] );
	},
	// Get a promise resolved when queues of a certain type
	// are emptied (fx is the type by default)
	promise: function( type, obj ) {
		var tmp,
			count = 1,
			defer = jQuery.Deferred(),
			elements = this,
			i = this.length,
			resolve = function() {
				if ( !( --count ) ) {
					defer.resolveWith( elements, [ elements ] );
				}
			};

		if ( typeof type !== "string" ) {
			obj = type;
			type = undefined;
		}
		type = type || "fx";

		while ( i-- ) {
			tmp = data_priv.get( elements[ i ], type + "queueHooks" );
			if ( tmp && tmp.empty ) {
				count++;
				tmp.empty.add( resolve );
			}
		}
		resolve();
		return defer.promise( obj );
	}
});
var pnum = (/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/).source;

var strundefined = typeof undefined;



support.focusinBubbles = "onfocusin" in window;


var
	rkeyEvent = /^key/,
	rmouseEvent = /^(?:mouse|contextmenu)|click/,
	rfocusMorph = /^(?:focusinfocus|focusoutblur)$/,
	rtypenamespace = /^([^.]*)(?:\.(.+)|)$/;

function returnTrue() {
	return true;
}

function returnFalse() {
	return false;
}

function safeActiveElement() {
	try {
		return document.activeElement;
	} catch ( err ) { }
}

/*
 * Helper functions for managing events -- not part of the public interface.
 * Props to Dean Edwards' addEvent library for many of the ideas.
 */
jQuery.event = {

	global: {},

	add: function( elem, types, handler, data, selector ) {

		var handleObjIn, eventHandle, tmp,
			events, t, handleObj,
			special, handlers, type, namespaces, origType,
			elemData = data_priv.get( elem );

		// Don't attach events to noData or text/comment nodes (but allow plain objects)
		if ( !elemData ) {
			return;
		}

		// Caller can pass in an object of custom data in lieu of the handler
		if ( handler.handler ) {
			handleObjIn = handler;
			handler = handleObjIn.handler;
			selector = handleObjIn.selector;
		}

		// Make sure that the handler has a unique ID, used to find/remove it later
		if ( !handler.guid ) {
			handler.guid = jQuery.guid++;
		}

		// Init the element's event structure and main handler, if this is the first
		if ( !(events = elemData.events) ) {
			events = elemData.events = {};
		}
		if ( !(eventHandle = elemData.handle) ) {
			eventHandle = elemData.handle = function( e ) {
				// Discard the second event of a jQuery.event.trigger() and
				// when an event is called after a page has unloaded
				return typeof jQuery !== strundefined && jQuery.event.triggered !== e.type ?
					jQuery.event.dispatch.apply( elem, arguments ) : undefined;
			};
		}

		// Handle multiple events separated by a space
		types = ( types || "" ).match( rnotwhite ) || [ "" ];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// There *must* be a type, no attaching namespace-only handlers
			if ( !type ) {
				continue;
			}

			// If event changes its type, use the special event handlers for the changed type
			special = jQuery.event.special[ type ] || {};

			// If selector defined, determine special event api type, otherwise given type
			type = ( selector ? special.delegateType : special.bindType ) || type;

			// Update special based on newly reset type
			special = jQuery.event.special[ type ] || {};

			// handleObj is passed to all event handlers
			handleObj = jQuery.extend({
				type: type,
				origType: origType,
				data: data,
				handler: handler,
				guid: handler.guid,
				selector: selector,
				needsContext: selector && jQuery.expr.match.needsContext.test( selector ),
				namespace: namespaces.join(".")
			}, handleObjIn );

			// Init the event handler queue if we're the first
			if ( !(handlers = events[ type ]) ) {
				handlers = events[ type ] = [];
				handlers.delegateCount = 0;

				// Only use addEventListener if the special events handler returns false
				if ( !special.setup || special.setup.call( elem, data, namespaces, eventHandle ) === false ) {
					if ( elem.addEventListener ) {
						elem.addEventListener( type, eventHandle, false );
					}
				}
			}

			if ( special.add ) {
				special.add.call( elem, handleObj );

				if ( !handleObj.handler.guid ) {
					handleObj.handler.guid = handler.guid;
				}
			}

			// Add to the element's handler list, delegates in front
			if ( selector ) {
				handlers.splice( handlers.delegateCount++, 0, handleObj );
			} else {
				handlers.push( handleObj );
			}

			// Keep track of which events have ever been used, for event optimization
			jQuery.event.global[ type ] = true;
		}

	},

	// Detach an event or set of events from an element
	remove: function( elem, types, handler, selector, mappedTypes ) {

		var j, origCount, tmp,
			events, t, handleObj,
			special, handlers, type, namespaces, origType,
			elemData = data_priv.hasData( elem ) && data_priv.get( elem );

		if ( !elemData || !(events = elemData.events) ) {
			return;
		}

		// Once for each type.namespace in types; type may be omitted
		types = ( types || "" ).match( rnotwhite ) || [ "" ];
		t = types.length;
		while ( t-- ) {
			tmp = rtypenamespace.exec( types[t] ) || [];
			type = origType = tmp[1];
			namespaces = ( tmp[2] || "" ).split( "." ).sort();

			// Unbind all events (on this namespace, if provided) for the element
			if ( !type ) {
				for ( type in events ) {
					jQuery.event.remove( elem, type + types[ t ], handler, selector, true );
				}
				continue;
			}

			special = jQuery.event.special[ type ] || {};
			type = ( selector ? special.delegateType : special.bindType ) || type;
			handlers = events[ type ] || [];
			tmp = tmp[2] && new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" );

			// Remove matching events
			origCount = j = handlers.length;
			while ( j-- ) {
				handleObj = handlers[ j ];

				if ( ( mappedTypes || origType === handleObj.origType ) &&
					( !handler || handler.guid === handleObj.guid ) &&
					( !tmp || tmp.test( handleObj.namespace ) ) &&
					( !selector || selector === handleObj.selector || selector === "**" && handleObj.selector ) ) {
					handlers.splice( j, 1 );

					if ( handleObj.selector ) {
						handlers.delegateCount--;
					}
					if ( special.remove ) {
						special.remove.call( elem, handleObj );
					}
				}
			}

			// Remove generic event handler if we removed something and no more handlers exist
			// (avoids potential for endless recursion during removal of special event handlers)
			if ( origCount && !handlers.length ) {
				if ( !special.teardown || special.teardown.call( elem, namespaces, elemData.handle ) === false ) {
					jQuery.removeEvent( elem, type, elemData.handle );
				}

				delete events[ type ];
			}
		}

		// Remove the expando if it's no longer used
		if ( jQuery.isEmptyObject( events ) ) {
			delete elemData.handle;
			data_priv.remove( elem, "events" );
		}
	},

	trigger: function( event, data, elem, onlyHandlers ) {

		var i, cur, tmp, bubbleType, ontype, handle, special,
			eventPath = [ elem || document ],
			type = hasOwn.call( event, "type" ) ? event.type : event,
			namespaces = hasOwn.call( event, "namespace" ) ? event.namespace.split(".") : [];

		cur = tmp = elem = elem || document;

		// Don't do events on text and comment nodes
		if ( elem.nodeType === 3 || elem.nodeType === 8 ) {
			return;
		}

		// focus/blur morphs to focusin/out; ensure we're not firing them right now
		if ( rfocusMorph.test( type + jQuery.event.triggered ) ) {
			return;
		}

		if ( type.indexOf(".") >= 0 ) {
			// Namespaced trigger; create a regexp to match event type in handle()
			namespaces = type.split(".");
			type = namespaces.shift();
			namespaces.sort();
		}
		ontype = type.indexOf(":") < 0 && "on" + type;

		// Caller can pass in a jQuery.Event object, Object, or just an event type string
		event = event[ jQuery.expando ] ?
			event :
			new jQuery.Event( type, typeof event === "object" && event );

		// Trigger bitmask: & 1 for native handlers; & 2 for jQuery (always true)
		event.isTrigger = onlyHandlers ? 2 : 3;
		event.namespace = namespaces.join(".");
		event.namespace_re = event.namespace ?
			new RegExp( "(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)" ) :
			null;

		// Clean up the event in case it is being reused
		event.result = undefined;
		if ( !event.target ) {
			event.target = elem;
		}

		// Clone any incoming data and prepend the event, creating the handler arg list
		data = data == null ?
			[ event ] :
			jQuery.makeArray( data, [ event ] );

		// Allow special events to draw outside the lines
		special = jQuery.event.special[ type ] || {};
		if ( !onlyHandlers && special.trigger && special.trigger.apply( elem, data ) === false ) {
			return;
		}

		// Determine event propagation path in advance, per W3C events spec (#9951)
		// Bubble up to document, then to window; watch for a global ownerDocument var (#9724)
		if ( !onlyHandlers && !special.noBubble && !jQuery.isWindow( elem ) ) {

			bubbleType = special.delegateType || type;
			if ( !rfocusMorph.test( bubbleType + type ) ) {
				cur = cur.parentNode;
			}
			for ( ; cur; cur = cur.parentNode ) {
				eventPath.push( cur );
				tmp = cur;
			}

			// Only add window if we got to document (e.g., not plain obj or detached DOM)
			if ( tmp === (elem.ownerDocument || document) ) {
				eventPath.push( tmp.defaultView || tmp.parentWindow || window );
			}
		}

		// Fire handlers on the event path
		i = 0;
		while ( (cur = eventPath[i++]) && !event.isPropagationStopped() ) {

			event.type = i > 1 ?
				bubbleType :
				special.bindType || type;

			// jQuery handler
			handle = ( data_priv.get( cur, "events" ) || {} )[ event.type ] && data_priv.get( cur, "handle" );
			if ( handle ) {
				handle.apply( cur, data );
			}

			// Native handler
			handle = ontype && cur[ ontype ];
			if ( handle && handle.apply && jQuery.acceptData( cur ) ) {
				event.result = handle.apply( cur, data );
				if ( event.result === false ) {
					event.preventDefault();
				}
			}
		}
		event.type = type;

		// If nobody prevented the default action, do it now
		if ( !onlyHandlers && !event.isDefaultPrevented() ) {

			if ( (!special._default || special._default.apply( eventPath.pop(), data ) === false) &&
				jQuery.acceptData( elem ) ) {

				// Call a native DOM method on the target with the same name name as the event.
				// Don't do default actions on window, that's where global variables be (#6170)
				if ( ontype && jQuery.isFunction( elem[ type ] ) && !jQuery.isWindow( elem ) ) {

					// Don't re-trigger an onFOO event when we call its FOO() method
					tmp = elem[ ontype ];

					if ( tmp ) {
						elem[ ontype ] = null;
					}

					// Prevent re-triggering of the same event, since we already bubbled it above
					jQuery.event.triggered = type;
					elem[ type ]();
					jQuery.event.triggered = undefined;

					if ( tmp ) {
						elem[ ontype ] = tmp;
					}
				}
			}
		}

		return event.result;
	},

	dispatch: function( event ) {

		// Make a writable jQuery.Event from the native event object
		event = jQuery.event.fix( event );

		var i, j, ret, matched, handleObj,
			handlerQueue = [],
			args = slice.call( arguments ),
			handlers = ( data_priv.get( this, "events" ) || {} )[ event.type ] || [],
			special = jQuery.event.special[ event.type ] || {};

		// Use the fix-ed jQuery.Event rather than the (read-only) native event
		args[0] = event;
		event.delegateTarget = this;

		// Call the preDispatch hook for the mapped type, and let it bail if desired
		if ( special.preDispatch && special.preDispatch.call( this, event ) === false ) {
			return;
		}

		// Determine handlers
		handlerQueue = jQuery.event.handlers.call( this, event, handlers );

		// Run delegates first; they may want to stop propagation beneath us
		i = 0;
		while ( (matched = handlerQueue[ i++ ]) && !event.isPropagationStopped() ) {
			event.currentTarget = matched.elem;

			j = 0;
			while ( (handleObj = matched.handlers[ j++ ]) && !event.isImmediatePropagationStopped() ) {

				// Triggered event must either 1) have no namespace, or
				// 2) have namespace(s) a subset or equal to those in the bound event (both can have no namespace).
				if ( !event.namespace_re || event.namespace_re.test( handleObj.namespace ) ) {

					event.handleObj = handleObj;
					event.data = handleObj.data;

					ret = ( (jQuery.event.special[ handleObj.origType ] || {}).handle || handleObj.handler )
							.apply( matched.elem, args );

					if ( ret !== undefined ) {
						if ( (event.result = ret) === false ) {
							event.preventDefault();
							event.stopPropagation();
						}
					}
				}
			}
		}

		// Call the postDispatch hook for the mapped type
		if ( special.postDispatch ) {
			special.postDispatch.call( this, event );
		}

		return event.result;
	},

	handlers: function( event, handlers ) {
		var i, matches, sel, handleObj,
			handlerQueue = [],
			delegateCount = handlers.delegateCount,
			cur = event.target;

		// Find delegate handlers
		// Black-hole SVG <use> instance trees (#13180)
		// Avoid non-left-click bubbling in Firefox (#3861)
		if ( delegateCount && cur.nodeType && (!event.button || event.type !== "click") ) {

			for ( ; cur !== this; cur = cur.parentNode || this ) {

				// Don't process clicks on disabled elements (#6911, #8165, #11382, #11764)
				if ( cur.disabled !== true || event.type !== "click" ) {
					matches = [];
					for ( i = 0; i < delegateCount; i++ ) {
						handleObj = handlers[ i ];

						// Don't conflict with Object.prototype properties (#13203)
						sel = handleObj.selector + " ";

						if ( matches[ sel ] === undefined ) {
							matches[ sel ] = handleObj.needsContext ?
								jQuery( sel, this ).index( cur ) >= 0 :
								jQuery.find( sel, this, null, [ cur ] ).length;
						}
						if ( matches[ sel ] ) {
							matches.push( handleObj );
						}
					}
					if ( matches.length ) {
						handlerQueue.push({ elem: cur, handlers: matches });
					}
				}
			}
		}

		// Add the remaining (directly-bound) handlers
		if ( delegateCount < handlers.length ) {
			handlerQueue.push({ elem: this, handlers: handlers.slice( delegateCount ) });
		}

		return handlerQueue;
	},

	// Includes some event props shared by KeyEvent and MouseEvent
	props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),

	fixHooks: {},

	keyHooks: {
		props: "char charCode key keyCode".split(" "),
		filter: function( event, original ) {

			// Add which for key events
			if ( event.which == null ) {
				event.which = original.charCode != null ? original.charCode : original.keyCode;
			}

			return event;
		}
	},

	mouseHooks: {
		props: "button buttons clientX clientY offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
		filter: function( event, original ) {
			var eventDoc, doc, body,
				button = original.button;

			// Calculate pageX/Y if missing and clientX/Y available
			if ( event.pageX == null && original.clientX != null ) {
				eventDoc = event.target.ownerDocument || document;
				doc = eventDoc.documentElement;
				body = eventDoc.body;

				event.pageX = original.clientX + ( doc && doc.scrollLeft || body && body.scrollLeft || 0 ) - ( doc && doc.clientLeft || body && body.clientLeft || 0 );
				event.pageY = original.clientY + ( doc && doc.scrollTop  || body && body.scrollTop  || 0 ) - ( doc && doc.clientTop  || body && body.clientTop  || 0 );
			}

			// Add which for click: 1 === left; 2 === middle; 3 === right
			// Note: button is not normalized, so don't use it
			if ( !event.which && button !== undefined ) {
				event.which = ( button & 1 ? 1 : ( button & 2 ? 3 : ( button & 4 ? 2 : 0 ) ) );
			}

			return event;
		}
	},

	fix: function( event ) {
		if ( event[ jQuery.expando ] ) {
			return event;
		}

		// Create a writable copy of the event object and normalize some properties
		var i, prop, copy,
			type = event.type,
			originalEvent = event,
			fixHook = this.fixHooks[ type ];

		if ( !fixHook ) {
			this.fixHooks[ type ] = fixHook =
				rmouseEvent.test( type ) ? this.mouseHooks :
				rkeyEvent.test( type ) ? this.keyHooks :
				{};
		}
		copy = fixHook.props ? this.props.concat( fixHook.props ) : this.props;

		event = new jQuery.Event( originalEvent );

		i = copy.length;
		while ( i-- ) {
			prop = copy[ i ];
			event[ prop ] = originalEvent[ prop ];
		}

		// Support: Cordova 2.5 (WebKit) (#13255)
		// All events should have a target; Cordova deviceready doesn't
		if ( !event.target ) {
			event.target = document;
		}

		// Support: Safari 6.0+, Chrome < 28
		// Target should not be a text node (#504, #13143)
		if ( event.target.nodeType === 3 ) {
			event.target = event.target.parentNode;
		}

		return fixHook.filter ? fixHook.filter( event, originalEvent ) : event;
	},

	special: {
		load: {
			// Prevent triggered image.load events from bubbling to window.load
			noBubble: true
		},
		focus: {
			// Fire native event if possible so blur/focus sequence is correct
			trigger: function() {
				if ( this !== safeActiveElement() && this.focus ) {
					this.focus();
					return false;
				}
			},
			delegateType: "focusin"
		},
		blur: {
			trigger: function() {
				if ( this === safeActiveElement() && this.blur ) {
					this.blur();
					return false;
				}
			},
			delegateType: "focusout"
		},
		click: {
			// For checkbox, fire native event so checked state will be right
			trigger: function() {
				if ( this.type === "checkbox" && this.click && jQuery.nodeName( this, "input" ) ) {
					this.click();
					return false;
				}
			},

			// For cross-browser consistency, don't fire native .click() on links
			_default: function( event ) {
				return jQuery.nodeName( event.target, "a" );
			}
		},

		beforeunload: {
			postDispatch: function( event ) {

				// Support: Firefox 20+
				// Firefox doesn't alert if the returnValue field is not set.
				if ( event.result !== undefined && event.originalEvent ) {
					event.originalEvent.returnValue = event.result;
				}
			}
		}
	},

	simulate: function( type, elem, event, bubble ) {
		// Piggyback on a donor event to simulate a different one.
		// Fake originalEvent to avoid donor's stopPropagation, but if the
		// simulated event prevents default then we do the same on the donor.
		var e = jQuery.extend(
			new jQuery.Event(),
			event,
			{
				type: type,
				isSimulated: true,
				originalEvent: {}
			}
		);
		if ( bubble ) {
			jQuery.event.trigger( e, null, elem );
		} else {
			jQuery.event.dispatch.call( elem, e );
		}
		if ( e.isDefaultPrevented() ) {
			event.preventDefault();
		}
	}
};

jQuery.removeEvent = function( elem, type, handle ) {
	if ( elem.removeEventListener ) {
		elem.removeEventListener( type, handle, false );
	}
};

jQuery.Event = function( src, props ) {
	// Allow instantiation without the 'new' keyword
	if ( !(this instanceof jQuery.Event) ) {
		return new jQuery.Event( src, props );
	}

	// Event object
	if ( src && src.type ) {
		this.originalEvent = src;
		this.type = src.type;

		// Events bubbling up the document may have been marked as prevented
		// by a handler lower down the tree; reflect the correct value.
		this.isDefaultPrevented = src.defaultPrevented ||
				// Support: Android < 4.0
				src.defaultPrevented === undefined &&
				src.getPreventDefault && src.getPreventDefault() ?
			returnTrue :
			returnFalse;

	// Event type
	} else {
		this.type = src;
	}

	// Put explicitly provided properties onto the event object
	if ( props ) {
		jQuery.extend( this, props );
	}

	// Create a timestamp if incoming event doesn't have one
	this.timeStamp = src && src.timeStamp || jQuery.now();

	// Mark it as fixed
	this[ jQuery.expando ] = true;
};

// jQuery.Event is based on DOM3 Events as specified by the ECMAScript Language Binding
// http://www.w3.org/TR/2003/WD-DOM-Level-3-Events-20030331/ecma-script-binding.html
jQuery.Event.prototype = {
	isDefaultPrevented: returnFalse,
	isPropagationStopped: returnFalse,
	isImmediatePropagationStopped: returnFalse,

	preventDefault: function() {
		var e = this.originalEvent;

		this.isDefaultPrevented = returnTrue;

		if ( e && e.preventDefault ) {
			e.preventDefault();
		}
	},
	stopPropagation: function() {
		var e = this.originalEvent;

		this.isPropagationStopped = returnTrue;

		if ( e && e.stopPropagation ) {
			e.stopPropagation();
		}
	},
	stopImmediatePropagation: function() {
		this.isImmediatePropagationStopped = returnTrue;
		this.stopPropagation();
	}
};

// Create mouseenter/leave events using mouseover/out and event-time checks
// Support: Chrome 15+
jQuery.each({
	mouseenter: "mouseover",
	mouseleave: "mouseout"
}, function( orig, fix ) {
	jQuery.event.special[ orig ] = {
		delegateType: fix,
		bindType: fix,

		handle: function( event ) {
			var ret,
				target = this,
				related = event.relatedTarget,
				handleObj = event.handleObj;

			// For mousenter/leave call the handler if related is outside the target.
			// NB: No relatedTarget if the mouse left/entered the browser window
			if ( !related || (related !== target && !jQuery.contains( target, related )) ) {
				event.type = handleObj.origType;
				ret = handleObj.handler.apply( this, arguments );
				event.type = fix;
			}
			return ret;
		}
	};
});

// Create "bubbling" focus and blur events
// Support: Firefox, Chrome, Safari
if ( !support.focusinBubbles ) {
	jQuery.each({ focus: "focusin", blur: "focusout" }, function( orig, fix ) {

		// Attach a single capturing handler on the document while someone wants focusin/focusout
		var handler = function( event ) {
				jQuery.event.simulate( fix, event.target, jQuery.event.fix( event ), true );
			};

		jQuery.event.special[ fix ] = {
			setup: function() {
				var doc = this.ownerDocument || this,
					attaches = data_priv.access( doc, fix );

				if ( !attaches ) {
					doc.addEventListener( orig, handler, true );
				}
				data_priv.access( doc, fix, ( attaches || 0 ) + 1 );
			},
			teardown: function() {
				var doc = this.ownerDocument || this,
					attaches = data_priv.access( doc, fix ) - 1;

				if ( !attaches ) {
					doc.removeEventListener( orig, handler, true );
					data_priv.remove( doc, fix );

				} else {
					data_priv.access( doc, fix, attaches );
				}
			}
		};
	});
}

jQuery.fn.extend({

	on: function( types, selector, data, fn, /*INTERNAL*/ one ) {
		var origFn, type;

		// Types can be a map of types/handlers
		if ( typeof types === "object" ) {
			// ( types-Object, selector, data )
			if ( typeof selector !== "string" ) {
				// ( types-Object, data )
				data = data || selector;
				selector = undefined;
			}
			for ( type in types ) {
				this.on( type, selector, data, types[ type ], one );
			}
			return this;
		}

		if ( data == null && fn == null ) {
			// ( types, fn )
			fn = selector;
			data = selector = undefined;
		} else if ( fn == null ) {
			if ( typeof selector === "string" ) {
				// ( types, selector, fn )
				fn = data;
				data = undefined;
			} else {
				// ( types, data, fn )
				fn = data;
				data = selector;
				selector = undefined;
			}
		}
		if ( fn === false ) {
			fn = returnFalse;
		} else if ( !fn ) {
			return this;
		}

		if ( one === 1 ) {
			origFn = fn;
			fn = function( event ) {
				// Can use an empty set, since event contains the info
				jQuery().off( event );
				return origFn.apply( this, arguments );
			};
			// Use same guid so caller can remove using origFn
			fn.guid = origFn.guid || ( origFn.guid = jQuery.guid++ );
		}
		return this.each( function() {
			jQuery.event.add( this, types, fn, data, selector );
		});
	},
	one: function( types, selector, data, fn ) {
		return this.on( types, selector, data, fn, 1 );
	},
	off: function( types, selector, fn ) {
		var handleObj, type;
		if ( types && types.preventDefault && types.handleObj ) {
			// ( event )  dispatched jQuery.Event
			handleObj = types.handleObj;
			jQuery( types.delegateTarget ).off(
				handleObj.namespace ? handleObj.origType + "." + handleObj.namespace : handleObj.origType,
				handleObj.selector,
				handleObj.handler
			);
			return this;
		}
		if ( typeof types === "object" ) {
			// ( types-object [, selector] )
			for ( type in types ) {
				this.off( type, selector, types[ type ] );
			}
			return this;
		}
		if ( selector === false || typeof selector === "function" ) {
			// ( types [, fn] )
			fn = selector;
			selector = undefined;
		}
		if ( fn === false ) {
			fn = returnFalse;
		}
		return this.each(function() {
			jQuery.event.remove( this, types, fn, selector );
		});
	},

	trigger: function( type, data ) {
		return this.each(function() {
			jQuery.event.trigger( type, data, this );
		});
	},
	triggerHandler: function( type, data ) {
		var elem = this[0];
		if ( elem ) {
			return jQuery.event.trigger( type, data, elem, true );
		}
	}
});


// Based off of the plugin by Clint Helfers, with permission.
// http://blindsignals.com/index.php/2009/07/jquery-delay/
jQuery.fn.delay = function( time, type ) {
	time = jQuery.fx ? jQuery.fx.speeds[ time ] || time : time;
	type = type || "fx";

	return this.queue( type, function( next, hooks ) {
		var timeout = setTimeout( next, time );
		hooks.stop = function() {
			clearTimeout( timeout );
		};
	});
};


jQuery.each( ("blur focus focusin focusout load resize scroll unload click dblclick " +
	"mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " +
	"change select submit keydown keypress keyup error contextmenu").split(" "), function( i, name ) {

	// Handle event binding
	jQuery.fn[ name ] = function( data, fn ) {
		return arguments.length > 0 ?
			this.on( name, null, data, fn ) :
			this.trigger( name );
	};
});

jQuery.fn.extend({
	hover: function( fnOver, fnOut ) {
		return this.mouseenter( fnOver ).mouseleave( fnOut || fnOver );
	},

	bind: function( types, data, fn ) {
		return this.on( types, null, data, fn );
	},
	unbind: function( types, fn ) {
		return this.off( types, null, fn );
	},

	delegate: function( selector, types, data, fn ) {
		return this.on( types, selector, data, fn );
	},
	undelegate: function( selector, types, fn ) {
		// ( namespace ) or ( selector, types [, fn] )
		return arguments.length === 1 ? this.off( selector, "**" ) : this.off( types, selector || "**", fn );
	}
});


var nonce = jQuery.now();

var rquery = (/\?/);



// Support: Android 2.3
// Workaround failure to string-cast null input
jQuery.parseJSON = function( data ) {
	return JSON.parse( data + "" );
};


// Cross-browser xml parsing
jQuery.parseXML = function( data ) {
	var xml, tmp;
	if ( !data || typeof data !== "string" ) {
		return null;
	}

	// Support: IE9
	try {
		tmp = new DOMParser();
		xml = tmp.parseFromString( data, "text/xml" );
	} catch ( e ) {
		xml = undefined;
	}

	if ( !xml || xml.getElementsByTagName( "parsererror" ).length ) {
		jQuery.error( "Invalid XML: " + data );
	}
	return xml;
};


var
	// Document location
	ajaxLocParts,
	ajaxLocation,

	rhash = /#.*$/,
	rts = /([?&])_=[^&]*/,
	rheaders = /^(.*?):[ \t]*([^\r\n]*)$/mg,
	// #7653, #8125, #8152: local protocol detection
	rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
	rnoContent = /^(?:GET|HEAD)$/,
	rprotocol = /^\/\//,
	rurl = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,

	/* Prefilters
	 * 1) They are useful to introduce custom dataTypes (see ajax/jsonp.js for an example)
	 * 2) These are called:
	 *    - BEFORE asking for a transport
	 *    - AFTER param serialization (s.data is a string if s.processData is true)
	 * 3) key is the dataType
	 * 4) the catchall symbol "*" can be used
	 * 5) execution will start with transport dataType and THEN continue down to "*" if needed
	 */
	prefilters = {},

	/* Transports bindings
	 * 1) key is the dataType
	 * 2) the catchall symbol "*" can be used
	 * 3) selection will start with transport dataType and THEN go to "*" if needed
	 */
	transports = {},

	// Avoid comment-prolog char sequence (#10098); must appease lint and evade compression
	allTypes = "*/".concat("*");

// #8138, IE may throw an exception when accessing
// a field from window.location if document.domain has been set
try {
	ajaxLocation = location.href;
} catch( e ) {
	// Use the href attribute of an A element
	// since IE will modify it given document.location
	ajaxLocation = document.createElement( "a" );
	ajaxLocation.href = "";
	ajaxLocation = ajaxLocation.href;
}

// Segment location into parts
ajaxLocParts = rurl.exec( ajaxLocation.toLowerCase() ) || [];

// Base "constructor" for jQuery.ajaxPrefilter and jQuery.ajaxTransport
function addToPrefiltersOrTransports( structure ) {

	// dataTypeExpression is optional and defaults to "*"
	return function( dataTypeExpression, func ) {

		if ( typeof dataTypeExpression !== "string" ) {
			func = dataTypeExpression;
			dataTypeExpression = "*";
		}

		var dataType,
			i = 0,
			dataTypes = dataTypeExpression.toLowerCase().match( rnotwhite ) || [];

		if ( jQuery.isFunction( func ) ) {
			// For each dataType in the dataTypeExpression
			while ( (dataType = dataTypes[i++]) ) {
				// Prepend if requested
				if ( dataType[0] === "+" ) {
					dataType = dataType.slice( 1 ) || "*";
					(structure[ dataType ] = structure[ dataType ] || []).unshift( func );

				// Otherwise append
				} else {
					(structure[ dataType ] = structure[ dataType ] || []).push( func );
				}
			}
		}
	};
}

// Base inspection function for prefilters and transports
function inspectPrefiltersOrTransports( structure, options, originalOptions, jqXHR ) {

	var inspected = {},
		seekingTransport = ( structure === transports );

	function inspect( dataType ) {
		var selected;
		inspected[ dataType ] = true;
		jQuery.each( structure[ dataType ] || [], function( _, prefilterOrFactory ) {
			var dataTypeOrTransport = prefilterOrFactory( options, originalOptions, jqXHR );
			if ( typeof dataTypeOrTransport === "string" && !seekingTransport && !inspected[ dataTypeOrTransport ] ) {
				options.dataTypes.unshift( dataTypeOrTransport );
				inspect( dataTypeOrTransport );
				return false;
			} else if ( seekingTransport ) {
				return !( selected = dataTypeOrTransport );
			}
		});
		return selected;
	}

	return inspect( options.dataTypes[ 0 ] ) || !inspected[ "*" ] && inspect( "*" );
}

// A special extend for ajax options
// that takes "flat" options (not to be deep extended)
// Fixes #9887
function ajaxExtend( target, src ) {
	var key, deep,
		flatOptions = jQuery.ajaxSettings.flatOptions || {};

	for ( key in src ) {
		if ( src[ key ] !== undefined ) {
			( flatOptions[ key ] ? target : ( deep || (deep = {}) ) )[ key ] = src[ key ];
		}
	}
	if ( deep ) {
		jQuery.extend( true, target, deep );
	}

	return target;
}

/* Handles responses to an ajax request:
 * - finds the right dataType (mediates between content-type and expected dataType)
 * - returns the corresponding response
 */
function ajaxHandleResponses( s, jqXHR, responses ) {

	var ct, type, finalDataType, firstDataType,
		contents = s.contents,
		dataTypes = s.dataTypes;

	// Remove auto dataType and get content-type in the process
	while ( dataTypes[ 0 ] === "*" ) {
		dataTypes.shift();
		if ( ct === undefined ) {
			ct = s.mimeType || jqXHR.getResponseHeader("Content-Type");
		}
	}

	// Check if we're dealing with a known content-type
	if ( ct ) {
		for ( type in contents ) {
			if ( contents[ type ] && contents[ type ].test( ct ) ) {
				dataTypes.unshift( type );
				break;
			}
		}
	}

	// Check to see if we have a response for the expected dataType
	if ( dataTypes[ 0 ] in responses ) {
		finalDataType = dataTypes[ 0 ];
	} else {
		// Try convertible dataTypes
		for ( type in responses ) {
			if ( !dataTypes[ 0 ] || s.converters[ type + " " + dataTypes[0] ] ) {
				finalDataType = type;
				break;
			}
			if ( !firstDataType ) {
				firstDataType = type;
			}
		}
		// Or just use first one
		finalDataType = finalDataType || firstDataType;
	}

	// If we found a dataType
	// We add the dataType to the list if needed
	// and return the corresponding response
	if ( finalDataType ) {
		if ( finalDataType !== dataTypes[ 0 ] ) {
			dataTypes.unshift( finalDataType );
		}
		return responses[ finalDataType ];
	}
}

/* Chain conversions given the request and the original response
 * Also sets the responseXXX fields on the jqXHR instance
 */
function ajaxConvert( s, response, jqXHR, isSuccess ) {
	var conv2, current, conv, tmp, prev,
		converters = {},
		// Work with a copy of dataTypes in case we need to modify it for conversion
		dataTypes = s.dataTypes.slice();

	// Create converters map with lowercased keys
	if ( dataTypes[ 1 ] ) {
		for ( conv in s.converters ) {
			converters[ conv.toLowerCase() ] = s.converters[ conv ];
		}
	}

	current = dataTypes.shift();

	// Convert to each sequential dataType
	while ( current ) {

		if ( s.responseFields[ current ] ) {
			jqXHR[ s.responseFields[ current ] ] = response;
		}

		// Apply the dataFilter if provided
		if ( !prev && isSuccess && s.dataFilter ) {
			response = s.dataFilter( response, s.dataType );
		}

		prev = current;
		current = dataTypes.shift();

		if ( current ) {

		// There's only work to do if current dataType is non-auto
			if ( current === "*" ) {

				current = prev;

			// Convert response if prev dataType is non-auto and differs from current
			} else if ( prev !== "*" && prev !== current ) {

				// Seek a direct converter
				conv = converters[ prev + " " + current ] || converters[ "* " + current ];

				// If none found, seek a pair
				if ( !conv ) {
					for ( conv2 in converters ) {

						// If conv2 outputs current
						tmp = conv2.split( " " );
						if ( tmp[ 1 ] === current ) {

							// If prev can be converted to accepted input
							conv = converters[ prev + " " + tmp[ 0 ] ] ||
								converters[ "* " + tmp[ 0 ] ];
							if ( conv ) {
								// Condense equivalence converters
								if ( conv === true ) {
									conv = converters[ conv2 ];

								// Otherwise, insert the intermediate dataType
								} else if ( converters[ conv2 ] !== true ) {
									current = tmp[ 0 ];
									dataTypes.unshift( tmp[ 1 ] );
								}
								break;
							}
						}
					}
				}

				// Apply converter (if not an equivalence)
				if ( conv !== true ) {

					// Unless errors are allowed to bubble, catch and return them
					if ( conv && s[ "throws" ] ) {
						response = conv( response );
					} else {
						try {
							response = conv( response );
						} catch ( e ) {
							return { state: "parsererror", error: conv ? e : "No conversion from " + prev + " to " + current };
						}
					}
				}
			}
		}
	}

	return { state: "success", data: response };
}

jQuery.extend({

	// Counter for holding the number of active queries
	active: 0,

	// Last-Modified header cache for next request
	lastModified: {},
	etag: {},

	ajaxSettings: {
		url: ajaxLocation,
		type: "GET",
		isLocal: rlocalProtocol.test( ajaxLocParts[ 1 ] ),
		global: true,
		processData: true,
		async: true,
		contentType: "application/x-www-form-urlencoded; charset=UTF-8",
		/*
		timeout: 0,
		data: null,
		dataType: null,
		username: null,
		password: null,
		cache: null,
		throws: false,
		traditional: false,
		headers: {},
		*/

		accepts: {
			"*": allTypes,
			text: "text/plain",
			html: "text/html",
			xml: "application/xml, text/xml",
			json: "application/json, text/javascript"
		},

		contents: {
			xml: /xml/,
			html: /html/,
			json: /json/
		},

		responseFields: {
			xml: "responseXML",
			text: "responseText",
			json: "responseJSON"
		},

		// Data converters
		// Keys separate source (or catchall "*") and destination types with a single space
		converters: {

			// Convert anything to text
			"* text": String,

			// Text to html (true = no transformation)
			"text html": true,

			// Evaluate text as a json expression
			"text json": jQuery.parseJSON,

			// Parse text as xml
			"text xml": jQuery.parseXML
		},

		// For options that shouldn't be deep extended:
		// you can add your own custom options here if
		// and when you create one that shouldn't be
		// deep extended (see ajaxExtend)
		flatOptions: {
			url: true,
			context: true
		}
	},

	// Creates a full fledged settings object into target
	// with both ajaxSettings and settings fields.
	// If target is omitted, writes into ajaxSettings.
	ajaxSetup: function( target, settings ) {
		return settings ?

			// Building a settings object
			ajaxExtend( ajaxExtend( target, jQuery.ajaxSettings ), settings ) :

			// Extending ajaxSettings
			ajaxExtend( jQuery.ajaxSettings, target );
	},

	ajaxPrefilter: addToPrefiltersOrTransports( prefilters ),
	ajaxTransport: addToPrefiltersOrTransports( transports ),

	// Main method
	ajax: function( url, options ) {

		// If url is an object, simulate pre-1.5 signature
		if ( typeof url === "object" ) {
			options = url;
			url = undefined;
		}

		// Force options to be an object
		options = options || {};

		var transport,
			// URL without anti-cache param
			cacheURL,
			// Response headers
			responseHeadersString,
			responseHeaders,
			// timeout handle
			timeoutTimer,
			// Cross-domain detection vars
			parts,
			// To know if global events are to be dispatched
			fireGlobals,
			// Loop variable
			i,
			// Create the final options object
			s = jQuery.ajaxSetup( {}, options ),
			// Callbacks context
			callbackContext = s.context || s,
			// Context for global events is callbackContext if it is a DOM node or jQuery collection
			globalEventContext = s.context && ( callbackContext.nodeType || callbackContext.jquery ) ?
				jQuery( callbackContext ) :
				jQuery.event,
			// Deferreds
			deferred = jQuery.Deferred(),
			completeDeferred = jQuery.Callbacks("once memory"),
			// Status-dependent callbacks
			statusCode = s.statusCode || {},
			// Headers (they are sent all at once)
			requestHeaders = {},
			requestHeadersNames = {},
			// The jqXHR state
			state = 0,
			// Default abort message
			strAbort = "canceled",
			// Fake xhr
			jqXHR = {
				readyState: 0,

				// Builds headers hashtable if needed
				getResponseHeader: function( key ) {
					var match;
					if ( state === 2 ) {
						if ( !responseHeaders ) {
							responseHeaders = {};
							while ( (match = rheaders.exec( responseHeadersString )) ) {
								responseHeaders[ match[1].toLowerCase() ] = match[ 2 ];
							}
						}
						match = responseHeaders[ key.toLowerCase() ];
					}
					return match == null ? null : match;
				},

				// Raw string
				getAllResponseHeaders: function() {
					return state === 2 ? responseHeadersString : null;
				},

				// Caches the header
				setRequestHeader: function( name, value ) {
					var lname = name.toLowerCase();
					if ( !state ) {
						name = requestHeadersNames[ lname ] = requestHeadersNames[ lname ] || name;
						requestHeaders[ name ] = value;
					}
					return this;
				},

				// Overrides response content-type header
				overrideMimeType: function( type ) {
					if ( !state ) {
						s.mimeType = type;
					}
					return this;
				},

				// Status-dependent callbacks
				statusCode: function( map ) {
					var code;
					if ( map ) {
						if ( state < 2 ) {
							for ( code in map ) {
								// Lazy-add the new callback in a way that preserves old ones
								statusCode[ code ] = [ statusCode[ code ], map[ code ] ];
							}
						} else {
							// Execute the appropriate callbacks
							jqXHR.always( map[ jqXHR.status ] );
						}
					}
					return this;
				},

				// Cancel the request
				abort: function( statusText ) {
					var finalText = statusText || strAbort;
					if ( transport ) {
						transport.abort( finalText );
					}
					done( 0, finalText );
					return this;
				}
			};

		// Attach deferreds
		deferred.promise( jqXHR ).complete = completeDeferred.add;
		jqXHR.success = jqXHR.done;
		jqXHR.error = jqXHR.fail;

		// Remove hash character (#7531: and string promotion)
		// Add protocol if not provided (prefilters might expect it)
		// Handle falsy url in the settings object (#10093: consistency with old signature)
		// We also use the url parameter if available
		s.url = ( ( url || s.url || ajaxLocation ) + "" ).replace( rhash, "" )
			.replace( rprotocol, ajaxLocParts[ 1 ] + "//" );

		// Alias method option to type as per ticket #12004
		s.type = options.method || options.type || s.method || s.type;

		// Extract dataTypes list
		s.dataTypes = jQuery.trim( s.dataType || "*" ).toLowerCase().match( rnotwhite ) || [ "" ];

		// A cross-domain request is in order when we have a protocol:host:port mismatch
		if ( s.crossDomain == null ) {
			parts = rurl.exec( s.url.toLowerCase() );
			s.crossDomain = !!( parts &&
				( parts[ 1 ] !== ajaxLocParts[ 1 ] || parts[ 2 ] !== ajaxLocParts[ 2 ] ||
					( parts[ 3 ] || ( parts[ 1 ] === "http:" ? "80" : "443" ) ) !==
						( ajaxLocParts[ 3 ] || ( ajaxLocParts[ 1 ] === "http:" ? "80" : "443" ) ) )
			);
		}

		// Convert data if not already a string
		if ( s.data && s.processData && typeof s.data !== "string" ) {
			s.data = jQuery.param( s.data, s.traditional );
		}

		// Apply prefilters
		inspectPrefiltersOrTransports( prefilters, s, options, jqXHR );

		// If request was aborted inside a prefilter, stop there
		if ( state === 2 ) {
			return jqXHR;
		}

		// We can fire global events as of now if asked to
		fireGlobals = s.global;

		// Watch for a new set of requests
		if ( fireGlobals && jQuery.active++ === 0 ) {
			jQuery.event.trigger("ajaxStart");
		}

		// Uppercase the type
		s.type = s.type.toUpperCase();

		// Determine if request has content
		s.hasContent = !rnoContent.test( s.type );

		// Save the URL in case we're toying with the If-Modified-Since
		// and/or If-None-Match header later on
		cacheURL = s.url;

		// More options handling for requests with no content
		if ( !s.hasContent ) {

			// If data is available, append data to url
			if ( s.data ) {
				cacheURL = ( s.url += ( rquery.test( cacheURL ) ? "&" : "?" ) + s.data );
				// #9682: remove data so that it's not used in an eventual retry
				delete s.data;
			}

			// Add anti-cache in url if needed
			if ( s.cache === false ) {
				s.url = rts.test( cacheURL ) ?

					// If there is already a '_' parameter, set its value
					cacheURL.replace( rts, "$1_=" + nonce++ ) :

					// Otherwise add one to the end
					cacheURL + ( rquery.test( cacheURL ) ? "&" : "?" ) + "_=" + nonce++;
			}
		}

		// Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
		if ( s.ifModified ) {
			if ( jQuery.lastModified[ cacheURL ] ) {
				jqXHR.setRequestHeader( "If-Modified-Since", jQuery.lastModified[ cacheURL ] );
			}
			if ( jQuery.etag[ cacheURL ] ) {
				jqXHR.setRequestHeader( "If-None-Match", jQuery.etag[ cacheURL ] );
			}
		}

		// Set the correct header, if data is being sent
		if ( s.data && s.hasContent && s.contentType !== false || options.contentType ) {
			jqXHR.setRequestHeader( "Content-Type", s.contentType );
		}

		// Set the Accepts header for the server, depending on the dataType
		jqXHR.setRequestHeader(
			"Accept",
			s.dataTypes[ 0 ] && s.accepts[ s.dataTypes[0] ] ?
				s.accepts[ s.dataTypes[0] ] + ( s.dataTypes[ 0 ] !== "*" ? ", " + allTypes + "; q=0.01" : "" ) :
				s.accepts[ "*" ]
		);

		// Check for headers option
		for ( i in s.headers ) {
			jqXHR.setRequestHeader( i, s.headers[ i ] );
		}

		// Allow custom headers/mimetypes and early abort
		if ( s.beforeSend && ( s.beforeSend.call( callbackContext, jqXHR, s ) === false || state === 2 ) ) {
			// Abort if not done already and return
			return jqXHR.abort();
		}

		// aborting is no longer a cancellation
		strAbort = "abort";

		// Install callbacks on deferreds
		for ( i in { success: 1, error: 1, complete: 1 } ) {
			jqXHR[ i ]( s[ i ] );
		}

		// Get transport
		transport = inspectPrefiltersOrTransports( transports, s, options, jqXHR );

		// If no transport, we auto-abort
		if ( !transport ) {
			done( -1, "No Transport" );
		} else {
			jqXHR.readyState = 1;

			// Send global event
			if ( fireGlobals ) {
				globalEventContext.trigger( "ajaxSend", [ jqXHR, s ] );
			}
			// Timeout
			if ( s.async && s.timeout > 0 ) {
				timeoutTimer = setTimeout(function() {
					jqXHR.abort("timeout");
				}, s.timeout );
			}

			try {
				state = 1;
				transport.send( requestHeaders, done );
			} catch ( e ) {
				// Propagate exception as error if not done
				if ( state < 2 ) {
					done( -1, e );
				// Simply rethrow otherwise
				} else {
					throw e;
				}
			}
		}

		// Callback for when everything is done
		function done( status, nativeStatusText, responses, headers ) {
			var isSuccess, success, error, response, modified,
				statusText = nativeStatusText;

			// Called once
			if ( state === 2 ) {
				return;
			}

			// State is "done" now
			state = 2;

			// Clear timeout if it exists
			if ( timeoutTimer ) {
				clearTimeout( timeoutTimer );
			}

			// Dereference transport for early garbage collection
			// (no matter how long the jqXHR object will be used)
			transport = undefined;

			// Cache response headers
			responseHeadersString = headers || "";

			// Set readyState
			jqXHR.readyState = status > 0 ? 4 : 0;

			// Determine if successful
			isSuccess = status >= 200 && status < 300 || status === 304;

			// Get response data
			if ( responses ) {
				response = ajaxHandleResponses( s, jqXHR, responses );
			}

			// Convert no matter what (that way responseXXX fields are always set)
			response = ajaxConvert( s, response, jqXHR, isSuccess );

			// If successful, handle type chaining
			if ( isSuccess ) {

				// Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
				if ( s.ifModified ) {
					modified = jqXHR.getResponseHeader("Last-Modified");
					if ( modified ) {
						jQuery.lastModified[ cacheURL ] = modified;
					}
					modified = jqXHR.getResponseHeader("etag");
					if ( modified ) {
						jQuery.etag[ cacheURL ] = modified;
					}
				}

				// if no content
				if ( status === 204 || s.type === "HEAD" ) {
					statusText = "nocontent";

				// if not modified
				} else if ( status === 304 ) {
					statusText = "notmodified";

				// If we have data, let's convert it
				} else {
					statusText = response.state;
					success = response.data;
					error = response.error;
					isSuccess = !error;
				}
			} else {
				// We extract error from statusText
				// then normalize statusText and status for non-aborts
				error = statusText;
				if ( status || !statusText ) {
					statusText = "error";
					if ( status < 0 ) {
						status = 0;
					}
				}
			}

			// Set data for the fake xhr object
			jqXHR.status = status;
			jqXHR.statusText = ( nativeStatusText || statusText ) + "";

			// Success/Error
			if ( isSuccess ) {
				deferred.resolveWith( callbackContext, [ success, statusText, jqXHR ] );
			} else {
				deferred.rejectWith( callbackContext, [ jqXHR, statusText, error ] );
			}

			// Status-dependent callbacks
			jqXHR.statusCode( statusCode );
			statusCode = undefined;

			if ( fireGlobals ) {
				globalEventContext.trigger( isSuccess ? "ajaxSuccess" : "ajaxError",
					[ jqXHR, s, isSuccess ? success : error ] );
			}

			// Complete
			completeDeferred.fireWith( callbackContext, [ jqXHR, statusText ] );

			if ( fireGlobals ) {
				globalEventContext.trigger( "ajaxComplete", [ jqXHR, s ] );
				// Handle the global AJAX counter
				if ( !( --jQuery.active ) ) {
					jQuery.event.trigger("ajaxStop");
				}
			}
		}

		return jqXHR;
	},

	getJSON: function( url, data, callback ) {
		return jQuery.get( url, data, callback, "json" );
	},

	getScript: function( url, callback ) {
		return jQuery.get( url, undefined, callback, "script" );
	}
});

jQuery.each( [ "get", "post" ], function( i, method ) {
	jQuery[ method ] = function( url, data, callback, type ) {
		// shift arguments if data argument was omitted
		if ( jQuery.isFunction( data ) ) {
			type = type || callback;
			callback = data;
			data = undefined;
		}

		return jQuery.ajax({
			url: url,
			type: method,
			dataType: type,
			data: data,
			success: callback
		});
	};
});

// Attach a bunch of functions for handling common AJAX events
jQuery.each( [ "ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend" ], function( i, type ) {
	jQuery.fn[ type ] = function( fn ) {
		return this.on( type, fn );
	};
});


var r20 = /%20/g,
	rbracket = /\[\]$/,
	rCRLF = /\r?\n/g,
	rsubmitterTypes = /^(?:submit|button|image|reset|file)$/i,
	rsubmittable = /^(?:input|select|textarea|keygen)/i;

function buildParams( prefix, obj, traditional, add ) {
	var name;

	if ( jQuery.isArray( obj ) ) {
		// Serialize array item.
		jQuery.each( obj, function( i, v ) {
			if ( traditional || rbracket.test( prefix ) ) {
				// Treat each array item as a scalar.
				add( prefix, v );

			} else {
				// Item is non-scalar (array or object), encode its numeric index.
				buildParams( prefix + "[" + ( typeof v === "object" ? i : "" ) + "]", v, traditional, add );
			}
		});

	} else if ( !traditional && jQuery.type( obj ) === "object" ) {
		// Serialize object item.
		for ( name in obj ) {
			buildParams( prefix + "[" + name + "]", obj[ name ], traditional, add );
		}

	} else {
		// Serialize scalar item.
		add( prefix, obj );
	}
}

// Serialize an array of form elements or a set of
// key/values into a query string
jQuery.param = function( a, traditional ) {
	var prefix,
		s = [],
		add = function( key, value ) {
			// If value is a function, invoke it and return its value
			value = jQuery.isFunction( value ) ? value() : ( value == null ? "" : value );
			s[ s.length ] = encodeURIComponent( key ) + "=" + encodeURIComponent( value );
		};

	// Set traditional to true for jQuery <= 1.3.2 behavior.
	if ( traditional === undefined ) {
		traditional = jQuery.ajaxSettings && jQuery.ajaxSettings.traditional;
	}

	// If an array was passed in, assume that it is an array of form elements.
	if ( jQuery.isArray( a ) || ( a.jquery && !jQuery.isPlainObject( a ) ) ) {
		// Serialize the form elements
		jQuery.each( a, function() {
			add( this.name, this.value );
		});

	} else {
		// If traditional, encode the "old" way (the way 1.3.2 or older
		// did it), otherwise encode params recursively.
		for ( prefix in a ) {
			buildParams( prefix, a[ prefix ], traditional, add );
		}
	}

	// Return the resulting serialization
	return s.join( "&" ).replace( r20, "+" );
};

jQuery.fn.extend({
	serialize: function() {
		return jQuery.param( this.serializeArray() );
	},
	serializeArray: function() {
		return this.map(function() {
			// Can add propHook for "elements" to filter or add form elements
			var elements = jQuery.prop( this, "elements" );
			return elements ? jQuery.makeArray( elements ) : this;
		})
		.filter(function() {
			var type = this.type;

			// Use .is( ":disabled" ) so that fieldset[disabled] works
			return this.name && !jQuery( this ).is( ":disabled" ) &&
				rsubmittable.test( this.nodeName ) && !rsubmitterTypes.test( type ) &&
				( this.checked || !rcheckableType.test( type ) );
		})
		.map(function( i, elem ) {
			var val = jQuery( this ).val();

			return val == null ?
				null :
				jQuery.isArray( val ) ?
					jQuery.map( val, function( val ) {
						return { name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
					}) :
					{ name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
		}).get();
	}
});


jQuery.ajaxSettings.xhr = function() {
	try {
		return new XMLHttpRequest();
	} catch( e ) {}
};

var xhrId = 0,
	xhrCallbacks = {},
	xhrSuccessStatus = {
		// file protocol always yields status code 0, assume 200
		0: 200,
		// Support: IE9
		// #1450: sometimes IE returns 1223 when it should be 204
		1223: 204
	},
	xhrSupported = jQuery.ajaxSettings.xhr();

// Support: IE9
// Open requests must be manually aborted on unload (#5280)
if ( window.ActiveXObject ) {
	jQuery( window ).on( "unload", function() {
		for ( var key in xhrCallbacks ) {
			xhrCallbacks[ key ]();
		}
	});
}

support.cors = !!xhrSupported && ( "withCredentials" in xhrSupported );
support.ajax = xhrSupported = !!xhrSupported;

jQuery.ajaxTransport(function( options ) {
	var callback;

	// Cross domain only allowed if supported through XMLHttpRequest
	if ( support.cors || xhrSupported && !options.crossDomain ) {
		return {
			send: function( headers, complete ) {
				var i,
					xhr = options.xhr(),
					id = ++xhrId;

				xhr.open( options.type, options.url, options.async, options.username, options.password );

				// Apply custom fields if provided
				if ( options.xhrFields ) {
					for ( i in options.xhrFields ) {
						xhr[ i ] = options.xhrFields[ i ];
					}
				}

				// Override mime type if needed
				if ( options.mimeType && xhr.overrideMimeType ) {
					xhr.overrideMimeType( options.mimeType );
				}

				// X-Requested-With header
				// For cross-domain requests, seeing as conditions for a preflight are
				// akin to a jigsaw puzzle, we simply never set it to be sure.
				// (it can always be set on a per-request basis or even using ajaxSetup)
				// For same-domain requests, won't change header if already provided.
				if ( !options.crossDomain && !headers["X-Requested-With"] ) {
					headers["X-Requested-With"] = "XMLHttpRequest";
				}

				// Set headers
				for ( i in headers ) {
					xhr.setRequestHeader( i, headers[ i ] );
				}

				// Callback
				callback = function( type ) {
					return function() {
						if ( callback ) {
							delete xhrCallbacks[ id ];
							callback = xhr.onload = xhr.onerror = null;

							if ( type === "abort" ) {
								xhr.abort();
							} else if ( type === "error" ) {
								complete(
									// file: protocol always yields status 0; see #8605, #14207
									xhr.status,
									xhr.statusText
								);
							} else {
								complete(
									xhrSuccessStatus[ xhr.status ] || xhr.status,
									xhr.statusText,
									// Support: IE9
									// Accessing binary-data responseText throws an exception
									// (#11426)
									typeof xhr.responseText === "string" ? {
										text: xhr.responseText
									} : undefined,
									xhr.getAllResponseHeaders()
								);
							}
						}
					};
				};

				// Listen to events
				xhr.onload = callback();
				xhr.onerror = callback("error");

				// Create the abort callback
				callback = xhrCallbacks[ id ] = callback("abort");

				try {
					// Do send the request (this may raise an exception)
					xhr.send( options.hasContent && options.data || null );
				} catch ( e ) {
					// #14683: Only rethrow if this hasn't been notified as an error yet
					if ( callback ) {
						throw e;
					}
				}
			},

			abort: function() {
				if ( callback ) {
					callback();
				}
			}
		};
	}
});




// Install script dataType
jQuery.ajaxSetup({
	accepts: {
		script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
	},
	contents: {
		script: /(?:java|ecma)script/
	},
	converters: {
		"text script": function( text ) {
			jQuery.globalEval( text );
			return text;
		}
	}
});

// Handle cache's special case and crossDomain
jQuery.ajaxPrefilter( "script", function( s ) {
	if ( s.cache === undefined ) {
		s.cache = false;
	}
	if ( s.crossDomain ) {
		s.type = "GET";
	}
});

// Bind script tag hack transport
jQuery.ajaxTransport( "script", function( s ) {
	// This transport only deals with cross domain requests
	if ( s.crossDomain ) {
		var script, callback;
		return {
			send: function( _, complete ) {
				script = jQuery("<script>").prop({
					async: true,
					charset: s.scriptCharset,
					src: s.url
				}).on(
					"load error",
					callback = function( evt ) {
						script.remove();
						callback = null;
						if ( evt ) {
							complete( evt.type === "error" ? 404 : 200, evt.type );
						}
					}
				);
				document.head.appendChild( script[ 0 ] );
			},
			abort: function() {
				if ( callback ) {
					callback();
				}
			}
		};
	}
});




var oldCallbacks = [],
	rjsonp = /(=)\?(?=&|$)|\?\?/;

// Default jsonp settings
jQuery.ajaxSetup({
	jsonp: "callback",
	jsonpCallback: function() {
		var callback = oldCallbacks.pop() || ( jQuery.expando + "_" + ( nonce++ ) );
		this[ callback ] = true;
		return callback;
	}
});

// Detect, normalize options and install callbacks for jsonp requests
jQuery.ajaxPrefilter( "json jsonp", function( s, originalSettings, jqXHR ) {

	var callbackName, overwritten, responseContainer,
		jsonProp = s.jsonp !== false && ( rjsonp.test( s.url ) ?
			"url" :
			typeof s.data === "string" && !( s.contentType || "" ).indexOf("application/x-www-form-urlencoded") && rjsonp.test( s.data ) && "data"
		);

	// Handle iff the expected data type is "jsonp" or we have a parameter to set
	if ( jsonProp || s.dataTypes[ 0 ] === "jsonp" ) {

		// Get callback name, remembering preexisting value associated with it
		callbackName = s.jsonpCallback = jQuery.isFunction( s.jsonpCallback ) ?
			s.jsonpCallback() :
			s.jsonpCallback;

		// Insert callback into url or form data
		if ( jsonProp ) {
			s[ jsonProp ] = s[ jsonProp ].replace( rjsonp, "$1" + callbackName );
		} else if ( s.jsonp !== false ) {
			s.url += ( rquery.test( s.url ) ? "&" : "?" ) + s.jsonp + "=" + callbackName;
		}

		// Use data converter to retrieve json after script execution
		s.converters["script json"] = function() {
			if ( !responseContainer ) {
				jQuery.error( callbackName + " was not called" );
			}
			return responseContainer[ 0 ];
		};

		// force json dataType
		s.dataTypes[ 0 ] = "json";

		// Install callback
		overwritten = window[ callbackName ];
		window[ callbackName ] = function() {
			responseContainer = arguments;
		};

		// Clean-up function (fires after converters)
		jqXHR.always(function() {
			// Restore preexisting value
			window[ callbackName ] = overwritten;

			// Save back as free
			if ( s[ callbackName ] ) {
				// make sure that re-using the options doesn't screw things around
				s.jsonpCallback = originalSettings.jsonpCallback;

				// save the callback name for future use
				oldCallbacks.push( callbackName );
			}

			// Call if it was a function and we have a response
			if ( responseContainer && jQuery.isFunction( overwritten ) ) {
				overwritten( responseContainer[ 0 ] );
			}

			responseContainer = overwritten = undefined;
		});

		// Delegate to script
		return "script";
	}
});




// data: string of html
// context (optional): If specified, the fragment will be created in this context, defaults to document
// keepScripts (optional): If true, will include scripts passed in the html string
jQuery.parseHTML = function( data, context, keepScripts ) {
	if ( !data || typeof data !== "string" ) {
		return null;
	}
	if ( typeof context === "boolean" ) {
		keepScripts = context;
		context = false;
	}
	context = context || document;

	var parsed = rsingleTag.exec( data ),
		scripts = !keepScripts && [];

	// Single tag
	if ( parsed ) {
		return [ context.createElement( parsed[1] ) ];
	}

	parsed = jQuery.buildFragment( [ data ], context, scripts );

	if ( scripts && scripts.length ) {
		jQuery( scripts ).remove();
	}

	return jQuery.merge( [], parsed.childNodes );
};


// Keep a copy of the old load method
var _load = jQuery.fn.load;

/**
 * Load a url into a page
 */
jQuery.fn.load = function( url, params, callback ) {
	if ( typeof url !== "string" && _load ) {
		return _load.apply( this, arguments );
	}

	var selector, type, response,
		self = this,
		off = url.indexOf(" ");

	if ( off >= 0 ) {
		selector = jQuery.trim( url.slice( off ) );
		url = url.slice( 0, off );
	}

	// If it's a function
	if ( jQuery.isFunction( params ) ) {

		// We assume that it's the callback
		callback = params;
		params = undefined;

	// Otherwise, build a param string
	} else if ( params && typeof params === "object" ) {
		type = "POST";
	}

	// If we have elements to modify, make the request
	if ( self.length > 0 ) {
		jQuery.ajax({
			url: url,

			// if "type" variable is undefined, then "GET" method will be used
			type: type,
			dataType: "html",
			data: params
		}).done(function( responseText ) {

			// Save response for use in complete callback
			response = arguments;

			self.html( selector ?

				// If a selector was specified, locate the right elements in a dummy div
				// Exclude scripts to avoid IE 'Permission Denied' errors
				jQuery("<div>").append( jQuery.parseHTML( responseText ) ).find( selector ) :

				// Otherwise use the full result
				responseText );

		}).complete( callback && function( jqXHR, status ) {
			self.each( callback, response || [ jqXHR.responseText, status, jqXHR ] );
		});
	}

	return this;
};




// Register as a named AMD module, since jQuery can be concatenated with other
// files that may use define, but not via a proper concatenation script that
// understands anonymous AMD modules. A named AMD is safest and most robust
// way to register. Lowercase jquery is used because AMD module names are
// derived from file names, and jQuery is normally delivered in a lowercase
// file name. Do this after creating the global so that if an AMD module wants
// to call noConflict to hide this version of jQuery, it will work.
if ( typeof define === "function" && define.amd ) {
	define( "jquery", [], function() {
		return jQuery;
	});
}




var
	// Map over jQuery in case of overwrite
	_jQuery = window.jQuery,

	// Map over the $ in case of overwrite
	_$ = window.$;

jQuery.noConflict = function( deep ) {
	if ( window.$ === jQuery ) {
		window.$ = _$;
	}

	if ( deep && window.jQuery === jQuery ) {
		window.jQuery = _jQuery;
	}

	return jQuery;
};

// Expose jQuery and $ identifiers, even in
// AMD (#7102#comment:10, https://github.com/jquery/jquery/pull/557)
// and CommonJS for browser emulators (#13566)
if ( typeof noGlobal === strundefined ) {
	window.jQuery = window.$ = jQuery;
}




return jQuery;

}));

//jquery 1.4 dependencies  : $.each, $.extend, $.ajax, $.isFunction, $.isPlainObject

// Uses CommonJS, AMD or browser globals to create a jQuery extension.
(function (factory) {
    if (typeof exports === 'object') {
        // Node/CommonJS
        factory(require('jquery'));
    } else if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define('jsperanto',['jquery'], factory);
    } else {
        // Browser globals
        factory(jQuery);
    }
}(function($) {
   
    var o = {};
    var dictionary = false; //not yet loaded
    var currentLang = false;
    var count_of_replacement = 0;

    
    function init(callback,options){
        options = $.isPlainObject(options) ? options : callback;
        callback = $.isFunction(callback) ? callback : function(){}; 

        $.extend(o,{
            //defaults
            interpolationPrefix : '__',
            interpolationSuffix : '__',
            pluralSuffix : '_plural',
            getSuffixMethod : function(count){ return ( count > 1 || typeof(count) == "string" )  ? o.pluralSuffix : ""; },
            maxRecursion : 50, //used while applying reuse of strings to avoid infinite loop
            reusePrefix : "$t(",
            reuseSuffix : ")",
            fallbackLang : 'en-us', // see Language fallback section
            dicoPath : 'locales', // see Dictionary section
            async : true, // might be used to force initialization, dictionary loading to be syncronous
            keyseparator : ".", // keys passed to $.jsperanttranslate use this separator
            setDollarT : true, // $.t aliases $.jsperanttranslate, nice shortcut
            dictionary : false, // to supply the dictionary instead of loading it using $.ajax. A (big) javascript object containing your namespaced translations
            lang : false, //specify a language to use
            suffixNotFound : ["suffix_not_found_", Math.random()].join('') // used internally by translate
        },options);
        if(!o.lang){o.lang = detectLanguage();}
        return loadDictionary(o.lang,function(loadedLang){
            currentLang = loadedLang;
            if(o.setDollarT){$.t = $.t || translate;} //shortcut
            if(callback) callback(translate);
        });
    }

    function applyReplacement(string,replacementHash){
        $.each(replacementHash,function(key,value){
            string = string.split([o.interpolationPrefix,key,o.interpolationSuffix].join('')).join(value);
        });
        return string;
    }

    function applyReuse(translated,options){
        while (translated.indexOf(o.reusePrefix) != -1){
            count_of_replacement++;
            if(count_of_replacement > o.maxRecursion){break;} // safety net for too much recursion
            var index_of_opening = translated.indexOf(o.reusePrefix);
            var index_of_end_of_closing = translated.indexOf(o.reuseSuffix,index_of_opening) + o.reuseSuffix.length;
            var token = translated.substring(index_of_opening,index_of_end_of_closing);
            var token_sans_symbols = token.replace(o.reusePrefix,"").replace(o.reuseSuffix,"");
            var translated_token = _translate(token_sans_symbols,options);
            translated = translated.replace(token,translated_token);
        }
        return translated;
    }
    
    function detectLanguage(){
        if(navigator){
            return navigator.language && navigator.language.toLocaleLowerCase() || navigator.userLanguage && navigator.userLanguage.toLocaleLowerCase();
        }else{
            return o.fallbackLang;
        }
    }

    function containsCount(options){
       return (typeof options.count == 'number' || typeof options.count == 'string');
    }

    function getCountSuffix(options) {
       var suffix = o.getSuffixMethod(options.count);
       return ( typeof(suffix) == "string" ) ? suffix : '';
   }

    function translate(dottedkey,options){
        count_of_replacement = 0;
        return _translate(dottedkey,options);
    }

    /*
    options.defaultValue
    options.count
    */
    function _translate(dottedkey,options){
        options = options || {};
        var notfound = options.defaultValue || dottedkey;
        if(!dictionary){return notfound;} // No dictionary to translate from

        if(containsCount(options)){
            var optionsSansCount = $.extend({},options);
            delete optionsSansCount.count;
            optionsSansCount.defaultValue = o.suffixNotFound;
            var suffixKey = dottedkey + getCountSuffix(options);
            var translated = translate(suffixKey,optionsSansCount);
            if(translated != o.suffixNotFound){
                return applyReplacement(translated,{count:options.count});//apply replacement for count only
            }// else continue translation with original/singular key
        }
        
        var keys = dottedkey.split(o.keyseparator);
        var i = 0;
        var value = dictionary;
        while(keys[i]) {
            value = value && value[keys[i]];
            i++;
        }
        if(value){
            value = applyReplacement(value,options);
            value = applyReuse(value,options);
            return value;
        }else{
            return notfound;
        }
    }
    
    function loadDictionary(lang,doneCallback){
        if(o.dictionary){
            dictionary = o.dictionary;
            doneCallback(lang);
            return;
        }
        return $.ajax({
            url: [o.dicoPath,"/", lang, '.json'].join(''),
            success: function(data,status,xhr){
                dictionary = data;
                doneCallback(lang);
            },
            error : function(xhr,status,error){
                if(lang != o.fallbackLang){
                    loadDictionary(o.fallbackLang,doneCallback);
                }else{
                    doneCallback(false);
                }
            },
            async : o.async,
            dataType: "json"
        });
    }
    
    function lang(){
        return currentLang;
    }

    $.jsperanto = $.jsperanto || {
        init:init,
        t:translate,
        translate:translate,
        detectLanguage : detectLanguage,
        lang : lang
    };
}));

//     Underscore.js 1.6.0
//     http://underscorejs.org
//     (c) 2009-2014 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
//     Underscore may be freely distributed under the MIT license.

(function() {

  // Baseline setup
  // --------------

  // Establish the root object, `window` in the browser, or `exports` on the server.
  var root = this;

  // Save the previous value of the `_` variable.
  var previousUnderscore = root._;

  // Establish the object that gets returned to break out of a loop iteration.
  var breaker = {};

  // Save bytes in the minified (but not gzipped) version:
  var ArrayProto = Array.prototype, ObjProto = Object.prototype, FuncProto = Function.prototype;

  // Create quick reference variables for speed access to core prototypes.
  var
    push             = ArrayProto.push,
    slice            = ArrayProto.slice,
    concat           = ArrayProto.concat,
    toString         = ObjProto.toString,
    hasOwnProperty   = ObjProto.hasOwnProperty;

  // All **ECMAScript 5** native function implementations that we hope to use
  // are declared here.
  var
    nativeForEach      = ArrayProto.forEach,
    nativeMap          = ArrayProto.map,
    nativeReduce       = ArrayProto.reduce,
    nativeReduceRight  = ArrayProto.reduceRight,
    nativeFilter       = ArrayProto.filter,
    nativeEvery        = ArrayProto.every,
    nativeSome         = ArrayProto.some,
    nativeIndexOf      = ArrayProto.indexOf,
    nativeLastIndexOf  = ArrayProto.lastIndexOf,
    nativeIsArray      = Array.isArray,
    nativeKeys         = Object.keys,
    nativeBind         = FuncProto.bind;

  // Create a safe reference to the Underscore object for use below.
  var _ = function(obj) {
    if (obj instanceof _) return obj;
    if (!(this instanceof _)) return new _(obj);
    this._wrapped = obj;
  };

  // Export the Underscore object for **Node.js**, with
  // backwards-compatibility for the old `require()` API. If we're in
  // the browser, add `_` as a global object via a string identifier,
  // for Closure Compiler "advanced" mode.
  if (typeof exports !== 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      exports = module.exports = _;
    }
    exports._ = _;
  } else {
    root._ = _;
  }

  // Current version.
  _.VERSION = '1.6.0';

  // Collection Functions
  // --------------------

  // The cornerstone, an `each` implementation, aka `forEach`.
  // Handles objects with the built-in `forEach`, arrays, and raw objects.
  // Delegates to **ECMAScript 5**'s native `forEach` if available.
  var each = _.each = _.forEach = function(obj, iterator, context) {
    if (obj == null) return obj;
    if (nativeForEach && obj.forEach === nativeForEach) {
      obj.forEach(iterator, context);
    } else if (obj.length === +obj.length) {
      for (var i = 0, length = obj.length; i < length; i++) {
        if (iterator.call(context, obj[i], i, obj) === breaker) return;
      }
    } else {
      var keys = _.keys(obj);
      for (var i = 0, length = keys.length; i < length; i++) {
        if (iterator.call(context, obj[keys[i]], keys[i], obj) === breaker) return;
      }
    }
    return obj;
  };

  // Return the results of applying the iterator to each element.
  // Delegates to **ECMAScript 5**'s native `map` if available.
  _.map = _.collect = function(obj, iterator, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeMap && obj.map === nativeMap) return obj.map(iterator, context);
    each(obj, function(value, index, list) {
      results.push(iterator.call(context, value, index, list));
    });
    return results;
  };

  var reduceError = 'Reduce of empty array with no initial value';

  // **Reduce** builds up a single result from a list of values, aka `inject`,
  // or `foldl`. Delegates to **ECMAScript 5**'s native `reduce` if available.
  _.reduce = _.foldl = _.inject = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduce && obj.reduce === nativeReduce) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduce(iterator, memo) : obj.reduce(iterator);
    }
    each(obj, function(value, index, list) {
      if (!initial) {
        memo = value;
        initial = true;
      } else {
        memo = iterator.call(context, memo, value, index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // The right-associative version of reduce, also known as `foldr`.
  // Delegates to **ECMAScript 5**'s native `reduceRight` if available.
  _.reduceRight = _.foldr = function(obj, iterator, memo, context) {
    var initial = arguments.length > 2;
    if (obj == null) obj = [];
    if (nativeReduceRight && obj.reduceRight === nativeReduceRight) {
      if (context) iterator = _.bind(iterator, context);
      return initial ? obj.reduceRight(iterator, memo) : obj.reduceRight(iterator);
    }
    var length = obj.length;
    if (length !== +length) {
      var keys = _.keys(obj);
      length = keys.length;
    }
    each(obj, function(value, index, list) {
      index = keys ? keys[--length] : --length;
      if (!initial) {
        memo = obj[index];
        initial = true;
      } else {
        memo = iterator.call(context, memo, obj[index], index, list);
      }
    });
    if (!initial) throw new TypeError(reduceError);
    return memo;
  };

  // Return the first value which passes a truth test. Aliased as `detect`.
  _.find = _.detect = function(obj, predicate, context) {
    var result;
    any(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) {
        result = value;
        return true;
      }
    });
    return result;
  };

  // Return all the elements that pass a truth test.
  // Delegates to **ECMAScript 5**'s native `filter` if available.
  // Aliased as `select`.
  _.filter = _.select = function(obj, predicate, context) {
    var results = [];
    if (obj == null) return results;
    if (nativeFilter && obj.filter === nativeFilter) return obj.filter(predicate, context);
    each(obj, function(value, index, list) {
      if (predicate.call(context, value, index, list)) results.push(value);
    });
    return results;
  };

  // Return all the elements for which a truth test fails.
  _.reject = function(obj, predicate, context) {
    return _.filter(obj, function(value, index, list) {
      return !predicate.call(context, value, index, list);
    }, context);
  };

  // Determine whether all of the elements match a truth test.
  // Delegates to **ECMAScript 5**'s native `every` if available.
  // Aliased as `all`.
  _.every = _.all = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = true;
    if (obj == null) return result;
    if (nativeEvery && obj.every === nativeEvery) return obj.every(predicate, context);
    each(obj, function(value, index, list) {
      if (!(result = result && predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if at least one element in the object matches a truth test.
  // Delegates to **ECMAScript 5**'s native `some` if available.
  // Aliased as `any`.
  var any = _.some = _.any = function(obj, predicate, context) {
    predicate || (predicate = _.identity);
    var result = false;
    if (obj == null) return result;
    if (nativeSome && obj.some === nativeSome) return obj.some(predicate, context);
    each(obj, function(value, index, list) {
      if (result || (result = predicate.call(context, value, index, list))) return breaker;
    });
    return !!result;
  };

  // Determine if the array or object contains a given value (using `===`).
  // Aliased as `include`.
  _.contains = _.include = function(obj, target) {
    if (obj == null) return false;
    if (nativeIndexOf && obj.indexOf === nativeIndexOf) return obj.indexOf(target) != -1;
    return any(obj, function(value) {
      return value === target;
    });
  };

  // Invoke a method (with arguments) on every item in a collection.
  _.invoke = function(obj, method) {
    var args = slice.call(arguments, 2);
    var isFunc = _.isFunction(method);
    return _.map(obj, function(value) {
      return (isFunc ? method : value[method]).apply(value, args);
    });
  };

  // Convenience version of a common use case of `map`: fetching a property.
  _.pluck = function(obj, key) {
    return _.map(obj, _.property(key));
  };

  // Convenience version of a common use case of `filter`: selecting only objects
  // containing specific `key:value` pairs.
  _.where = function(obj, attrs) {
    return _.filter(obj, _.matches(attrs));
  };

  // Convenience version of a common use case of `find`: getting the first object
  // containing specific `key:value` pairs.
  _.findWhere = function(obj, attrs) {
    return _.find(obj, _.matches(attrs));
  };

  // Return the maximum element or (element-based computation).
  // Can't optimize arrays of integers longer than 65,535 elements.
  // See [WebKit Bug 80797](https://bugs.webkit.org/show_bug.cgi?id=80797)
  _.max = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.max.apply(Math, obj);
    }
    var result = -Infinity, lastComputed = -Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed > lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Return the minimum element (or element-based computation).
  _.min = function(obj, iterator, context) {
    if (!iterator && _.isArray(obj) && obj[0] === +obj[0] && obj.length < 65535) {
      return Math.min.apply(Math, obj);
    }
    var result = Infinity, lastComputed = Infinity;
    each(obj, function(value, index, list) {
      var computed = iterator ? iterator.call(context, value, index, list) : value;
      if (computed < lastComputed) {
        result = value;
        lastComputed = computed;
      }
    });
    return result;
  };

  // Shuffle an array, using the modern version of the
  // [Fisher-Yates shuffle](http://en.wikipedia.org/wiki/Fisher–Yates_shuffle).
  _.shuffle = function(obj) {
    var rand;
    var index = 0;
    var shuffled = [];
    each(obj, function(value) {
      rand = _.random(index++);
      shuffled[index - 1] = shuffled[rand];
      shuffled[rand] = value;
    });
    return shuffled;
  };

  // Sample **n** random values from a collection.
  // If **n** is not specified, returns a single random element.
  // The internal `guard` argument allows it to work with `map`.
  _.sample = function(obj, n, guard) {
    if (n == null || guard) {
      if (obj.length !== +obj.length) obj = _.values(obj);
      return obj[_.random(obj.length - 1)];
    }
    return _.shuffle(obj).slice(0, Math.max(0, n));
  };

  // An internal function to generate lookup iterators.
  var lookupIterator = function(value) {
    if (value == null) return _.identity;
    if (_.isFunction(value)) return value;
    return _.property(value);
  };

  // Sort the object's values by a criterion produced by an iterator.
  _.sortBy = function(obj, iterator, context) {
    iterator = lookupIterator(iterator);
    return _.pluck(_.map(obj, function(value, index, list) {
      return {
        value: value,
        index: index,
        criteria: iterator.call(context, value, index, list)
      };
    }).sort(function(left, right) {
      var a = left.criteria;
      var b = right.criteria;
      if (a !== b) {
        if (a > b || a === void 0) return 1;
        if (a < b || b === void 0) return -1;
      }
      return left.index - right.index;
    }), 'value');
  };

  // An internal function used for aggregate "group by" operations.
  var group = function(behavior) {
    return function(obj, iterator, context) {
      var result = {};
      iterator = lookupIterator(iterator);
      each(obj, function(value, index) {
        var key = iterator.call(context, value, index, obj);
        behavior(result, key, value);
      });
      return result;
    };
  };

  // Groups the object's values by a criterion. Pass either a string attribute
  // to group by, or a function that returns the criterion.
  _.groupBy = group(function(result, key, value) {
    _.has(result, key) ? result[key].push(value) : result[key] = [value];
  });

  // Indexes the object's values by a criterion, similar to `groupBy`, but for
  // when you know that your index values will be unique.
  _.indexBy = group(function(result, key, value) {
    result[key] = value;
  });

  // Counts instances of an object that group by a certain criterion. Pass
  // either a string attribute to count by, or a function that returns the
  // criterion.
  _.countBy = group(function(result, key) {
    _.has(result, key) ? result[key]++ : result[key] = 1;
  });

  // Use a comparator function to figure out the smallest index at which
  // an object should be inserted so as to maintain order. Uses binary search.
  _.sortedIndex = function(array, obj, iterator, context) {
    iterator = lookupIterator(iterator);
    var value = iterator.call(context, obj);
    var low = 0, high = array.length;
    while (low < high) {
      var mid = (low + high) >>> 1;
      iterator.call(context, array[mid]) < value ? low = mid + 1 : high = mid;
    }
    return low;
  };

  // Safely create a real, live array from anything iterable.
  _.toArray = function(obj) {
    if (!obj) return [];
    if (_.isArray(obj)) return slice.call(obj);
    if (obj.length === +obj.length) return _.map(obj, _.identity);
    return _.values(obj);
  };

  // Return the number of elements in an object.
  _.size = function(obj) {
    if (obj == null) return 0;
    return (obj.length === +obj.length) ? obj.length : _.keys(obj).length;
  };

  // Array Functions
  // ---------------

  // Get the first element of an array. Passing **n** will return the first N
  // values in the array. Aliased as `head` and `take`. The **guard** check
  // allows it to work with `_.map`.
  _.first = _.head = _.take = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[0];
    if (n < 0) return [];
    return slice.call(array, 0, n);
  };

  // Returns everything but the last entry of the array. Especially useful on
  // the arguments object. Passing **n** will return all the values in
  // the array, excluding the last N. The **guard** check allows it to work with
  // `_.map`.
  _.initial = function(array, n, guard) {
    return slice.call(array, 0, array.length - ((n == null) || guard ? 1 : n));
  };

  // Get the last element of an array. Passing **n** will return the last N
  // values in the array. The **guard** check allows it to work with `_.map`.
  _.last = function(array, n, guard) {
    if (array == null) return void 0;
    if ((n == null) || guard) return array[array.length - 1];
    return slice.call(array, Math.max(array.length - n, 0));
  };

  // Returns everything but the first entry of the array. Aliased as `tail` and `drop`.
  // Especially useful on the arguments object. Passing an **n** will return
  // the rest N values in the array. The **guard**
  // check allows it to work with `_.map`.
  _.rest = _.tail = _.drop = function(array, n, guard) {
    return slice.call(array, (n == null) || guard ? 1 : n);
  };

  // Trim out all falsy values from an array.
  _.compact = function(array) {
    return _.filter(array, _.identity);
  };

  // Internal implementation of a recursive `flatten` function.
  var flatten = function(input, shallow, output) {
    if (shallow && _.every(input, _.isArray)) {
      return concat.apply(output, input);
    }
    each(input, function(value) {
      if (_.isArray(value) || _.isArguments(value)) {
        shallow ? push.apply(output, value) : flatten(value, shallow, output);
      } else {
        output.push(value);
      }
    });
    return output;
  };

  // Flatten out an array, either recursively (by default), or just one level.
  _.flatten = function(array, shallow) {
    return flatten(array, shallow, []);
  };

  // Return a version of the array that does not contain the specified value(s).
  _.without = function(array) {
    return _.difference(array, slice.call(arguments, 1));
  };

  // Split an array into two arrays: one whose elements all satisfy the given
  // predicate, and one whose elements all do not satisfy the predicate.
  _.partition = function(array, predicate) {
    var pass = [], fail = [];
    each(array, function(elem) {
      (predicate(elem) ? pass : fail).push(elem);
    });
    return [pass, fail];
  };

  // Produce a duplicate-free version of the array. If the array has already
  // been sorted, you have the option of using a faster algorithm.
  // Aliased as `unique`.
  _.uniq = _.unique = function(array, isSorted, iterator, context) {
    if (_.isFunction(isSorted)) {
      context = iterator;
      iterator = isSorted;
      isSorted = false;
    }
    var initial = iterator ? _.map(array, iterator, context) : array;
    var results = [];
    var seen = [];
    each(initial, function(value, index) {
      if (isSorted ? (!index || seen[seen.length - 1] !== value) : !_.contains(seen, value)) {
        seen.push(value);
        results.push(array[index]);
      }
    });
    return results;
  };

  // Produce an array that contains the union: each distinct element from all of
  // the passed-in arrays.
  _.union = function() {
    return _.uniq(_.flatten(arguments, true));
  };

  // Produce an array that contains every item shared between all the
  // passed-in arrays.
  _.intersection = function(array) {
    var rest = slice.call(arguments, 1);
    return _.filter(_.uniq(array), function(item) {
      return _.every(rest, function(other) {
        return _.contains(other, item);
      });
    });
  };

  // Take the difference between one array and a number of other arrays.
  // Only the elements present in just the first array will remain.
  _.difference = function(array) {
    var rest = concat.apply(ArrayProto, slice.call(arguments, 1));
    return _.filter(array, function(value){ return !_.contains(rest, value); });
  };

  // Zip together multiple lists into a single array -- elements that share
  // an index go together.
  _.zip = function() {
    var length = _.max(_.pluck(arguments, 'length').concat(0));
    var results = new Array(length);
    for (var i = 0; i < length; i++) {
      results[i] = _.pluck(arguments, '' + i);
    }
    return results;
  };

  // Converts lists into objects. Pass either a single array of `[key, value]`
  // pairs, or two parallel arrays of the same length -- one of keys, and one of
  // the corresponding values.
  _.object = function(list, values) {
    if (list == null) return {};
    var result = {};
    for (var i = 0, length = list.length; i < length; i++) {
      if (values) {
        result[list[i]] = values[i];
      } else {
        result[list[i][0]] = list[i][1];
      }
    }
    return result;
  };

  // If the browser doesn't supply us with indexOf (I'm looking at you, **MSIE**),
  // we need this function. Return the position of the first occurrence of an
  // item in an array, or -1 if the item is not included in the array.
  // Delegates to **ECMAScript 5**'s native `indexOf` if available.
  // If the array is large and already in sort order, pass `true`
  // for **isSorted** to use binary search.
  _.indexOf = function(array, item, isSorted) {
    if (array == null) return -1;
    var i = 0, length = array.length;
    if (isSorted) {
      if (typeof isSorted == 'number') {
        i = (isSorted < 0 ? Math.max(0, length + isSorted) : isSorted);
      } else {
        i = _.sortedIndex(array, item);
        return array[i] === item ? i : -1;
      }
    }
    if (nativeIndexOf && array.indexOf === nativeIndexOf) return array.indexOf(item, isSorted);
    for (; i < length; i++) if (array[i] === item) return i;
    return -1;
  };

  // Delegates to **ECMAScript 5**'s native `lastIndexOf` if available.
  _.lastIndexOf = function(array, item, from) {
    if (array == null) return -1;
    var hasIndex = from != null;
    if (nativeLastIndexOf && array.lastIndexOf === nativeLastIndexOf) {
      return hasIndex ? array.lastIndexOf(item, from) : array.lastIndexOf(item);
    }
    var i = (hasIndex ? from : array.length);
    while (i--) if (array[i] === item) return i;
    return -1;
  };

  // Generate an integer Array containing an arithmetic progression. A port of
  // the native Python `range()` function. See
  // [the Python documentation](http://docs.python.org/library/functions.html#range).
  _.range = function(start, stop, step) {
    if (arguments.length <= 1) {
      stop = start || 0;
      start = 0;
    }
    step = arguments[2] || 1;

    var length = Math.max(Math.ceil((stop - start) / step), 0);
    var idx = 0;
    var range = new Array(length);

    while(idx < length) {
      range[idx++] = start;
      start += step;
    }

    return range;
  };

  // Function (ahem) Functions
  // ------------------

  // Reusable constructor function for prototype setting.
  var ctor = function(){};

  // Create a function bound to a given object (assigning `this`, and arguments,
  // optionally). Delegates to **ECMAScript 5**'s native `Function.bind` if
  // available.
  _.bind = function(func, context) {
    var args, bound;
    if (nativeBind && func.bind === nativeBind) return nativeBind.apply(func, slice.call(arguments, 1));
    if (!_.isFunction(func)) throw new TypeError;
    args = slice.call(arguments, 2);
    return bound = function() {
      if (!(this instanceof bound)) return func.apply(context, args.concat(slice.call(arguments)));
      ctor.prototype = func.prototype;
      var self = new ctor;
      ctor.prototype = null;
      var result = func.apply(self, args.concat(slice.call(arguments)));
      if (Object(result) === result) return result;
      return self;
    };
  };

  // Partially apply a function by creating a version that has had some of its
  // arguments pre-filled, without changing its dynamic `this` context. _ acts
  // as a placeholder, allowing any combination of arguments to be pre-filled.
  _.partial = function(func) {
    var boundArgs = slice.call(arguments, 1);
    return function() {
      var position = 0;
      var args = boundArgs.slice();
      for (var i = 0, length = args.length; i < length; i++) {
        if (args[i] === _) args[i] = arguments[position++];
      }
      while (position < arguments.length) args.push(arguments[position++]);
      return func.apply(this, args);
    };
  };

  // Bind a number of an object's methods to that object. Remaining arguments
  // are the method names to be bound. Useful for ensuring that all callbacks
  // defined on an object belong to it.
  _.bindAll = function(obj) {
    var funcs = slice.call(arguments, 1);
    if (funcs.length === 0) throw new Error('bindAll must be passed function names');
    each(funcs, function(f) { obj[f] = _.bind(obj[f], obj); });
    return obj;
  };

  // Memoize an expensive function by storing its results.
  _.memoize = function(func, hasher) {
    var memo = {};
    hasher || (hasher = _.identity);
    return function() {
      var key = hasher.apply(this, arguments);
      return _.has(memo, key) ? memo[key] : (memo[key] = func.apply(this, arguments));
    };
  };

  // Delays a function for the given number of milliseconds, and then calls
  // it with the arguments supplied.
  _.delay = function(func, wait) {
    var args = slice.call(arguments, 2);
    return setTimeout(function(){ return func.apply(null, args); }, wait);
  };

  // Defers a function, scheduling it to run after the current call stack has
  // cleared.
  _.defer = function(func) {
    return _.delay.apply(_, [func, 1].concat(slice.call(arguments, 1)));
  };

  // Returns a function, that, when invoked, will only be triggered at most once
  // during a given window of time. Normally, the throttled function will run
  // as much as it can, without ever going more than once per `wait` duration;
  // but if you'd like to disable the execution on the leading edge, pass
  // `{leading: false}`. To disable execution on the trailing edge, ditto.
  _.throttle = function(func, wait, options) {
    var context, args, result;
    var timeout = null;
    var previous = 0;
    options || (options = {});
    var later = function() {
      previous = options.leading === false ? 0 : _.now();
      timeout = null;
      result = func.apply(context, args);
      if (!timeout) context = args = null;
    };
    return function() {
      var now = _.now();
      if (!previous && options.leading === false) previous = now;
      var remaining = wait - (now - previous);
      context = this;
      args = arguments;
      if (remaining <= 0) {
        clearTimeout(timeout);
        timeout = null;
        previous = now;
        result = func.apply(context, args);
        if (!timeout) context = args = null;
      } else if (!timeout && options.trailing !== false) {
        timeout = setTimeout(later, remaining);
      }
      return result;
    };
  };

  // Returns a function, that, as long as it continues to be invoked, will not
  // be triggered. The function will be called after it stops being called for
  // N milliseconds. If `immediate` is passed, trigger the function on the
  // leading edge, instead of the trailing.
  _.debounce = function(func, wait, immediate) {
      var timeout, args, context, timestamp, result;

      var later = function() {
          var last = _.now() - timestamp;

          if (last < wait && last > 0) {
              timeout = setTimeout(later, wait - last);
          } else {
              timeout = null;
              if (!immediate) {
                  result = func.apply(context, args);
                  if (!timeout) context = args = null;
              }
          }
      };

      return function() {
          context = this;
          args = arguments;
          timestamp = _.now();
          var callNow = immediate && !timeout;
          if (!timeout) timeout = setTimeout(later, wait);
          if (callNow) {
              result = func.apply(context, args);
              context = args = null;
          }

          return result;
    };
  };

  // Returns a function that will be executed at most one time, no matter how
  // often you call it. Useful for lazy initialization.
  _.once = function(func) {
    var ran = false, memo;
    return function() {
      if (ran) return memo;
      ran = true;
      memo = func.apply(this, arguments);
      func = null;
      return memo;
    };
  };

  // Returns the first function passed as an argument to the second,
  // allowing you to adjust arguments, run code before and after, and
  // conditionally execute the original function.
  _.wrap = function(func, wrapper) {
    return _.partial(wrapper, func);
  };

  // Returns a function that is the composition of a list of functions, each
  // consuming the return value of the function that follows.
  _.compose = function() {
    var funcs = arguments;
    return function() {
      var args = arguments;
      for (var i = funcs.length - 1; i >= 0; i--) {
        args = [funcs[i].apply(this, args)];
      }
      return args[0];
    };
  };

  // Returns a function that will only be executed after being called N times.
  _.after = function(times, func) {
    return function() {
      if (--times < 1) {
        return func.apply(this, arguments);
      }
    };
  };

  // Object Functions
  // ----------------

  // Retrieve the names of an object's properties.
  // Delegates to **ECMAScript 5**'s native `Object.keys`
  _.keys = function(obj) {
    if (!_.isObject(obj)) return [];
    if (nativeKeys) return nativeKeys(obj);
    var keys = [];
    for (var key in obj) if (_.has(obj, key)) keys.push(key);
    return keys;
  };

  // Retrieve the values of an object's properties.
  _.values = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var values = new Array(length);
    for (var i = 0; i < length; i++) {
      values[i] = obj[keys[i]];
    }
    return values;
  };

  // Convert an object into a list of `[key, value]` pairs.
  _.pairs = function(obj) {
    var keys = _.keys(obj);
    var length = keys.length;
    var pairs = new Array(length);
    for (var i = 0; i < length; i++) {
      pairs[i] = [keys[i], obj[keys[i]]];
    }
    return pairs;
  };

  // Invert the keys and values of an object. The values must be serializable.
  _.invert = function(obj) {
    var result = {};
    var keys = _.keys(obj);
    for (var i = 0, length = keys.length; i < length; i++) {
      result[obj[keys[i]]] = keys[i];
    }
    return result;
  };

  // Return a sorted list of the function names available on the object.
  // Aliased as `methods`
  _.functions = _.methods = function(obj) {
    var names = [];
    for (var key in obj) {
      if (_.isFunction(obj[key])) names.push(key);
    }
    return names.sort();
  };

  // Extend a given object with all the properties in passed-in object(s).
  _.extend = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Return a copy of the object only containing the whitelisted properties.
  _.pick = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    each(keys, function(key) {
      if (key in obj) copy[key] = obj[key];
    });
    return copy;
  };

   // Return a copy of the object without the blacklisted properties.
  _.omit = function(obj) {
    var copy = {};
    var keys = concat.apply(ArrayProto, slice.call(arguments, 1));
    for (var key in obj) {
      if (!_.contains(keys, key)) copy[key] = obj[key];
    }
    return copy;
  };

  // Fill in a given object with default properties.
  _.defaults = function(obj) {
    each(slice.call(arguments, 1), function(source) {
      if (source) {
        for (var prop in source) {
          if (obj[prop] === void 0) obj[prop] = source[prop];
        }
      }
    });
    return obj;
  };

  // Create a (shallow-cloned) duplicate of an object.
  _.clone = function(obj) {
    if (!_.isObject(obj)) return obj;
    return _.isArray(obj) ? obj.slice() : _.extend({}, obj);
  };

  // Invokes interceptor with the obj, and then returns obj.
  // The primary purpose of this method is to "tap into" a method chain, in
  // order to perform operations on intermediate results within the chain.
  _.tap = function(obj, interceptor) {
    interceptor(obj);
    return obj;
  };

  // Internal recursive comparison function for `isEqual`.
  var eq = function(a, b, aStack, bStack) {
    // Identical objects are equal. `0 === -0`, but they aren't identical.
    // See the [Harmony `egal` proposal](http://wiki.ecmascript.org/doku.php?id=harmony:egal).
    if (a === b) return a !== 0 || 1 / a == 1 / b;
    // A strict comparison is necessary because `null == undefined`.
    if (a == null || b == null) return a === b;
    // Unwrap any wrapped objects.
    if (a instanceof _) a = a._wrapped;
    if (b instanceof _) b = b._wrapped;
    // Compare `[[Class]]` names.
    var className = toString.call(a);
    if (className != toString.call(b)) return false;
    switch (className) {
      // Strings, numbers, dates, and booleans are compared by value.
      case '[object String]':
        // Primitives and their corresponding object wrappers are equivalent; thus, `"5"` is
        // equivalent to `new String("5")`.
        return a == String(b);
      case '[object Number]':
        // `NaN`s are equivalent, but non-reflexive. An `egal` comparison is performed for
        // other numeric values.
        return a != +a ? b != +b : (a == 0 ? 1 / a == 1 / b : a == +b);
      case '[object Date]':
      case '[object Boolean]':
        // Coerce dates and booleans to numeric primitive values. Dates are compared by their
        // millisecond representations. Note that invalid dates with millisecond representations
        // of `NaN` are not equivalent.
        return +a == +b;
      // RegExps are compared by their source patterns and flags.
      case '[object RegExp]':
        return a.source == b.source &&
               a.global == b.global &&
               a.multiline == b.multiline &&
               a.ignoreCase == b.ignoreCase;
    }
    if (typeof a != 'object' || typeof b != 'object') return false;
    // Assume equality for cyclic structures. The algorithm for detecting cyclic
    // structures is adapted from ES 5.1 section 15.12.3, abstract operation `JO`.
    var length = aStack.length;
    while (length--) {
      // Linear search. Performance is inversely proportional to the number of
      // unique nested structures.
      if (aStack[length] == a) return bStack[length] == b;
    }
    // Objects with different constructors are not equivalent, but `Object`s
    // from different frames are.
    var aCtor = a.constructor, bCtor = b.constructor;
    if (aCtor !== bCtor && !(_.isFunction(aCtor) && (aCtor instanceof aCtor) &&
                             _.isFunction(bCtor) && (bCtor instanceof bCtor))
                        && ('constructor' in a && 'constructor' in b)) {
      return false;
    }
    // Add the first object to the stack of traversed objects.
    aStack.push(a);
    bStack.push(b);
    var size = 0, result = true;
    // Recursively compare objects and arrays.
    if (className == '[object Array]') {
      // Compare array lengths to determine if a deep comparison is necessary.
      size = a.length;
      result = size == b.length;
      if (result) {
        // Deep compare the contents, ignoring non-numeric properties.
        while (size--) {
          if (!(result = eq(a[size], b[size], aStack, bStack))) break;
        }
      }
    } else {
      // Deep compare objects.
      for (var key in a) {
        if (_.has(a, key)) {
          // Count the expected number of properties.
          size++;
          // Deep compare each member.
          if (!(result = _.has(b, key) && eq(a[key], b[key], aStack, bStack))) break;
        }
      }
      // Ensure that both objects contain the same number of properties.
      if (result) {
        for (key in b) {
          if (_.has(b, key) && !(size--)) break;
        }
        result = !size;
      }
    }
    // Remove the first object from the stack of traversed objects.
    aStack.pop();
    bStack.pop();
    return result;
  };

  // Perform a deep comparison to check if two objects are equal.
  _.isEqual = function(a, b) {
    return eq(a, b, [], []);
  };

  // Is a given array, string, or object empty?
  // An "empty" object has no enumerable own-properties.
  _.isEmpty = function(obj) {
    if (obj == null) return true;
    if (_.isArray(obj) || _.isString(obj)) return obj.length === 0;
    for (var key in obj) if (_.has(obj, key)) return false;
    return true;
  };

  // Is a given value a DOM element?
  _.isElement = function(obj) {
    return !!(obj && obj.nodeType === 1);
  };

  // Is a given value an array?
  // Delegates to ECMA5's native Array.isArray
  _.isArray = nativeIsArray || function(obj) {
    return toString.call(obj) == '[object Array]';
  };

  // Is a given variable an object?
  _.isObject = function(obj) {
    return obj === Object(obj);
  };

  // Add some isType methods: isArguments, isFunction, isString, isNumber, isDate, isRegExp.
  each(['Arguments', 'Function', 'String', 'Number', 'Date', 'RegExp'], function(name) {
    _['is' + name] = function(obj) {
      return toString.call(obj) == '[object ' + name + ']';
    };
  });

  // Define a fallback version of the method in browsers (ahem, IE), where
  // there isn't any inspectable "Arguments" type.
  if (!_.isArguments(arguments)) {
    _.isArguments = function(obj) {
      return !!(obj && _.has(obj, 'callee'));
    };
  }

  // Optimize `isFunction` if appropriate.
  if (typeof (/./) !== 'function') {
    _.isFunction = function(obj) {
      return typeof obj === 'function';
    };
  }

  // Is a given object a finite number?
  _.isFinite = function(obj) {
    return isFinite(obj) && !isNaN(parseFloat(obj));
  };

  // Is the given value `NaN`? (NaN is the only number which does not equal itself).
  _.isNaN = function(obj) {
    return _.isNumber(obj) && obj != +obj;
  };

  // Is a given value a boolean?
  _.isBoolean = function(obj) {
    return obj === true || obj === false || toString.call(obj) == '[object Boolean]';
  };

  // Is a given value equal to null?
  _.isNull = function(obj) {
    return obj === null;
  };

  // Is a given variable undefined?
  _.isUndefined = function(obj) {
    return obj === void 0;
  };

  // Shortcut function for checking if an object has a given property directly
  // on itself (in other words, not on a prototype).
  _.has = function(obj, key) {
    return hasOwnProperty.call(obj, key);
  };

  // Utility Functions
  // -----------------

  // Run Underscore.js in *noConflict* mode, returning the `_` variable to its
  // previous owner. Returns a reference to the Underscore object.
  _.noConflict = function() {
    root._ = previousUnderscore;
    return this;
  };

  // Keep the identity function around for default iterators.
  _.identity = function(value) {
    return value;
  };

  _.constant = function(value) {
    return function () {
      return value;
    };
  };

  _.property = function(key) {
    return function(obj) {
      return obj[key];
    };
  };

  // Returns a predicate for checking whether an object has a given set of `key:value` pairs.
  _.matches = function(attrs) {
    return function(obj) {
      if (obj === attrs) return true; //avoid comparing an object to itself.
      for (var key in attrs) {
        if (attrs[key] !== obj[key])
          return false;
      }
      return true;
    }
  };

  // Run a function **n** times.
  _.times = function(n, iterator, context) {
    var accum = Array(Math.max(0, n));
    for (var i = 0; i < n; i++) accum[i] = iterator.call(context, i);
    return accum;
  };

  // Return a random integer between min and max (inclusive).
  _.random = function(min, max) {
    if (max == null) {
      max = min;
      min = 0;
    }
    return min + Math.floor(Math.random() * (max - min + 1));
  };

  // A (possibly faster) way to get the current timestamp as an integer.
  _.now = Date.now || function() { return new Date().getTime(); };

  // List of HTML entities for escaping.
  var entityMap = {
    escape: {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#x27;'
    }
  };
  entityMap.unescape = _.invert(entityMap.escape);

  // Regexes containing the keys and values listed immediately above.
  var entityRegexes = {
    escape:   new RegExp('[' + _.keys(entityMap.escape).join('') + ']', 'g'),
    unescape: new RegExp('(' + _.keys(entityMap.unescape).join('|') + ')', 'g')
  };

  // Functions for escaping and unescaping strings to/from HTML interpolation.
  _.each(['escape', 'unescape'], function(method) {
    _[method] = function(string) {
      if (string == null) return '';
      return ('' + string).replace(entityRegexes[method], function(match) {
        return entityMap[method][match];
      });
    };
  });

  // If the value of the named `property` is a function then invoke it with the
  // `object` as context; otherwise, return it.
  _.result = function(object, property) {
    if (object == null) return void 0;
    var value = object[property];
    return _.isFunction(value) ? value.call(object) : value;
  };

  // Add your own custom functions to the Underscore object.
  _.mixin = function(obj) {
    each(_.functions(obj), function(name) {
      var func = _[name] = obj[name];
      _.prototype[name] = function() {
        var args = [this._wrapped];
        push.apply(args, arguments);
        return result.call(this, func.apply(_, args));
      };
    });
  };

  // Generate a unique integer id (unique within the entire client session).
  // Useful for temporary DOM ids.
  var idCounter = 0;
  _.uniqueId = function(prefix) {
    var id = ++idCounter + '';
    return prefix ? prefix + id : id;
  };

  // By default, Underscore uses ERB-style template delimiters, change the
  // following template settings to use alternative delimiters.
  _.templateSettings = {
    evaluate    : /<%([\s\S]+?)%>/g,
    interpolate : /<%=([\s\S]+?)%>/g,
    escape      : /<%-([\s\S]+?)%>/g
  };

  // When customizing `templateSettings`, if you don't want to define an
  // interpolation, evaluation or escaping regex, we need one that is
  // guaranteed not to match.
  var noMatch = /(.)^/;

  // Certain characters need to be escaped so that they can be put into a
  // string literal.
  var escapes = {
    "'":      "'",
    '\\':     '\\',
    '\r':     'r',
    '\n':     'n',
    '\t':     't',
    '\u2028': 'u2028',
    '\u2029': 'u2029'
  };

  var escaper = /\\|'|\r|\n|\t|\u2028|\u2029/g;

  // JavaScript micro-templating, similar to John Resig's implementation.
  // Underscore templating handles arbitrary delimiters, preserves whitespace,
  // and correctly escapes quotes within interpolated code.
  _.template = function(text, data, settings) {
    var render;
    settings = _.defaults({}, settings, _.templateSettings);

    // Combine delimiters into one regular expression via alternation.
    var matcher = new RegExp([
      (settings.escape || noMatch).source,
      (settings.interpolate || noMatch).source,
      (settings.evaluate || noMatch).source
    ].join('|') + '|$', 'g');

    // Compile the template source, escaping string literals appropriately.
    var index = 0;
    var source = "__p+='";
    text.replace(matcher, function(match, escape, interpolate, evaluate, offset) {
      source += text.slice(index, offset)
        .replace(escaper, function(match) { return '\\' + escapes[match]; });

      if (escape) {
        source += "'+\n((__t=(" + escape + "))==null?'':_.escape(__t))+\n'";
      }
      if (interpolate) {
        source += "'+\n((__t=(" + interpolate + "))==null?'':__t)+\n'";
      }
      if (evaluate) {
        source += "';\n" + evaluate + "\n__p+='";
      }
      index = offset + match.length;
      return match;
    });
    source += "';\n";

    // If a variable is not specified, place data values in local scope.
    if (!settings.variable) source = 'with(obj||{}){\n' + source + '}\n';

    source = "var __t,__p='',__j=Array.prototype.join," +
      "print=function(){__p+=__j.call(arguments,'');};\n" +
      source + "return __p;\n";

    try {
      render = new Function(settings.variable || 'obj', '_', source);
    } catch (e) {
      e.source = source;
      throw e;
    }

    if (data) return render(data, _);
    var template = function(data) {
      return render.call(this, data, _);
    };

    // Provide the compiled function source as a convenience for precompilation.
    template.source = 'function(' + (settings.variable || 'obj') + '){\n' + source + '}';

    return template;
  };

  // Add a "chain" function, which will delegate to the wrapper.
  _.chain = function(obj) {
    return _(obj).chain();
  };

  // OOP
  // ---------------
  // If Underscore is called as a function, it returns a wrapped object that
  // can be used OO-style. This wrapper holds altered versions of all the
  // underscore functions. Wrapped objects may be chained.

  // Helper function to continue chaining intermediate results.
  var result = function(obj) {
    return this._chain ? _(obj).chain() : obj;
  };

  // Add all of the Underscore functions to the wrapper object.
  _.mixin(_);

  // Add all mutator Array functions to the wrapper.
  each(['pop', 'push', 'reverse', 'shift', 'sort', 'splice', 'unshift'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      var obj = this._wrapped;
      method.apply(obj, arguments);
      if ((name == 'shift' || name == 'splice') && obj.length === 0) delete obj[0];
      return result.call(this, obj);
    };
  });

  // Add all accessor Array functions to the wrapper.
  each(['concat', 'join', 'slice'], function(name) {
    var method = ArrayProto[name];
    _.prototype[name] = function() {
      return result.call(this, method.apply(this._wrapped, arguments));
    };
  });

  _.extend(_.prototype, {

    // Start chaining a wrapped Underscore object.
    chain: function() {
      this._chain = true;
      return this;
    },

    // Extracts the result from a wrapped and chained object.
    value: function() {
      return this._wrapped;
    }

  });

  // AMD registration happens at the end for compatibility with AMD loaders
  // that may not enforce next-turn semantics on modules. Even though general
  // practice for AMD registration is to be anonymous, underscore registers
  // as a named module because, like jQuery, it is a base library that is
  // popular enough to be bundled in a third party lib, but not be part of
  // an AMD load request. Those cases could generate an error when an
  // anonymous define() is called outside of a loader request.
  if (typeof define === 'function' && define.amd) {
    define('underscore', [], function() {
      return _;
    });
  }
}).call(this);

//     uuid.js
//
//     Copyright (c) 2010-2012 Robert Kieffer
//     MIT License - http://opensource.org/licenses/mit-license.php

(function() {
  var _global = this;

  // Unique ID creation requires a high quality random # generator.  We feature
  // detect to determine the best RNG source, normalizing to a function that
  // returns 128-bits of randomness, since that's what's usually required
  var _rng;

  // Node.js crypto-based RNG - http://nodejs.org/docs/v0.6.2/api/crypto.html
  //
  // Moderately fast, high quality
  if (typeof(_global.require) == 'function') {
    try {
      var _rb = _global.require('crypto').randomBytes;
      _rng = _rb && function() {return _rb(16);};
    } catch(e) {}
  }

  if (!_rng && _global.crypto && crypto.getRandomValues) {
    // WHATWG crypto-based RNG - http://wiki.whatwg.org/wiki/Crypto
    //
    // Moderately fast, high quality
    var _rnds8 = new Uint8Array(16);
    _rng = function whatwgRNG() {
      crypto.getRandomValues(_rnds8);
      return _rnds8;
    };
  }

  if (!_rng) {
    // Math.random()-based (RNG)
    //
    // If all else fails, use Math.random().  It's fast, but is of unspecified
    // quality.
    var  _rnds = new Array(16);
    _rng = function() {
      for (var i = 0, r; i < 16; i++) {
        if ((i & 0x03) === 0) r = Math.random() * 0x100000000;
        _rnds[i] = r >>> ((i & 0x03) << 3) & 0xff;
      }

      return _rnds;
    };
  }

  // Buffer class to use
  var BufferClass = typeof(_global.Buffer) == 'function' ? _global.Buffer : Array;

  // Maps for number <-> hex string conversion
  var _byteToHex = [];
  var _hexToByte = {};
  for (var i = 0; i < 256; i++) {
    _byteToHex[i] = (i + 0x100).toString(16).substr(1);
    _hexToByte[_byteToHex[i]] = i;
  }

  // **`parse()` - Parse a UUID into it's component bytes**
  function parse(s, buf, offset) {
    var i = (buf && offset) || 0, ii = 0;

    buf = buf || [];
    s.toLowerCase().replace(/[0-9a-f]{2}/g, function(oct) {
      if (ii < 16) { // Don't overflow!
        buf[i + ii++] = _hexToByte[oct];
      }
    });

    // Zero out remaining bytes if string was short
    while (ii < 16) {
      buf[i + ii++] = 0;
    }

    return buf;
  }

  // **`unparse()` - Convert UUID byte array (ala parse()) into a string**
  function unparse(buf, offset) {
    var i = offset || 0, bth = _byteToHex;
    return  bth[buf[i++]] + bth[buf[i++]] +
            bth[buf[i++]] + bth[buf[i++]] + '-' +
            bth[buf[i++]] + bth[buf[i++]] + '-' +
            bth[buf[i++]] + bth[buf[i++]] + '-' +
            bth[buf[i++]] + bth[buf[i++]] + '-' +
            bth[buf[i++]] + bth[buf[i++]] +
            bth[buf[i++]] + bth[buf[i++]] +
            bth[buf[i++]] + bth[buf[i++]];
  }

  // **`v1()` - Generate time-based UUID**
  //
  // Inspired by https://github.com/LiosK/UUID.js
  // and http://docs.python.org/library/uuid.html

  // random #'s we need to init node and clockseq
  var _seedBytes = _rng();

  // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
  var _nodeId = [
    _seedBytes[0] | 0x01,
    _seedBytes[1], _seedBytes[2], _seedBytes[3], _seedBytes[4], _seedBytes[5]
  ];

  // Per 4.2.2, randomize (14 bit) clockseq
  var _clockseq = (_seedBytes[6] << 8 | _seedBytes[7]) & 0x3fff;

  // Previous uuid creation time
  var _lastMSecs = 0, _lastNSecs = 0;

  // See https://github.com/broofa/node-uuid for API details
  function v1(options, buf, offset) {
    var i = buf && offset || 0;
    var b = buf || [];

    options = options || {};

    var clockseq = options.clockseq != null ? options.clockseq : _clockseq;

    // UUID timestamps are 100 nano-second units since the Gregorian epoch,
    // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
    // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
    // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.
    var msecs = options.msecs != null ? options.msecs : new Date().getTime();

    // Per 4.2.1.2, use count of uuid's generated during the current clock
    // cycle to simulate higher resolution clock
    var nsecs = options.nsecs != null ? options.nsecs : _lastNSecs + 1;

    // Time since last uuid creation (in msecs)
    var dt = (msecs - _lastMSecs) + (nsecs - _lastNSecs)/10000;

    // Per 4.2.1.2, Bump clockseq on clock regression
    if (dt < 0 && options.clockseq == null) {
      clockseq = clockseq + 1 & 0x3fff;
    }

    // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
    // time interval
    if ((dt < 0 || msecs > _lastMSecs) && options.nsecs == null) {
      nsecs = 0;
    }

    // Per 4.2.1.2 Throw error if too many uuids are requested
    if (nsecs >= 10000) {
      throw new Error('uuid.v1(): Can\'t create more than 10M uuids/sec');
    }

    _lastMSecs = msecs;
    _lastNSecs = nsecs;
    _clockseq = clockseq;

    // Per 4.1.4 - Convert from unix epoch to Gregorian epoch
    msecs += 12219292800000;

    // `time_low`
    var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
    b[i++] = tl >>> 24 & 0xff;
    b[i++] = tl >>> 16 & 0xff;
    b[i++] = tl >>> 8 & 0xff;
    b[i++] = tl & 0xff;

    // `time_mid`
    var tmh = (msecs / 0x100000000 * 10000) & 0xfffffff;
    b[i++] = tmh >>> 8 & 0xff;
    b[i++] = tmh & 0xff;

    // `time_high_and_version`
    b[i++] = tmh >>> 24 & 0xf | 0x10; // include version
    b[i++] = tmh >>> 16 & 0xff;

    // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)
    b[i++] = clockseq >>> 8 | 0x80;

    // `clock_seq_low`
    b[i++] = clockseq & 0xff;

    // `node`
    var node = options.node || _nodeId;
    for (var n = 0; n < 6; n++) {
      b[i + n] = node[n];
    }

    return buf ? buf : unparse(b);
  }

  // **`v4()` - Generate random UUID**

  // See https://github.com/broofa/node-uuid for API details
  function v4(options, buf, offset) {
    // Deprecated - 'format' argument, as supported in v1.2
    var i = buf && offset || 0;

    if (typeof(options) == 'string') {
      buf = options == 'binary' ? new BufferClass(16) : null;
      options = null;
    }
    options = options || {};

    var rnds = options.random || (options.rng || _rng)();

    // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`
    rnds[6] = (rnds[6] & 0x0f) | 0x40;
    rnds[8] = (rnds[8] & 0x3f) | 0x80;

    // Copy bytes to buffer, if provided
    if (buf) {
      for (var ii = 0; ii < 16; ii++) {
        buf[i + ii] = rnds[ii];
      }
    }

    return buf || unparse(rnds);
  }

  // Export public API
  var uuid = v4;
  uuid.v1 = v1;
  uuid.v4 = v4;
  uuid.parse = parse;
  uuid.unparse = unparse;
  uuid.BufferClass = BufferClass;

  if (typeof define === 'function' && define.amd) {
    // Publish as AMD module
    define('uuid',[],function() {return uuid;});
  } else if (typeof(module) != 'undefined' && module.exports) {
    // Publish as node.js module
    module.exports = uuid;
  } else {
    // Publish as global (in browsers)
    var _previousRoot = _global.uuid;

    // **`noConflict()` - (browser only) to reset global 'uuid' var**
    uuid.noConflict = function() {
      _global.uuid = _previousRoot;
      return uuid;
    };

    _global.uuid = uuid;
  }
}).call(this);

/**
 * Dependency Injection class.
 * This class will be used to create components instances and store links to them
 */
define('shared/utils/dic-lib',[],function() {
	/**
	 * Dependency Injection container constructor
	 * @name Dic
	 * @constructor
	 *
	 * @param {Object} factories keys represent object name, values are factory methods
	 *
	 * @example
	 * {
	 *   className: function(options){
	 *      // if it should be a singleton, save it to this.registry['className']
	 *      if (this.registry['className']) {
	 *          return this.registry['className'];
	 *      }
	 *
	 *      // construct instance of className
	 *      return instance;
	 *   }
	 * }
	 */
	function Dic(factories) {
		this.factories = factories;
		this.registry = {};
	}

	/**
	 * Create instance using factory by type name
	 * @name Dic#getInstance
	 * @function
	 *
	 * @param  {string} name - singleton instance name
	 * @param  {Object} [options]
	 * @returns {mixed}
	 */
	Dic.prototype.getInstance = function(name, options) {
		if (!this.factories[name]) {
			throw new Error('Unknown type "' + name + '"');
		}

		return this.factories[name].call(this, options);
	};

	/**
	 * Create instance using factory by type name
	 * @name Dic#getInstance
	 * @function
	 *
	 * @param  {string} name - singleton instance name
	 * @param  {Object} [options]
	 * @returns {mixed}
	 */
	Dic.prototype.get = function(name, options) {
		return this.getInstance(name, options);
	};

	/**
	 * @deprecated
	 * This method should no longer be used.
	 * Save instance to the registry in factory method instead.
	 *
	 * Get instance from singletons registry.
	 * If there is no instance in registry new instance will be created and putted to registry
	 * @name Dic#getSingleton
	 * @function
	 *
	 * @param  {string} name - singleton instance name
	 * @param  {Object} options [optional]
	 * @returns {mixed}
	 */
	Dic.prototype.getSingleton = function(name, options) {
		if (!this.registry[name]) {
			this.registry[name] = this.getInstance(name, options);
		}

		return this.registry[name];
	};

	/**
	 * Adds speficied factories to the container
	 * @param {Object} extraFactories Hash of factories, format the same as for constructor
	 */
	Dic.prototype.addFactories = function(extraFactories) {
		for (var name in extraFactories) {
			this.addFactory(name, extraFactories[name]);
		}
	};

	/**
	 * Adds one factory to the container
	 * @param {string} name    Factory name
	 * @param {Object} factory Factory method
	 */
	Dic.prototype.addFactory = function(name, factory) {
		this.factories[name] = factory;
	};

	return Dic;
});
/**
 * Example of usage:
 * 
 * @example
 * <pre>
 * new Dic({
 *
 *   name: {
 *     module: require('path/to/module'),
 *     dependencies: [
 *       require('path/to/dependency')
 *     ],
 *     register: true|false, // true by default
 *     create: true|false,  // false by default
 *   },
 *
 *   module: function () {
 *     return <any>;
 *   }
 *
 * });
 * </pre>
 *
 * where a 'name' key is the name of factory
 */
define('aq/di',['shared/utils/dic-lib'], function (Di) {
    'use strict';

    /**
     *
     * @param name {String}
     * @param options
     * @returns {*}
     */
    Di.prototype.get = function (name, options) {

        var factory = this.factories[name];

        if (!factory) {
            throw new Error('Unknown type "' + name + '"');
        }

        if (this.registry[name]) {
            return this.registry[name];
        }

        if (_.isFunction(factory)) {
            return factory.call(this, options);
        }

        // inject dependencies from configuration, pass them into constructor
        var dependencies = _.isArray(factory.dependencies) ? [null].concat(factory.dependencies) : [null];
        var Module = factory.module.bind ? factory.module.bind.apply(factory.module, dependencies) : factory.module;

        if (factory.create){
            Module = new Module(options);
        }

        // save into registry
        if (factory.register !== false) {
            this.registry[name] = Module;
        }

        return Module;
    };

    /**
     *
     * @param name {string}
     * @param [options] {object}
     * @returns {object}
     */
    Di.prototype.create = function (name, options) {
        var Module = this.registry[name] || this.get(name, options);
        return _.isFunction(Module) ? (this.registry[name] = new Module(options)) : Module;
    };

    /**
     * Invoke "start" method in all registered modules
     */
    Di.prototype.start = function () {
        this._invoke('start');
    };

    /**
     * Invoke "suspend" method in all registered modules
     */
    Di.prototype.suspend = function () {
        this._invoke('suspend');
    };

    /**
     * Invoke "close" method in all registered modules
     */
    Di.prototype.close = function () {
        this._invoke('close');
    };

    Di.prototype._invoke = function (method) {
        _.each(this.registry, function (module) {
            if (module[method]) {
                module[method]();
            }
        });
    };

    return Di;
});

/* Simple JavaScript Inheritance
 * By John Resig http://ejohn.org/
 * MIT Licensed.
 *
 * Taken from here: http://ejohn.org/blog/simple-javascript-inheritance/
 */
define('shared/utils/class',[],function(){

	var initializing = false,
		fnTest = /xyz/.test(function(){xyz;}) ? /\b_super\b/ : /.*/;

	// The base Class implementation (does nothing)
	function Class (){}

	// Create a new Class that inherits from this class
	Class.extend = function(prop) {
		var _super = this.prototype;

		// Instantiate a base class (but only create the instance,
		// don't run the init constructor)
		initializing = true;
		var prototype = new this();
		initializing = false;

		// Copy the properties over onto the new prototype
		for (var name in prop) {
			// Check if we're overwriting an existing function
			prototype[name] = typeof prop[name] == "function" &&
				typeof _super[name] == "function" && fnTest.test(prop[name]) ?
				(function(name, fn){
					return function() {
						var tmp = this._super;

						// Add a new ._super() method that is the same method
						// but on the super-class
						this._super = _super[name];

						// The method only need to be bound temporarily, so we
						// remove it when we're done executing
						var ret = fn.apply(this, arguments);
						this._super = tmp;

						return ret;
					};
				})(name, prop[name]) :
				prop[name];
		}

		// The dummy class constructor
		function Class() {
			// All construction is actually done in the init method
			if ( !initializing && this.init ) {
				this.init.apply(this, arguments);
			}
		}

		// Populate our constructed prototype object
		Class.prototype = prototype;

		// Enforce the constructor to be what we expect
		Class.prototype.constructor = Class;

		// And make this class extendable
		Class.extend = arguments.callee;

		return Class;
	};

	return Class;
});

/**
 * A module that can be mixed in to *any object* in order to provide it with
 * custom events. You may bind with `on` or remove with `off` callback
 * functions to an event; `trigger`-ing an event fires all callbacks in succession.
 *
 * Taken from Backbone.Events under the MIT license.
 * http://backbonejs.org/backbone.js
 *
 */
define('aq/mixins/events',[],function () {
    'use strict';


    var Events = {

        // Bind an event to a `callback` function. Passing `"all"` will bind
        // the callback to all events fired.
        on: function(name, callback, context) {
            if (!eventsApi(this, 'on', name, [callback, context]) || !callback) return this;
            this._events = this._events || {};
            var events = this._events[name] || (this._events[name] = []);
            events.push({callback: callback, context: context, ctx: context || this});
            return this;
        },

        // Bind an event to only be triggered a single time. After the first time
        // the callback is invoked, it will be removed.
        once: function(name, callback, context) {
            if (!eventsApi(this, 'once', name, [callback, context]) || !callback) return this;
            var self = this;
            var once = _.once(function() {
                self.off(name, once);
                callback.apply(this, arguments);
            });
            once._callback = callback;
            return this.on(name, once, context);
        },

        // Remove one or many callbacks. If `context` is null, removes all
        // callbacks with that function. If `callback` is null, removes all
        // callbacks for the event. If `name` is null, removes all bound
        // callbacks for all events.
        off: function(name, callback, context) {
            var retain, ev, events, names, i, l, j, k;
            if (!this._events || !eventsApi(this, 'off', name, [callback, context])) return this;
            if (!name && !callback && !context) {
                this._events = void 0;
                return this;
            }
            names = name ? [name] : _.keys(this._events);
            for (i = 0, l = names.length; i < l; i++) {
                name = names[i];
                if ((events = this._events[name])) {
                    this._events[name] = retain = [];
                    if (callback || context) {
                        for (j = 0, k = events.length; j < k; j++) {
                            ev = events[j];
                            if ((callback && callback !== ev.callback && callback !== ev.callback._callback) ||
                                (context && context !== ev.context)) {
                                retain.push(ev);
                            }
                        }
                    }
                    if (!retain.length) delete this._events[name];
                }
            }

            return this;
        },

        // Trigger one or many events, firing all bound callbacks. Callbacks are
        // passed the same arguments as `trigger` is, apart from the event name
        // (unless you're listening on `"all"`, which will cause your callback to
        // receive the true name of the event as the first argument).
        trigger: function(name) {
            if (!this._events) return this;
            var args = Array.prototype.slice.call(arguments, 1);
            if (!eventsApi(this, 'trigger', name, args)) return this;
            var events = this._events[name];
            var allEvents = this._events.all;
            if (events) triggerEvents(events, args);
            if (allEvents) triggerEvents(allEvents, arguments);
            return this;
        },

        // Tell this object to stop listening to either specific events ... or
        // to every object it's currently listening to.
        stopListening: function(obj, name, callback) {
            var listeningTo = this._listeningTo;
            if (!listeningTo) return this;
            var remove = !name && !callback;
            if (!callback && typeof name === 'object') callback = this;
            if (obj) (listeningTo = {})[obj._listenId] = obj;
            for (var id in listeningTo) {
                obj = listeningTo[id];
                obj.off(name, callback, this);
                if (remove || _.isEmpty(obj._events)) delete this._listeningTo[id];
            }
            return this;
        }

    };

    // Regular expression used to split event strings.
    var eventSplitter = /\s+/;

    // Implement fancy features of the Events API such as multiple event
    // names `"change blur"` and jQuery-style event maps `{change: action}`
    // in terms of the existing API.
    var eventsApi = function(obj, action, name, rest) {
        if (!name) return true;

        // Handle event maps.
        if (typeof name === 'object') {
            for (var key in name) {
                obj[action].apply(obj, [key, name[key]].concat(rest));
            }
            return false;
        }

        // Handle space separated event names.
        if (eventSplitter.test(name)) {
            var names = name.split(eventSplitter);
            for (var i = 0, l = names.length; i < l; i++) {
                obj[action].apply(obj, [names[i]].concat(rest));
            }
            return false;
        }

        return true;
    };

    // A difficult-to-believe, but optimized internal dispatch function for
    // triggering events. Tries to keep the usual cases speedy (most internal
    // Backbone events have 3 arguments).
    var triggerEvents = function(events, args) {
        var ev, i = -1, l = events.length, a1 = args[0], a2 = args[1], a3 = args[2];
        switch (args.length) {
        case 0:
            while (++i < l) (ev = events[i]).callback.call(ev.ctx);
            return;
        case 1:
            while (++i < l) (ev = events[i]).callback.call(ev.ctx, a1);
            return;
        case 2:
            while (++i < l) (ev = events[i]).callback.call(ev.ctx, a1, a2);
            return;
        case 3:
            while (++i < l) (ev = events[i]).callback.call(ev.ctx, a1, a2, a3);
            return;
        default:
            while (++i < l) (ev = events[i]).callback.apply(ev.ctx, args);
            return;
        }
    };

    var listenMethods = {listenTo: 'on', listenToOnce: 'once'};

    // Inversion-of-control versions of `on` and `once`. Tell *this* object to
    // listen to an event in another object ... keeping track of what it's
    // listening to.
    _.each(listenMethods, function(implementation, method) {
        Events[method] = function(obj, name, callback) {
            var listeningTo = this._listeningTo || (this._listeningTo = {});
            var id = obj._listenId || (obj._listenId = _.uniqueId('l'));
            listeningTo[id] = obj;
            if (!callback && typeof name === 'object') callback = this;
            obj[implementation](name, callback, this);
            return this;
        };
    });

    // @compatibility.
    Events.bind   = Events.on;
    Events.unbind = Events.off;

    Events.when = function (name) {
        this._tempEventName = name;
        return this;
    };

    Events.then = function (callback) {
        this.on(this._tempEventName, callback);
        this._tempEventName = '';
        return this;
    };

    return Events;
});

define('aq/eventEmitter',['shared/utils/class', 'aq/mixins/events'], function (Class, events) {
    'use strict';

    return Class.extend(events);

});

define('aq/api/base',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (transport) {
            this._initTransport(transport);
        },

        _initTransport: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this._onNotification);
        },

        /**
         * _onNotification should be implemented in inherited class
         */
        _onNotification: function () {

        }

    });
});
define('aq/api/storage',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (transport) {
            this._super(transport);
        },

        /**
         * Permanently saves a JSON value. (The value will persist until the app is uninstalled)
         * @param key
         * @param json
         * @returns {jqXHR|jQuery.Deferred|*|$.Deferred}
         */
        saveJSON: function (key, json) {
            var data = {};
            data[key] = json;
            return this._transport.sendRequest({
                "path": "storage",
                "method": "POST",
                "content": data
            });
        },

        /**
         * Retrieve a previously saved JSON value by key
         * @param key {string} Key for the value to be retrieved.
         * @param defaultValue {object|string} value used for the key, if it has not been set yet
         * @returns {jqXHR|jQuery.Deferred|*|$.Deferred}
         */
        getJSON: function (key, defaultValue) {
            return this._transport.sendRequest({
                "path" : "storage",
                "method" : "GET",
                "content": {
                    "key" : key,
                    "defaultValue": defaultValue
                }
            });
        }
    });
});
/**
 * @Singleton
 */
define('aq/storage',['aq/api/storage'], function (Storage) {
    'use strict';

    var _storage = {

        image: {
            COUNT: 0
        },
        actions: {}

    };

    return Storage.extend({

        init: function (transport, constants, utils) {
            this.constants = constants;
            this.utils = utils;
            this._super(transport);
        },

        /**
         * Looks for the id for the given value in the images hash map.
         * If no ids found, it will generate a new id and add it
         * to the hash map and return the new id.
         * @param image {Object}
         * @returns {number}
         */
        getImageId: function (image) {

            if(!_.isString(image.data) || _.isEmpty(image.data)) {
                return this.constants.EMPTY_IMAGE_ID;
            }

            var imgUrl = this.utils.toJSON({data: image.data}, undefined, 0),
                imgData = this.utils.toJSON(image, undefined, 0);

            return _storage.image[imgUrl] || _storage.image[imgData] || this.addValue(imgData, 'image');
        },

        addLocalImageId: function (url, id) {
            return _storage.image[this.utils.toJSON({data: url}, undefined, 0)] = id;
        },

        /**
         * Retrieves the value based on the given id and type
         * @param id
         * @param type
         * @returns {string|undefined}
         */
        getValue: function (id, type) {
            var storage = _.invert(_storage[type] || {});
            return storage[id];
        },

        /**
         * Adds a new entry to the hash map and returns the newly generated id.
         * @param value {json}
         * @param type {string}
         * @returns {number} id
         */
        addValue: function (value, type) {
            return _storage[type][value] || this._addValue(value, type);
        },

        _addValue: function (value, type) {
            _storage[type][value] = ++_storage[type].COUNT;
            return _storage[type].COUNT;
        },

        /**
         *
         * @param id {number}
         * @param type {string}
         * @returns {boolean}
         */
        removeValue: function (id, type) {
            if (type !== 'COUNT') {
                for (var key in _storage[type]) {
                    if (_storage[type][key] === id) {
                        delete _storage[type][key];
                        return true;
                    }
                }
            }
            return false;
        },

        /**
         * Save action and value for on-screen soft button
         * @param keyId {number}
         * @param action {string}
         * @param value {string}
         */
        addAction: function (keyId, action, value) {
            _storage.actions[keyId] = {
                action: action,
                value: value
            };
        },

        /**
         * Get action and value by id for pressed on-screen soft button
         * @param keyId {number}
         * @returns {object}
         */
        getAction: function (keyId) {
            return _.extend({}, _storage.actions[keyId]);
        },

        clearActions: function () {
            delete _storage.actions;
            _storage.actions = {};
        }


    });
});
define('aq/view',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    var currentlyDisplayingTemplate = {
        data: {},
        LastUpdate: {},
        screenId: null
    };

    var isReady = true,  // is head unit ready to process screen update messages
        waitTime = 100;  // interval for sending to head unit screen update messages

    return EventEmitter.extend({


        /**
         * active events - bind event list
         *
         */
        activeEvents: [],

        /**
         *
         * @param options {object}
         */
        init: function (options) {
            this.utils = options.utils;
            this.constants = options.constants;
            this.storage = options.storage;
            this.controls = options.controls;
            this.screen = options.screen;
            this.templateProcessor = new options.TemplateProcessor(
                currentlyDisplayingTemplate, options.storage, options.appManager
            );

            this.logger = new options.Logger('high', 'WEB_VIEW', 'SCREEN');

            this.listenTo(this.screen, this.screen.events.screenUpdateComplete, this.onScreenUpdated);

            this.onSoftButtonPress = _.debounce(this.onSoftButtonPress.bind(this), 1000, true);
            this.listenTo(this.controls, this.controls.events.soft, this.onSoftButtonPress);
            this.listenTo(this.controls, this.controls.events.hard, this.onHardButtonPress);
            this.listenTo(this.controls, this.controls.events.keyboard, this.onKeyboardButtonPress);

            this._updateScreen = _.throttle(this._updateScreen.bind(this), waitTime);
        },

        onSoftButtonPress: function (data) {
            var content = data.content && data.content.data,
                btnClickOnScreenId = content && content.screenId,
                currentScreenId = currentlyDisplayingTemplate.screenId;

            this.logger.info({onSoftButtonPress: data});

            // avoid clicking on a rendering screen (which is not yet displayed)
            if (!!btnClickOnScreenId && !!currentScreenId &&
                parseInt(btnClickOnScreenId, 10) !== parseInt(currentScreenId, 10)) {
                return false;
            }
            this.trigger(data.action, {
                value: data.value
            });
        },

        onHardButtonPress: function (data) {
            this.logger.info({onHardButtonPress: data});

            this.trigger(data.button, {
                type: "hardButtonPressed"
            });
        },

        onKeyboardButtonPress: function (data) {
            this.logger.info({onKeyboardButtonPress: data});

            this.trigger(this.controls.events.keyboard, {
                letter: data.value,
                type: "hardButtonPressed"
            });
        },

        /**
         * Start list to specified head unit hard control
         */
        startListenTo: function (hardControl) {
            var to = {};
            to[hardControl] = true;
            if (this.activeEvents.indexOf(hardControl) === -1) {
                this.activeEvents.push(hardControl);
                return this.controls.startListenTo(to);
            }
        },

        /**
         * Stop list to specified head unit hard control
         * If no argument passed stop listen to all specific head unit hard controls
         */
        stopListenTo: function (hardControl) {
            var to = {},
                activeEventIndex = this.activeEvents.indexOf(hardControl);
            if (hardControl && activeEventIndex !== -1) {
                to[hardControl] = true;
                this.activeEvents.splice(activeEventIndex, 1);
            }
            return this.controls.stopListenTo(to);
        },

        getKeyboardButtonEventName: function () {
            return this.controls.events.keyboard;
        },

        getBackButtonEventName: function () {
            return this.constants.HARD_KEY_NAMES.back;
        },

        getScrollEventName: function () {
            return this.constants.HARD_KEY_NAMES.scroll;
        },

        getSeekUpEventName: function () {
            return this.constants.HARD_KEY_NAMES.seekUp;
        },

        getSeekDownEventName: function () {
            return this.constants.HARD_KEY_NAMES.seekDown;
        },

        getUnMuteEventName: function(){
            return this.constants.HARD_KEY_NAMES.unmute;
        },

        getMuteEventName: function(){
            return this.constants.HARD_KEY_NAMES.mute;
        },

        getEnterEventName: function(){
            return this.constants.HARD_KEY_NAMES.enter;
        },

        showLoading: function (text) {
            this.resetScreen();
            this._displaySystemScreen('show', text);
        },

        hideLoading: function () {
            this._displaySystemScreen('hide', '');
        },

        showKeyboard: function (keyboardBgImg1, keyboardBgImg2) {
            this.screen.displayKeyboardScreen(keyboardBgImg1, keyboardBgImg2);
        },

        showMediaSourceScreen: function () {
            this.screen.displayMediaSourceScreen();
        },

        _displaySystemScreen: function (state, text) {
            text = typeof text === 'string' ? text : '';
            state = ['hide', 'show'].indexOf(state) !== -1 ? state : 'show';
            this.screen.displaySystemScreen(state, text);
        },

        resetScreen: function () {
            currentlyDisplayingTemplate.data = {};
            currentlyDisplayingTemplate.LastUpdate = {};
            currentlyDisplayingTemplate.screenId = null;
        },

        getCurrentTemplate: function () {
            return $.extend(true, {}, currentlyDisplayingTemplate.data);
        },

        /**
         * Process the template and updates the screen with the generated data.
         * @param template {object}
         * @returns {boolean}
         */
        updateScreen: function (template) {
            this.logger.info({
                msg: 'updateScreen: unbind and invoke _updateScreen',
                tpl: template
            });
            this.off();
            return this._updateScreen($.extend(true, {}, template));
        },

        onScreenUpdated: function (content) {
            isReady = true;
            currentlyDisplayingTemplate.screenId = content.data.screenId;
        },

        isCurrentTemplateIsEqualToGenerated: function(generatedTemplate) {
            return this.utils.isEqual(generatedTemplate, currentlyDisplayingTemplate.data);
        },

        _updateScreen: function (template) {
            var nextTemplate;
            this.logger.info({"before template processing" : {
                tpl: template
            }});

            //When rendering list with active item selected, this equality check
            //may not be enough to determine if screen need to be updated.
            // See CV-1997 for this particular use case.
            if (template.templateId !== "vp2c-3" && this.isCurrentTemplateIsEqualToGenerated(template)) {
                this.logger.info({"_updateScreen" : "this template is exactly the same as previous one."});
                return false;
            }

            nextTemplate = this.templateProcessor.process(template);
            this.screen.updateScreen(nextTemplate);
            this.hideLoading();
            currentlyDisplayingTemplate.data = template;
            return true;
        }

    });
});

/**
 * Audio focus
 */

define('aq/api/hu/audio',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            audioFocus: 'audioFocus'
        },

        init: function (transport) {
            this._super(transport);
        },

        /**
         *
         * @returns {$.Deferred}
         */
        focus: function () {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'audioFocus',
                    state: 'acquire'
                }
            });
        },

        /**
         *
         * @returns {$.Deferred}
         */
        releaseFocus: function () {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'audioFocus',
                    state: 'release'
                }
            });
        },

        /**
         *
         * @param content {Object}
         * {
         *    "type": "audioFocus",
         *    "data": {
         *        "state" : "<Audio Focus State>"
         *        "status" : "<Status of the request>"
         *    }
         * }
         *
         * <Audio Focus State>: release || acquire
         *
         * @private
         */
        _onNotification: function (content) {
            var notificationName = content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }
    });
});
/**
 * VR module for applications launch
 */

define('aq/api/hu/vr',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            vrAppLaunch: 'vrAppLaunch'
        },

        init: function (transport, utils, constants) {
            this.constants = constants;
            this.utils = utils;
            this._super(transport);
        },

        /**
         *
         * @param apps {Array}
         * [
         *   appDisplayName: <appDisplayName>,
         *   appName: <appName>
         * ]
         */
        setVrAppLaunchByListOfApps: function (apps) {
            // apps that could be launched through VR
            var appsList = this.constants.APPS_GRAMMAR;

            var appNameMap = this.constants.APP_NAME_MAP;

            // filter out not needed apps from list of all available apps
            var vrApps = apps.filter(function (app) {
                return appsList[app.appName];
            });

            this.setVrAppLaunch(vrApps.map(function (app) {
                return {
                    displayName: app.appDisplayName,
                    launchName: appNameMap[app.appName],
                    grammar: appsList[app.appName]
                };
            }));
        },

        /**
         *
         * @param list {Array}
         * [
         *   displayName: <string>,
         *   launchName: <handsetAppNAme>,
         *   grammar: []
         * ]
         *
         * @returns {$.Deferred}
         */
        setVrAppLaunch: function (list) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'setVrAppLaunch',
                    data: this.utils.toObject(list)
                }
            });
        },

        /**
         *
         * @param content {Object}
         * {
         *    "type": "vrAppLaunch",
         *    "data": {
         *        "launchName" : "<handsetAppName>"
         *    }
         * }
         *
         * @private
         */
        _onNotification: function (content) {
            var notificationName = content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }
    });
});
/* jshint unused:false*/
define('shared/thor_interface/navigation',['shared/utils/class', 'jquery'], function (Class, $) {
	'use strict';

	/**
	 * @typedef {object} Navigation#DestinationType
	 * @property {string} NONE
	 * @property {string} WAY_POINT_DESTINATION
	 * @property {string} FINAL_DESTINATION
	 * @property {string} DESTINATION_ON_MAP
	 */

	/**
	 * @typedef {object} Navigation#LocationType
	 * @property {string} CURRENT_LOCATION
	 * @property {string} DESTINATION_LOCATION
	 */

	return Class.extend(
		{

			init: function () {
				this.directions = ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'];
			},

			/**
			 * Starts navigation using coordinates and address
			 * @param  {number} lat     Latitude coordinate
			 * @param  {number} lon     Longitude coordinate
			 * @param  {string} address Full address of POI
			 */
			start: function (lat, lon, address) {
				throw new Error('not implemented');
			},

			/**
			 * Add waypoint to the map using coordinates and address
			 * @param  {number} lat     Latitude coordinate
			 * @param  {number} lon     Longitude coordinate
			 * @param  {string} address Full address of POI
			 */
			addWaypoint: function (lat, lon, address) {
				throw new Error('not implemented');
			},

			/**
			 * Gets last received location by type.
			 * This method will not request actual coordinates from HU, it will return
			 * already cached results of location coordinates.
			 *
			 * @param {Navigation#DestinationType} type Destination type
			 */
			getLastReceivedLocation: function (type) {
				throw new Error('not implemented');
			},

			/**
			 * Requests current location from the HU
			 * @return {jQuery.Promise} - return value should match type of object {lat: number, lon: number}
			 */
			getCurrentLocation: function () {
				throw new Error('not implemented');
			},

			/**
			 * Requests destination location from the HU
			 * @return {jQuery.Promise} - return value should match type of object {lat: number, lon: number}
			 */
			getDestinationLocation: function () {
				throw new Error('not implemented');
			},

			/**
			 * Requests location form the HU by type
			 * @param {Navigation#LocationType} type Location type
			 * @return {jQuery.Promise} return value should match type of object {lat: number, lon: number}
			 */
			getLocation: function (type) {
				throw new Error('not implemented');
			},

			/**
			 * gets vehicle heading in degrees(from 0 to 315 with step 45)
			 * @return {jQuery.Deferred} Value should be a number: 0(due north), 45(due north-east), 90(due east), 135,
			 * 180 ..., 315
			 */
			getVehicleHeading: function () {
				throw new Error('not implemented');
			},

			/**
			 * Get vehicle's speed in km/h by default
			 *
			 * @param {string} [unit=KMPH] - Unit type, possible values: KMPH, MPH
			 * @return {jQuery.Deferred} Value should be a number
			 */
			getVehicleSpeed: function (unit) {
				throw new Error('not implemented');
			},

			/**
			 * Convertes radians to degress
			 * @param  {number} n Radian to be converted
			 * @return {number}
			 */
			toDeg: function (n) {
				return n * 180 / Math.PI;
			},

			/**
			 * Convertes degress to radians
			 * @param  {number} n Degree to be converted
			 * @return {number}
			 */
			toRad: function (n) {
				return n * Math.PI / 180;
			},

			/**
			 * @return value "M" or "KM"
			 */
			getDistanceUnit: function () {
				throw new Error('not implemented');
			},

			preciseRound: function (num, decimals, toFixed) {
				var sign = num >= 0 ? 1 : -1,
					value;
				value = (Math.round((num * Math.pow(10, decimals)) + (sign * 0.001)) / Math.pow(10, decimals));
				value = (toFixed) ? value.toFixed(decimals) : value;

				return value;
			},

			/**
			 * Calculates bearing between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			getBearing: function (from, to) {
				var dLon = this.toRad(to.lon - from.lon),
					lat1 = this.toRad(from.lat),
					lat2 = this.toRad(to.lat),
					y = Math.sin(dLon) * Math.cos(lat2),
					x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon),
					brng = this.toDeg(Math.atan2(y, x));

				return (brng + 360) % 360;
			},

			/**
			 * Calculates direction between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			calcDirection: function (from, to) {
				var bearing = this.getBearing(from, to),
					dirIndex = Math.round(bearing / 45) % 8;

				return this.directions[dirIndex] || "";
			},

			/**
			 * Calculates distance between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			calcDistance: function (from, to) {
				var radlat1 = Math.PI * from.lat / 180,
					radlat2 = Math.PI * to.lat / 180,
					theta = from.lon - to.lon,
					radtheta = Math.PI * theta / 180,
					dist;

				dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) *
				Math.cos(radtheta);
				dist = Math.acos(dist);
				dist = dist * 180 / Math.PI;
				dist = dist * 60 * 1.1515;

				return this.preciseRound(dist, 2, false);
			}

		});
});
define('aq/api/hu/navigation',['shared/thor_interface/navigation', 'aq/mixins/events'], function (Navigation, events) {
    'use strict';

    return Navigation.extend({

        LOCATION_TYPE: {
            'CURRENT': 'current',
            'DESTINATION': 'destination'
        },

        events: {
            vehicleState: 'vehicleState:changed'
        },

        vehicleStates: {
            moving: 'moving',
            stopped: 'stopped'
        },

        init: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this._onNotification);
        },


        getLocation: function (locationType) {
            //TODO check, is Alpine HU support this feature
            if (locationType === this.LOCATION_TYPE.DESTINATION) {
                return this.getDestinationLocation();
            } else {
                return this.getCurrentLocation();
            }
        },

        getDestinationLocation: function () {
            console.error('Not implemented yet');
            return false;
        },

        /**
         * response:
         *
         * {
         *   content: {
         *     data: { latitude : <Latitude>, longitude: <Longitude> },
         *     error: {}
         *   }
         * }
         *
         * @returns {$.Deferred}
         */
        getCurrentLocation: function () {
            return this._transport.sendRequest({
                "path" : "location",
                "method" : "GET"
            });
        },

        /**
         * Return vehicle state:
         *  - moving
         *  - stopped
         *
         * @returns {$.Deferred}
         */
        getVehicleState: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method" : "POST",
                "content": {
                    "type": "getVehicleState"
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content && content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }

    }).extend(events);

});
define('aq/utils',[],function () {
    'use strict';

    return {

        /**
         * Parse a string as JSON. If the JSON is invalid, this function throws
         * a SyntaxError unless the safe option is set.
         *
         * @param {string} json The JSON string
         * @param {function} [reviver] prescribes how the value originally produced by parsing is transformed
         * @param {boolean} [safe=true] True to return null, false to throw an exception
         * @returns {object} returns the Object corresponding to the given JSON text or null
         */
        parseJSON: function (json, reviver, safe) {
            safe = safe !== false;

            try {
                return JSON.parse(json, reviver);
            } catch (e) {
                if (safe === true) {
                    return null;
                }
                throw e;
            }
        },

        /**
         * Convert value to JSON like string
         *
         * @param json {string|boolean|object}
         * @param [replacer] {function}
         * @param [space] {number}
         * @param [safe] {boolean} true by default. suppress any exceptions
         * @returns {json|error} return converted json or throw exception
         */
        toJSON: function (json, replacer, space, safe) {
            space = typeof space !== 'number' ? 2 : space;
            safe = safe !== false;

            try {
                var result = JSON.stringify(json, replacer, space);
                if (result === undefined) {
                    throw new Error('undefined cant be converted to json');
                }
                return result;
            } catch (e) {
                if (safe === true) {
                    return JSON.stringify({});
                }
                throw e;
            }
        },

        /**
         * @param list {Array}
         */
        toObject: function (list) {
            return _.reduce(list, function (memo, val, index) {
                memo[index] = val;
                return memo;
            }, {});
        },

        /**
         * @fixme: This method should not be here because it is not a kind of general purpose util method
         */
        isReportDataEmpty: function(data) {
            return !_.contains(_.map(data, function(value) {
                return isFinite(value) && !_.isArray(value) ? false : _.isEmpty(value);
            }), false);
        },

        /**
         *
         * @returns {string} android || ios
         */
        getPlatform: function () {
            return this.platfrom || this._getPlatform();
        },

        _getPlatform: function () {
            var ios = /iPhone/i;

            this.platfrom = ios.test(window.navigator.userAgent) ? 'ios' : 'android';
            return this.platfrom;
        },

        isEqual: function (a, b) {
            return this.toJSON(a) === this.toJSON(b);
        },

        ellipsis: function (str, length) {
            str = typeof str !== 'string' ? '' : str;
            return str.length > length ? str.substring(0, length).concat('...') : str;
        },
        
        freeze: function (o) {
            return Object.freeze ? this._freeze(o) : o;
        },

        _freeze: function (o) {
            Object.freeze(o);

            Object.getOwnPropertyNames(o).forEach(function (prop) {
                if (o.hasOwnProperty(prop) && o[prop] !== null &&
                    (typeof o[prop] === "object") && !Object.isFrozen(o[prop])) {
                    this._freeze(o[prop]);
                }
            }, this);

            return o;
        },

        /**
         * Check that passed object contain given path
         *
         * @param o {Object}
         * @param p {String}
         */
        resolve: function (o, p) {
            o = Object.prototype.toString.call(o) === "[object Object]" ? o : {};

            var delimiter = ".",
                path = String.prototype.split.call(p || "", delimiter);

            return path.reduce(function (obj, key) {
                return (obj !== undefined && obj !== null) ? obj[key] : obj;
            }, o);
        }

    };
});

/*
*   Track Progress Counter
*
*   This module's creation is related to CV-2314
*   please view the ticket for more details
*
*/

define('aq/api/progressCounter',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        // better not change this
        // we should constraint
        // to 3rd partys tick length
        // which is equal to webkit's
        TICK_LENGTH: 1000,

        _active: false,

        _elapsedTime: 0,

        _totalTime: 0,

        _timer: null,

        init: function () {
        },

        /*
        * Starts the timer
        * @param {
        *           elapsedTime: number,
        *           totalTime: number
        *       }
        */
        start: function(data) {
            this.update(data);
            this.on();
        },

        /*
        * Rest timer to initial values
        * can be used on closing current app
        */
        reset: function() {
            this.off();
            this.setElapsedTime(0);
            this.setTotalTime(0);
        },

        /*
        * Switch timer on
        */
        on: function() {
            this._active = true;
            this.tick();
        },

        /*
        * Switch timer off
        */
        off: function() {
            this._active = false;
            this._killTimer();
        },

        /*
        * Timer handler
        */
        tick: function(){
            if(this._active) {
                if (this._elapsedTime <= this._totalTime) {
                    this._timer = setTimeout(this._onTick.bind(this), this.TICK_LENGTH);
                }
                else {
                    this.off();
                }
            }
        },

        /*
        * Timer tick handler
        */
        _onTick: function() {
            this._elapsedTime++;
            this._killTimer();
            this.tick();
        },

        /*
        * Timer killer
        * prevents several timer to tick
        * at the same time
        */
        _killTimer: function () {
            if (this._timer) {
                clearTimeout(this._timer);
                this._timer = null;
            }
        },

        /*
        * Update the timer
        * @param {
        *           elapsedTime: number,
        *           totalTime: number
        *       }
        */
        update: function(data) {
            this.setElapsedTime(data.elapsedTime);
            this.setTotalTime(data.totalTime);
        },

        /*
        * Elapsed time setter
        */
        setElapsedTime: function(elapsedTime) {
            this._elapsedTime = +elapsedTime || 0;
        },

        /*
        * Total time setter
        */
        setTotalTime: function(totalTime) {
            this._totalTime = +totalTime || 0;
        },

        /*
        * Elapsed time getter
        */
        getElapsedTime: function() {
            return this._elapsedTime <= this._totalTime ?
                this._elapsedTime : this._elapsedTime = this._totalTime;
        },

        /*
        * Total time getter
        */
        getTotalTime: function() {
            return this._totalTime;
        },

        /*
        * Is timer active
        */
        isActive: function() {
            return this._active;
        }
    });
});
define('aq/api/logger',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        /**
         * Indicate which env use to logging:
         * webView to send log messages directly to web view
         * otherwise print messages to js console
         */
        env: 'WEB_VIEW',

        /**
         * Possible values: none, high, med, low
         */
        levels: {
            high: ['debug', 'info', 'log', 'warn', 'error'],
            med: ['log', 'warn', 'error'],
            low: ['warn', 'error'],
            none: []
        },

        /**
         * Available log methods
         */
        loggers: ['debug', 'info', 'log', 'warn', 'error'],

        /**
         * @constructor
         * @param transport {Transport}
         * @param level {string} Logger level
         * @param env {string} Which env use to logging
         * @param prefix {string} Prefix
         */
        init: function (transport, level, env, prefix) {

            this._super(transport);
            this._prefix = prefix || '';
            this.setEnvironment(env);
            this.setLevel(level);

            // init loggers
            this.loggers.forEach(function (logLevel) {
                this[logLevel] = function (data) {
                    return this._log(logLevel, data);
                };
            }, this);
        },

        setLevel: function (level) {
            this.level = this.levels[level] ? level : 'low';
        },

        setEnvironment: function (env) {
            this.env = env;
            this.logger = this.env === 'WEB_VIEW' ? this._sendRequest.bind(this) : function (data, level) {
                window.console[level](this._prefix, data);
            };
        },

        _log: function (logger, data) {
            var level = this.levels[this.level],
                isLoggerTypePresent = level && level.indexOf(logger) > -1;
            return level && isLoggerTypePresent ? this.logger(data, logger) : false;
        },

        /**
         * iOS HAP uses JSLog as a tag for js logs
         * android HAP uses JS_LOG as a tag for js logs
         *
         * @param data
         */
        _sendRequest: function (data) {
            var msg = {};
            msg[this._prefix || 'JS_LOG'] = data;
            return this._transport.sendLogRequest(msg);
        }
    });
});
/* jshint unused:false*/
define('shared/thor_interface/commandControl',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc CommandControl adapter. Responsible for interaction with third party applications.
	 * Used to send commands to third party applications and handle asynchronous messages from them.
	 *
	 * @name CommandControl
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send command to 3rd-party applications
		 *
		 * @name CommandControl#sendCommand
		 * @function
		 * @abstract
		 *
		 * @param  {object} command - Command to 3rd-party app
		 *
		 * @returns {jQuery.Deferred}
		 */
		sendCommand: function (command) {
			throw new Error('not implemented');
		},

		/**
		 * Bind callback function to async event from 3rd-party applications
		 *
		 * @name CommandControl#onAsyncEvent
		 * @function
		 * @abstract
		 *
		 * @param {Function} callback
		 */
		onAsyncEvent: function () {
			throw new Error('not implemented');
		},

		/**
		 * Terminate all current commands to 3rd-party applications for appName if specified or all current commands
		 * May be used when application changes route or shutting down
		 *
		 * @name CommandControl#abortApplicationCommands
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName] - HMI application name
		 */
		abortApplicationCommands: function(){
			throw new Error('not implemented');
		}
	});
});

define('aq/api/commandControl',['shared/thor_interface/commandControl', 'aq/mixins/events'], function (CommandControl, Events) {
    'use strict';

    return CommandControl.extend({

        init: function (transport, options) {
            options = options || {};

            this.appName = options.appName || this.appName;

            // e.g. application/octet-stream, application/json
            this.contentType = options.contentType || this.contentType;

            // e.g. base64
            this.contentTransferEncoding = options.transferEncoding || this.transferEncoding;

            this._initTransport(transport);
        },

        _initTransport: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this.handleNotification);
        },

        /**
         *
         * @param content {Object}
         * @returns {$.Deferred}
         */
        sendCommand: function (content) {
            var headers = {
                "App-Name": this.appName,
                "Content-Type": this.contentType
            };
            if (this.contentTransferEncoding) {
                headers["Content-Transfer-Encoding"] = this.contentTransferEncoding;
            } else {
                headers["Content-Length"] = encodeURI(JSON.stringify(content)).split(/%..|./).length - 1;
            }

            return this._transport.sendRequest({
                path: "meha",
                method: "POST",
                headers: headers,
                content: content
            });
        },

        handleNotification: function () {
            throw new Error('not implemented');
        },

        abortApplicationRequests: function(){
            throw new Error('not implemented');
        }

    }).extend(Events);
});

/* jshint unused:false*/
define('shared/thor_interface/appManager',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc HMI application manager. Used to manage HMI application
	 *
	 * @name AppManager
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Start HMI application
		 *
		 * @name AppManager#startApp
		 * @function
		 * @abstract
		 *
		 * @param {object} params
		 *
		 * @example
		 * {
		 * "appName": "iheartradio",
		 * "notificationType": "launchApp",
		 * "path": "file:///data/data/abq/hup/iheartradio/7.18.0"
		 * }
		 */
		startApp: function () {
			throw new Error('not implemented');
		},

		/**
		 * Close current HMI application
		 *
		 * @name AppManager#closeApp
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		closeApp: function () {
			throw new Error('not implemented');
		},

		/**
		 * Load application policy. If no application name specified current application policy will be fetched
		 *
		 * @name AppManager#loadPolicy
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName]
		 *
		 * @returns {jQuery.Deferred}
		 */
		loadPolicy: function () {
			throw new Error('not implemented');
		},

		/**
		 * Loads application profile. If no application name specified current application profile will be fetched
		 *
		 * @name AppManager#loadProfile
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName]
		 *
		 * @returns {jQuery.Deferred}
		 */
		loadProfile: function () {
			throw new Error('not implemented');
		},

		/**
		 * Switch application
		 *
		 * @name AppManager#switchApp
		 * @function
		 * @abstract
		 *
		 * @param {string} appName
		 *
		 * @return {string} new application name
		 */
		switchApp: function(){
			throw new Error('not implemented');
		},

		/**
		 * Get current running application name
		 *
		 * @name AppManager#getCurrentApplicationName
		 * @function
		 * @abstract
		 *
		 * @return {string} name of current running application
		 */
		getCurrentApplicationName: function(){
			throw new Error('not implemented');
		},

		/**
		 * Set current running application name
		 *
		 * @name AppManager#setCurrentApplicationName
		 * @function
		 * @abstract
		 *
		 * @param {string} appName
		 */
		setCurrentApplicationName: function(){
			throw new Error('not implemented');
		}
	});
});

define('aq/appManager',['shared/thor_interface/appManager', 'aq/eventEmitter'], function (AppManager, EventEmitter) {
    'use strict';

    /**
     * @classdesc HMI application manager. Used to manage HMI application
     *
     * Each application should have next mandatory methods:
     *
     * -> start() (called when application is about started)
     * -> onSuspend() (called when user starts another application, thus current one goes to 'suspended' state)
     * -> onClose() (called when application is about closed, e.g. user presses 'Exit' button, etc)
     *
     */
    return EventEmitter.extend(AppManager).extend({

        events: {
            showHomeScreen: 'showHomeScreen'
        },

        /**
         * apps: {
         *      home: {
         *      status: [active|suspended|closed],
         *      type: [cloud|extension|base],
         *      id: {String}
         * }
         */
        apps: {},

        /**
         * Keep configs of each available HMI app
         */
        appConfigs: {},

        /**
         * @constructor
         *
         * @param options {object}
         */
        init: function (options) {
            this.dic = options.dic;
            this.constants = options.constants;
            this.logger = new (this.dic.get('Logger'))('high', 'WEB_VIEW', 'APP_MANAGER');
            this.translation = options.translation;
            this.currentAppName = this.constants.APP_NAME_MAP.uconnect;
        },

        /**
         * Start HMI application
         *
         * @param {object} params
         *
         * @example
         * {
		 *   "appName": "iheartradio"
		 * }
         */
        startApp: function (params) {
            var self = this,
                appName = params.appName,
                images = self.dic.get('images');

            self.setCurrentApplicationName(appName);
            self.logger.log({'Before app loaded: ': appName});

            // application was never loaded before
            if (!self.apps[appName]) {
                self.loadProfile(appName)
                    .done(function (cfg) {

                        cfg = cfg[0];

                        self.logger.log({'LOADED: ': {
                            appName: appName,
                            version: cfg.version
                        }});

                        var app = self.apps[appName] = require(appName),
                            appImages = cfg.images || {},
                            imageIds;

                        app.appId = cfg.appId;
                        app.cfg = cfg;
                        app.type = cfg.type;

                        app.on('suspend', function () {
                            self.suspendApp(appName);
                        });

                        app.on('close', function () {
                            self.closeApp(appName);
                            self.trigger(self.events.showHomeScreen);
                        });

                        // We have to pre-fill local in-memory storage with ID <-> filePath before starting HMI app
                        imageIds = images.addImageIdsToLocalStore(appImages, app.appId);

                        $.when(self._startApp(app, appName)
                            ).done(function() {
                                images.cacheAppImages(imageIds, app.appId);
                            }.bind(self));

                    })
                    .fail(function (res) {
                        self.logger.error({"Can't load application assets for: ": appName});
                        self.logger.error(res ? res.responseText : 'net::ERR_FILE_NOT_FOUND');
                        self.trigger(self.events.showHomeScreen, true);
                    });

            } else {
                this._startApp(self.apps[appName], appName);
            }
        },

        _startApp: function (app, appName) {
            var returnObj = {};

            this.translation.reloadLocale(appName);
            returnObj = app.start(this.dic);
            app.status = this.constants.APP_STATUS.RUNNING;
            this.logger.log({'Started: ': appName});
            console.log("==============_startApp returnObj:" + returnObj);
            return returnObj;
        },

        /**
         * Close HMI application by name
         *
         * @param {string} appName
         */
        closeApp: function (appName) {
            var app = this.apps[appName || this.getCurrentApplicationName()];
            if (app) {
                if (_.isFunction(app.onClose)) app.onClose();
                app.status = this.constants.APP_STATUS.CLOSED;
            }
            this.logger.log({"closed app: ": appName || this.getCurrentApplicationName()});
        },

        /**
         * Suspend HMI application by name
         *
         * @param appName
         */
        suspendApp: function (appName) {
            var app = this.apps[appName || this.getCurrentApplicationName()];
            if (app) {
                if (_.isFunction(app.onSuspend)) app.onSuspend();
                app.status = this.constants.APP_STATUS.SUSPENDED;
            }
            this.logger.log({"suspended app: ": appName || this.getCurrentApplicationName()});
        },

        destroyApp: function (appName) {
            this.closeApp(appName);

            // explicitly unloading modules and their dependencies
            // so that they can be garbage-collected
            var pattern = new RegExp('^' + appName);
            _.each(require._defined, function (module, name) {
                if (pattern.test(name)) {
                    delete require._defined[name];
                }
            });
            if (this.apps[appName]) {
                this.apps[appName].off();
                this.apps[appName] = {};
                delete this.apps[appName];
            }
        },

        /**
         * Switch application
         *
         * @param {string} appName
         * @param {string} appCategory
         *
         * @return {string} new application name
         */
        switchApp: function (appName, appCategory) {
            this.logger.log({"switchApp: ": appName});

            // suspend current app
            this.suspendApp();

            if (this.getCurrentApplicationName() !== appName) {

                // and if the current application is an audio app
                // and requested to open application is also audio app - stop/close current
                var playingApp = this.isAudioAppPlaying(),
                    isAudioApp = appCategory === 'Music';
                if (playingApp && isAudioApp) this.closeApp(playingApp);
            }

            this.startApp({appName: appName});
        },

        /**
         * Loads application resources (app config, locales and code)
         * If no application name specified current application will be fetched
         *
         * @param {string} [appName]
         *
         * @returns {jQuery.Deferred}
         */
        loadProfile: function (appName) {
            this.logger.log({'Loading: ': appName});

            appName = appName || this.getCurrentApplicationName();

            var path = this.constants.RELATIVE_APP_PATH(appName),
                configFile = this.constants.APP_CONFIG_NAME,
                applicationFile = this.constants.APP_FILE_NAME;

            return $.when(
                // app config
                $.getJSON(path.concat(configFile)),

                // app translation file
                this.translation.initLocale(appName),

                // app code
                this._injectScript(path.concat(applicationFile))
            );
        },

        _injectScript: function (src) {
            var dfd = $.Deferred(),
                token = (+new Date()), // to avoid cache
                script = document.createElement('script');
            script.src = src + '?' + token;
            script.onload = dfd.resolve;
            script.onerror = dfd.reject;
            window.document.head.appendChild(script);
            return dfd.promise();
        },

        /**
         * Get current running application name
         *
         * @return {string} name of current running application
         */
        getCurrentApplicationName: function () {
            return this.currentAppName;
        },

        /**
         * Set current running application name
         *
         * @param {string} appName
         */
        setCurrentApplicationName: function (appName) {
            this.currentAppName = appName;
        },

        getActiveAppId: function () {
            return this.apps[this.currentAppName] && this.apps[this.currentAppName].appId;
        },

        saveImageArchives: function (archivesVersionMap) {
            var images = this.dic.get('images');
            this.logger.info({"saveImageArchives from the map: ": archivesVersionMap});
            images.sendImageArchives(archivesVersionMap);
        },


        getPlatform: function () {
            return this.platform;
        },

        /**
         * setting platform type (vp4 or vp2c)
         * @param platform string
         */
        setPlatform: function (platform) {
            this.platform = platform;
        },

        /**
         * start application on IOS appSwitch failure
         */
        startAppAfterAppSwitchFailure: function () {
            this.startApp({appName: this.getCurrentApplicationName()});
        },

        /**
         *
         * @returns {String} playing application name
         */
        isAudioAppPlaying: function () {
            var appNames = _.keys(this.apps),
                apps = this.apps,
                closed = this.constants.APP_STATUS.CLOSED;
            return _.find(appNames, function (appName) {
                return apps[appName].type === 'extension' && apps[appName].status !== closed;
            });
        },

        /**
         * NOTE: `this` is an instance of appList here!
         * @param data {Object}
         * 
         * @return void
         */
        updateAppConfigs: function (data) {
            if (data && data.state === 'connected') {
                // Only load config files for all application if it is the very first connection
                if (_.isEqual(this.appManager.appConfigs, {})) {
                    this.loadAppConfigs();
                }
            }
        }
    });

});

/**
 * iOS only application container module
 */

define('aq/api/hap/appContainer',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (transport) {
            this._super(transport);
        },

        /**
         *
         * @returns {$.Deferred}
         */
        getApplicationContainerName: function () {
            return this._transport.sendRequest({
                "path": "appName",
                "method": "GET"
            }).then(function (content) {
                return content.data.appName;
            });
        },

        /**
         * send notification to HU to show loading screen while bluetooth is off
         * @returns {$.Deferred}
         */
        sendAppSwitchEvent: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "appSwitch"
                }
            });
        },


        /**
         *
         * @param appContainerName {String}
         * @returns {$.Deferred}
         */
        switchApplicationContainerTo: function (appContainerName) {
            return this._transport.sendRequest({
                "path" : "appSwitch",
                "method" : "POST",
                "content": {
                    "appName" : appContainerName
                }
            });
        }
    });
});
/**
 * Translation module
 *
 * @export $.t
 */
define('aq/translation',['shared/utils/class'], function (Class) {
    'use strict';

    var lang = 'en-us',
        fallbackLang = lang,

        localesBaseFolder = 'locales',
        inMovingLocalesFolder = localesBaseFolder + '/' + 'moving',
        localesFolder = localesBaseFolder;

    return Class.extend({

        init: function (profile, constants, navigation) {

            /**
             * collection for loaded locales in format
             *
             * {
             *   appName: locale,
             *   ...
             * }
             */
            this.loaded = {};
            this.currAppName = false;
            
            this.config = constants;
            this.profile = profile;
            this.navigation = navigation;

            this.profile.on(this.profile.events.headUnitLanguage, this.onLanguageChanged, this);
            this.navigation.on(this.navigation.events.vehicleState, this.onVehicleStateChanged, this);


            // fetch language and vehicle state on head unit connection
            this.profile.on(this.profile.events.appModeStateChange, function (response) {
                if (response.data.state === 'start') {
                    this.navigation.getVehicleState();
                    this.profile.getLanguage();
                }
            }.bind(this));

            // and in case if page was reloaded due to update - fetch language and vehicle state immediately
            this.navigation.getVehicleState();
            this.profile.getLanguage();

            //init AQ locale for OEM app

        },

        _setLanguage: function (language) {
            lang = language;
        },

        _setLocalesFolder: function (state) {
            var isMoving = state === this.navigation.vehicleStates.moving;
            localesFolder = isMoving ? inMovingLocalesFolder : localesBaseFolder;
        },

        getLanguage: function () {
            return lang;
        },

        getLocalesFolder: function () {
            return localesFolder;
        },

        onVehicleStateChanged: function (data) {
            this._setLocalesFolder(data.state);
            _.each(this.loaded, function (locale, appName) {
                this.initLocale(appName);
            }.bind(this));
        },

        onLanguageChanged: function (response) {
            var code = response.data.code;
            this._setLanguage(code);
            _.each(this.loaded, function (locale, appName) {
                this.initLocale(appName);
            }.bind(this));
        },

        /**
         * Download translation file according to current language and application name
         * then store it locally and init $.esperanto
         * @param appName
         * @returns {$.Deferred}
         */
        initLocale: function (appName) {
            var path = this.config.RELATIVE_APP_PATH(appName),
                dfd = $.Deferred(),
                options = {
                    lang: lang,
                    fallbackLang: lang,
                    dicoPath: path + this.getLocalesFolder()
                };

            var onSuccess = function (data) {
                this.loaded[appName] = data;

                if(this.currAppName){
                    this.reloadLocale(this.currAppName);
                }
                dfd.resolve();
            }.bind(this);

            $.jsperanto.init(function () {}, options)
                .done(onSuccess)
                .fail(function () {
                    // try to use fallback lang
                    $.jsperanto.init(function () {
                        var isSuccess = $.jsperanto.lang();
                        return isSuccess ? dfd.resolve() : dfd.reject();
                    }, _.extend(options, {lang: fallbackLang})).done(onSuccess);
                });

            return dfd.promise();
        },

        /**
         * Init $.esperanto with the translation file according to given appName and current language
         * If translation file not loaded yet - load it
         * @param appName
         * @returns {*}
         */
        reloadLocale: function (appName) {
            this.currAppName = appName;
            return this.loaded[appName] ? $.jsperanto.init(function () {}, {
                dictionary: this.loaded[appName]
            }) : this.initLocale(appName);
        }

    });

});

/**
 *
 */
define('aq/images',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (storage, screen, profile, constants) {
            var self = this;

            this.storage = storage;
            this.screen = screen;
            this.constants = constants;

            var configLoaded = $.getJSON(this.constants.APP_CONFIG_NAME);

            configLoaded
                .done(function(response) {
                    var sharedImages = response && response.images;
                    self.sharedImageIds = self.addImageIdsToLocalStore(sharedImages, "00");
                })
                //TODO: Log error message
                .fail();

            // collection of cached images
            // <appId>: {
            //   hash: <String>
            //   progress: <Deferred>
            // }
            this.apps = {};

            // on initial head unit connection cache aq shared images
            profile.on(profile.events.appModeStateChange, function (response) {
                if (response.data.state === 'start') {
                    this.cacheSharedImages();
                }
            }.bind(this));
        },

        /**
         *  key - value map
         *  key - zipId (assets_zipId)
         *  value - appName assosiated with zipId
         */
        zipIdsMap: {},

        cacheAppImagesByApps: function (apps, index) {
            var app = apps[index],
                self = this;

            if (app) {
                var appName = app.appName.toLowerCase(),
                    path = self.constants.RELATIVE_APP_PATH(appName),
                    configFile = self.constants.APP_CONFIG_NAME;

                $.getJSON(path.concat(configFile))
                    .done(function (cfg) {
                        var appImages = cfg.images || {},
                            appId = cfg.appId;

                        self.cacheAppImages(appImages, appId)
                            .always(self.cacheAppImagesByApps.bind(self, apps, index + 1));

                    })
                    .fail(self.cacheAppImagesByApps.bind(self, apps, index + 1));
            }
        },

        cacheAppImages: function (imageIds, appId) {
            var app = this.apps[appId] || {},
                isImagesChanged = JSON.stringify(imageIds) !== app.hash,
                isImageCacheFailed = app.progress ? app.progress.state() === 'rejected' : false,
                needToCache = isImagesChanged || isImageCacheFailed;

            return needToCache ? this.cacheImages(imageIds, appId) : $.when(app.progress);
        },

        sendImageArchives: function (zipIdsMap) {
            if (!_.isEqual(this.zipIdsMap, zipIdsMap)) {
                this.zipIdsMap = zipIdsMap;
                this.screen.saveZip(zipIdsMap);
            }
        },

        /**
         * @returns {$.Deferred}
         */
        cacheSharedImages: function () {
            return this.screen.cacheImages(this.sharedImageIds, "00");
        },

        /**
         *
         * Cache images by application id
         *
         * @param images {List} Collection of imageIds connected to the full image path
         * @param appId {String}
         * @returns {$.Deferred}
         */
        cacheImages: function (imageIds, appId) {
            this.apps[appId] = {
                hash: JSON.stringify(imageIds),
                progress: this.screen.cacheImages(imageIds)
            };
            return this.apps[appId].progress;
        },

        /**
         * Add image
         * @param images {Object} Collection of imageIds connected to the full image path
         * @param appId {String}
         * @returns {Array} imageIds in the following format: <appID><imgID><imgVer>
         */
        addImageIdsToLocalStore: function (images, appId) {
            var ids = [],
                imgId;

            _.each(images, function (url, id) {
                imgId = parseInt(appId + id, 10);
                this.storage.addLocalImageId(url, imgId);
                ids.push(imgId);
            }, this);

            return ids;
        }
    });

});

define('aq/constants',['aq/utils'], function (utils) {
    'use strict';

    /**
     * @const
     */
    return utils.freeze({

        APP_STATUS: {
            RUNNING: "running",
            CLOSED: "closed",
            SUSPENDED: "suspended"
        },

        PLATFORM: {
            VP2C : 'vp2c',
            VP4 : 'vp4'
        },

        IMAGE_ARCHIVE: {
            ZIP: 'zip',
            JAR: 'jar'
        },

        RELATIVE_APP_PATH: function (appName) {
            return "../<appName>/".replace(/<appName>/, appName);
        },

        APP_FILE_NAME: "app.js",
        APP_CONFIG_NAME: "app.json",

        /**
         * <appName>: <handsetAppName>
         *
         * appName - hmi app name
         * handsetAppName - handset app name that is used for appLaunch and meha messages
         */
        APP_NAME_MAP: {
            pandora : 'pandora',
            slacker : 'com.slacker.radio.Slacker',
            iheartradio : 'com.clearchannel.iheartradio',
            uconnect: 'uconnect'
        },

        APPS_GRAMMAR: {
            pandora: [
                "#'lOnt&S_p@n.'dO.R+$#", // "Launch Pandora"
                "#'lOnt&S_p@n.'dO.R+$_'va&I.$_'mo&U.b$l#", // "Launch Pandora Via Mobile"
                "#'o&U.p$n_p@n.'dO.R+$#", // "Open Pandora"
                "#'o&U.p$n_p@n.'dO.R+$_'va&I.$_'mo&U.b$l#" // "Open Pandora Via Mobile"
            ],
            slacker: [
                "#'lOnt&S_'sl@.k$R+#", // "Launch Slacker"
                "#'lOnt&S_'sl@.k$R+_'R+e&I.di.o&U#", // "Launch Slacker Radio"
                "#'lOnt&S_'sl@.k$R+_'va&I.$_'mo&U.b$l#", // "Launch Slacker Via Mobile"
                "#'o&U.p$n_'sl@.k$R+#", //  "Open Slacker"
                "#'o&U.p$n_'sl@.k$R+_'R+e&I.di.o&U#", // "Open Slacker Radio"
                "#'o&U.p$n_'sl@.k$R+_'va&I.$_'mo&U.b$l#" // "Open Slacker Via Mobile"
            ],
            iheartradio: [
                //old phonems
                "#'lOnt&S_'a&I.h$R+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Launch IHeartRadio Via Mobile"
                "#'lOnt&S_'a&I.h$R+t#", // "Launch iheart"
                "#'lOnt&S_'a&I.h$R+t_'va&I.$_'mo&U.b$l#", // "Launch iheart via Mobile"
                "#'lOnt&S_'2a&I.h$R+.'tR+e&I.di.o&U#", // "Launch iheartradio"
                "#'o&U.p$n_'a&I.'hAR+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Open iHeartRadio Via Mobile"
                "#'o&U.p$n_'a&I.h$R+t#", // "Open iheart"
                "#'o&U.p$n_'a&I.h$R+t_'va&I.$_'mo&U.b$l#", // "Open iheart via Mobile"
                "#'o&U.p$n_'2a&I.h$R+.'tR+e&I.di.o&U#", // "Open iheartradio"
                //new phonems added (according to cv-1961)
                "#'lOnt&S_'a&I.h$R+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Launch IHeartRadio Via Mobile"
                "#'lOnt&S_'a&I_'hAR+t#", // "Launch iheart"
                "#'lOnt&S_'a&I_'hAR+t_'va&I.$_'mo&U.b$l#", // "Launch iheart via Mobile"
                "#'l@nt&S_'a&I_'hAR+t_'R+e&I.di.o&U#", // "Launch iheartradio"
                "#'o&U.p$n_'a&I_'hAR+t_'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Open iHeartRadio Via Mobile"
                "#'o&U.p$n_'a&I_'hAR+t#", // "Open iheart"
                "#'o&U.p$n_'a&I_'hAR+t_'va&I.$_'mo&U.b$l#", // "Open iheart via Mobile"
                "#'o&U.p$n_'a&I_'hAR+t_'R+e&I.di.o&U#" // "Open iheartradio"
            ]
        },

        HARD_KEYS: {
            "h1": "back",
            "h2": "seekUp",
            "h3": "seekDown",
            "h4": "preset",
            "h5": "scroll",
            "h6": "unmute",
            "h7": "mute",
            "h8": "enter"
        },

        HARD_KEY_NAMES: {
            back: "back",
            seekUp: "seekUp",
            seekDown: "seekDown",
            preset: "preset",
            scroll: "scroll",
            unmute: "unmute",
            mute: "mute",
            enter: "enter"
        },

        /**
         * app switch btn (typeOfScreen value in applicationModeStateChange)
         */
        SWITCH_BTN_TYPES: {
            hard_btn: true,
            soft_btn: false
        },

        APP_LIST_COLOR: {
            VP2C: {
                uconnect: '#80b5ff',
                pandora: '#00adef',
                iheartradio: '#900e1a',
                slacker: '#cd5718'
            },
            VP4: {
                uconnect: 0x80b5ff,
                pandora: 0x00adef,
                iheartradio: 0x900e1a,
                slacker: 0xcd5718,
                aha: 0xb8741b
            }
        },

        URL: {
            filePath : "file:///",
            androidPath : "file:///HMI_ROOT/www/"
        },

        EMPTY_IMAGE_ID: 0

    });
});

define('aq/api/hap/fileManager',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (options) {
            this._super(options.transport);
            this.huMetaData = options.huMetaData;
            this._utils = options.transport._utils;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'FILE_MANAGER');
        },

        /**
         *write and submit data to the service on disconnection
         */
        submitReportFile: function (options) {
            var reportData = options.reportData,
                reportName = options.reportName,
                fileName = options.fileName,
                pathToSubmit = options.pathToSubmit,
                uuid = options.uuid,
                handsetProfile = options.handsetProfile;

            if (this._utils.isReportDataEmpty(reportData)) {
                return;
            }

            // 1. creates a file
            // 2. writes data to it
            // 3. submits it to pathToSubmit
            return this.createFile({
                    fileName:   fileName,
                    reportName: reportName
                }).done(
                    function () {
                        this.writeToFile({
                            fileName: fileName,
                            data:     reportData
                        }).done(
                            function() {
                                this.submitFile({
                                    fileName:       fileName,
                                    handsetProfile: handsetProfile,
                                    pathToSubmit:   pathToSubmit,
                                    uuid: uuid
                                });
                            }.bind(this));
                    }.bind(this));
        },

        /**
         * not used
         * checking if file is empty
         * @returns jQuery.Deferred
         */
        isFileEmpty: function (options) {
            var fileName = options.fileName;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "isEmpty"
                }
            }).done(function (data) {
                    var isEmpty = data.data && data.data.isEmpty;
                    this.logger.log({'File is empty: ': fileName});
                    this.logger.log({'File is empty: ' : isEmpty});
                }.bind(this))
                .fail(function () {
                    this.logger.log({'File is not empty: ': fileName});
                }.bind(this));
        },

        /**
         * creating file to write into
         * @returns jQuery.Deferred
         */
        createFile: function (options) {
            var fileName = options.fileName;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "create"
                }
            }).done(function () {
                this.logger.log({'File created: ': fileName});
            }.bind(this))
            .fail(function () {
                this.logger.log({'File not created: ': fileName});
            }.bind(this));
        },

        /**
         * writes data to file
         * @returns {jqXHR|jQuery.Deferred|}
         */
        writeToFile: function (options) {
            var fileName = options.fileName,
                data = options.data;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "write",
                    "data": data
                }
            }).done(function () {
                this.logger.log({'Report Data written: ': data});
            }.bind(this)).fail(function () {
                this.logger.log({'Report Data not written: ': data});
            }.bind(this));
        },

        /**
         * removing report file
         * @returns jQuery.Deferred
         */
        deleteFile: function (fileName) {
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "delete"
                }
            }).done(function () {
                this.logger.log({'Report file removed: ': fileName});
            }.bind(this));
        },

        /**
         * submit data usage report to service and remove report file in both success and fail cases
         * url - string (url link for report submission)
         * @returns jQuery.Deferred
         */
        submitFile: function (options) {
            var fileName = options.fileName,
                pathToSubmit = options.pathToSubmit,
                uuid = options.uuid,
                handsetProfile = options.handsetProfile,
                hostToSubmit = handsetProfile.backendInfo && handsetProfile.backendInfo.clientGatewayUrl,
                hostLength;

            //TODO: fix url on IOS HAP
            if (hostToSubmit) {
                hostLength = hostToSubmit.length;
                if (hostToSubmit[hostLength - 1] !=='/') {
                    hostToSubmit +='/';
                }
                hostToSubmit = hostToSubmit + pathToSubmit + uuid.v1() + "?client-type=phone";
            } else {
                this.logger.log({'URL FOR REPORT SUBMISION NOT VALID':''});
                this.logger.log({'Report data not submitted, because URL is not valid ': hostToSubmit});
                return;
            }

            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "put",
                    "data" : hostToSubmit
                }
            }).done(function () {
                this.logger.log({'Report data submitted: ': hostToSubmit});
            }.bind(this)).fail(function () {
                this.logger.log({'Report data not submitted': hostToSubmit});
            }.bind(this)).always(function () {
                //todo uncoment file deletion (tmp for debugging purposes)
                //this.deleteFile(fileName);
            }.bind(this));
        }

    });
});

define('aq/api/hap/fileReporter',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        reports: {},

        init: function (options) {
            this._super(options.initData.transport);
            this.huMetaData = options.initData.huMetaData;
            this.logger = new options.initData.Logger('high', 'WEB_VIEW', 'FILE_REPORTER');
            try {
                this.reports = this._initReports(options.reports, options.initData);
            }
            catch (err) {
                throw new Error(err.stack);
            }

            this.listenTo(
                this.huMetaData,
                this.huMetaData.events.readyToSubmitReport,
                this.submitReportFiles,
                this);
        },

        _initReports: function(reports, initData) {
            for(var report in reports) {
                if(reports.hasOwnProperty(report)) {
                    reports[report] = new reports[report](initData);
                }
            }

            return reports;
        },

        /**
         *write and submit data to the service on disconnection
         */
        submitReportFiles: function (reportId) {
            if (this.reports.hasOwnProperty(reportId)) {
                this.reports[reportId].submitReportFile();
            }
        }
    });
});
define('aq/api/hap/baseReport',['aq/api/base'], function (Base) {
    'use strict';
    // require uuid module
    var uuid = require('uuid');

    return Base.extend({
        /**
         * name of the report file
         */
        _fileName: null,

        /**
         * report file name prefix
         */
        _reportName: 'baseReport_',

        /**
         * url to submit file to
         */
        _pathToSubmit: null,

        /**
         * data to report
         */
        _reportData: [],

        /**
        * corresponding to current report metaReporter's name
        */
        _metaReporterName: null,

        /**
        * corresponding to current report metaReporter
        */
        _metaReporter: null,

        init: function (options) {
            this.uuid = uuid;
            this._super(options.transport);
            this.huMetaData = options.huMetaData;
            this.fileManager = options.fileManager;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'REPORT', this._reportName);

            this._setMetaReporter();
        },


        /**
         * check if data is redy to be submitted (data is empty while running emulator and pressing F5,
         * bluetooth reconnection needed to trigger headUnitConnectionState event )
         * @returns {boolean}
         */
        reportIsReady: function () {
            throw new Error('[BaseReport] ready check is not implemented');
        },

        /**
         * storing data to the usageReport object
         * @param appName
         */
        writeReport: function () {
            throw new Error('[BaseReport] writing is not implemented');
        },

        submitReportFile:function () {
            if (this.reportIsReady()) {
                var defferedSubmit = this.fileManager.submitReportFile(this._getSubmissionReportData());
                if (defferedSubmit) {
                    defferedSubmit.always(this._clearReportData.bind(this));
                }
            }
        },

        _setMetaReporter: function() {
            if (this.huMetaData.metaReporters.hasOwnProperty(this._metaReporterName)) {
                this._metaReporter = this.huMetaData.metaReporters[this._metaReporterName];
            }
            else {
                throw new ReferenceError(
                    "[BaseReport] check MetaReportes names - there's no such MetaReporter: " +
                    this._metaReporterName
                    );
            }
        },

        _getSubmissionReportData: function() {
            this._fileName = 'report_' + this._reportName + new Date().getTime().toString();

            return {
                reportData:     this.getReportData(),
                reportName:     this._reportName,
                fileName:       this._fileName,
                pathToSubmit:   this._pathToSubmit,
                uuid:           this.uuid,
                handsetProfile: this._metaReporter.getHandsetProfile()
            };
        },

        getReportData: function() {
            throw new Error('[BaseReport] get_report_data is not implemented');
        },

        _clearReportData: function() {
            throw new Error('[BaseReport] clearing_data is not implemented');
        }
    });
});
define('aq/api/hap/reports/firstUsageReport', ['aq/api/hap/baseReport'], function (BaseReport) {
    'use strict';

    return BaseReport.extend({
        /**
         * name of the report file
         */
        _fileName:         null,

        /**
         * report file name prefix
         */
        _reportName:       'firstUsage_',

        /**
         * url to submit file to
         */
        _pathToSubmit:     'mip_services/core/api/1.0/appusage/',

        /**
         * data to report
         */
        _reportData: {
            usageReport: []
        },

        /**
        * corresponding to current report metaReporter's name
        */
        _metaReporterName: 'firstUsageMetaReporter',
        
        /**
        * corresponding to current report metaReporter
        */
        _metaReporter: null,

        init: function(options) {
            this._super(options);
        },
        /**
         * check if data is ready to be submitted (data is empty while running emulator and pressing F5,
         * bluetooth reconnection needed to trigger headUnitConnectionState event )
         * @returns {boolean}
         */
        reportIsReady: function () {
            return !_.isNull(this._metaReporter.getHuInfo()) && !_.isNull(this._metaReporter.getHandsetProfile());
        },

        /**
         * storing data to the usageReport object
         * @param appName
         */
        writeReport: function (appName) {
            this._reportData.usageReport.push(this._metaReporter.generateReportData(appName));
        },

        getReportData: function() {
            return this._reportData;
        },

        _clearReportData: function() {
            this._reportData.usageReport = [];
        }
    });
});
define('aq/api/hap/reports/idcEventsReport', ['aq/api/hap/baseReport'], function (BaseReport) {
    'use strict';

    return BaseReport.extend({
        /**
         * name of the report file
         */
        _fileName:         null,

        /**
         * report file name prefix
         */
        _reportName:       'idcEvents_',

        /**
         * url to submit file to
         */
        _pathToSubmit:     'mip_services/core/api/1.0/miscellaneous/file/',

        /**
         * data to report
         */
        _reportData: {
            events: []
        },

        /**
        * corresponding to current report metaReporter's name
        */
        _metaReporterName: 'idcEventsMetaReporter',
        
        /**
        * corresponding to current report metaReporter
        */
        _metaReporter: null,

        init: function(options) {
            this._super(options);

            this.listenTo(
                this._metaReporter,
                this._metaReporter.events.idcEventsDataUpdated,
                this.writeReport,
                this);
        },
        /**
         * check if data is ready to be submitted (data is empty while running emulator and pressing F5,
         * bluetooth reconnection needed to trigger headUnitConnectionState event )
         * @returns {boolean}
         */
        reportIsReady: function () {
            return !_.isNull(this._metaReporter.getHuInfo()) && !_.isNull(this._metaReporter.getHandsetProfile());
        },

        /**
         * storing data to the usageReport object
         *
         */
        writeReport: function () {
            this._reportData = this._metaReporter.generateReportData();
        },

        getReportData: function() {
            return this._reportData;
        },

        _clearReportData: function() {
            this._reportData.events = [];
            this._metaReporter._resetMetaData();
        }
    });
});
define('aq/api/hu/reportMetadata',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            'readyToSubmitReport' : 'readyToSubmitReport'
        },

        metaReporters: null,

        init: function (options) {
            this._super(options.initData.transport);
            this.metaReporters = options.metaReporters;
            this.logger = new options.initData.Logger('high', 'WEB_VIEW', 'METAREPORT MANAGER');
            this.listenTo(this, this.events.headUnitConnectionState, this.onConnectionStateChange);
            try {
                this.metaReporters = this._initMetaReporters(this.metaReporters, options.initData);
            }
            catch (err) {
                throw new Error(err.stack);
            }
        },

        _initMetaReporters: function(metaReports, initData) {
            for(var metaReport in metaReports) {
                if(metaReports.hasOwnProperty(metaReport)) {
                    metaReports[metaReport] = new metaReports[metaReport](
                        initData.transport,
                        initData.controls,
                        initData.appManager
                    );
                    this.listenTo(metaReports[metaReport], this.events.readyToSubmitReport, this.readyToSubmitReport);
                }
            }

            return metaReports;
        },

        readyToSubmitReport: function(reportData) {
            this.trigger(this.events.readyToSubmitReport, reportData);
        }
    });
});
define('aq/api/hu/baseMetaReporter',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            'headUnitConnectionState':  'headUnitConnectionState',
            'readyToSubmitReport':      'readyToSubmitReport',
            'idcEventsDataUpdated':     'idcEventsDataUpdated',
            'locationDataUpdated':      'locationDataUpdated'
        },

        _huState: {
            connected:    'connected',
            disconnected: 'disconnected'
        },

        /**
         * headUnitInfo (on headUnitConnectionState event)
         */
        _huInfo:            null,

        /**
         * handsetProfile
         */
        _handsetProfile:    null,

        /**
         * device location
         */
        _location:    null,

        /**
         * data to report
         */
        _metaData:          null,

        /**
         * HAP api_path to get _metaData
         */
        _apiPath:           null,

        /**
         * id of corresponding report module
         */
        _reportId:          "baseReport",

        /**
         * bluetooth connection state
         */
        _connectionsState:  null,

        _utils: null,

        init: function (transport) {
            this._super(transport);
            this._utils = transport._utils;
            this.listenTo(this, this.events.headUnitConnectionState, this.onConnectionStateChange);

            this._getHandsetProfile();
            this._getLocation();
        },

        getHuInfo: function () {
            return this._huInfo;
        },

        getHandsetProfile: function () {
            return this._handsetProfile;
        },

        getLocation: function () {
            return this._location;
        },

        /**
         * report data to submit,
         *data {
         *  vin: "vin",
         *  countryCode: "countryCode",
         *  huType: "huType",
         *  huId: "huId",
         *  mipId: "mipId",
         *  appName: "appName",
         *  launchTime: "Date ISO standart"
         * }
         */
        generateReportData: function () {
            throw new Error('[BaseReport] writing is not implemented');
        },

        resetMetaData: function() {
            throw new Error('[BaseReport] writing is not implemented');
        },

        /**
         * set HU info on connectionState === connected
         * @param huInfo
         * {
         *    data: {
         *      headUnitInfo: "key:val, key: val",
         *
         *    state: "connected" or "disconnected"
         *    }
         * }
         * @private
         */
        _setHUInfo: function (huInfo) {
            if (huInfo.state === this._huState.connected && huInfo.headUnitInfo) {
                this._huInfo = huInfo.headUnitInfo;
                this._getHandsetProfile();
            }
        },

        _getMetaData: function() {
            throw new Error('[BaseReport] writing is not implemented');
        },

        _getHandsetProfile: function () {
            return this._transport.sendRequest({
                "path": 'handsetProfile',
                "method": "GET"
            }).done(function (responseData) {
                //TODO: fix ios handsetProfile on IOS HAP
                if (responseData.data) {
                    this._handsetProfile = responseData.data;
                } else {
                    this._handsetProfile = responseData;
                }
            }.bind(this));
        },

        _getLocation: function() {
            return this._transport.sendRequest({
                "path": 'location',
                "method": "GET"
            }).done(function (responseData) {

                if (responseData.data) {
                    this._location = responseData.data;
                } else {
                    this._location = responseData;
                }
            }.bind(this));
        },

        /**
         * Handler listening to "headUnitConnectionState" event,
         * e.g. "state":"connected"
         * 
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * @example
         * <pre>
         * "headUnitInfo":{
         *      "hupPlatformVersion":"1.0.0",
         *      "vehicleMake":"10",
         *      "headUnitType":"VP4_6_5",
         *      "vin":"1C6RR6MT1DS1031UC",
         *      "hupPlatformName":"VP4_6_5",
         *      "huPartNumber":"735601023 ",
         *      "headUnitSerialNumber":"T00BE351390163",
         *      "huFirmwareVersion":"-1.-1.-1"}
         *  }
         *  </pre>
         *
         * TODO: HUP has an issue of sending disconnected state before connected on connecting device.
         *       report this to HUP team.
         *
         *  @return void
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            if (this._utils.isReportDataEmpty(this._handsetProfile)) {
                this._getHandsetProfile();
            }
        },

        _onNotification: function (content) {
            var notificationName = content.type;
            if (notificationName) {
                if (this.events[notificationName]) {
                    this.trigger(this.events[notificationName], content.data);
                }
            }
        }
    });
});

define('aq/api/hu/metaReporters/firstUsageMetaReporter',['aq/api/hu/baseMetaReporter'], function (BaseMetaReporter) {
    'use strict';

    return BaseMetaReporter.extend({

        /**
         * HAP api_path to get _metaData
         */
        _apiPath:   'handsetProfile',

        /**
         * id of corresponding report module
         */
        _reportId:  'firstUsageReport',

        /**
         * handsetProfile
         */
        _handsetProfile: null,

        init: function (transport) {
            this._super(transport);
        },

        /**
         * report data to submit,
         *data {
         *  vin: "vin",
         *  countryCode: "countryCode",
         *  huType: "huType",
         *  huId: "huId",
         *  mipId: "mipId",
         *  appName: "appName",
         *  launchTime: "Date ISO standart"
         * }
         */
        generateReportData: function (appName) {
            var userInfo = this._handsetProfile && this._handsetProfile.userInfo,
                handsetInfo = this._handsetProfile && this._handsetProfile.handsetInfo,
                mipId = userInfo && userInfo.mipId,
                country = handsetInfo && handsetInfo.oemAppCountry,
                huType = this._huInfo && this._huInfo.headUnitType,
                huId = this._huInfo && this._huInfo.headUnitSerialNumber,
                vin = this._huInfo && this._huInfo.vin;

            return {
                countryCode: country,
                appName: appName,
                huType: huType,
                huId: huId,
                launchTime: new Date().toISOString(),
                mipId: mipId,
                vin: vin
            };
        },

        _getMetaData: function () {
            return this._transport.sendRequest({
                "path": this._apiPath,
                "method": "GET"
            }).done(function (responseData) {
                //TODO: fix ios handsetProfile on IOS HAP
                if (responseData.data) {
                    this._handsetProfile = responseData.data;
                } else {
                    this._handsetProfile = responseData;
                }

                //submit report on disconnected state
                if (this._connectionsState && this._connectionsState === this._huState.disconnected) {
                    this.trigger(this.events.readyToSubmitReport, this._reportId);
                }
            }.bind(this));
        },

        /**
         *
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * }
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            //submit report on disconnected state
            if (this._connectionsState === this._huState.disconnected) {
                this.trigger(this.events.readyToSubmitReport, this._reportId);
            }
        }
    });
});
define('aq/api/hu/metaReporters/idcEventsMetaReporter',['aq/api/hu/baseMetaReporter'], function (BaseMetaReporter) {
    'use strict';

    return BaseMetaReporter.extend({

        /**
         * data to report
         */
        _metaData: {
            events: []
        },

        _connectionEventType: {
            connected: 'headUnitConnect',
            disconnected: 'headUnitDisconnect'
        },

        /**
         * HAP api_path to get _metaData
         */
        _apiPath: "idcEvents",

        /**
         * id of corresponding report module
         */
        _reportId: "idcEventsReport",

        /**
         * handsetProfile
         */
        _handsetProfile: null,

        init: function (transport, controls, appManager) {
            this._super(transport);
            this.controls = controls;
            this.appManager = appManager;
            this.listenTo(this.controls, this.controls.events.soft, this.processSoftButtonEvent);
        },

        processSoftButtonEvent: function (data) {
            if (data.content) {
                var buttonName = data.button || data.action;
                var eventObject = {
                    time: new Date().toISOString(),
                    type: 'appEvent',
                    data: {
                        appName: this.appManager.getCurrentApplicationName(),
                        appVersion: 'version',
                        appEventType: 'softButtonPressed',
                        appEventDetails: buttonName
                    }
                };
                this._metaData.events.push(eventObject);
            }
        },

        processConnectionStateEvent: function () {
            //todo vehicleInfo, profileInfo
            this._metaData.events.push({
                time:        new Date().toISOString(),
                type:        this._connectionEventType[this._connectionsState],
                location:    this.getLocation(),
                handsetInfo: this.getHandsetProfile(),
                huInfo:      this.getHuInfo(),
                //TODO: vehicleInfo: this.getVehicleInfo(), - there's no info in onConnectionsStateChange data
                //TODO: profileInfo: this.getProfileInfo(), - TBD
            });
        },

        /**
         * generate idcEvents report
         * @return events 
         * [
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    },
         *
         *    ...
         *
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    }
         * ]
         */
        generateReportData: function () {
            return this._metaData;
        },

        resetMetaData: function() {
            this._metaData.events = [];
        },

        _getMetaData: function () {
            var bufferedIdcEventsLength = this._metaData.events.length;
            
            this._isReceivingIdcEvents = true;
            return this._transport.sendRequest({
                "path": this._apiPath,
                "method": "GET"
            }).done(function (responseData) {
                this._setIdcEvents(responseData.data.events);
                this._isReceivingIdcEvents = false;

                if(bufferedIdcEventsLength !== this._metaData.events.length) {
                    this.trigger(this.events.idcEventsDataUpdated);
                }

                //submit report on disconnected state
                if (this._connectionsState && this._connectionsState === this._huState.disconnected) {
                    this.trigger(this.events.readyToSubmitReport, this._reportId);
                }
            }.bind(this));
        },

        /**
         * set idcEvents info on every notification and uniqueness check
         * @param events 
         * [
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    },
         *
         *    ...
         *
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    }
         * ]
         * @private
         */
        _setIdcEvents: function(events) {
            return this._metaData.events = _.uniq(
                    this._metaData.events.concat(events),
                    function(item) {
                        return JSON.stringify(item);
                    }
                );
        },

        _resetMetaData:function() {
            this._metaData.events = [];
        },

        /**
         *
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * }
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            this.processConnectionStateEvent();
            //submit report on disconnected state if it is not empty
            if (!this._utils.isReportDataEmpty(this._metaData) &&
                this._connectionsState === this._huState.disconnected) {
                this.trigger(this.events.idcEventsDataUpdated);
                this.trigger(this.events.readyToSubmitReport, this._reportId);
            }
        }
    });
});
/* jshint unused:false*/
define('shared/thor_interface/profile',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Access layer for fetching HUP data and back-end HMI settings
	 *
	 * @todo Profile interface may be extended by more partial HUP data fetching functions like language info
	 *
	 * @name Profile
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Get all HUP information: HMI applications list, statuses e.t.c.
		 * Contents of response is platform-dependent
		 *
		 * @name Profile#getHupInfo
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		getHupInfo: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get units of measurement
		 * Contents of response has to be
		 *  {
		 *      speedUnit: 'MPH'(or KMH),
		 *      tempUnit: 'F'(or C)
		 *  }
		 *
		 * @name Profile#getUnitsOfMeasurement
		 * @function
		 * @abstract
		 *
		 * @returns {object}
		 */
		getUnitsOfMeasurement: function () {
			throw new Error('not implemented');
		}
	});
});

define('aq/api/hap/profile',['shared/thor_interface/profile', 'aq/api/base'], function (Profile, Base) {
    'use strict';

    return Profile.extend(Base.extend({

        events: {
            appModeStateChange: 'appModeState:change',
            profileStateChange: 'profileState:change',
            choreoError: 'choreo:error',
            applicationListResponse: 'applicationList:response',
            clientGatewayInfoResponse: 'clientGatewayInfo:response',
            headUnitLanguage: 'language:change',
            choreo: 'choreo:notification'
        },

        init: function (transport) {
            this._super(transport);
        },

        getHupInfo: function () {
            return $.when(
                this.getClientGateway(),
                this.getApplicationList(),
                this.getLanguage()
            );
        },

        /**
         * Get available application list
         * [
         *  "appName": <appName>,
         *  "appDisplayName": <appDisplayName>,
         *  "appCategory": <appCategory>,
         *  "appPath": <appPath>
         * ]
         *
         * @returns {$.Deferred}
         */
        getApplicationList: function () {
            return this._transport.sendRequest({
                "path" : "profile",
                "method" : "GET"
            }).then(function (response) {
                return response.data;
            }, function (response) {
                return response && response.error;
            });
        },

        /**
         * data: {
         *   url: <Client Gateway URL>,
         *   headers: {
         *     "Access-Key-Id": <Access-Key-Id>,
         *     "App-Token": <App-Token>,
         *     "Auth-Token": <Auth-Token>,
         *     "Hu-Id": <Head Unit ID>,
         *     "Mip-Id": <MIP ID>
         *   }
         * }
         *
         * @returns {$.Deferred}
         */
        getClientGateway: function () {
            return this._transport.sendRequest({
                "path" : "clientGatewayInfo",
                "method" : "GET"
            });
        },

        /**
         *
         * TODO this is head unit call
         *
         * @returns {$.Deferred}
         */
        getLanguage: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "getLanguage"
                }
            });
        },

        /**
         * Notify that js is ready to processing messages
         */
        ready: function () {
            return this._transport.sendRequest({
                "path": "thorState",
                "method": "POST",
                "content": {
                    "state": "ready"
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content.type;
            
            if (!!notificationName && Object.keys(this.events).indexOf(notificationName) !== -1) {
                this.trigger(this.events[notificationName], content);
            } else if(content.name && content.data && content.data.type &&
                    content.name === "ERROR" && content.data.type === "choreo"){
                this.trigger(this.events.choreoError, content);
            }
        }
    }).prototype);
});

/**
 * Indicate hard or soft key clicks
 * Used internally in view(display)
 */
define('aq/api/hu/controls',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            buttonEvent: 'onButtonPress',
            soft: 'onSoftButtonPress',
            hard: 'onHardButtonPress',
            keyboard: 'keyboard'
        },

        init: function (storage, constants, transport) {
            this.constants = constants;
            this.storage = storage;
            this._super(transport);
        },

        onButtonPress: function (content) {
            this.trigger(this.events.buttonEvent, content);
            this[this.events[content.data.buttonType]](content);
        },

        onSoftButtonPress: function (content) {
            var softKey = this.storage.getAction(content.data.buttonId);

            this.trigger(this.events.soft, {
                content: content,
                action: softKey.action,
                value: softKey.value
            });
        },

        onHardButtonPress: function (content) {
            var keyId = content.data.buttonId,
                name = this.constants.HARD_KEYS[keyId];

            this.trigger(this.events.hard, {
                content: content,
                button: name
            });
        },

        startListenTo: function (to) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'startListen',
                    to: to
                }
            });
        },

        stopListenTo: function (to) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'stopListen',
                    to: to
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content.type;

            // fixme use for comparison notification name from events map
            if (notificationName === 'buttonEvent') {
                this.onButtonPress(content);
            } else if (notificationName === this.events.keyboard) {
                this.trigger(this.events.keyboard, content.data);
            }
        }

    });
});
/**
 * Transport for screen updates api
 * Used internally
 */
define('aq/api/hu/screen',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        /**
         *  key - value map
         *  key - zipId (assets_zipId)
         *  value - appName
         */
        zipMap:  {},

        events: {
            screenUpdateComplete: 'updateScreen:complete',
            image: 'image:request',
            imageRequest: 'image:request',
            file: 'file:request',
            archiveRequest: 'file:request',
            imageResponse: 'image:response',
            saveImageComplete: 'saveImageComplete',
            saveFileComplete: 'saveFileComplete',
            deleteImageComplete: 'deleteImageComplete',
            headUnitConnectionState: 'headUnitConnectionState'
        },

        init: function (options) {
            this.storage = options.storage;
            this._super(options.transport);
            this.utils = options.utils;
            this.constants = options.constants;
            this.appManager = options.appManager;

            this.listenTo(this, this.events.imageRequest, this.onImageRequest);
            this.listenTo(this, this.events.archiveRequest, this.onArchiveRequest);
            this.listenTo(this, this.events.saveFileComplete, this.onSaveFileComplete);
        },

        /**
         * Send template to the head unit.
         * Head unit should send as a response the screenUpdateComplete event
         * when template processing will be completed.
         *
         * @param data {Object} template
         * @returns {$.Deferred}
         */
        updateScreen: function (data) {
            var content = {
                "type": "screenUpdate",
                "data": data
            };

            return this._transport.sendRequest({
                "path": "headunit/event",
                "headers": {
                    "Content-Type": "application/json",
                    "Content-Length": encodeURI(JSON.stringify(content)).split(/%..|./).length - 1
                },
                "method": "POST",
                "content": content
            });
        },

        displayMediaSourceScreen: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "goToMediaSourcePage"
                }
            });
        },

        displayKeyboardScreen: function (keyboardBgImg1, keyboardBgImg2) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "goToKeyboard",
                    "imageId1": this.storage.getImageId({data: keyboardBgImg1}) || 101004,
                    "imageId2": this.storage.getImageId({data: keyboardBgImg2}) || 102000
                }
            });
        },

        /**
         *
         * Show or hide the system loading screen
         *
         * @param state {Number}
         * @param text {String}
         * @returns {$.Deferred}
         */
        displaySystemScreen: function (state, text) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "systemScreen",
                    "state": state,
                    "text": text
                }
            });
        },

        /**
         * Send the image to the head unit
         *
         * @params options {Object}
         *
         * @returns {$.Deferred}
         */
        updateImage: function (options, sequenceNumber) {
            // TODO: Calling private _onSendRequest()? Create public method like sendAsyncRequest()
            return this._transport._onSendRequest({
                "path": "thor/image",
                "headers": {"Content-Type": "image/png"},
                "method": "POST",
                "sequenceNumber": sequenceNumber,
                "code": 200,
                "status": "OK",
                "responseHandler": {
                    "name": "imageResponse",
                    "params": options
                }
            });
        },

        /**
         * @param requestContent - request content
         * {
         *  fileId - zipId identifier (assets_zipId)
         * }
         *
         * @param sequenceNumber
         * @returns {*}
         */
        sendImageArchive: function (requestContent, sequenceNumber) {
            var zipId = requestContent.fileId,
                appName = this.zipMap[zipId],
                path = this.constants.URL.filePath,
                archiveType = this.constants.IMAGE_ARCHIVE.ZIP;

            if(this.utils.getPlatform() === "android") {
                path = this.constants.URL.androidPath;
            }
            path = path + appName + "/assets_" + zipId + "." + archiveType;

            this.appManager.logger.log({'sendImageArchive' : 'sendImageArchive'});
            this.appManager.logger.log({'path' : path});

            return this._transport._onSendRequest({
                "path": "thor/file",
                "headers": {"Content-Type": "application/" + archiveType},
                "method": "POST",
                "sequenceNumber": sequenceNumber,
                "code": 200,
                "status": "OK",
                "responseHandler": {
                    'name': 'file',
                    'params': {
                        url: path
                    }
                }
            });
        },

        onSaveFileComplete: function () {
            this.appManager.logger.log({'onSaveFileComplete' : 'onSaveFileComplete'});
        },

        cacheImages: function (images) {
            return this._cacheImages(images);
        },

        onArchiveRequest: function (content, notification) {
            this.sendImageArchive(content, notification.sequenceNumber);
        },

        onImageRequest: function (content, notification) {
            var imgId = content.imageId,
                imgData = this.storage.getValue(imgId, 'image'),
                appId = content.appId,
                constants = this.constants;

            imgData = this.utils.parseJSON(imgData);

            if (!imgData) return;

            // TODO figure out available image formats
            var format = /^file:\/\//.test(imgData.data) ? 'file' : 'base64';

            // TODO taken from DA
            if(this.utils.getPlatform() === "android") {
                // Replace file:///  with  file:///HMI_ROOT/www/
                imgData.data = imgData.data ?
                    imgData.data.replace(constants.URL.filePath, constants.URL.androidPath) : "";
            }

            this.updateImage({
                imageId: imgId,
                url: imgData.data,
                format: format,
                appId: appId,
                width: imgData.w || 0,
                height: imgData.h || 0
            }, notification.sequenceNumber);
        },

        /**
         *
         * @param images {Array}
         */
        _cacheImages: function (images) {
            var dfd = $.Deferred(),
                cacheImages = this._transport.sendRequest({
                    "path": "headunit/event",
                    "method": "POST",
                    "content": {
                        "type": "saveImages",
                        "data": {
                            "imageIds": images
                        }
                    }
                });

            cacheImages
                .done(function () {
                    this.once(this.events.saveImageComplete, dfd.resolve);
                    // reject by timeout if image caching not completed
                    // TODO figure out timeout time and should we show any error message
                    _.delay(dfd.reject, 30000);
                }.bind(this))
                .fail(dfd.reject);

            return dfd.promise();
        },


        /**
         *
         * @returns {jqXHR|jQuery.Deferred}
         */
        saveZip: function (zipMap) {
            var zipIds = Object.keys(zipMap).map(function (zipId) {
                return parseInt(zipId, 10);
            });
            
            this.zipMap = zipMap;
            
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "saveFile",
                    "data": {
                        "fileIds" : zipIds
                    }
                }
            });
        },

        /**
         *
         * @param images {Array}
         */
        invalidateImagesCache: function (images) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "deleteImages",
                    "data": {
                        "imageIds": images
                    }
                }
            });
        },

        _onNotification: function (content, notification) {
            var notificationName = content.type ||
                _.last(notification && notification.path && notification.path.split('/'));
            if (Object.keys(this.events).indexOf(notificationName) !== -1) {
                this.trigger(this.events[notificationName], content, notification);
            }
        }

    });
});

define('aq/templates/handlers/translators/base',['shared/utils/class'], function (Class) {
    'use strict';

    var EMPTY_IMAGE_ID = 0;

    return Class.extend({

        buttons: [],

        init: function (storage, appManager, config, constants) {
            this.storage = storage;
            this.appManager = appManager;
            this.buttonsBranding = config.buttonsBranding;
            this.constants = constants;
        },

        translate: function (data, processedTemplate) {
            processedTemplate.buttons = this.ensureButtons(processedTemplate.buttons);
            data.templateContent = processedTemplate;
            return data;
        },

        ensureButtons: function (buttons) {
            var defaults = _.object(this.buttons, this.buttons.map(Object.bind({}, {})));
            return _.defaults(buttons, defaults);
        },

        processButtons: function (content, buttonSize) {
            var button = {},
                buttons = {};
            content = content || {};
            
            _.each(content, function (item, key) {
                button = {};

                item.image = item.image || '';
                item.backgroundImage = item.backgroundImage || '';

                button.image = {
                    normal: this.storage.getImageId(_.extend({
                        data: item.image.normal || item.image
                    }, buttonSize)),

                    pressed: this.storage.getImageId(_.extend({
                        data: item.image.pressed
                    }, buttonSize))
                };

                button.backgroundImage = {
                    normal: this.storage.getImageId(_.extend({
                        data: item.backgroundImage.normal || item.backgroundImage
                    }, buttonSize)),

                    pressed: this.storage.getImageId(_.extend({
                        data: item.backgroundImage.pressed
                    }, buttonSize))
                };

                if (_.isString(item.text)) {
                    button.text = item.text;
                }

                // defined as true if no stateEnabled
                button.stateEnabled = _.isUndefined(item.stateEnabled) ? true : item.stateEnabled;

                button.scrollUp = !!item.scrollUp;
                button.scrollDown = !!item.scrollDown;

                // save button in case it's not empty
                if (button.image.normal !== EMPTY_IMAGE_ID || button.backgroundImage.normal !== EMPTY_IMAGE_ID ||
                    button.text || button.scrollUp || button.scrollDown) {

                    buttons[key] = button;

                    // Save button actions
                    if (item.action !== undefined || item.value !== undefined) {
                        this.storage.addAction(parseInt(key, 10), item.action, item.value);
                    }
                }

            }, this);

            return buttons;
        },

        /**
         *
         * Filter out from object-like-array key-values pairs that between "from" and "to" indexes
         * For example: filterByRange({1: true, 2: true, 3: false}, 2, 3) =>
         *                  {2: true, 3: false}
         *
         * @param items {object}
         * @param from {number}
         * @param to {number}
         * @returns {object}
         */
        filterByRange: function (items, from, to) {
            return _.reduce(items, function (memo, value, key) {
                if (key >= from && key <= to) {
                    memo[key] = value;
                }
                return memo;
            }, {});
        }
    });
});

/*
 *  Popup
 *  Template VP2C-1
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-1"
 *      "templateContent" : {
 *          "title" : {
 *              "text": <string>
 *          },
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              }
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
  *             ... 6
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  main text char limit is 85
 *  buttons text char limit is 14
 *    _______________________________________________
 *   |                                               |
 *   |-----------------------------------------------|
 *   |   _________________________________________   |
 *   |  |                                         |  |
 *   |  |              title                      |  |
 *   |  |                                         |  |
 *   |  |            main text                    |  |
 *   |  |                                         |  |
 *   |  | --------------------------------------- |  |
 *   |  |   button   |    button     |   button   |  |
 *   |  |_________________________________________|  |
 *   |_______________________________________________|
 *
 */

define('aq/templates/handlers/translators/vp2c-1',['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, utils) {
    'use strict';

    var CONSTANTS = {
        buttons: {
            // 1
            left: {w: 52, h: 52},
            // 2 - 3
            center: {w: 118, h: 52},
            // 4 - 6
            threesome: {w: 106, h: 52}
        }
    };

    return Base.extend({

        templateName: 'vp2c-1',

        mainTextCharLimit: 85,

        buttons: _.range(1, 7),

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.title = content.title || '';
            template.title = {
                text: content.title.text || content.title
            };

            content.main = content.main || {};
            var text = _.isObject(content.main.text) ? content.main.text[1] : content.main.text;
            template.main = {
                text: {
                    1: utils.ellipsis(text, this.mainTextCharLimit)
                }
            };
            template.buttons = this.getButtons(content.buttons);

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons.left),
                this.processButtons(this.filterByRange(buttons, 2, 3), CONSTANTS.buttons.center),
                this.processButtons(this.filterByRange(buttons, 4, 6), CONSTANTS.buttons.threesome)
            );
        }
    });
});
/*
 *  Template VP2C-6
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-6",
 *      "backgroundImage" : <number>,
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 7
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "3": <string>
 *              },
 *              "images": {
 *                  "1" : <number>,
 *                  ... 2
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_7  |                                    |
 *   |-----------------------------------------------|
 *   |   _____________                               |
 *   |  |             |                              |
 *   |  |             |  text_1                      |
 *   |  |  images_1   |  text_2                      |
 *   |  |             |  text_3                      |
 *   |  |             |                              |
 *   |  |_____________|                              |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 *
 */

define('aq/templates/handlers/translators/vp2c-2',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 61, h: 52}, // TODO could be dynamic
        // 7
        button: {w: 52, h: 44},

        mainImageItem: {w: 75, h: 75},
        sideImageItem: {w: 25, h: 25},
        titleImage: {w: 329, h: 30}
    };

    return Base.extend({

        templateName: 'vp2c-2',

        buttons: _.range(1, 8),

        translate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = this.getButtons(buttons);


            content.main = content.main || {};
            content.main.text = content.main.text || {};
            template.main = {};

            var item,
                items = {};
            for (var i = 1; i < 4; i++) {
                item = content.main.text[i] || {};
                items[i] = item.text || '';
            }
            template.main.text = items;


            template.main.images = this.getImages(content.main.images);
            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            // progress bar
            template.progress = {};
            if (content.progress && content.progress.total) {
                template.progress = {
                    total: content.progress.total,
                    current: content.progress.elapsed / content.progress.total,
                    color: content.progress.color,
                    active: content.progress.active
                };
            }

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 7, 7), CONSTANTS.button)
            );
        },

        getImages: function (templateImages) {
            var images = {};
            templateImages = templateImages || {};

            images[1] =  this.storage.getImageId({
                data: templateImages[1],
                w: CONSTANTS.mainImageItem.w,
                h: CONSTANTS.mainImageItem.h
            });

            images[2] =  this.storage.getImageId({
                data: templateImages[2],
                w: CONSTANTS.sideImageItem.w,
                h: CONSTANTS.sideImageItem.h
            });

            return images;
        }

    });
});
/*
 *  Template VP2C-3
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-3",
 *      "templateContent" : {
 *          "title" : {
 *              "text": <string>
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "scrollUp": <boolean>,
 *                  "scrollDown": <boolean>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              ... 10
 *          },
 *          "list": {
 *              "activeListItem" : <int>, //index in the array of the element to be highlighted. Defaults to null.
 *              "items": [{
 *                  "image1": <number>,
 *                  "image2": <number>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              }, ...]
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  Text char limit in list is 16 (truncated by HU)
 *  Title char limit is 16
 *
 *   ________________________________________________
 *  | _____   |         title                   |    |
 *  ||b_200|  |---------------------------------| /\ |
 *  ||_____|  |                                 |    |
 *  |         | img1 | text              | img2 |    |
 *  | _____   |                                 |    |
 *  || b_2 |  | img1 | text              | img2 |    |
 *  ||_____|  |                                 |    |
 *  | _____   | img1 | text              | img2 |    |
 *  || b_1 |  |                                 |    |
 *  ||_____|  | img1 | text              | img2 | \/ |
 *  |_________|_________________________________|____|
 *
 */

define('aq/templates/handlers/translators/vp2c-3',['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, utils) {
    'use strict';

    var CONSTANTS = {
        titleCharLimit: 16,
        itemIconSize: {w: 32, h: 32},
        buttonSize: {w: 72, h: 52},
        listItemId: 101
    };

    return Base.extend({

        templateName: 'vp2c-3',

        buttons: _.range(1, 11),

        translate: function (data) {
            var template = {},
                content = data.templateContent,
                /**
                 *
                 * {
                 *   title: string,
                 *   cursorColor: 'hex color', // using hardware scroll
                 *   pressedHighlightColor: 'hex color',
                 *   selectedHighlightColor: 'hex color',
                 * }
                 */


                title = _.isUndefined(content.title) ? '' : (content.title.text || content.title),
                scrollPressedStateImage = this.storage.getImageId({
                    data: this._getScrollPressedState() || '',
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

            template.ignorePartialUpdate = data.ignorePartialUpdate || false;

            template.title = {
                text: utils.ellipsis(title, CONSTANTS.titleCharLimit),
                pressedHighlightColor: this._getListBranding(),
                selectedHighlightColor: this._getListBranding(),
                scrollPressedState: scrollPressedStateImage
            };

            var items = content.list.items || (_.isArray(content.list) ? content.list : []);
            template.list = {
                activeListItem: _.isNumber(content.list && content.list.activeListItem) ?
                    content.list.activeListItem : null,
                items: this.processListItems(items)
            };

            // 1 - 10
            template.buttons = this.processButtons(content.buttons, CONSTANTS.buttonSize);

            return this._super(data, template);
        },

        processListItems: function (content) {
            var list = [];
            content = _.isArray(content) ? content : [];

            content.forEach(function (listItem, key) {

                var item = {};

                var leftImage = listItem.image || listItem.image1,
                    rightImage = listItem.image2;


                item.image1 = this.storage.getImageId({
                    data: leftImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.image2 = this.storage.getImageId({
                    data: rightImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.text = _.isString(listItem.text) ? listItem.text : "";

                //Save list actions
                if (listItem.action !== undefined || listItem.value !== undefined) {
                    this.storage.addAction(key + CONSTANTS.listItemId, listItem.action, listItem.value);
                }

                list.push(item);

            }, this);

            return list;
        },

        _getScrollPressedState: function () {
            var appName = this.appManager.getCurrentApplicationName(),
                pathToButtonsBrandingPressedState;
            //appName for homeList 'uconnect' has to be changed to 'aq' (in file system)
            appName = appName === this.constants.APP_NAME_MAP.uconnect ? 'aq' : appName;
            pathToButtonsBrandingPressedState = 'file:///' + appName + this.buttonsBranding.path;

            return pathToButtonsBrandingPressedState + this.buttonsBranding.scrollBranding + '.png';
        },

        _getListBranding: function () {
            return this.constants.APP_LIST_COLOR.VP2C[this.appManager.getCurrentApplicationName()];
        }

    });
});

/*
 *  Template VP2C-5
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-5",
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 10
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *    _______________________________________________
 *   |   but_10  |                                   |
 *   |-----------------------------------------------|
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_1    | |   but_2    | |   but_3    | |
 *   |  |____________| |____________| |____________| |
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_4    | |   but_5    | |   but_6    | |
 *   |  |____________| |____________| |____________| |
 *   |_______________________________________________|
 *
 */

define('aq/templates/handlers/translators/vp2c-5',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        bigButton: {w: 122, h: 57}, // buttons 1 - 9
        button: {w: 72, h: 52}, // button 10
        titleImage: {w: 376, h: 75}
    };

    return Base.extend({

        templateName: 'vp2c-5',

        buttons: _.range(1, 11),

        translate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 9), CONSTANTS.bigButton),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.button)
            );

            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            return this._super(data, template);
        }
    });
});
/*
 *  Template VP2C-6
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-6",
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 9
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "2": <string>
 *              },
 *              "images": {
 *                  "1" : <number>
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_7  |                                    |
 *   |-----------------------------------------------|
 *   | ____   _____________                     ____ |
 *   |     | |             |                   |     |
 *   |     | |             |  text_1           |     |
 *   | b_8 | | main_image  |  text_2           | b_9 |
 *   |     | |             |  text_3           |     |
 *   | ____| |             |                   |____ |
 *   |       |_____________|                         |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 */

define('aq/templates/handlers/translators/vp2c-6',['aq/templates/handlers/translators/vp2c-2'], function (Player) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 61, h: 52}, // TODO could be dynamic
        // 8, 9
        sideButton: {w: 52, h: 52},
        // 7
        button: {w: 52, h: 44},

        mainImageItem: { w: 75, h: 75},
        titleImage: {w: 324, h: 32}
    };

    return Player.extend({

        templateName: 'vp2c-6',

        buttons: _.range(1, 10),

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 7, 7), CONSTANTS.button),
                this.processButtons(this.filterByRange(buttons, 8, 9), CONSTANTS.sideButton)
            );
        },

        getImages: function (templateImages) {
            var images = {};
            templateImages = templateImages || {};

            images[1] = this.storage.getImageId({
                data: templateImages[1],
                w: CONSTANTS.mainImageItem.w,
                h: CONSTANTS.mainImageItem.h
            });

            return images;
        }

    });
});
/*
 *  Popup with images
 *  Template VP2C-7
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-7"
 *      "templateContent" : {
 *          "main": {
 *              "text": {
 *                  "1": <string>,
 *                  ... 3
 *              },
 *              "images": {
 *                  "1": <number>
 *              }
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *             ... 4
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 */

define('aq/templates/handlers/translators/vp2c-7',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        imageSize: {w: 75, h: 75},
        buttons: {
            1: { w: 52, h: 52},
            2: {w: 75, h: 52},
            // 3 - 4
            standard: {w: 118, h: 52}
        }
    };

    return Base.extend({

        templateName: 'vp2c-7',

        buttons: _.range(1, 5),

        translate: function (data) {

            var template = {}, key,
                content = data.templateContent;

            content.main = content.main || {};
            content.main.text = content.main.text || {};
            content.main.images = content.main.images || {};

            template.main = {
                text: {},
                images: {}
            };

            for (key = 1; key < 4; key++) {
                template.main.text[key] =  content.main.text[key] || "";
            }

            template.main.images[1] = this.storage.getImageId(_.extend({
                data: content.main.images[1]
            }, CONSTANTS.imageSize));

            template.buttons = this.getButtons(content.buttons);

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons[1]),
                this.processButtons(this.filterByRange(buttons, 2, 2), CONSTANTS.buttons[2]),
                this.processButtons(this.filterByRange(buttons, 3, 4), CONSTANTS.buttons.standard)
            );
        }
    });
});
/*
 * Template VP2C-8
 * Loading screen
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-8"
 *      "templateContent" : {
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              },
 *              "images": {
 *                  "1": <number>
 *              }
 *          }
 *      }
 *  }
 *
 *
 *
 *  item_1 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |                                               |
 *   |                 _____________                 |
 *   |                |             |                |
 *   |                |             |                |
 *   |                |  image_1    |                |
 *   |                |             |                |
 *   |                |_____________|                |
 *   |                                               |
 *   |                     text_1                    |
 *   |_______________________________________________|

 *
 *
 *
 */


define('aq/templates/handlers/translators/vp2c-8',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // on first launch if set to 75x75
        // images can be resized by HUP to 75x39
        mainImageItem: { w: 230, h: 120}
    };

    return Base.extend({

        templateName: 'vp2c-8',

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.main = content.main || {};
            template.main = {};

            if (content.main.images && content.main.images[1]) {
                template.main.images = {
                    1: this.storage.getImageId(_.extend({
                        data: content.main.images[1]
                    }, CONSTANTS.mainImageItem))
                };
            }
            if (content.main.text && content.main.text[1]) {
                template.main.text = template.main.text || {};
                template.main.text[1] = content.main.text[1];
            }

            data.templateContent = template;
            return data;
        }
    });
});

define('aq/templates/handlers/translator',['shared/utils/class',
        'aq/templates/handlers/translators/vp2c-1',
        'aq/templates/handlers/translators/vp2c-2',
        'aq/templates/handlers/translators/vp2c-3',
        'aq/templates/handlers/translators/vp2c-5',
        'aq/templates/handlers/translators/vp2c-6',
        'aq/templates/handlers/translators/vp2c-7',
        'aq/templates/handlers/translators/vp2c-8'
    ],
    function (Class) {
    'use strict';

    var templates = Array.prototype.slice.call(arguments, 1),
        screenId = 1;

    return Class.extend({

        init: function (storage, appManager, config, consntants) {
            this.appManager = appManager;
            this.storage = storage;
            this.templateTypes = {};
            _.each(templates, function (Template) {
                var tpl = new Template(storage, appManager, config, consntants);
                this.templateTypes[tpl.templateName.toLowerCase()] = tpl;
            }, this);
        },

        translate: function (data) {
            // Clear actions map
            this.storage.clearActions();

            var OEMAppId = 0x9999;
            data.appId = parseInt(this.appManager.getActiveAppId(), 10) || OEMAppId;
            data.screenId = screenId++;

            /** Loading type:
             *   * 1 - show loading screen while populating the screen;
             *         hide loading once everything is loaded including images.
             *   * 2 - show loading while loading text, and hide it;
             *         Images will be displayed dynamically as downloaded.
             *   * 3 - do not show loading animation during screen transition.
             */
            data.loadingType = _.contains([1,2,3], data.loadingType) ? data.loadingType : 1;

            data.systemHeader = !!data.systemHeader;

            data.backgroundImage = this.storage.getImageId({
                data: data.backgroundImage,
                w: 400,
                h: 240
            });

            var template = this.templateTypes[data.templateId.toLowerCase()];

            return template ? template.translate(data) : null;
        }
    });
});

/**
 * Partial update can be applicable for the templates with the same type and with at least one the same element.
 *
 * Diff for partial update should be calculated using following rules:
 *
 * Buttons:
 *  If the button parameter is missing, then assume that it has not been changed.
 *  If the button parameter is an empty JSON {}, then assume that it has been removed.
 *  If the button parameter is a valid JSON with new values, then assume that it has been updated.
 *
 * Text:
 *  If the text parameter is missing, then assume that it has not been changed.
 *  If the text value is an empty string, then assume that it has been removed and display the empty string.
 *  If the text value is a valid string, then assume that it has been updated and display the provided string.
 *
 * Images:
 *  If the image key parameter is missing, then assume that it has not been changed.
 *  If the image id is 0, then assume that it has been removed
 *  and display an empty placeholder/image (remove the image if it was populated previously).
 *  If the image id is >0, then assume that it has been updated and display the given image.
 *
 * List:
 *  If the list parameter is missing, then assume that it has not been changed.
 *  If the list parameter value is an empty array, then assume that it has been updated and display an empty list.
 *  If the list parameter value is a valid array of JSONs,
 *  then assume that it has been updated and display the updated list.
 */

define('aq/templates/handlers/partialUpdate',['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        init: function (cf) {
            this.cf = cf;
        },

        translate: function (template) {
            var appId = template.appId,
                templateId = template.templateId,
                id = appId + ':' + templateId,
                cf = this.cf,
                self = this;

            var originalTpl = $.extend(true, {}, template.templateContent),
                requestedToDisplayTpl = template.templateContent,
                displayingTpl = cf.cache.LastUpdate && cf.cache.LastUpdate.template;

            template.partialUpdate = false;

            // don't do partial update if instructed by this flag
            if (!template.ignorePartialUpdate && this.isPartialUpdateApplicable(id)) {

                var walk = function walk (next, current) {
                    _.each(next, function (nextItem, key) {
                        //if (cf.expand[key] && _.isObject(item) && _.isObject(current[key])) {
                        if (cf.expand[key] && _.isObject(nextItem) && _.isObject(current[key])) {
                            walk(nextItem, current[key]);
                        } else {
                            // if currently displayed template has this element
                            if (current[key]) {
                                // and this element is the same as in requested to display template
                                if (self.isEqual(current[key], nextItem)) {
                                    // remove this element and set partial update flag
                                    delete next[key];
                                    template.partialUpdate = true;
                                    template.loadingType = 3;
                                }
                            }
                        }
                    });
                };

                // walk through template and remove elements that has not changed
                walk(requestedToDisplayTpl, displayingTpl);
            }
            
            //When rendering list, active item is not cached 
            //to prevent view rendering being ignored incorrectly. 
            // See CV-1997 for this particular use case.
            if(template.templateId === 'vp2c-3'){
                if(originalTpl.list && originalTpl.list.activeListItem){
                    originalTpl.list.activeListItem = null;
                }
            }

            // store requested to display template for further use
            cf.cache.LastUpdate = {
                id: id,
                template: originalTpl
            };

            return template;
        },

        /**
         * Apply partial update only when we are trying to render
         * template with the same id more than once
         *
         * @param id {String}
         * @returns {boolean}
         */
        isPartialUpdateApplicable: function (id) {
            var lastUpdate = this.cf.cache.LastUpdate || {};
            return _.isObject(lastUpdate.template) && lastUpdate.id === id;
        },

        isEqual: function (a, b) {
            return JSON.stringify(a) === JSON.stringify(b);
        }
    });

});

define('common/view/config',[],function () {
    "use strict";
    
    return {
        buttonsBranding: {
            'vp2c-1': {
                1: '56x56',
                2: '118x52',
                3: '118x52',
                4: '106x52',
                5: '106x52',
                6: '106x52'
            },
            'vp2c-2': {
                7: '52x44'
            },
            'vp2c-3': {
                1: '75x52',
                2: '75x52',
                3: '75x52',
                4: '75x52',
                5: '75x52',
                6: '75x52',
                7: '75x52',
                8: '75x52',
                9: '75x52',
                10: '75x52'
            },
            'vp2c-5': {
                1: '118x52',
                2: '118x52',
                3: '118x52',
                4: '118x52',
                5: '118x52',
                6: '118x52',
                7: '118x52',
                8: '118x52',
                9: '118x52',
                10: '52x44'
            },
            'vp2c-6': {
                7: '52x44',
                8: '56x56',
                9: '56x56'
            },
            'vp2c-7': {
                1: '56x56',
                2: '75x52',
                3: '118x52',
                4: '118x52'
            },

            scrollBranding: '75x52',

            path: '/images/buttons/pressed/'
        }
    };
});

define('aq/templates/processor',['shared/utils/class',
    'aq/templates/handlers/translator',
    'aq/templates/handlers/partialUpdate',
    'common/view/config',
    'aq/constants'
],
    function (Class, Translator, PartialUpdate, config, constants) {
        'use strict';

        var handlers = [];

        return Class.extend({

            init: function (displayedTemplateData, storage, appManager) {

                displayedTemplateData.LastUpdate = {};

                this.addHandler(new Translator(storage, appManager, config, constants))
                    .addHandler(new PartialUpdate({
                        cache: displayedTemplateData,
                        expand: {
                            buttons: true,
                            // main > main.images and main.text
                            main: true,
                            images: true,
                            text: true
                        }
                    }));
            },

            addHandler: function (handler) {
                handlers.push(handler);
                return this;
            },

            process: function (indata) {
                var data = $.extend(true, {}, indata);
                handlers.forEach(function (handler) {
                    data = $.extend(true, {}, handler.translate(data));
                });

                return data;
            }
        });
    });

/* jshint unused:false*/
define('shared/thor_interface/transport',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Transport class. Low level private interface used to provide http connection with HUP.
	 * May be used by Choreo, huApi, CommandControl interfaces to send http requests to HUP.
	 *
	 * @name Transport
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send request using current transport options. From application name.
		 * appName also can be used as custom identifier of group of requests.
		 *
		 * @name Transport#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {Object} options
		 * @param {String} appName
		 *
		 * @returns {jqXHR}
		 */
		sendRequest: function() {
			throw new Error('not implemented');
		},

		/**
		 * Aborts all application requests. Or all if no application name specified
		 * May be used when application changes route or shutting down
		 *
		 * @name Transport#abortRequests
		 * @function
		 * @abstract
		 *
		 * @param {String} [appName]
		 */
		abortRequests: function() {
			throw new Error('not implemented');
		}
	});
});

/**
 * @Singleton
 *
 * Low level transport responsible for communication between HAP and HMI
 * Entry point for all incoming and outcoming calls
 *
 */
define('aq/api/transport/transport',['shared/thor_interface/transport', 'aq/mixins/events'], function (Trasnport, events) {
    'use strict';

    var instance;

    return Trasnport.extend({

        waitBeforeResolve: 20 * 1000,

        /**
         * @constructor
         */
        init: function (utils, RequestsQueue, platfrom) {

            if (instance) {
                return instance;
            }
            instance = _.extend(this, events);

            this._utils = utils;
            this._platform = platfrom;
            this._requests = new RequestsQueue(this);
            this._timeoutIds = [];

            // entry point for all incoming messages
            window.onNotification = this._onReceiveResponse.bind(this);
            return this;
        },

        /**
         * @param data {Object}
         * @param callback {Function} optional, deprecated
         *
         * @return {$.Deferred}
         */
        sendRequest: function (data, callback) {
            var deferred = this._requests.add(data);
            data.requestNumber = deferred.requestNumber;

            // stringify data, send to native layer
            this._onSendRequest(data);

            // compatibility support
            if (typeof callback === 'function') {
                callback(data.requestNumber);
            }

            // automatically reject by timeout if deferred still in pending state
            var wait = this.waitBeforeResolve;
            this._timeoutIds.push(setTimeout(function () {
                if (deferred.state() === 'pending') {
                    var error = {
                        error: {
                            // Request timed out
                            code: 170000,
                            description: 'Rejected by timeout',
                            timeout: wait,
                            request: data
                        }
                    };
                    this.sendLogRequest({'[Transport][Request][Timeout]': error});
                    deferred.reject(error);
                }
            }.bind(this), wait));

            return deferred
                .always(this.handleNotification.bind(this))
                .promise();
        },

        /**
         * Send log request to native layer
         * @param data {Object}
         */
        sendLogRequest: function (data) {
            this._platform.log(data);
        },

        /**
         *
         * @param content {Object}
         * @param notification {Object} full response from HAP
         */
        handleNotification: function (content, notification) {
            var isThorEvent = /thor\/event$/.test(notification && notification.path),
                isMEHAEvent = /meha\/event$/.test(notification && notification.path),
                needToRespond = isThorEvent || isMEHAEvent,
                responseStatus = {
                    code: 200,
                    status: 'OK'
                };

            try {
                this.trigger('notification', content, notification);
            } catch (e) {
                this.sendLogRequest({
                    ERROR: {
                        msg: e.toString(),
                        stack: e.stack || ''
                    }
                });
                responseStatus = {
                    code: 400,
                    status: 'Bad Request'
                };
            } finally {
                if (needToRespond) {
                    this._platform.send(this._utils.toJSON(_.extend({
                        sequenceNumber: notification.sequenceNumber,
                        headers: {
                            'Content-Length': 0
                        }
                    }, responseStatus)));
                }
            }
        },

        abortRequests: function () {
            this._timeoutIds.forEach(window.clearTimeout);
            this._requests.clear();
        },

        /**
         * Send all messages to the native layer
         * @private
         */
        _onSendRequest: function (data) {
            var headers = data.headers || {"Content-Type": "application/json"};
            var path = '/hap/api/1.0/' + data.path;
            var json = _.extend(data, {
                "path": path,
                "headers": headers
            });
            this._platform.send(this._utils.toJSON(json));
            this.sendLogRequest({'[Transport][onSendRequest]': json});
        },

        /**
         * Receive all messages from the native layer
         *
         * @param response {JSON|Object}
         *
         * {
         *   "sequenceNumber": <Number>,
         *   "requestNumber": <Number>,
         *   "path": <String>,
         *   "headers" : {
         *        "Content-type" : "application/json"
         *   },
         *   "content" : {
         *        "type" : <String>,
         *        "data" : <Object>,
         *        "error" : {
         *            "code" : <Error Code: section 3.4>,
         *            "description" : "<Error Description: section 3.4>"
         *        }
         *   }
         * }
         */
        _onReceiveResponse: function (response) {
            response = _.isString(response) ? this._utils.parseJSON(response) : response;
            this.sendLogRequest({'[Transport][onNotification]': response});

            if (response === null) throw new Error("[Transport][onNotification] Can't parse JSON");

            var content = response.content || {},
                deferred = this._requests.get(response.requestNumber);

            // completely async notification
            if (!deferred) return this.handleNotification(content, response);

            return this._isFail(content)  ? this._onFailure(content, deferred) : this._onSuccess(content, deferred);
        },

        _isFail: function (content) {
            var error = content.error;
            // android HAP always send error code(for success responses also)
            // 150000 is a success response

            var successCode = 150000;
            return error && error.code && error.code !== successCode;
        },

        _onSuccess: function (content, deferred) {
            deferred.resolve(content);
        },

        _onFailure: function (content, deferred) {
            console.error('[Transport][Request][Resolved][Fail]', content.error);
            deferred.reject(content);
        }

    });

});
/**
 * iOS native transport layer
 */
define('aq/api/transport/ios',[],function () {
    'use strict';

    // save the cached iframe el
    var iframe = window.document.createElement('iframe');

    return {

        /**
         * Send messages to native ios layer
         * @param data {json}
         */
        send: function (data) {
            try {
                var frame = iframe.cloneNode();
                frame.setAttribute('src', 'update:' + encodeURIComponent(data));
                window.document.documentElement.appendChild(frame);
                frame.parentNode.removeChild(frame);
                frame = null;
            } catch (e) {
                console.error(e);
            }

        },

        /**
         * Send log to the native env
         * @param msg {*}
         */
        log: function (msg) {
            this.send(JSON.stringify({
                "path": "/hap/api/1.0/log",
                "headers": {"Content-Type": "text/plain"},
                "method": "POST",
                "content": {
                    msg: this.ejectImage($.extend(true, {}, msg)),
                    time: +new Date()
                }
            }));
        },

        ejectImage: function (msg) {
            _.each(msg, function (val, key) {
                if (_.isObject(val)) {
                    this.ejectImage(val);
                } else {
                    if (_.isString(val) && val.length > 10000) msg[key] = 'base64/image';
                }
            }, this);
            return msg;
        }
    };

});
/**
 * Android native transport layer
 */
define('aq/api/transport/android',[],function () {
    'use strict';

    return {

        /**
         * Send messages to native android layer
         * @param data {json}
         */
        send: function (data) {
            try {
                window.android.exec(data);
            } catch (e) {
                console.error('[EXEC ERROR]', e);
                console.trace();
            }
        },

        /**
         * Send log to the native env
         * @param msg {*}
         */
        log: function (msg) {
            try {
                msg = JSON.stringify(this.ejectImage($.extend(true, {}, msg)), null, 2);
                window.android.log(msg);
            } catch (e) {
                console.error('[LOG ERROR]', e);
            }

        },

        ejectImage: function (msg) {
            _.each(msg, function (val, key) {
                if (_.isObject(val)) {
                    this.ejectImage(val);
                } else {
                    if (_.isString(val) && val.length > 10000) msg[key] = 'base64/image';
                }
            }, this);
            return msg;
        }
    };
});

/**
 * Collection of stored deferred for each request
 */
define('aq/api/transport/queue',['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        /**
         * @constructor
         */
        init: function () {
            this._queuee = {};
            this._requestNumber = 0;
        },

        /**
         * Create and put into queue deferred object
         * @returns {$.Deferred}
         */
        add: function () {
            var currentRequestNumber = this._requestNumber++;
            var deferred = $.Deferred();

            deferred.requestNumber = currentRequestNumber;
            this._queuee[currentRequestNumber] = deferred;

            return deferred;
        },

        /**
         * Get and remove deferred object from queue
         * @param requestNumber
         * @returns {$.Deferred}
         */
        get: function (requestNumber) {
            var deferred = this._queuee[requestNumber];
            this._remove(requestNumber);
            return deferred;
        },

        /**
         * Cleanup and release memory
         */
        clear: function () {
            $.each(this._queuee, this._remove.bind(this));
            this._queuee = {};
        },

        /**
         * @param requestNumber
         */
        _remove: function (requestNumber) {
            this._queuee[requestNumber] = null;
            delete this._queuee[requestNumber];
        }
    });

});
/* jshint unused:false*/
define('shared/thor_interface/choreo',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Choreo requests adapter. Implements access layer to Choreo API.
	 * Uses Transport as http transport layer abstraction
	 *
	 * @name Choreo
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send request to Choreo API gateway
		 *
		 * @name Choreo#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {object} params
		 * @param {string} params.url
		 * @param {string} [params.method] GET or POST
		 * @param {object} [params.data]
		 *
		 * @returns {jQuery.Deferred}
		 */
		sendRequest: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get image from Choreo proxy
		 *
		 * @name Choreo#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {object} url
		 *
		 * @returns {jQuery.Deferred}
		 */
		getExternalImageByUrl: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get Choreo request parameters.
		 *
		 * @name Choreo#getParams
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		getParams: function () {
			throw new Error('not implemented');
		},

		/**
		 * Terminate all current requests for appName if specified or all current commands
		 * May be used when application changes route or shutting down
		 *
		 * @name Choreo#abortApplicationRequests
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName] - HMI application name
		 */
		abortApplicationRequests: function(){
			throw new Error('not implemented');
		}
	});
});

define('aq/api/choreo',['jquery', 'shared/thor_interface/choreo', 'aq/mixins/events'], function ($, Choreo, Events) {
    'use strict';

    /**
     * @class
     */
    return Choreo.extend({
        /** @lends Choreo */

        /**
         * Property required for compatibility with shared modules
         * @type {string}
         */
        baseUrl: '',

        /**
         * @constructs Choreo
         * @param {Transport} transport
         * @param {Profile} profile
         * @param {Object} options
         *
         */
        init: function (transport, profile, options) {
            options = options || {};

            this.contentType = options || "application/json";

            this._transport = transport;
            this._profile = profile;
        },


        /**
         *
         * @param params {Object}
         * @returns {$.Deferred}
         */
        sendRequest: function (params) {
            params = params || {};

            params.method = params.method || "GET";
            params.path =  "choreo";

            return this.getParams()
                .then(function (choreoParams) {

                    params.url = choreoParams.url+ '/' + params.url;
                    params.headers = $.extend({}, choreoParams.headers, params.headers);

                    return this._transport.sendRequest(params);
                }.bind(this));
        },


        /**
         * Get image from Choreo proxy
         *
         * @name Choreo#getExternalImageByUrl
         * @function
         *
         * @param {String} url
         * @param {Boolean} [encode]
         *
         * @returns {jQuery.Deferred}
         */
        getExternalImageByUrl: function (url, encode) {
            return this.getExternalImagesByUrl([url], encode)
                .then(function (urls) {
                    return urls[0];
                });
        },

        /**
         * Get array of images from Choreo proxy
         *
         * @name Choreo#getExternalImagesByUrl
         * @function
         *
         * @param {Array} urls
         * @param {Boolean} [encode]
         *
         * @returns {jQuery.Deferred}
         */
        getExternalImagesByUrl: function (urls, encode) {
            var _this = this,
                proxiedLinks = [];
            encode = !!encode;

            return this.getParams()
                .then(function (params) {
                    $.each(urls, function (index, url) {
                        if (!url) {
                            proxiedLinks.push('');
                        } else {
                            proxiedLinks.push(
                                params.url + '/mip_services/core/api/1.0/miscellaneous/image?' +
                                $.param({
                                    to_encode: encode,
                                    auth_token: params.headers['Auth-Token'],
                                    mip_id: params.headers['Mip-Id'],
                                    image_url: url.replace(/ /g, '%20')
                                })
                            );
                        }
                    });

                    //if we need encoded images - then we should fetch all base64 data from Choreo
                    if (encode) {
                        var queue = proxiedLinks.map(function (url, key) {
                            //TODO set small timeout for fast resolve
                            var def = $.Deferred();
                            _this._transport.sendRequest({
                                method: "GET",
                                path: "choreo",
                                url: url
                            })
                                .then(function (data) {
                                    proxiedLinks[key] = data;
                                }, function () {
                                    proxiedLinks[key] = '';
                                })
                                .always(function () {
                                    def.resolve();
                                });

                            return def.promise();
                        });

                        return $.when.apply(null, queue).then(function () {
                            return proxiedLinks;
                        });
                    } else {
                        return proxiedLinks;
                    }
                });
        },

        /**
         * @TODO add some kind of cache
         *
         * Get Choreo request parameters.
         *
         * @name Choreo#getParams
         * @function
         *
         * @returns {jQuery.Deferred}
         */
        getParams: function () {
            var _this = this;
            if (!this._cachedParams) {

                this._cachedParams = this._profile.getClientGateway()
                    .done(function () {
                        setTimeout(function () {
                            _this._cachedParams = null;
                        }, 60000);
                    });
            }
            return _this._cachedParams;
        },

        /**
         * Terminate all current requests for appName if specified or all current commands
         * May be used when application changes route or shutting down
         *
         * @name Choreo#abortApplicationRequests
         * @this Choreo
         * @function
         *
         */
        abortApplicationRequests: function(){
            this._transport.abortRequests();
        }

    }).extend(Events);
});
define('aq/errorHandler',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    
    var eventMap = {};

    return EventEmitter.extend({
        init: function (dependencies) {
            this.Popup = dependencies.popup;
            this.Profile = dependencies.profile;
            this.homeApp = dependencies.homeApp;
            this.translation = dependencies.translation;
            
            // Loop through all dependencies and create a map of object -> eventName
            _.each(dependencies, function (anObject, objectName) {
                if (anObject.events) {
                    _.each(anObject.events, function (internalEvtName, externalEvtName) {
                        // build a name of possible eventHandler
                        var handlerName = "_" + externalEvtName + "EventHandler";
                        if (!eventMap[objectName]) {
                            eventMap[objectName] = {};
                        }
                        eventMap[objectName][externalEvtName] = {
                            internalEvtName: internalEvtName,
                            handler: handlerName,
                            self: anObject
                        };
                    });
                }
            });
            
            // FIXME: Once moved to some config, replace "AQ"
            this.translation.initLocale("aq");
            
            this.handle();
        },

        /**
         * Attach event listeners to all possible events defined in each component passed in dependencies
         * 
         * @public
         * @return void
         */
        handle: function () {
            _.each(eventMap, function (objectEvents) {                
                _.each(objectEvents, function (evtConfig) {
                    if (_.isFunction(this[evtConfig.handler])) {
                        this.listenTo(evtConfig.self, evtConfig.internalEvtName, this[evtConfig.handler]);
                    }
                }, this);
            }, this);
        },

        /**
         * Choreo Event Hadler
         * 
         * @param data {Object}
         * @private
         * 
         * @return void
         */
        _choreoEventHandler: function (data) {
            this._handleError(data && data.code);
        },
        
        /**
         * Shows a popup with text determined from errorCode passed as argument
         * 
         * @param {string|number} errorCode
         * @private
         * 
         * @return void
         */
        _handleError: function (errorCode) {
            var title = $.t(['error', errorCode, 'title'].join('.'), {defaultValue: ''});
            var text = $.t(['error', errorCode, 'text'].join('.'), {
                defaultValue: $.t('error.generic.text')
            });
            
            this.showPopup({title: title, text: text}, 35000);
        },

        /**
         * Shows a popup with passed text.
         * 
         * Popup will close after `delay` time (seconds) if passed.
         * Additionally and `action` could be passed - what should happen after popup is closed,
         * by default user will be redirected back to the main Home page with available application list.
         * 
         * @param text {String}
         * @param delay {Number}. Optional. Delay in seconds after which an `action` will be triggered.
         * @param action {String} Optional. Defines which action should be done after popup is closed.
         * 
         * @public
         * 
         * @return {Popup}
         */
        showPopup: function (texts, delay, action) {
            var popup = new this.Popup();

            action = action || this.homeApp.renderHomeScreen.bind(this.homeApp, null);

            popup.render({
                title: texts.title,
                text: texts.text,
                buttons: [popup.buttons.exit]
            });

            this.listenToOnce(popup.display, popup.events.close, action);

            if (delay) {
                _.delay(action, delay);
            }

            return popup;
        }
    });
});

/**
 * Dependency injection container
 */
define('aq/dic',['require','aq/di','aq/storage','aq/view','aq/api/hu/audio','aq/api/hu/vr','aq/api/hu/navigation','aq/utils','aq/api/progressCounter','aq/api/logger','aq/api/commandControl','aq/appManager','aq/api/hap/appContainer','aq/translation','aq/images','aq/constants','aq/api/hap/fileManager','aq/api/hap/fileReporter','aq/api/hap/reports/firstUsageReport','aq/api/hap/reports/idcEventsReport','aq/api/hu/reportMetadata','aq/api/hu/baseMetaReporter','aq/api/hu/metaReporters/firstUsageMetaReporter','aq/api/hu/metaReporters/idcEventsMetaReporter','aq/api/hap/profile','aq/api/hu/controls','aq/api/hu/screen','aq/templates/processor','aq/api/transport/transport','aq/api/transport/ios','aq/api/transport/android','aq/api/transport/queue','aq/api/choreo','aq/errorHandler'],function (require) {
    'use strict';

    var Dic = require('aq/di');

    return new Dic({

        storage: function () {
            var Storage = require('aq/storage');
            return (this.registry.storage = new Storage(
                this.get('transport'),
                this.get('constants'),
                this.get('utils')
            ));
        },

        display: function () {
            var View = require('aq/view');
            this.registry.display = new View({
                utils:             this.get('utils'),
                storage:           this.get('storage'),
                constants:         this.get('constants'),
                controls:          this.get('controls'),
                screen:            this.get('screen'),
                appManager:        this.get('appManager'),
                TemplateProcessor: this.get('TemplateProcessor'),
                Logger:            this.get('Logger')
            });
            return this.registry.display;
        },

        audio: function () {
            var Audio = require('aq/api/hu/audio');
            return (this.registry.audio = new Audio(this.get('transport')));
        },

        vr: function () {
            var VR = require('aq/api/hu/vr');
            return (this.registry.vr = new VR(
                this.get('transport'), this.get('utils'), this.get('constants')));
        },

        navigation: function () {
            var Navigation = require('aq/api/hu/navigation');
            return (this.registry.navigation = new Navigation(this.get('transport')));
        },

        utils: function () {
            var utils = require('aq/utils');
            return (this.registry.utils = utils);
        },

        progressCounter: function() {
            var ProgressCounter = require('aq/api/progressCounter');
            return (this.registry.progressCounter = ProgressCounter);
        },

        Logger: function () {
            var Logger = require('aq/api/logger');
            return Logger.bind(Logger, this.get('transport'));
        },

        CommandControl: function () {
            return require('aq/api/commandControl');
        },

        /////////////////////////////////////

        appManager: function () {
            var AppManager = require('aq/appManager');
            var appManager = new AppManager({
                dic:         this,
                constants:   this.get('constants'),
                translation: this.get('translation')
            });

            return (this.registry.appManager = appManager);
        },

        appContainer: function () {
            var AppContainer = require('aq/api/hap/appContainer');
            return (this.registry.appContainer = new AppContainer(this.get('transport')));
        },

        translation: function () {
            var Translation = require('aq/translation');
            return (this.registry.translation = new Translation(
                this.get('profile'), this.get('constants'), this.get('navigation')));
        },

        images: function () {
            var Images = require('aq/images');
            return (this.registry.images = new Images(
                this.get('storage'),
                this.get('screen'),
                this.get('profile'),
                this.get('constants'),
                this.get('Logger')
            ));
        },

        constants: function () {
            return require('aq/constants');
        },

        fileManager: function () {
            var FileManager = require('aq/api/hap/fileManager');
            return (this.registry.fileManager = new FileManager({
                    transport:   this.get('transport'),
                    huMetaData:  this.get('reportMetadata'),
                    Logger:      this.get('Logger')
                }));
        },

        fileReporter: function () {
            var FileReporter = require('aq/api/hap/fileReporter');
            return (this.registry.fileReporter = new FileReporter({
                initData: {
                    transport:   this.get('transport'),
                    huMetaData:  this.get('reportMetadata'),
                    Logger:      this.get('Logger'),
                    fileManager: this.get('fileManager')
                },
                reports: {
                    firstUsageReport: require('aq/api/hap/reports/firstUsageReport'),
                    idcEventsReport: require('aq/api/hap/reports/idcEventsReport')
                }
            }));
        },

        reportMetadata: function () {
            var ReportMetadata = require('aq/api/hu/reportMetadata');
            return (this.registry.reportMetadata = new ReportMetadata({
                initData: {
                    transport:   this.get('transport'),
                    Logger:      this.get('Logger'),
                    controls: this.get('controls'),
                    appManager: this.get('appManager')
                },
                metaReporters: {
                    baseMetaReporter: require('aq/api/hu/baseMetaReporter'),
                    firstUsageMetaReporter: require('aq/api/hu/metaReporters/firstUsageMetaReporter'),
                    idcEventsMetaReporter: require('aq/api/hu/metaReporters/idcEventsMetaReporter')
                }
            }));
        },

        profile: function () {
            var Profile = require('aq/api/hap/profile');
            return (this.registry.profile = new Profile(this.get('transport')));
        },

        controls: function () {
            var Controls = require('aq/api/hu/controls');
            this.registry.controls = new Controls(this.get('storage'), this.get('constants'), this.get('transport'));
            return this.registry.controls;
        },

        screen: function () {
            var Screen = require('aq/api/hu/screen');
            this.registry.screen = new Screen({
                transport: this.get('transport'),
                storage: this.get('storage'),
                utils: this.get('utils'),
                constants: this.get('constants'),
                appManager: this.get('appManager')
            });
            return this.registry.screen;
        },

        TemplateProcessor: function () {
            return require('aq/templates/processor');
        },

        transport: function () {
            var Transport = require('aq/api/transport/transport'),
                utils = this.get('utils'),
                platform = utils.getPlatform() === 'ios' ? require('aq/api/transport/ios')
                    : require('aq/api/transport/android');

            this.registry.transport = new Transport(
                utils, require('aq/api/transport/queue'), platform
            );

            return this.registry.transport;
        },

        Choreo: function () {
            return require('aq/api/choreo');
        },
        
        ErrorHandler: function() {
            return require('aq/errorHandler');
        }

    });
});

define('vp2c/home/appList',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        events: {
            start: 'start'
        },

        init: function (options) {
            this.constants = options.constants;
            this.vr = options.vr;
            this.appManager = options.appManager;
            this.profile = options.profile;
            this.display = options.display;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'APP_LIST');
            this.Popup = options.Popup;
            this.firstUsageReport = options.fileReporter.reports.firstUsageReport;
            /**
             * [{
             *   appName: {string},
             *   appDisplayName: {string},
             *   appCategory: {string},
             *   appPath: {string}
             * }, ...]
             *
             */
            this.applications = [];
            this.needToRestart = false;
            this.profileSyncError = 0;

            this.profile.on(this.profile.events.profileStateChange, this.onProfileSyncStart, this);
            this.profile.on(this.profile.events.choreoError, this.onProfileSyncError, this);
            this.profile.on(this.profile.events.appModeStateChange, this.onAppModeStateChange, this);

            this.appManager.on(this.appManager.events.showHomeScreen, this.showHomeScreen, this);

            this.profile.ready();
        },

        /**
         *
         * SWITCH_BTN_TYPES: {
         *   hard_btn: true,
         *   soft_btn: false
         * }
         *
         */
        appSwitchBtnType: null,

        /**
         *  key - value map
         *  key - zipId (assets_zipId)
         *  value - appName
         */
        zipIds: {},
        lastProfileSyncStatus: null,

        showHomeScreen: function (fetchAppList) {
            this.getAvailableApps(fetchAppList)
                .done(this.goToHomeScreen.bind(this));
        },

        startApplicationBy: function () {
            throw new Error('Abstract method');
        },

        goToHomeScreen: function () {
            throw new Error('Abstract method');
        },

        getAvailableApps: function (force) {
            return _.isEmpty(this.applications) || force ?
                this.profile.getApplicationList().done(this.saveAvailableApps.bind(this)) :
                $.when(this.applications);
        },

        saveAvailableApps: function (apps) {
            apps = _.isArray(apps) ? apps : [];

            //alphabethize apps array
            if (apps.length) {
                apps = _.sortBy(apps, function(appObj){
                    return appObj.appDisplayName.toLowerCase();
                });
            }

            this.applications = apps.map(function (item) {
                item.appName = item.appName ? item.appName.toLowerCase() : '';
                return item;
            });
            this._setVrAppLaunchByListOfApps(this.applications);
        },

        startApp: function (appName, appCategory) {
            this.logger.log({'start::app': appName});

            this.stopListening();
            this.appManager.switchApp(appName, appCategory);

            this.logger.log({'started::app': appName});
        },

        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state;
            this.logger.log({'onAppModeStateChange': state});

            if (response.data.state === 'start' && !_.isEmpty(this.applications)) {
                this._setVrAppLaunchByListOfApps(this.applications);
            }
            this._super(state);
        },
        
        onProfileSyncError: function (response){
            var errorCode = response.data.code;
            this.profileSyncError = errorCode;
            this._handleError(this.profileSyncError);
        },

        onProfileSyncStart: function (response) {
            var content = response.data || {},
                profileSyncStatus = content.state;

            this.logger.log({'onProfileSyncStart': content});
            this.profileSyncInProgress = true;

            switch (profileSyncStatus) {
            case "start":
                // todo what should we do when profile sync is started?
                break;

            case "inProgress":
                // todo need to put "aq" to constants
                // if host lib (AQ) updated - need to reload the page
                if (_.findWhere(content.updatingApps, {appName: 'aq'}) ||
                    _.findWhere(content.newApps, {appName: 'aq'})) {
                    this.needToRestart = true;
                    break;
                }

                // destroy applications that were loaded previously because of new version is available
                if (!_.isEmpty(content.updatingApps)) {
                    _.each(content.updatingApps, function (app) {
                        this.logger.log({'app:destroyed': app.appName});
                        this.appManager.destroyApp(app.appName.toLowerCase());
                    }, this);
                }
                break;

            case "complete":
                if (this.needToRestart) {
                    this.logger.log('[HMI][Re-Initialize][Refresh]');
                    window.location.reload();
                    break;
                } else if(this.profileSyncError){
                    break;
                }

                this.profileSyncInProgress = false;
                this.saveAvailableApps(content.availableApps);
                this.startApplicationBy();
                
                var currentAppName = this.appManager.getCurrentApplicationName(),
                    homeAppName = this.constants.APP_NAME_MAP.uconnect;
                this.logger.log('before configs loaded:');
                this.logger.log({'appName' : currentAppName});
                this.logger.log({'currentAppName' : currentAppName});

                if (currentAppName === homeAppName) {
                    this.loadAppConfigs()
                        .done(function () {
                        this.logger.log({'configs loaded:': this.zipIds});
                        this.appManager.saveImageArchives(this.zipIds);
                    }.bind(this))
                        .fail(function () {
                        this.logger.log('HMI app configs are not loaded:');
                    }.bind(this));
                }

                break;

            default:
                // todo if something get wrong - trigger profile sync again
            }
        },

        renderHomeScreen: function (apps) {
            // home app name is needed to be set to prevent
            // other apps render calls to take focus from the background
            this._setHomeAppName();

            apps = apps || this.applications;
            var template = this._getHomeTemplate();
            _.each(apps, function (app) {

                // TODO manually filter out aq from appList
                if (app.appName !== 'aq') {
                    template.templateContent.list.push({
                        action: this.events.start,
                        value: app,
                        text: app.appDisplayName || '',
                        image1: 'file:///' + app.appName + '/images/launcher.png'
                    });
                }
            }, this);
            //apps.length = 1 is consider empty app list
            //which conflict with the same format sent for screen refresh
            //thus, don't do partial update when app list is empty.
            if(apps.length === 1){
                template.ignorePartialUpdate = true;
            }
            this.display.updateScreen(template);
            this.startListening();
        },


        /**
         * save first use data if every time application is used
         * do not save data if app runs twice and more times in a row
         * @param appName - application that was clicked on appList
         */
        writeFirstUsageReport: function (appName) {
            var appData = this.appManager.apps[appName];
            if (((!appData || appData.status !== this.constants.APP_STATUS.SUSPENDED)&&
                this.firstUsageReport.reportIsReady())) {
                this.logger.log({'Ready to write first use data: ': appName});
                this.firstUsageReport.writeReport(this.constants.APP_NAME_MAP[appName]);
            }
        },

        _setHomeAppName: function () {
            var currentAppName = this.appManager.getCurrentApplicationName(),
                homeAppName = this.constants.APP_NAME_MAP.uconnect;

            if (currentAppName !== homeAppName) {
                this.appManager.setCurrentApplicationName(homeAppName);
            }

            return true;
        },

        _getHomeTemplate: function () {
            return {
                templateId: 'vp2c-3',
                loadingType: 3,
                templateContent: {
                    // TODO i18n
                    title: {
                        text: 'Via Mobile'
                    },
                    list: []
                }
            };
        },

        /**
         * loading configs for all available HMI apps
         * @returns {deferred}
         */
        loadAppConfigs: function () {
            var dfd = $.Deferred(),
                dfdList = [];
            this.getAvailableApps().done(function () {
                _.each(this.applications, function (app) {
                    dfdList.push(this.generateAppConfigLoadDfd(app.appName));
                }, this);
                $.when.apply(null, dfdList).done(dfd.resolve).fail(dfd.reject);
            }.bind(this)).fail(dfd.reject);
            return dfd.promise();
        },

        /**
         * @param appName
         * @returns {deferred}
         * loading config file for HMI application appName and getting
         */
        generateAppConfigLoadDfd: function (appName) {
            var path = this.constants.RELATIVE_APP_PATH(appName),
                configFile = this.constants.APP_CONFIG_NAME;

            return $.getJSON(path.concat(configFile))
                .done(function (cfgFile) {
                    var appId = parseInt(cfgFile.appId, 10),
                        imageVersion = cfgFile.imageVersion,
                        platform,
                        zipId;
                    if (appName === 'aq') {
                        platform = cfgFile.platform;
                        this.appManager.setPlatform(platform);
                    }
                    //sending zip only for the next HMI applications (Slacker, Pandora, Iheartradio)
                    if (imageVersion) {
                        zipId = appId.toString() + imageVersion.toString();
                        this.zipIds[parseInt(zipId, 10)] = appName;
                    }
                    this.logger.log({'config for app: ': appName});
                    this.logger.log({'zipId for app: ': zipId});
                    this.logger.log({'appId for app: ': appId});
                    this.logger.log(cfgFile);
                }.bind(this))
                .fail(function () {
                    this.logger.log({'config for app: ': appName});
                }.bind(this));
        },

        /**
         * Handle errors
         * @param {string|number} errorCode
         */
        _handleError: function (errorCode) {
            this.translation.reloadLocale("aq"); //Without reloading, current locale may not be AQ
            var text = $.t(['error', errorCode, 'text'].join('.'), {
                    defaultValue: $.t('error.generic.text')
                });

            this.showPopup(text);
        },

        showPopup: function (text, delay, action) {
            var popup = new this.Popup(),
                currentAppName = this.appManager.getCurrentApplicationName(),
                homeAppName = this.constants.APP_NAME_MAP.uconnect;

            action = action || this.renderHomeScreen.bind(this, null);

            if (currentAppName !== homeAppName) {
                action = this.appManager.startAppAfterAppSwitchFailure.bind(this.appManager);
            }

            popup.render({
                title: '',
                text: text,
                buttons: [popup.buttons.exit]
            });

            this.listenToOnce(popup.display, popup.events.close, action);

            if (delay) {
                _.delay(action, delay);
            }

            return popup;
        }

    });
});

/**
 * TODO rewrite this module later
 * iOS appList modules responsible for appLaunch and appContainer switching
 */

define('vp2c/home/ios/appList',['vp2c/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        // TODO move to constants
        homeApplicationContainerName: 'uconnect',

        /**
         * IOS error (appSwitch in case of screen locked device)
         */
        SCREEN_LOCKED_ERROR_CODE: 10008,

        init: function (options) {
            this.display = options.display;
            this.translation = options.translation;
            this.appContainer = options.appContainer;
            this._super(options);
            
            
            this.translation.initLocale("aq").then(function(){
                this.appContainer.getApplicationContainerName().done(function (containerName) {
                    if (containerName === this.homeApplicationContainerName && !this.profileSyncInProgress) {
                        this.showLoading();
                    }
                }.bind(this));
            }.bind(this));
            
            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.switchApplicationContainerTo(null, handsetAppName);
            }.bind(this));
            
            return this;
        },
        
        showLoading: function(){
            this.translation.reloadLocale("aq");
            var text = $.t('loading');
            this.display.showLoading(text);
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                this.switchApplicationContainerTo(data.value.appName);
            });
        },

        /**
         *
         * @param response.data.state {String} state === 'start' || state === 'resume' || state === 'exit'
         * @param response.data.typeOfScreen {Boolean} typeOfScreen === true || typeOfScreen === false
         */
        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state,
                typeOfScreen = response && response.data && response.data.typeOfScreen;

            this.appSwitchBtnType = typeOfScreen ? this.constants.SWITCH_BTN_TYPES.hard_btn :
                this.constants.SWITCH_BTN_TYPES.soft_btn;

            if (state === 'start' && !this.profileSyncInProgress) {
                this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen before ready: ': state});
                // ready will trigger profile sync or not trigger (iOS only)
                this.profile.ready();
            }
            this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen: ': state});

            //not render home screen(and switch to oem branded app) because HU lost focus
            // (the user clicks the apps button)
            //but render on resume state so that we are able to let user press phone button and let current application
            //running
            if (state === 'resume' && this.appSwitchBtnType) {
                this.logger.log({'onAppModeStateChangeInIos ': state});
                this.goToHomeScreen();
            }
        },

        startApplicationBy: function () {
            this.translation.initLocale("aq")
                .then(this.startApplicationByCurrentContainerName.bind(this));
        },

        /**
         * Switch to OEM app or just show homeScreen
         */
        goToHomeScreen: function () {
            this.logger.log({'goToHomeScreen': 'goToHomeScreen'});

            this.appContainer.getApplicationContainerName().done(function (containerName) {
                this.logger.log({'container': containerName});
                this.logger.log({'currentApp': this.homeApplicationContainerName});

                if (containerName === this.homeApplicationContainerName) {
                    this.display.resetScreen();
                    this.renderHomeScreen();
                } else {
                    this.switchApplicationContainerTo(null, this.homeApplicationContainerName);
                }

            }.bind(this));
        },

        renderHomeScreen: function () {
            var parent = this;
            var parentSuper = this._super;

            this.getAvailableApps().done(function () {
                //TODO For some reason, the this context here is no longer AppList,
                //     thus generate undefined error from calling this._super()
                parentSuper.apply(parent);
            }.bind(this));
        },

        /**
         * @param appName
         * @param handsetAppName
         */
        switchApplicationContainerTo: function (appName, handsetAppName) {
            var appNameMap = this.constants.APP_NAME_MAP;

            appName = appName || _.invert(appNameMap)[handsetAppName];
            handsetAppName = handsetAppName || appNameMap[appName];

            if (handsetAppName !== this.homeApplicationContainerName) {
                this.writeFirstUsageReport(appName);
            }

            // if handsetAppName defined - we need to switch to this smartphone app
            if (handsetAppName) {
                this.logger.log({'switchApplicationContainerTo': handsetAppName});
                this.appContainer.sendAppSwitchEvent().done(function () {
                    this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });
                    this.appContainer.switchApplicationContainerTo(handsetAppName)
                    .done(function(){
                            this.showLoading();
                        }.bind(this))
                    .fail(function (content) {
                        	var errorCode = content.error && content.error.code;
                            this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });

                            //show error popup from UCONECT to HMI APP
                            if (errorCode === this.SCREEN_LOCKED_ERROR_CODE) {
                                errorCode = (handsetAppName !== this.homeApplicationContainerName) ? 'switchToUAA' : 'switchToPartner';
                                this._handleError(errorCode);
                            }
                    }.bind(this));
                }.bind(this));
            } else {
                this.logger.log({'no handset app name': "no handset"});
                this.logger.log({'app name': "app name"});

                this.startApp(appName);
            }
        },

        _setVrAppLaunchByListOfApps: function (apps) {
            var appName = this.appManager.getCurrentApplicationName();
            //avoid setting vr commands when user is on pandora IOS (there is only one HMI Pandora)
            if (appName === this.constants.APP_NAME_MAP.uconnect) {
                this.vr.setVrAppLaunchByListOfApps(apps);
            }
        },

        /**
         * If we in OEM app - just show appList,
         * otherwise show loading and switch to needed container
         *
         * Invoked:
         *  - on profile sync complete
         */
        startApplicationByCurrentContainerName: function () {
            var appNameMap = _.invert(this.constants.APP_NAME_MAP);
            this.logger.log({'startApplicationByCurrentContainerName': ''});

            this.appContainer.getApplicationContainerName().done(function (containerName) {

                this.logger.log({'startApplicationByCurrentContainerName': containerName});

                this.display.resetScreen();

                if (containerName === this.homeApplicationContainerName) {
                    this.logger.log({'renderHomeScreen': 'render apps list'});
                    this.renderHomeScreen();
                } else {
                    this.logger.log({'startApp': appNameMap[containerName]});
                    this.startApp(appNameMap[containerName]);
                }

            }.bind(this));
        }

    });
});
define('vp2c/home/android/appList',['vp2c/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        events: {
            start: 'start'
        },


        init: function (options) {
            this.translation = options.translation;
            this.translation.initLocale("aq");
            this._super(options);
            this.getAvailableApps().done(this.startApplicationBy.bind(this));

            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.startApp(_.invert(this.constants.APP_NAME_MAP)[handsetAppName]);
            }.bind(this));

            return this;
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                var app = data.value || {};

                //avoid reporting for template suite
                if (app.appCategory === 'Music') {
                    this.writeFirstUsageReport(app.appName);
                }
                this.startApp(app.appName, app.appCategory);
            });
        },

        onAppModeStateChange: function (data) {
            var state =  data.data && data.data.state;
            var typeOfScreen = data.data && data.data.typeOfScreen;
            
            this.appSwitchBtnType = typeOfScreen ? this.constants.SWITCH_BTN_TYPES.hard_btn :
                this.constants.SWITCH_BTN_TYPES.soft_btn;
            // re-render home screen because HU just started or resumed from another screen
            // todo should we render home screen when HU focus is lost?
            if (state !== 'exit' && this.appSwitchBtnType) {
                this.display.resetScreen();
                this.renderHomeScreen();
            }
        },

        startApplicationBy: function () {
            this.appManager.suspendApp();
            this.renderHomeScreen.apply(this, arguments);
        },

        /**
         * @param apps - list of app to set vr grammars on HU
         * @private
         */
        _setVrAppLaunchByListOfApps: function (apps) {
            this.vr.setVrAppLaunchByListOfApps(apps);
        },

        goToHomeScreen: function () {
            this.renderHomeScreen.apply(this, arguments);
        }
    });
});
// Since we have vp2c as a base for all other platforms, we don't do anything here but should return extend-able class
define('common/view/base_extension',['aq/eventEmitter'], function (EventEmitter) {
    return EventEmitter;
});

define('common/view/base',['common/view/config', 'aq/eventEmitter', 'aq/dic', 'common/view/base_extension'],
    function (Config, EventEmitter, dic, PlatformExtension) {
    'use strict';

    var appManager;
    //var constants = dic.get('constants'); // FIXME: Not used?

    return EventEmitter.extend({

        /**
         * View options
         */
        useButtonsBranding: true,

        branding: Config.buttonsBranding,
        maxButtonsInStripe: Config.maxButtonsInPlayerStripe || 6,

        init: function (display, options) {
            options = options || {};
            this.useButtonsBranding = options.useButtonsBranding || this.useButtonsBranding;
            //setting appName in case of aq templates branding
            this.appName = options.appName;
            this.display = display;
            if(options.branding) {
                this.branding = this._updateSubProperty(this.branding, options.branding);
            }
        },

        updateScreen: function (template) {
            template = this.useButtonsBranding ? this.applyButtonsBranding(template) : template;
            this._template = $.extend(true, {}, template);
            return this.display.updateScreen(template);
        },

        /**
         * On alpha jump (ABC jump) press
         */
        onAlphaJump: function () {
            this.showKeyboard();
        },

        showKeyboard: function (keyboardBgImg1, keyboardBgImg2) {
            this.display.showKeyboard(keyboardBgImg1, keyboardBgImg2);
            this.listenTo(this.display, this.display.getKeyboardButtonEventName(), this._onKeyboardButtonPressed);
            this.trigger('keyboard:shown');
        },

        hideKeyboard: function () {
            this.updateScreen(this._template);
            if (this.startListening) this.startListening();
            this.trigger('keyboard:hidden');
        },

        applyButtonsBranding: function (template) {
            // Lazy load. We need this to be able to run unit tests without Error about calling
            // "undefined" while evaluating window.android.exec and window.android.log methods.
            // FIXME: Base view should not know anything about appManager...
            if (_.isUndefined(appManager)) {
                appManager = require('aq/dic').get('appManager');
            }

            var appName = appManager.getCurrentApplicationName(),
                branding = this.branding[template.templateId];

            // apply buttons branding only if buttons set
            if (template.templateContent.buttons) {
                template.templateContent.buttons =
                    this._applyCommonBranding(template.templateContent.buttons, branding, appName);
            }

            return template;
        },

        /**
         *
         * @param buttons {Object} Numeric collection of buttons
         * @param branding {Object}
         * @param appName {String}
         * @returns {Object} Numeric collection of buttons
         * @private
         */
        _applyCommonBranding: function (buttons, branding, appName) {
            appName = this.appName ? this.appName : appName;
            var pathToButtonsBrandingPressedState = 'file:///' + appName + this.branding.path,
                // todo move to constants
                pathToButtonsBrandingNormalState = 'file:///aq/images/buttons/normal/',
                getStripeButtonNameByKey = this._getStripeButtonNameByKey(buttons);

            _.each(buttons, function (button, key) {
                // overwrite default backgroundImage
                if (!button.backgroundImage) {
                    button.backgroundImage = {
                        normal: pathToButtonsBrandingNormalState +
                            (branding[key] || getStripeButtonNameByKey(key)) + '.png',
                        pressed: pathToButtonsBrandingPressedState +
                            (branding[key] || getStripeButtonNameByKey(key)) + '.png'
                    };
                }
            });

            return buttons;
        },

        _getStripeButtonNameByKey: function (buttons) {
            var buttonsStripeCount = _.filter(buttons, function (button, key) {
                    return parseInt(key, 10) <= this.maxButtonsInStripe;
                }, this).length;

            return function (key) {
                key = parseInt(key, 10);
                var postfix = (key === 1) ? 'left' : key === buttonsStripeCount ? 'right' : 'center';
                return 'stripe_' + buttonsStripeCount + '_' + postfix;
            };
        },

        /**
         * Handle click on a button in the Keyboard popup
         * @param data
         * @returns {*}
         * @private
         */
        _onKeyboardButtonPressed: function (data) {
            var input = "" + data.letter,
            templateContent = this._template.templateContent;

            // pressed close button
            if (!input || input === 'exit' || input === 'null') {
                return this.hideKeyboard();
            }

            var letter = input.toUpperCase();
            letter = letter[0] || "";

            // sort items
            var items = _.isArray(templateContent.list) ? templateContent.list : templateContent.list.items;
            items = _.isArray(items) ? items : [];
            
            // select item to match lower and upper cases
            var index = _.sortedIndex(_.pluck(items, 'text'), letter, function (item) {
                return item[0].toUpperCase().charCodeAt(0);
            });
            
            // Workaround for Pandora's MyStation list where first element is always Shuffle thus should be skipped,
            // in other words, index should be shift by one if the very first element should be highlighted
            if (items[0] && items[0].text && (items[0].text.toLowerCase().indexOf("shuffle") !== -1) && index === 0) {
                index++;
            }

            // update template with the new sorted items and set activeListItem
            templateContent.list = {
                activeListItem: index,
                items: items
            };

            this.hideKeyboard();
        },

        /**
        *
        * Update common subproperties such as 'branding'
        * @param propertyToUpdate {Object}
        * @param updateWith {Object}
        *
        **/
        _updateSubProperty: function(propertyToUpdate, updateWith) {
            _.each(updateWith, function(newValue, keyToUpdate) {
                if (propertyToUpdate.hasOwnProperty(keyToUpdate)) {
                    if (typeof propertyToUpdate[keyToUpdate] === 'object') {
                        propertyToUpdate[keyToUpdate] = this._updateSubProperty(propertyToUpdate[keyToUpdate],
                            newValue);
                    }
                    else {
                        propertyToUpdate[keyToUpdate] = newValue;
                    }
                }
            }, this);

            return propertyToUpdate;
        },

        bindScrollEvent: function () {
            this.display.startListenTo(this.display.getScrollEventName());
        },

        unbindScrollEvent: function () {
            this.display.stopListenTo(this.display.getScrollEventName());
        },

        render: function(options) {
            if (this.config && this.config.appName) {
                if(this.isCurrentApplication(this.config.appName)) {
                    this._render(options);
                }
                else {
                    return false;
                }
            }
            else {
                this._render(options);
            }
        },

        isCurrentApplication: function (appName) {
            if (_.isUndefined(appManager)) {
                appManager = require('aq/dic').get('appManager');
            }
            return appName === appManager.getCurrentApplicationName();
        }
    }).extend(PlatformExtension.prototype);
});

define('vp2c/home/views/popup',['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({
        events: {
            close: 'close'
        },

        images: {
            close: 'file:///aq/images/close.png',
            surface: 'file:///aq/images/surface.png'
        },

        init: function (display) {
            this._super(display, {
                useButtonsBranding: true,
                appName: 'aq'
            });
            this.initButtons();
            this.template = {};
            this.display = display;
        },

        initButtons: function () {
            this.buttons = {
                exit: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                }
            };
        },

        render: function (options) {
            var delay = options.delay;
            this.text = options.text;
            this.title = options.title;

            this.template = this.generateTemplate(options.buttons);
            this.updateScreen(this.template);

            if (delay) {
                _.delay(this._triggerClose.bind(this), delay);
            }
        },

        _triggerClose: function () {
            this.display.trigger(this.events.close);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp2c-1',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }
    });
});
/**
 * Dependency injection container
 */
define('vp2c/dic',['aq/di','aq/dic','vp2c/home/ios/appList','vp2c/home/android/appList','vp2c/home/views/popup'],function () {
    'use strict';

    var Dic = require('aq/di'),
        PlatformServices = require('aq/dic');
    
    return new Dic({
    
        appList: function () {
            var utils = PlatformServices.get('utils'),
                AppList = utils.getPlatform() === 'ios' ? require('vp2c/home/ios/appList') :
                    require('vp2c/home/android/appList');

            PlatformServices.registry.appList = new AppList({
                appManager: PlatformServices.get('appManager'),
                profile: PlatformServices.get('profile'),
                display: PlatformServices.get('display'),
                appContainer: PlatformServices.get('appContainer'),
                constants: PlatformServices.get('constants'),
                vr: PlatformServices.get('vr'),
                Logger: PlatformServices.get('Logger'),
                Popup: this.get('Popup'),
                fileReporter: PlatformServices.get('fileReporter'),
                translation: PlatformServices.get('translation')
            });

            return PlatformServices.registry.appList;
        },

        Popup: function () {
            var Popup = require('vp2c/home/views/popup');
            return Popup.bind.apply(Popup, [null].concat(PlatformServices.get('display')));
        }
    });
});

/**
 * Injectable hook for storing and calculating responsiveness on user actions
 * Not for production builds
 */
define('aq/kpi',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    var KPI = EventEmitter.extend({

        captureEvents: {
            screenUpdate: 'screenUpdate',
            thirdParty: /meha$/,
            // todo add time processing
            saveImages: 'saveImages'
        },

        init: function (dic) {
            this.dic = dic;
            this.transport = this.dic.get('transport');
            this.controls = this.dic.get('controls');

            /**
             * {
             *   seqId: <number>,
             *   hmi: {
             *     receive: <Date>,
             *     respond: [<Date>, <Date>, ...]
             *     thirdParty: [[{start: <Date>, end: <Date>}], ...]
             *   }
             * }
             */
            this.kpi = {};

            /**
             * {
             *    appStart: Date,
             *    appName: app name,
             *    buttonName: 'buttonCommandSend' // button name was requested by AQ
             *  }
             * @type {null}
             */
            this.appStart = null;

            this.listenTo(this.controls, this.controls.events.soft, this.start);
            this.listenTo(this.controls, this.controls.events.hard, this.start);

            // monkey patching, re-write to more elegant solution later
            this._onSendRequest = this.transport._onSendRequest.bind(this.transport);
            this.transport._onSendRequest = this.onSendRequest.bind(this);
            // todo test stuff, remove later
            // this.counter = 1;
        },

        /**
         * capturing any soft or hard btn event
         * Start
         */
        start: function (data) {
            // todo test stuff, remove later
            //data.content.KPI = {
            //    seqId: this.counter++
            //};
            data = data || {};

            if (data.content && data.content.KPI) {
                var buttonName = data.button || data.action;
                this.kpi = data.content.KPI;
                this.kpi.hmi = {
                    buttonName: buttonName,
                    receive: Date.now(),
                    respond: [],
                    diff: [],
                    thirdParty: [[]]
                };
            } else if (data.action === 'start') {
                // click event on app list
                this.appStart = {
                    appStart: Date.now(),
                    appName: data.value.appName,
                    buttonName: 'buttonCommandSend'
                };
            }
        },

        onSendRequest: function (data) {
            var isScreenUpdateEvent = (data.content && data.content.type) === this.captureEvents.screenUpdate;

            if (this.kpi && this.kpi.hmi) {
                var dfd = this.transport._requests._queuee[data.requestNumber],
                    kpi = this.kpi,
                    screenUpdateCount = kpi.hmi.respond.length,
                    thirdParty = kpi.hmi.thirdParty,
                    thirdPartyEnd,
                    respondEnd,
                    thirdPartyStart,
                    index;

                if (this.captureEvents.thirdParty.test(data.path)) {
                    thirdPartyStart = Date.now();
                    index = thirdParty[screenUpdateCount].push({start: thirdPartyStart});

                    dfd.always(function () {
                        thirdPartyEnd = thirdParty[screenUpdateCount][index - 1].end = Date.now();
                        thirdParty[screenUpdateCount][index - 1].diff = thirdPartyEnd - thirdPartyStart;
                    });
                } else if (isScreenUpdateEvent) {
                    respondEnd = Date.now();
                    kpi.hmi.respond.push(respondEnd);
                    thirdParty.push([]);

                    if (kpi.hmi.diff.length === 0) {
                        kpi.hmi.diff.push(respondEnd - kpi.hmi.receive);
                    }
                    data.content.KPI = this.kpi;
                }
            // logging app start on first screenUpdate
            } else if (this.appStart && isScreenUpdateEvent) {
                data.content.KPI = {
                    hmi: this.appStart
                };
                this.appStart = null;
            }
            this._onSendRequest(data);
        }
    });

    return {
        init: function (dic) {
            return new KPI(dic);
        }
    };
});
/**
 *
 */
define('vp2c/aq',['require','aq/dic','vp2c/dic','aq/kpi','jsperanto'],function (require) {
    'use strict';

    var PlatformServices = require('aq/dic'),
        VP2CServices = require('vp2c/dic');
    
    require('aq/kpi').init(PlatformServices);
    require('jsperanto');


    var commonLogger = new (PlatformServices.get('Logger'))('med', 'WEB_VIEW', 'CORE');
    window.onerror = function (errorMsg, url, lineNumber, columnNumber, error) {
        commonLogger.error("[HMI][ERROR]: "+ url +" line "+ lineNumber +": "+ errorMsg);
        if (error) {
            commonLogger.error("[HMI][ERROR][TRACE]: " + error.stack);
        }
    };

    commonLogger.log({
        msg: 'HMI CORE initialized',
        version: 'Version: 2.15.9'
    });

    // creation order is important

    // cache images
    PlatformServices.create('images');

    // request available applications
    // and notify HAP that HMI is ready to process messages
    VP2CServices.create('appList');
});


//# sourceMappingURL=app.js.map