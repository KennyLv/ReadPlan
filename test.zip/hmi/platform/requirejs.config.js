requirejs.config({

    baseUrl: "./",

    paths: {
        almond: "core/lib/almond/almond",
        jquery: "core/lib/jquery/jquery",
        jsperanto: "core/lib/jsperanto/jquery.jsperanto",
        underscore: "core/lib/underscore/underscore",
        uuid: "core/lib/node-uuid/uuid"
    },

    deps: ["almond", "jquery", "jsperanto", "underscore", "uuid"],

    findNestedDependencies: true,
    useStrict: true,
    removeCombined: true,

    packages: [{
        name: "aq",
        location: "core/src"
    }, {
        name: "shared",
        location: "core/modules/shared"
    }, {
        name: 'common',
        location: '../common'
    }]
});
