module.exports = function(grunt) {
    "use strict";

    var platform = grunt.option("platform") || "vp2c";

    /**
     * Version is taken from Jenkins' parameters set before each build,
     * this is what "process.env.<app-name>" means.
     * Version could be specified either for each particular app (ex: aq=1.2.3, slacker=2.3.4, ..),
     * or for all apps via "aq=1.2.3;slacker=2.3.4;..." argument defined to the build process
     */
    var version = process.env.aq ? ['', process.env.aq] :
            (process.env.versions || "").match(/aq=([^;]+)/),
        manifestVersion = version ? version[1] : "0.0.0";

    var path = require('path'),
        nodeModulesDir = grunt.cli.tasks.some(function (item) {
            return item.indexOf('chdir') !== -1;
        }) ? '../' : '';

    grunt.file.expand(path.join(nodeModulesDir, 'node_modules/grunt-*/tasks')).forEach(function (aTask) {
        grunt.loadTasks(aTask);
    });

    var checkCircularDependencies = function (data) {
        var madge = require("madge"),
            circular = madge([data.path], {
                format: "amd",
                optimized: true
            }).circular(),
            isCyclic = circular.getArray().length;

        if (isCyclic) {
            circular.getArray().forEach(function (path) {
                path.forEach(function (module, idx) {
                    if (idx) {
                        process.stdout.write(" -> ");
                    }
                    process.stdout.write(module);
                });
                process.stdout.write("\n");
            });
            grunt.fail.fatal("Circular dependencies detected");
        }
    };

    var extendWithVp4Commands = function (commandsSiquenceArray, platform) {
        if (platform === 'vp4') {
            //pushing VP4 release commands to commands array
            commandsSiquenceArray.splice(
                commandsSiquenceArray.indexOf("clean:assets") + 1,
                0,
                "casper:signJar:--jarFilePath=" + grunt.config.get('archiveFilePath'));
        }

        return commandsSiquenceArray;
    };

    var b2bConfig = {
            b2bRegions: {
                NORTH_AMERICA_USA: { text: 'United States',
                                     toProcess: process.env.us !== "false"},
                NORTH_AMERICA_CA:  { text: 'Canada',
                                     toProcess: process.env.ca !== "false"},
                MEXICO:            { text: 'Mexico',
                                     toProcess: process.env.mx !== "false"}
            },
            hupVersion: process.env.hupVersion || '2.0'
    };

    var config = grunt.initConfig({

        app: grunt.file.readJSON(platform + "/resources/app.json"),
        version: "<%= app.version %>",
        appId: "<%= parseInt(app.appId, 10) %>",
        imageVersion: "<%= parseInt(app.imageVersion, 10) %>",

        buildFolder: "dist",

        moduleName: "aq",
        moduleFileName: "app.js",
        moduleHtml: "index.html",
        moduleFolder: "<%= buildFolder %>/<%= moduleName %>",
        moduleMetadata: 'metadata',
        assetsDirName: 'assets',
        archiveType: (platform !== 'vp4') ? 'zip' : 'jar',
        archiveFilePath: "<%= moduleFolder %>/<%= assetsDirName %>_<%= imageVersion %>.<%= archiveType %>",

        jshint: {
            options: {
                jshintrc: "../.jshintrc"
            },
            all: [
                "core/src/**/*.js"
            ]
        },

        copy: {
            configs: {
                files: [{
                    flatten: true,
                    expand: true,
                    cwd: platform + "/hmiapps/",
                    src: "config.js",
                    dest: "../common/view/"
                }, {
                    flatten: true,
                    expand: true,
                    cwd: platform + "/hmiapps/common/view/",
                    src: "base_extension.js",
                    dest: "../common/view/"
                }]
            },
            resources: {
                expand: true,
                cwd: platform + "/resources",
                src: "**",
                dest: "<%= moduleFolder %>/"
            },
            release: {
                flatten: true,
                expand: true,
                src: ["<%= moduleFolder %>.zip", platform + "/<%= moduleMetadata %>/*"],
                dest: "<%= moduleFolder %>/"
            }
        },

        symlink: {
            options: {
                overwrite: true
            },
            expanded: {
                files: [
                    {
                        expand: true,
                        cwd: platform,
                        src: ["templates"],
                        dest: "core/src"
                    }
                ]
            }
        },

        requirejs: {
            release: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: [platform + "/<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies
                }
            },
            dev: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: [platform + "/<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    generateSourceMaps: true,
                    optimize: "none"
                }
            }
        },

        replace: {
            version: {
                src: ["<%= moduleFolder %>/<%= moduleHtml %>", "<%= moduleFolder %>/<%= moduleFileName %>"],
                overwrite: true,
                replacements: [{
                    from: "<VERSION>",
                    to: "<%= version %>"
                }]
            },
            release: {
                src: ["<%= buildFolder %>/<%= moduleName %>/MANIFEST.txt"],
                overwrite: true,
                replacements: [{
                    from: "<VERSION>",
                    to: manifestVersion
                },
                {
                    from: "<REGIONS_KEYS>",

                    to: function() {
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey);
                            }
                        }

                        return replaceWith.join(',');
                    }
                },
                {
                    from: "<REGIONS>",
                    to: function(){
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions.hasOwnProperty(regionKey) &&
                                b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey + ':' + b2bConfig.b2bRegions[regionKey].text);
                            }
                        }

                        return replaceWith.join('\n');
                    }
                },
                {
                    from: "<HUP_VERSION>",
                    to: b2bConfig.hupVersion
                }]
            },
            //adds app's version to every log output
            // works only with release task
            releaseWithAppVersionInLogs: {
                src: ["<%= moduleFolder %>/<%= moduleFileName %>"],
                overwrite: true,
                replacements: [{
                    from: /WEB_VIEW","/g,
                    to: function(match){
                            return match.replace(/"$/, '"[' + manifestVersion + ']');
                        }
                }]
            }
        },

        compress: {
            module: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %>.zip",
                    mode: "zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= buildFolder %>/",
                    src: "<%= moduleName %>/**"
                }]
            },
            release: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %><%= version %>.zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= moduleFolder %>",
                    src: "**"
                }]
            },

            //TODO change archive name to assets_imageVersion appId in the next HUP release
            // to look like this (assests_10) where 1 is imageVersion and 0 is appId
            assets: {
                options: {
                    archive: "<%= archiveFilePath %>",
                    mode: "zip"
                },
                files: [{
                    filter: "isFile",
                    expand: true,
                    cwd: "<%= moduleFolder %>/<%= assetsDirName %>/",
                    src: "**",
                    dest: "./"
                }]
            }
        },

        clean: {
            before: ["<%= buildFolder %>"],
            assets: ["<%= moduleFolder %>/<%= assetsDirName %>", "<%= moduleFolder %>/xlet.properties"],
            middle: ["<%= moduleFolder %>"],
            after: ["<%= moduleFolder %>.zip"]
        },

        casper: {
            options : {
                test : false,
                args: [] // NOTE: We need this to be able to pass option to casper
            },
            signJar: {
                src: ["../tools/sign_archive.js"]
            }
        }
    });

    grunt.registerTask("assets", "Prepares jar file with resources (static assets)", function () {
        if (platform !== "vp4") {
            config.archiveType = 'zip';
        }
        var imageMap = config.app.images,
            moduleFolder = path.join(config.buildFolder, config.moduleName),
            resourcesDistDir = path.join(moduleFolder, config.assetsDirName),
            imageIds = Object.keys(imageMap),
            fileList = [];

        grunt.file.mkdir(resourcesDistDir);

        // Regex to extract hmi app name and path to launcher icon
        var regex = new RegExp("^file:\\/\\/\\/(\\w+)\\/(.+)$");

        for (var i = 0, l = imageIds.length; i < l; i++) {
            var imgId = imageIds[i],
                imgPath = imageMap[imgId],
                fileExtension = imgPath.split(".").pop(),
                newFileName = parseInt(config.app.appId + imgId, 10) + "." + fileExtension,
                newFilePath = path.join(resourcesDistDir, "images", newFileName);

            imgPath = imgPath.replace("file:///" + config.moduleName, moduleFolder);

            // NOTE: Launcher icon placed in each particular hmi application under platform specific directory
            if (imgPath.indexOf("launcher.png") !== -1) {
                imgPath = imgPath.replace(regex, platform + "/hmiapps/$1/resources/$2");
            }

            // Because now we have a copy-paste (from VP2C) issues in platform's app.json file, check if file exist
            if (grunt.file.exists(imgPath)) {
                grunt.file.copy(imgPath, newFilePath);
                fileList.push("images/" + newFileName);
            } else {
                console.log("FILE DOES NOT EXIST!", imgPath);
            }
        }

        if (platform === "vp4") {
            grunt.file.copy(platform + "/resources/xlet.properties", resourcesDistDir + "/xlet.properties");
            grunt.file.write(resourcesDistDir + "/manifest.txt", fileList.join("\n"));
        }

        grunt.task.run(["compress:assets"]);
    });


    grunt.registerTask("default", ["release"]);

    grunt.registerTask("dev", ["jshint", "clean:before", "copy:configs", "copy:resources", "symlink",
        "requirejs:dev", "replace:version", "assets", "clean:assets"]);

    grunt.registerTask("release", (extendWithVp4Commands)([
        "jshint", "clean:before", "copy:configs", "copy:resources", "assets",
        "symlink", "requirejs:release",
        "replace:version", "replace:releaseWithAppVersionInLogs", "clean:assets",
        "compress:module", "clean:middle", "copy:release", "replace:release",
        "compress:release", "clean:middle", "clean:after"
    ],platform));

    grunt.registerTask("release-pretty", (extendWithVp4Commands)([
        "jshint", "clean:before", "copy:configs", "copy:resources", "assets", "symlink", "requirejs:dev",
        "replace:version", "clean:assets",
        "compress:module", "clean:middle", "copy:release", "replace:release",
        "compress:release", "clean:middle", "clean:after"
    ],platform));

};
