define('aq/templates/processor',['shared/utils/class',
    'aq/templates/handlers/translator',
    'aq/templates/handlers/partialUpdate',
    'common/view/config',
    'aq/constants'
],
    function (Class, Translator, PartialUpdate, config, constants) {
        'use strict';

        var handlers = [];

        return Class.extend({

            init: function (displayedTemplateData, storage, appManager) {
	    
                displayedTemplateData.LastUpdate = {};

                this.addHandler(new Translator(storage, appManager, config, constants))
                    .addHandler(new PartialUpdate({
                        cache: displayedTemplateData,
                        expand: {
                            buttons: true,
                            // main > main.images and main.text
                            main: true,
                            images: true,
                            text: true
                        }
                    }));
            },

            addHandler: function (handler) {
                handlers.push(handler);
                return this;
            },

            process: function (indata) {
                var data = $.extend(true, {}, indata);
		
                handlers.forEach(function (handler) {
                    data = $.extend(true, {}, handler.translate(data));
                });

                return data;
            }
        });
    });
