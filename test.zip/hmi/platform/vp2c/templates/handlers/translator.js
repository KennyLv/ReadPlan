define('aq/templates/handlers/translator',['shared/utils/class',
        'aq/templates/handlers/translators/vp2c-1',
        'aq/templates/handlers/translators/vp2c-2',
        'aq/templates/handlers/translators/vp2c-3',
        'aq/templates/handlers/translators/vp2c-5',
        'aq/templates/handlers/translators/vp2c-6',
        'aq/templates/handlers/translators/vp2c-7',
        'aq/templates/handlers/translators/vp2c-8',
        'aq/templates/handlers/translators/vp2c-9',
        'aq/templates/handlers/translators/vp2c-10'
    ],
    function (Class) {
    'use strict';

    var templates = Array.prototype.slice.call(arguments, 1),
        screenId = 1;

    return Class.extend({

        init: function (storage, appManager, config, consntants) {
            this.appManager = appManager;
            this.storage = storage;
            this.templateTypes = {};
            _.each(templates, function (Template) {
                var tpl = new Template(storage, appManager, config, consntants);
                this.templateTypes[tpl.templateName.toLowerCase()] = tpl;
                console.log("===========================" + tpl.templateName.toLowerCase() + "-----" + tpl);
            }, this);
        },

        translate: function (data) {
            // Clear actions map
            this.storage.clearActions();

            var OEMAppId = 0x9999;
            data.appId = parseInt(this.appManager.getActiveAppId(), 10) || OEMAppId;
            data.screenId = screenId++;

            /** Loading type:
             *   * 1 - show loading screen while populating the screen;
             *         hide loading once everything is loaded including images.
             *   * 2 - show loading while loading text, and hide it;
             *         Images will be displayed dynamically as downloaded.
             *   * 3 - do not show loading animation during screen transition.
             */
            data.loadingType = _.contains([1,2,3], data.loadingType) ? data.loadingType : 1;

            data.systemHeader = !!data.systemHeader;

            data.backgroundImage = this.storage.getImageId({
                data: data.backgroundImage,
                w: 400,
                h: 240
            });

	    console.log("======================in Translator==========================================");
	    console.log(data.templateId.toLowerCase());
	    
            var template = this.templateTypes[data.templateId.toLowerCase()];

            return template ? template.translate(data) : null;
        }
    });
});
