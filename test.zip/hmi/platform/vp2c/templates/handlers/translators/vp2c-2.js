/*
 *  Template VP2C-6
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-6",
 *      "backgroundImage" : <number>,
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 7
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "3": <string>
 *              },
 *              "images": {
 *                  "1" : <number>,
 *                  ... 2
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_7  |                                    |
 *   |-----------------------------------------------|
 *   |   _____________                               |
 *   |  |             |                              |
 *   |  |             |  text_1                      |
 *   |  |  images_1   |  text_2                      |
 *   |  |             |  text_3                      |
 *   |  |             |                              |
 *   |  |_____________|                              |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 *
 */

define('aq/templates/handlers/translators/vp2c-2',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 61, h: 52}, // TODO could be dynamic
        // 7
        button: {w: 52, h: 44},

        mainImageItem: {w: 75, h: 75},
        sideImageItem: {w: 25, h: 25},
        titleImage: {w: 329, h: 30}
    };

    return Base.extend({

        templateName: 'vp2c-2',

        buttons: _.range(1, 8),

        translate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = this.getButtons(buttons);


            content.main = content.main || {};
            content.main.text = content.main.text || {};
            template.main = {};

            var item,
                items = {};
            for (var i = 1; i < 4; i++) {
                item = content.main.text[i] || {};
                items[i] = item.text || '';
            }
            template.main.text = items;


            template.main.images = this.getImages(content.main.images);
            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            // progress bar
            template.progress = {};
            if (content.progress && content.progress.total) {
                template.progress = {
                    total: content.progress.total,
                    current: content.progress.elapsed / content.progress.total,
                    color: content.progress.color,
                    active: content.progress.active
                };
            }

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 7, 7), CONSTANTS.button)
            );
        },

        getImages: function (templateImages) {
            var images = {};
            templateImages = templateImages || {};

            images[1] =  this.storage.getImageId({
                data: templateImages[1],
                w: CONSTANTS.mainImageItem.w,
                h: CONSTANTS.mainImageItem.h
            });

            images[2] =  this.storage.getImageId({
                data: templateImages[2],
                w: CONSTANTS.sideImageItem.w,
                h: CONSTANTS.sideImageItem.h
            });

            return images;
        }

    });
});