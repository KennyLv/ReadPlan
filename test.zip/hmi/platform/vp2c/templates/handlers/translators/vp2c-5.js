/*
 *  Template VP2C-5
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-5",
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 10
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *    _______________________________________________
 *   |   but_10  |                                   |
 *   |-----------------------------------------------|
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_1    | |   but_2    | |   but_3    | |
 *   |  |____________| |____________| |____________| |
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_4    | |   but_5    | |   but_6    | |
 *   |  |____________| |____________| |____________| |
 *   |_______________________________________________|
 *
 */

define('aq/templates/handlers/translators/vp2c-5',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        bigButton: {w: 122, h: 57}, // buttons 1 - 9
        button: {w: 72, h: 52}, // button 10
        titleImage: {w: 376, h: 75}
    };

    return Base.extend({

        templateName: 'vp2c-5',

        buttons: _.range(1, 11),

        translate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 9), CONSTANTS.bigButton),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.button)
            );

            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            return this._super(data, template);
        }
    });
});