/*
 *  Template VP2C-6
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-6",
 *      "templateContent" : {
 *          "title": {
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 9
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "2": <string>
 *              },
 *              "images": {
 *                  "1" : <number>
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_7  |                                    |
 *   |-----------------------------------------------|
 *   | ____   _____________                     ____ |
 *   |     | |             |                   |     |
 *   |     | |             |  text_1           |     |
 *   | b_8 | | main_image  |  text_2           | b_9 |
 *   |     | |             |  text_3           |     |
 *   | ____| |             |                   |____ |
 *   |       |_____________|                         |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 */

define('aq/templates/handlers/translators/vp2c-6',['aq/templates/handlers/translators/vp2c-2'], function (Player) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 61, h: 52}, // TODO could be dynamic
        // 8, 9
        sideButton: {w: 52, h: 52},
        // 7
        button: {w: 52, h: 44},

        mainImageItem: { w: 75, h: 75},
        titleImage: {w: 324, h: 32}
    };

    return Player.extend({

        templateName: 'vp2c-6',

        buttons: _.range(1, 10),

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 7, 7), CONSTANTS.button),
                this.processButtons(this.filterByRange(buttons, 8, 9), CONSTANTS.sideButton)
            );
        },

        getImages: function (templateImages) {
            var images = {};
            templateImages = templateImages || {};

            images[1] = this.storage.getImageId({
                data: templateImages[1],
                w: CONSTANTS.mainImageItem.w,
                h: CONSTANTS.mainImageItem.h
            });

            return images;
        }

    });
});