/*
 *  Popup with images
 *  Template VP2C-7
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-7"
 *      "templateContent" : {
 *          "main": {
 *              "text": {
 *                  "1": <string>,
 *                  ... 3
 *              },
 *              "images": {
 *                  "1": <number>
 *              }
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *             ... 4
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 */

define('aq/templates/handlers/translators/vp2c-7',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        imageSize: {w: 75, h: 75},
        buttons: {
            1: { w: 52, h: 52},
            2: {w: 75, h: 52},
            // 3 - 4
            standard: {w: 118, h: 52}
        }
    };

    return Base.extend({

        templateName: 'vp2c-7',

        buttons: _.range(1, 5),

        translate: function (data) {

            var template = {}, key,
                content = data.templateContent;

            content.main = content.main || {};
            content.main.text = content.main.text || {};
            content.main.images = content.main.images || {};

            template.main = {
                text: {},
                images: {}
            };

            for (key = 1; key < 4; key++) {
                template.main.text[key] =  content.main.text[key] || "";
            }

            template.main.images[1] = this.storage.getImageId(_.extend({
                data: content.main.images[1]
            }, CONSTANTS.imageSize));

            template.buttons = this.getButtons(content.buttons);

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons[1]),
                this.processButtons(this.filterByRange(buttons, 2, 2), CONSTANTS.buttons[2]),
                this.processButtons(this.filterByRange(buttons, 3, 4), CONSTANTS.buttons.standard)
            );
        }
    });
});