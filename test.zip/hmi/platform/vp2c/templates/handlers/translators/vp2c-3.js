/*
 *  Template VP2C-3
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-3",
 *      "templateContent" : {
 *          "title" : {
 *              "text": <string>
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "scrollUp": <boolean>,
 *                  "scrollDown": <boolean>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              ... 10
 *          },
 *          "list": {
 *              "activeListItem" : <int>, //index in the array of the element to be highlighted. Defaults to null.
 *              "items": [{
 *                  "image1": <number>,
 *                  "image2": <number>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              }, ...]
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  Text char limit in list is 16 (truncated by HU)
 *  Title char limit is 16
 *
 *   ________________________________________________
 *  | _____   |         title                   |    |
 *  ||b_200|  |---------------------------------| /\ |
 *  ||_____|  |                                 |    |
 *  |         | img1 | text              | img2 |    |
 *  | _____   |                                 |    |
 *  || b_2 |  | img1 | text              | img2 |    |
 *  ||_____|  |                                 |    |
 *  | _____   | img1 | text              | img2 |    |
 *  || b_1 |  |                                 |    |
 *  ||_____|  | img1 | text              | img2 | \/ |
 *  |_________|_________________________________|____|
 *
 */

define('aq/templates/handlers/translators/vp2c-3',['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, utils) {
    'use strict';

    var CONSTANTS = {
        titleCharLimit: 16,
        itemIconSize: {w: 32, h: 32},
        buttonSize: {w: 72, h: 52},
        listItemId: 101
    };

    return Base.extend({

        templateName: 'vp2c-3',

        buttons: _.range(1, 11),

        translate: function (data) {
            var template = {},
                content = data.templateContent,
                /**
                 *
                 * {
                 *   title: string,
                 *   cursorColor: 'hex color', // using hardware scroll
                 *   pressedHighlightColor: 'hex color',
                 *   selectedHighlightColor: 'hex color',
                 * }
                 */


                title = _.isUndefined(content.title) ? '' : (content.title.text || content.title),
                scrollPressedStateImage = this.storage.getImageId({
                    data: this._getScrollPressedState() || '',
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

            template.ignorePartialUpdate = data.ignorePartialUpdate || false;

            template.title = {
                text: utils.ellipsis(title, CONSTANTS.titleCharLimit),
                pressedHighlightColor: this._getListBranding(),
                selectedHighlightColor: this._getListBranding(),
                scrollPressedState: scrollPressedStateImage
            };

            var items = content.list.items || (_.isArray(content.list) ? content.list : []);
            template.list = {
                activeListItem: _.isNumber(content.list && content.list.activeListItem) ?
                    content.list.activeListItem : null,
                items: this.processListItems(items)
            };

            // 1 - 10
            template.buttons = this.processButtons(content.buttons, CONSTANTS.buttonSize);

            return this._super(data, template);
        },

        processListItems: function (content) {
            var list = [];
            content = _.isArray(content) ? content : [];

            content.forEach(function (listItem, key) {

                var item = {};

                var leftImage = listItem.image || listItem.image1,
                    rightImage = listItem.image2;


                item.image1 = this.storage.getImageId({
                    data: leftImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.image2 = this.storage.getImageId({
                    data: rightImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.text = _.isString(listItem.text) ? listItem.text : "";

                //Save list actions
                if (listItem.action !== undefined || listItem.value !== undefined) {
                    this.storage.addAction(key + CONSTANTS.listItemId, listItem.action, listItem.value);
                }

                list.push(item);

            }, this);

            return list;
        },

        _getScrollPressedState: function () {
            var appName = this.appManager.getCurrentApplicationName(),
                pathToButtonsBrandingPressedState;
            //appName for homeList 'uconnect' has to be changed to 'aq' (in file system)
            appName = appName === this.constants.APP_NAME_MAP.uconnect ? 'aq' : appName;
            pathToButtonsBrandingPressedState = 'file:///' + appName + this.buttonsBranding.path;

            return pathToButtonsBrandingPressedState + this.buttonsBranding.scrollBranding + '.png';
        },

        _getListBranding: function () {
            return this.constants.APP_LIST_COLOR.VP2C[this.appManager.getCurrentApplicationName()];
        }

    });
});
