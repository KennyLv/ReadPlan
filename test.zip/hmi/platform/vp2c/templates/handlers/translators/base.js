define('aq/templates/handlers/translators/base',['shared/utils/class'], function (Class) {
    'use strict';

    var EMPTY_IMAGE_ID = 0;

    return Class.extend({

        buttons: [],

        init: function (storage, appManager, config, constants) {
            this.storage = storage;
            this.appManager = appManager;
            this.buttonsBranding = config.buttonsBranding;
            this.constants = constants;
        },

        translate: function (data, processedTemplate) {
            processedTemplate.buttons = this.ensureButtons(processedTemplate.buttons);
            data.templateContent = processedTemplate;
            return data;
        },

        ensureButtons: function (buttons) {
            var defaults = _.object(this.buttons, this.buttons.map(Object.bind({}, {})));
            return _.defaults(buttons, defaults);
        },

        processButtons: function (content, buttonSize) {
            var button = {},
                buttons = {};
            content = content || {};
            
            _.each(content, function (item, key) {
                button = {};

                item.image = item.image || '';
                item.backgroundImage = item.backgroundImage || '';

                button.image = {
                    normal: this.storage.getImageId(_.extend({
                        data: item.image.normal || item.image
                    }, buttonSize)),

                    pressed: this.storage.getImageId(_.extend({
                        data: item.image.pressed
                    }, buttonSize))
                };

                button.backgroundImage = {
                    normal: this.storage.getImageId(_.extend({
                        data: item.backgroundImage.normal || item.backgroundImage
                    }, buttonSize)),

                    pressed: this.storage.getImageId(_.extend({
                        data: item.backgroundImage.pressed
                    }, buttonSize))
                };

                if (_.isString(item.text)) {
                    button.text = item.text;
                }

                // defined as true if no stateEnabled
                button.stateEnabled = _.isUndefined(item.stateEnabled) ? true : item.stateEnabled;

                button.scrollUp = !!item.scrollUp;
                button.scrollDown = !!item.scrollDown;

                // save button in case it's not empty
                if (button.image.normal !== EMPTY_IMAGE_ID || button.backgroundImage.normal !== EMPTY_IMAGE_ID ||
                    button.text || button.scrollUp || button.scrollDown) {

                    buttons[key] = button;

                    // Save button actions
                    if (item.action !== undefined || item.value !== undefined) {
                        this.storage.addAction(parseInt(key, 10), item.action, item.value);
                    }
                }

            }, this);

            return buttons;
        },

        /**
         *
         * Filter out from object-like-array key-values pairs that between "from" and "to" indexes
         * For example: filterByRange({1: true, 2: true, 3: false}, 2, 3) =>
         *                  {2: true, 3: false}
         *
         * @param items {object}
         * @param from {number}
         * @param to {number}
         * @returns {object}
         */
        filterByRange: function (items, from, to) {
            return _.reduce(items, function (memo, value, key) {
                if (key >= from && key <= to) {
                    memo[key] = value;
                }
                return memo;
            }, {});
        }
    });
});
