/*
 *  Popup
 *  Template VP2C-1
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-1"
 *      "templateContent" : {
 *          "title" : {
 *              "text": <string>
 *          },
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              }
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
  *             ... 6
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  main text char limit is 85
 *  buttons text char limit is 14
 *    _______________________________________________
 *   |                                               |
 *   |-----------------------------------------------|
 *   |   _________________________________________   |
 *   |  |                                         |  |
 *   |  |              title                      |  |
 *   |  |                                         |  |
 *   |  |            main text                    |  |
 *   |  |                                         |  |
 *   |  | --------------------------------------- |  |
 *   |  |   button   |    button     |   button   |  |
 *   |  |_________________________________________|  |
 *   |_______________________________________________|
 *
 */

define('aq/templates/handlers/translators/vp2c-1',['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, utils) {
    'use strict';

    var CONSTANTS = {
        buttons: {
            // 1
            left: {w: 52, h: 52},
            // 2 - 3
            center: {w: 118, h: 52},
            // 4 - 6
            threesome: {w: 106, h: 52}
        }
    };

    return Base.extend({

        templateName: 'vp2c-1',

        mainTextCharLimit: 85,

        buttons: _.range(1, 7),

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.title = content.title || '';
            template.title = {
                text: content.title.text || content.title
            };

            content.main = content.main || {};
            var text = _.isObject(content.main.text) ? content.main.text[1] : content.main.text;
            template.main = {
                text: {
                    1: utils.ellipsis(text, this.mainTextCharLimit)
                }
            };
            template.buttons = this.getButtons(content.buttons);

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons.left),
                this.processButtons(this.filterByRange(buttons, 2, 3), CONSTANTS.buttons.center),
                this.processButtons(this.filterByRange(buttons, 4, 6), CONSTANTS.buttons.threesome)
            );
        }
    });
});