/*
 * Template VP2C-8
 * Loading screen
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-8"
 *      "templateContent" : {
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              },
 *              "images": {
 *                  "1": <number>
 *              }
 *          }
 *      }
 *  }
 *
 *
 *
 *  item_1 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |                                               |
 *   |                 _____________                 |
 *   |                |             |                |
 *   |                |             |                |
 *   |                |  image_1    |                |
 *   |                |             |                |
 *   |                |_____________|                |
 *   |                                               |
 *   |                     text_1                    |
 *   |_______________________________________________|

 *
 *
 *
 */


define('aq/templates/handlers/translators/vp2c-8',['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // on first launch if set to 75x75
        // images can be resized by HUP to 75x39
        mainImageItem: { w: 230, h: 120}
    };

    return Base.extend({

        templateName: 'vp2c-8',

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.main = content.main || {};
            template.main = {};

            if (content.main.images && content.main.images[1]) {
                template.main.images = {
                    1: this.storage.getImageId(_.extend({
                        data: content.main.images[1]
                    }, CONSTANTS.mainImageItem))
                };
            }
            if (content.main.text && content.main.text[1]) {
                template.main.text = template.main.text || {};
                template.main.text[1] = content.main.text[1];
            }

            data.templateContent = template;
            return data;
        }
    });
});
