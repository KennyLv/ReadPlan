/**
 * Dependency injection container
 */
define('vp2c/dic',['aq/di','aq/dic','vp2c/home/ios/appList','vp2c/home/android/appList','vp2c/home/views/popup'],function () {
    'use strict';

    var Dic = require('aq/di'),
        PlatformServices = require('aq/dic');
    
    return new Dic({
    
        appList: function () {
            var utils = PlatformServices.get('utils'),
                AppList = utils.getPlatform() === 'ios' ? require('vp2c/home/ios/appList') :
                    require('vp2c/home/android/appList');
					
            PlatformServices.registry.appList = new AppList({
                appManager: PlatformServices.get('appManager'),
                profile: PlatformServices.get('profile'),
                display: PlatformServices.get('display'),
                appContainer: PlatformServices.get('appContainer'),
                constants: PlatformServices.get('constants'),
                vr: PlatformServices.get('vr'),
                Logger: PlatformServices.get('Logger'),
                Popup: this.get('Popup'),
                fileReporter: PlatformServices.get('fileReporter'),
                translation: PlatformServices.get('translation')
            });

            return PlatformServices.registry.appList;
        },

        Popup: function () {
            var Popup = require('vp2c/home/views/popup');
            return Popup.bind.apply(Popup, [null].concat(PlatformServices.get('display')));
        }
    });
});
