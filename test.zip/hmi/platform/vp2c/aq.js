/**
 *
 */
define('vp2c/aq',['require','aq/dic','vp2c/dic','aq/kpi','jsperanto'],function (require) {
    'use strict';

    var PlatformServices = require('aq/dic'),
        VP2CServices = require('vp2c/dic');
    
    require('aq/kpi').init(PlatformServices);
    require('jsperanto');


    var commonLogger = new (PlatformServices.get('Logger'))('med', 'WEB_VIEW', 'CORE');
    window.onerror = function (errorMsg, url, lineNumber, columnNumber, error) {
        commonLogger.error("[HMI][ERROR]: "+ url +" line "+ lineNumber +": "+ errorMsg);
        if (error) {
            commonLogger.error("[HMI][ERROR][TRACE]: " + error.stack);
        }
    };

    commonLogger.log({
        msg: 'HMI CORE initialized',
        version: 'Version: <VERSION>'
    });

    // creation order is important

    // cache images
    PlatformServices.create('images');

    // request available applications
    // and notify HAP that HMI is ready to process messages
    VP2CServices.create('appList');
});
