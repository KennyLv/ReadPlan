/**
 * TODO rewrite this module later
 * iOS appList modules responsible for appLaunch and appContainer switching
 */

define('vp2c/home/ios/appList',['vp2c/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        // TODO move to constants
        homeApplicationContainerName: 'uconnect',

        /**
         * IOS error (appSwitch in case of screen locked device)
         */
        SCREEN_LOCKED_ERROR_CODE: 10008,

        init: function (options) {
            this.display = options.display;
            this.translation = options.translation;
            this.appContainer = options.appContainer;
            this._super(options);
            
            
            this.translation.initLocale("aq").then(function(){
                this.appContainer.getApplicationContainerName().done(function (containerName) {
                    if (containerName === this.homeApplicationContainerName && !this.profileSyncInProgress) {
                        this.showLoading();
                    }
                }.bind(this));
            }.bind(this));
            
            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.switchApplicationContainerTo(null, handsetAppName);
            }.bind(this));
            
            return this;
        },
        
        showLoading: function(){
            this.translation.reloadLocale("aq");
            var text = $.t('loading');
            this.display.showLoading(text);
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                this.switchApplicationContainerTo(data.value.appName);
            });
        },

        /**
         *
         * @param response.data.state {String} state === 'start' || state === 'resume' || state === 'exit'
         * @param response.data.typeOfScreen {Boolean} typeOfScreen === true || typeOfScreen === false
         */
        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state,
                typeOfScreen = response && response.data && response.data.typeOfScreen;

            this.appSwitchBtnType = typeOfScreen ? this.constants.SWITCH_BTN_TYPES.hard_btn :
                this.constants.SWITCH_BTN_TYPES.soft_btn;

            if (state === 'start' && !this.profileSyncInProgress) {
                this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen before ready: ': state});
                // ready will trigger profile sync or not trigger (iOS only)
                this.profile.ready();
            }
            this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen: ': state});

            //not render home screen(and switch to oem branded app) because HU lost focus
            // (the user clicks the apps button)
            //but render on resume state so that we are able to let user press phone button and let current application
            //running
            if (state === 'resume' && this.appSwitchBtnType) {
                this.logger.log({'onAppModeStateChangeInIos ': state});
                this.goToHomeScreen();
            }
        },

        startApplicationBy: function () {
            this.translation.initLocale("aq")
                .then(this.startApplicationByCurrentContainerName.bind(this));
        },

        /**
         * Switch to OEM app or just show homeScreen
         */
        goToHomeScreen: function () {
            this.logger.log({'goToHomeScreen': 'goToHomeScreen'});

            this.appContainer.getApplicationContainerName().done(function (containerName) {
                this.logger.log({'container': containerName});
                this.logger.log({'currentApp': this.homeApplicationContainerName});

                if (containerName === this.homeApplicationContainerName) {
                    this.display.resetScreen();
                    this.renderHomeScreen();
                } else {
                    this.switchApplicationContainerTo(null, this.homeApplicationContainerName);
                }

            }.bind(this));
        },

        renderHomeScreen: function () {
            var parent = this;
            var parentSuper = this._super;

            this.getAvailableApps().done(function () {
                //TODO For some reason, the this context here is no longer AppList,
                //     thus generate undefined error from calling this._super()
                parentSuper.apply(parent);
            }.bind(this));
        },

        /**
         * @param appName
         * @param handsetAppName
         */
        switchApplicationContainerTo: function (appName, handsetAppName) {
            var appNameMap = this.constants.APP_NAME_MAP;

            appName = appName || _.invert(appNameMap)[handsetAppName];
            handsetAppName = handsetAppName || appNameMap[appName];

            if (handsetAppName !== this.homeApplicationContainerName) {
                this.writeFirstUsageReport(appName);
            }

            // if handsetAppName defined - we need to switch to this smartphone app
            if (handsetAppName) {
                this.logger.log({'switchApplicationContainerTo': handsetAppName});
                this.appContainer.sendAppSwitchEvent().done(function () {
                    this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });
                    this.appContainer.switchApplicationContainerTo(handsetAppName)
                    .done(function(){
                            this.showLoading();
                        }.bind(this))
                    .fail(function (content) {
                        	var errorCode = content.error && content.error.code;
                            this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });

                            //show error popup from UCONECT to HMI APP
                            if (errorCode === this.SCREEN_LOCKED_ERROR_CODE) {
                                errorCode = (handsetAppName !== this.homeApplicationContainerName) ? 'switchToUAA' : 'switchToPartner';
                                this._handleError(errorCode);
                            }
                    }.bind(this));
                }.bind(this));
            } else {
                this.logger.log({'no handset app name': "no handset"});
                this.logger.log({'app name': "app name"});

                this.startApp(appName);
            }
        },

        _setVrAppLaunchByListOfApps: function (apps) {
            var appName = this.appManager.getCurrentApplicationName();
            //avoid setting vr commands when user is on pandora IOS (there is only one HMI Pandora)
            this.appContainer.getApplicationContainerName().done(function (containerName) {
                if (containerName === this.homeApplicationContainerName) {
                    this.vr.setVrAppLaunchByListOfApps(apps);
                }
            }.bind(this));
        },
        /**
         * saving image archives only in case of uconnect application on IOS
         *
         * @private
         */
        _saveImageArchives: function () {
            this.appContainer.getApplicationContainerName().done(function (containerName) {
                if (containerName === this.homeApplicationContainerName) {
                    this.loadAppConfigs()
                        .done(function () {
                            this.logger.log({'configs loaded:': this.zipIds});
                            this.appManager.saveImageArchives(this.zipIds);
                        }.bind(this))
                        .fail(function () {
                            this.logger.log('HMI app configs are not loaded:');
                        }.bind(this));
                }
            }.bind(this));
        },

        /**
         * If we in OEM app - just show appList,
         * otherwise show loading and switch to needed container
         *
         * Invoked:
         *  - on profile sync complete
         */
        startApplicationByCurrentContainerName: function () {
            var appNameMap = _.invert(this.constants.APP_NAME_MAP);
            this.logger.log({'startApplicationByCurrentContainerName': ''});

            this.appContainer.getApplicationContainerName().done(function (containerName) {

                this.logger.log({'startApplicationByCurrentContainerName': containerName});

                this.display.resetScreen();

                if (containerName === this.homeApplicationContainerName) {
                    this.logger.log({'renderHomeScreen': 'render apps list'});
                    this.renderHomeScreen();
                } else {
                    this.logger.log({'startApp': appNameMap[containerName]});
                    this.startApp(appNameMap[containerName]);
                }

            }.bind(this));
        }

    });
});