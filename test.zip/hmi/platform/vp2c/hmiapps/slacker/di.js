define(function () {
    'use strict';

    var Dic = require('aq/di'),
        aq = require('aq/dic'),
        display = aq.get('display'),
        viewOptions = [{
            display:   display,
            config:    require('slacker/config')
        }];

    return new Dic({

        config: {
            module: require('slacker/config')
        },

        apiConstants:{
            module: require('slacker/models/constants')
        },

        commandControl: {
            module: require('slacker/services/commandControl'),
            dependencies: [aq.get('transport')]
        },

        model: function () {
            var Model = require('slacker/models/extension');
            return (this.registry.model = new Model({
                commandControl: this.get('commandControl'),
                trackStorage: this.get('trackStorage')
            }));
        },

        router: function () {
            var Router = require('slacker/router');
            return (this.registry.router = new Router({
                dic: this,
                model: this.get('model'),
                SplashScreen: this.get('Splash'),
                Popup1: this.get('Popup1'),
                display: aq.get('display')
            }));
        },


        trackStorage: function () {
            var Storage = require('slacker/models/storage');
            return (this.registry.trackStorage = new Storage());
        },

        'controller/home': function () {
            var Home = require('slacker/controllers/home');
            return (this.registry['controller/home'] = new Home({
                model: this.get('model'),
                List: this.get('List'),
                Popup1: this.get('Popup1'),
                HomeScreen: this.get('views/homeScreen')
            }));
        },

        'controller/myMusic': function () {
            var Stations = require('slacker/controllers/myMusic');
            return (this.registry['controller/myStations'] = new Stations({
                model: this.get('model'),
                List: this.get('List'),
                Popup1: this.get('Popup1'),
                MyMusicConfig: this.get('MyMusicConfig')
            }));
        },

        'controller/allStations': function () {
            var Stations = require('slacker/controllers/allStations');
            return (this.registry['controller/myStations'] = new Stations({
                model: this.get('model'),
                List: this.get('List'),
                Popup1: this.get('Popup1')
            }));
        },

        'controller/player': function () {
            var Player = require('slacker/controllers/player');
            return (this.registry['controller/player'] = new Player({
                model: this.get('model'),
                Player: this.get('Player'),
                Popup1: this.get('Popup1'),
                Popup2: this.get('Popup2')
            }));
        },

        'views/homeScreen': {
            module: require('slacker/views/homeScreen'),
            dependencies: viewOptions
        },

        Player: {
            module: require('slacker/views/player'),
            dependencies: viewOptions
        },

        Popup1: {
            module: require('slacker/views/common/popup1'),
            dependencies: viewOptions
        },

        Popup2: {
            module: require('slacker/views/common/popup2'),
            dependencies: viewOptions
        },

        List: {
            module: require('slacker/views/common/list'),
            dependencies: viewOptions
        },

        Splash: {
            module: require('slacker/views/common/splashScreen'),
            dependencies: viewOptions
        },

        MyMusicConfig: {
            module: require('slacker/config/myMusicConfig')
        }
    });
});