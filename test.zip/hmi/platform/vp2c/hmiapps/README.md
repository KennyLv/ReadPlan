This directory contains platform specific skins and customizations for each application available in HMIApps repository.
