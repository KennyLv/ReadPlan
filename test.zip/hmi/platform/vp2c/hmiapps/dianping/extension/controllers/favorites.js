define('dianping/controllers/favorites', ['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    
    return EventEmitter.extend({

        init: function (options) {
            this.view = options.view;
            this.config=options.config;
            this.navigation=options.navigation;
            this.Popup = options.popup;
            this.policy = options.policy;
        },
        
        start: function () {
            this.showLocationScreen();
            this.startListening();
        },
        
        startListening: function () {
            this.stopListening();
            this.listenTo(this.view, this.view.events.goBack, this.goBack);
            this.listenTo(this.view, this.view.events.showLocationScreen, this.showLocationScreen);
        },
        
        suspend: function() {
            this.stopListening();
        },
        
        onSuspend: function () {
            this.trigger('suspend');
        },
        
        close: function() {
            this.stopListening();
        },
        
        showLocationScreen: function () {
            var template = this.view.generateTemplate();
            template = this.policy.generateTemplateWithPolicy(template);
            this.view.render(template);
        },
        
        goBack: function() {
            if(this.policy.checkClickExceed()){
                this.config.policyHistory.backButtonEvent = 'show:setLocation';
                this.config.policyHistory.data = null;
                this.trigger('show:popup');
            }else{
                this.trigger('show:menu');
            }
        },
	
        
        showPopup: function (info) {
            var popup = new this.Popup(),
                title = info.code,
                text = info.description;
            popup.render({
                title: title,
                text: text,
                buttons: [popup.buttons.exit,popup.buttons.retry]
            });
            this.config.cacheData.templateId = 'Template4-B';
            var locationType=this.config.cacheData.locationType;
            this.listenToOnce(popup.display, popup.events.retry, this.navigation.goToSetLocation(locationType));
            this.listenToOnce(popup.display, popup.events.close, this.showLocationScreen);
        }
    });
});