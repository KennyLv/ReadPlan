﻿define('dianping/views/favorites', ['dianping/views/common/baseView'], function (View) {
    'use strict';

    return View.extend({
        events: {
            goBack: 'goBack',
            onSuspend: 'onSuspend',
            back : 'goBack',
            seekUp: 'seekUp',
            seekDown:"seekDown",
            showLocationScreen:'showLocationScreen'
        },
        
        locTypes:{
            current:'current',
            destination:'destination'
        },
	
        images: {
				surface: 'file:///dianping/images/black-bg.png',
				back: 'file:///dianping/images/buttons/back.png',
				logo0: 'file:///dianping/images/32x32.png',
				scrollUp: 'file:///dianping/images/buttons/scroll-up.png',
				scrollDown: 'file:///dianping/images/buttons/scroll-down.png'
        },

        init: function (display, config,constants) {
            this.template = {};
            this.display = display;
            this.constants = constants;
            this._super(config);
            if (this.baseEvents) {
                this.events = _.extend(this.events, this.baseEvents);
            }
            this.resetHLDatas();
        },


        render: function (template) {
            this.template = template;
            this.config.cacheData.templateId=this.template.templateId;
            this.start();
        },

        start: function () {
            this.template.ignorePartialUpdate = true;
            this.display.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                if (this[method]) {
                    this.listenTo(this.display, event, this[method].bind(this));
                }
            }, this);
        },

		generateTemplate: function () {
			return {
				templateId: 'vp2c-3',
				backgroundImage: this.images.surface,
				loadingType: 3,
				templateContent: {
					title: $.t("favorites"),
					list : [
						{
							text : '黄焖鸡米饭',
							image1: this.images["logo0"],
							action: this.events.goToResultsList,
							value : "01_dsa_dsa"
						},
						{
							text : '黄焖鸡米饭1',
							image1: this.images["logo0"],
							action: this.events.goToResultsList,
							value : "01_dsa_dsa"
						}
					],
					/*list: [{
						text: {
							text:$.t("curr_location"),
						},
						image1: {
							image:this.locationType===this.locTypes.current?this.images.scrollUp:0,
						},
						action: this.events.goToSetLocation,
						value:this.locTypes.current
					},{
						text: {
							text:$.t("destination"),
						},
						image1: {
							image:this.locationType===this.locTypes.destination?this.images.scrollUp:0,
						},
						action: this.events.goToSetLocation,
						highlight:this.hl_list_index===1?true:false,
						value:this.locTypes.destination
					}],*/
					buttons: {
						1:{
							text: $.t('sort_by_date'),
							image: this.images.back,
							action: this.events.goBack,
							highlight:this.hl_button_index>-1?true:false
						},
						2:{
							text: $.t('sort_by_distance'),
							image: this.images.back,
							action: this.events.goBack,
							highlight:this.hl_button_index>-1?true:false
						}
					}
				}
			};
		},
	
        goBack: function () {
            this.trigger(this.events.goBack);
        },
        
        onSuspend: function () {
            this.trigger(this.events.onSuspend);
        },
	
        resetHLDatas:function(){
            this.hl_type = "list";
            this.hl_list_index = -1;
            this.hl_button_index = -1;
        },
        
        seekUp: function(){
            if(this.hl_type ==='button'){
                if(this.hl_button_index===0){
                    this.hl_type ='list';
                    this.hl_button_index =-1;
                    this.hl_list_index =1;
                }
            }
            else
            {
                if(this.hl_list_index>0){
                    this.hl_list_index = this.hl_list_index-1;
                }
            }
            this.trigger(this.events.showLocationScreen);
        },
        seekDown: function(){
            if(this.hl_type==='list'){
                if(this.hl_list_index>=1){
                    this.hl_type='button';
                    this.hl_button_index=0;
                    this.hl_list_index =-1;
                }
                else{
                    this.hl_list_index = this.hl_list_index+1;
                }
            }
            else
            {
                this.hl_button_index=0;
            }
            this.trigger(this.events.showLocationScreen);
        }
        
    });
});