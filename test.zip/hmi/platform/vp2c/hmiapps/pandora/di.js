define(function (require) {
    'use strict';

    var Dic = require('aq/di'),
        aq = require('aq/dic'),
        display = [aq.get('display')],
        viewOptions = [{
            display:   aq.get('display'),
            config:    require('pandora/config')
        }];

    return new Dic({

        config: {
            module: require('pandora/config')
        },

        commandControl: {
            module: require('pandora/services/commandControl'),
            dependencies: [aq.get('transport')]
        },

        model: function () {
            var Model = require('pandora/models/extension');
            return (this.registry.model = new Model({
                PandoraLink: this.get('PandoraLink'),
                PandoraView: this.get('PandoraView'),
                commandControl: this.get('commandControl'),
                config: this.get('config'),
                reportMetadata: aq.get('reportMetadata')
            }));
        },

        router: function () {
            var Router = require('pandora/router');
            return (this.registry.router = new Router({
                dic: this,
                model: this.get('model'),
                SplashScreen: this.get('Splash')
            }));
        },

        'controller/createStation': function () {
            var CreateStation = require('pandora/controllers/createStation');
            return (this.registry['controller/createStation'] = new CreateStation({
                model: this.get('model'),
                List: this.get('List'),
                Popup: this.get('Popup')
            }));
        },

        'controller/myStations': function () {
            var MyStations = require('pandora/controllers/myStations');
            return (this.registry['controller/myStations'] = new MyStations({
                model: this.get('model'),
                MyStations: this.get('views/myStations'),
                MyStationsInDeleteMode: this.get('views/myStationsInDeleteMode'),
                Popup: this.get('Popup')
            }));
        },

        'controller/player': function () {
            var Player = require('pandora/controllers/player');
            return (this.registry['controller/player'] = new Player({
                model: this.get('model'),
                Player: this.get('views/player'),
                Popup: this.get('Popup')
            }));
        },

        'views/myStations': {
            module: require('pandora/views/myStations'),
            dependencies: viewOptions
        },

        'views/myStationsInDeleteMode': {
            module: require('pandora/views/myStationsInDeleteMode'),
            dependencies: viewOptions
        },

        'views/player': {
            module: require('pandora/views/player'),
            dependencies: viewOptions
        },

        Popup: {
            module: require('pandora/views/common/popup'),
            dependencies: viewOptions
        },

        List: {
            module: require('pandora/views/common/list'),
            dependencies: viewOptions
        },

        Splash: {
            module: require('pandora/views/common/splashScreen'),
            dependencies: viewOptions
        },

        /**
         * Vendor modules
         */
        PandoraLink: {
            module: require('pandora/vendor/PandoraLink')
        },
        PandoraView: {
            module: require('pandora/vendor/PandoraViewWrapper'),
            dependencies: display
        }

    });
});
