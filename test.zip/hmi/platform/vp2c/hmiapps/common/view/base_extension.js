// Since we have vp2c as a base for all other platforms, we don't do anything here but should return extend-able class
define(['aq/eventEmitter'], function (EventEmitter) {
    return EventEmitter;
});
