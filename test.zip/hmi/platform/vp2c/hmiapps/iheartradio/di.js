define(function () {
    'use strict';

    var Dic = require('aq/di'),
        aq = require('aq/dic'),
        display = aq.get('display'),
        viewOptions = [{
            display:   display,
            config:    require('iheartradio/config')
        }];

    return new Dic({

        config: {
            module: require('iheartradio/config')
        },

        commandControl: {
            module: require('iheartradio/services/commandControl'),
            dependencies: [aq.get('transport')]
        },

        model: function () {
            var Model = require('iheartradio/models/model');
            return (this.registry.model = new Model({
                commandControl: this.get('commandControl'),
                config: this.get('config')
            }));
        },

        router: function () {
            var Router = require('iheartradio/router');
            return (this.registry.router = new Router({
                dic: this,
                model: this.get('model')
            }));
        },

        'controller/home': function() {
            var MainScreen = require('iheartradio/controllers/home');
            return (this.registry['controller/home'] = new MainScreen({
                model: this.get('model'),
                Popup: this.get('Popup'),
                MainScreen: this.get('views/home'),
                config: this.get('config')
            }));
        },

        'controller/stationsMenu': function() {
            var StationsMeu = require('iheartradio/controllers/stationsMenu');
            return (this.registry['controller/stationsMenu'] = new StationsMeu({
                model: this.get('model'),
                Popup: this.get('Popup'),
                List: this.get('views/common/list'),
                config: this.get('config')
            }));
        },

        'controller/player': function() {
            var PlayerController = require('iheartradio/controllers/player');
            return (this.registry['controller/player'] = new PlayerController({
                model: this.get('model'),
                Popup: this.get('Popup'),
                Player: this.get('views/player'),
                config: this.get('config')
            }));
        },

        'views/home': {
            module: require('iheartradio/views/home'),
            dependencies: viewOptions
        },

        'views/common/list': {
            module: require('iheartradio/views/common/list'),
            dependencies: viewOptions
        },

        'views/player': {
            module: require('iheartradio/views/player'),
            dependencies: viewOptions
        },

        Popup: {
            module: require('iheartradio/views/common/popup'),
            dependencies: viewOptions
        },

        SplashScreen: {
            module: require('iheartradio/views/common/splashScreen'),
            dependencies: viewOptions
        }
    });
});
