define(['aq/eventEmitter', 'aq/dic'], function (EventEmitter, Dic) {
    'use strict';

    var appManager = Dic.get('appManager');

    var titleBarButtonPostfixMap = {
        10: "left",
        11: "right",
        12: "mid"
    };

    var images = {
        close: 'file:///aq/images/popup/close.png'
    };
    
    var events = {
        close: "close"
    };

    return EventEmitter.extend({
        applyButtonsBranding: function (template) {
            template = this._super(template);

            var appName = appManager.getCurrentApplicationName(),
                branding = this.branding[template.templateId];

            // apply buttons branding only if buttons set
            if (template.templateContent.buttons) {
                template.templateContent.buttons =
                    this._applyTitleBarBranding(template.templateContent.buttons, branding, appName);
            }

            return template;
        },

        _applyTitleBarBranding: function (buttons, branding, appName) {
            appName = this.appName ? this.appName : appName;
            var pathToNormalButtonsBranding = 'file:///' + appName + '/images/titlebar/buttons/normal/',
                pathToPressedButtonsBranding = 'file:///' + appName + '/images/titlebar/buttons/pressed/';
            
            _.each(buttons, function (button, key) {
                var breadcrumbButtonBackground = this._getTitleBarButtonNameByKey(key, 10, 12);
                if (breadcrumbButtonBackground) {
                    button.backgroundImage = {
                        normal: pathToNormalButtonsBranding +
                            breadcrumbButtonBackground + '.png',
                        pressed: pathToPressedButtonsBranding +
                            breadcrumbButtonBackground + '.png'
                    };
                }
            }, this);

            return buttons;
        },

        _getTitleBarButtonNameByKey: function (key, from, to) {
            key = parseInt(key, 10);
            if (key > 0 && key >= from && key <= to) {
                var defaultPostfix = (key === from) ? 'left' : (key === to ? 'right' : 'mid');
                // we may need to redefine namings, thus have a map for IDs which need to be re-named
                return titleBarButtonPostfixMap[key] || defaultPostfix;
            }
            else {
                return null;
            }
        },

        /**
         * @override base method. VP4 HUP does not have native implementation, so regular JSON Template should be sent
         */
        showKeyboard: function (images) {
            var template = this._generateKeyboardLayout(images);
            template = this.useButtonsBranding ? this.applyButtonsBranding(template) : template;
            
            // !!! IMPORTANT NOTE !!!
            // We call update HU directly instead of through `this.updateScreen`,
            // because we do not need to rewrite current this._template instance which is a current list 
            this.display.updateScreen(template);
            this.listenTo(this.display, this.display.getKeyboardButtonEventName(), this._onKeyboardButtonPressed);
            this.listenTo(this.display, events.close, this._onCloseKeyboard);
            this.trigger('keyboard:shown');
        },

        _onCloseKeyboard: function () {
            this.hideKeyboard();
        },

        _generateKeyboardLayout: function (assetsData) {
            return {
                templateId: 'vp4-4',
                backgroundImage: assetsData.surface,
                systemHeader: true,
                templateContent: {
                    buttons:{
                        1: {
                            image: {
                                normal: images.close
                            },
                            action: events.close
                        },
                        2: {
                            text: 'null' // This is just a stub since HUP will be responsible to render switch button 
                        },
                        // This button just to pass information which is applicable for all keyboard buttons
                        3: {
                            text: 'null'
                        }
                    },
                    main: {
                        images: assetsData.main.images
                    }
                }
            };
        }
    });
});
