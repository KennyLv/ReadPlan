define(['pandora/controllers/myStations'], function (BaseMyStations) {
    'use strict';

    return BaseMyStations.extend({

        init: function (options) {
            this._super(_.extend(options, {
                mainAction: this.showMyStations
            }));
            this.model = options.model;
            this.constants = this.model.constants;

            this.MyStaions = options.MyStations;
            this.Popup = options.Popup;
        },

//        start: function () {
//            // if we came here from player screen fetch stations manually
//            if (this.model.getCurrentStatus() !== this.constants.status.PNDR_STATUS_NO_STATION_ACTIVE) {
//                this.model.eventStationList();
//            }
//
//            this.showMyStations();
//
//            // listen on updates from pandora API
//            this.listenTo(this.model, {
//                'update:stationList': this.updateStationList,
//                // CV-1282: Back and Now Playing buttons stay disabled after internet connection was established
//                'show:playerScreen': function () {
//                    this.updateStationList(this.model.getStations());
//                }.bind(this),
//                'show:notice': this.handleNotice,
//                'show:errorStatus': this.handleError
//            });
//        },

        onStationDelete: function (item) {
            if (item.value) {
                var popup = new this.Popup();
                popup.render({
                    title: $.t('popups.stationDelete.title'),
                    text: item.value.stationName,
                    buttons: [popup.buttons.cancel, popup.buttons.deleteStation]
                });
                this.listenToOnce(popup.display,
                    popup.events.close, this.showMyStations);
                this.listenToOnce(popup.display,
                    popup.events.deleteStation,this.onStationDeleteConfirmed.bind(this, item.value));
            }
        },

        onStationDeleteConfirmed: function (station) {
            var stations = this.model.getStations().filter(function (item) {
                return item.stationToken !== station.stationToken;
            });
            this.model.eventStationDelete(station.stationToken);

            // if user deletes the last station the application should
            // show status popup that will offer to create the new station
            if (stations.length === 1) {
                this.model.setCurrentStatus(this.constants.status.PNDR_STATUS_NO_STATIONS);
                this.onGoToCreateStation();
                return;
            }

            this.showMyStations();

            // if the user deletes a station that is currently playing
            // the application should trigger playing the Shuffle All station
            if (this.model.getActiveStationToken() === station.stationToken) {
                var shuffleStation = _.findWhere(this.model.getStations(), {isQuickMix: true});
                this.model.setActiveStationInfo(shuffleStation);
                this.model.eventStationSelect(shuffleStation.stationToken);
            }
        }
    });
});
