define(['pandora/views/player'], function (BasePlayer) {
    'use strict';

    return BasePlayer.extend({

        images: {
            source: 'file:///aq/images/buttons/normal/source.png',
            buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
            barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
            barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
            barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
            surface: 'file:///pandora/images/surface.png',
            logo: 'file:///pandora/images/pandora.png',
            header: 'file:///pandora/images/player/header.png',
            headerBackground: 'file:///pandora/images/titlebar/full.png',
            shared: 'file:///pandora/images/stations/shared.png',
            shuffle: 'file:///pandora/images/stations/shuffle.png',
            thumbsUp: 'file:///pandora/images/player/tup/<%= code %>.png',
            thumbsDown: 'file:///pandora/images/player/tdown/<%= code %>.png',
            myStations: 'file:///pandora/images/player/stations.png',
            skip: 'file:///pandora/images/player/skip.png',
            skipDisabled: 'file:///pandora/images/player/skip_disabled.png',
            bookmarkSelected: 'file:///pandora/images/player/bookmark_selected.png',
            bookmarkUnselected: 'file:///pandora/images/player/bookmark_unselected.png',
            bookmarkDisabled: 'file:///pandora/images/player/bookmark_disabled.png',
            play: 'file:///pandora/images/player/play.png',
            pause: 'file:///pandora/images/player/pause.png'
        },

        generateTemplate: function () {
            return {
                templateId: 'vp4-2',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header,
                        backgroundImage: this.images.headerBackground
                    },
                    buttons: _.extend(this.getButtons(), {
                        10: {
                            image: this.images.source,
                            action: this.events.source
                        }
                    }),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: this.getProgressBar()
                }
            };
        },

        getButtons: function () {
            return {
                1: this.getMyStationsButton(),
                2: this.getThumbUpButton(),
                3: this.getThumbDownButton(),
                4: this.getPlayToggleButton(),
                5: this.getSkipButton(),
                6: this.getBookmarkButton()
            };
        },

        getMyStationsButton: function () {
            return {
                image: {
                    normal: this.images.myStations
                },
                action: this.events.goToMyStations
            };
        },

        /**
         *
         * @returns {Object}
         */
        getThumbUpButton: function () {
            var rating = this.trackInfo ? (this.trackInfo.getAllowRating() && this.trackInfo.getRating()) : false;

            return _.isNumber(rating) ? {
                image: {
                    normal: _.template(this.images.thumbsUp, {code: 1 & rating}),
                    pressed: 0
                },
                action: this.events.likeSong
            } : {
                image: {
                    normal: _.template(this.images.thumbsUp, {code: 'disabled'}),
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        /**
         *
         * @return {Object}
         */
        getThumbDownButton: function () {
            var rating = this.trackInfo ?  (this.trackInfo.getAllowRating() && this.trackInfo.getRating()) : false;
            return _.isNumber(rating) ? {
                image: {
                    normal: _.template(this.images.thumbsDown, {code: 2 & rating}),
                    pressed: 0
                },
                action: this.events.dislikeSong
            } : {
                image: {
                    normal: _.template(this.images.thumbsDown, {code: 'disabled'}),
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        getSkipButton: function () {
            var isSkippEnabled = this.trackInfo ? this.trackInfo.getAllowSkip() : false;
            return {
                image: {
                    normal: isSkippEnabled ? this.images.skip : this.images.skipDisabled,
                    pressed: 0
                },
                action: isSkippEnabled ? this.events.skipSong : '',
                stateEnabled: isSkippEnabled
            };
        },

        getBookmarkButton: function () {
            var isBookmarkEnabled = this.trackInfo && this.trackInfo.getAllowBookmark();

            if (isBookmarkEnabled) {
                var isBookmarked = this.trackInfo.getIsTrackBookmarked();
                return {
                    image: {
                        normal: isBookmarked ? this.images.bookmarkSelected : this.images.bookmarkUnselected,
                        pressed: 0
                    },
                    action: isBookmarked ? '' : this.events.bookmark
                };
            }

            return {
                image: {
                    normal: this.images.bookmarkDisabled,
                    pressed: 0
                },
                stateEnabled: false
            };
        },

        getProgressBar: function () {
            var progressBar = this._super();

            if (progressBar.color) {
                progressBar.color = this.display.constants.APP_LIST_COLOR.VP4.pandora;
            }

            return progressBar;
        },

        getPlayToggleButton: function () {
            var isPlaying = this.model.isPlaying();
            return {
                image: {
                    normal: isPlaying ? this.images.pause : this.images.play,
                    pressed: 0
                },
                action: isPlaying ? this.events.pause : this.events.play
            };
        },

        getImages: function () {
            var isAudioAd = this.trackInfo && this.trackInfo.getIsAudioAd();
            return {
                1: isAudioAd ? this.images.logo : (this.model.getAlbumArt() || this.images.logo),
                2: this.getStationTypeImage(),
                3: this.images.barFrameTop,
                4: this.images.barFrameBottom,
                5: this.images.barFrameRight,
                6: this.images.buttonbarDivider
            };
        },

        getStationTypeImage: function () {
            var info = this.stationInfo || {};
            return info.isQuickMix ? this.images.shuffle :
                info.isShared ? this.images.shared : 0;
        }
    });
});