define(['pandora/../../platform/vp4/hmiapps/pandora/views/common/list', 'pandora/views/myStations'],
    
    function (BaseCustomList, BaseMyStationsList) {
    'use strict';
        
        // 1: We have to mixin everything from original (VP2C) Pandora's My Station list with _.extend({}, ...);
        // and
        // 2: extend from the custom Common List
        
        // TODO: Check if it possible to do the next:
        // Overwrite BaseList with a CustomBaseList declaration
        // _.extend(BaseMyStationList, BaseCustomMyStationList.prototype);
        // 
        // BaseMyStationsList.extend({custom_vp4_my_station_list})
        
        // 1:
        return BaseCustomList
            .extend(_.extend(BaseMyStationsList.prototype, {
                init: function (display, model) {
    
                    this._super(display, model);

                    this.events = _.extend({
                        createStation: 'createStation',
                        deleteClicked: 'onDelete',
                        onAlphaJump: 'onAlphaJump',
                        sortBy: 'onSortBy',
                        removeStation: 'onRemoveStation'
                    }, this.events);
                    
                    // NOTE:
                    // We have to copy-paste everything from VP2C Pandora MyStation list
                    // because those images are extended in runtime, during initiation of object 
                    this.images = _.extend(
                        BaseCustomList.prototype.images,
                        this.images,
                        {
                            active: 'file:///pandora/images/stations/playing.png',
                            alphaJump: 'file:///pandora/images/stations/alpha_jump.png',
                            alphaJumpDisabled: 'file:///pandora/images/stations/alpha_jump_disabled.png',
                            back: 'file:///aq/images/buttons/normal/titlebar_button_back.png',
                            backDisabled: 'file:///aq/images/buttons/normal/titlebar_button_back_disabled.png',
                            createStation: 'file:///pandora/images/stations/buttons/create_station.png',
                            createStationBackgroundNormal: 'file:///pandora/images/stations/buttons/backgrounds/normal/create_station.png',
                            createStationBackgroundPressed: 'file:///pandora/images/stations/buttons/backgrounds/pressed/create_station.png',
                            delete: 'file:///pandora/images/stations/delete.png',
                            shared: 'file:///pandora/images/stations/shared.png',
                            shuffle: 'file:///pandora/images/stations/shuffle.png',
                            sortBy: 'file:///pandora/images/stations/buttons/sortBy/<%= code %>.png',
                            sortByName: 'file:///pandora/images/stations/buttons/sort_by_name.png',
                            sortByDate: 'file:///pandora/images/stations/buttons/sort_by_date.png',
                            sortByNameBackgroundNormal: 'file:///pandora/images/stations/buttons/backgrounds/normal/tab1.png',
                            sortByNameBackgroundPressed: 'file:///pandora/images/stations/buttons/backgrounds/pressed/tab1.png',
                            sortByDateBackgroundNormal: 'file:///pandora/images/stations/buttons/backgrounds/normal/tab2.png',
                            sortByDateBackgroundPressed: 'file:///pandora/images/stations/buttons/backgrounds/pressed/tab2.png',
                            stationsBackground: 'file:///pandora/images/stations/list_background.png',
                            stationsTitleBackground: 'file:///pandora/images/titlebar/small.png',
                            player: 'file:///aq/images/buttons/normal/now_playing.png',
                            playerDisabled: 'file:///aq/images/buttons/normal/now_playing_disabled.png',
                            cursorShort: 'file:///pandora/images/stations/cursor_short.png',
                            cursorShortPressed: 'file:///pandora/images/stations/cursor_short_active.png'
                        }
                    );
                },

                getListCursor: function () {
                    return {
                        image: {
                            normal: this.images.cursorShort,
                            pressed: this.images.cursorShortPressed
                        }
                    };
                },

                getButtons: function () {
                    var buttons = this._super();
                    var sortOrder = this._getSortOrder();
                    
                    return _.extend(buttons, {
                        1: {
                            image: {
                                normal: this.images.sortByName
                            },
                            backgroundImage: {
                                normal: sortOrder === 1 ? this.images.sortByNameBackgroundPressed :
                                    this.images.sortByNameBackgroundNormal,
                                pressed: this.images.sortByNameBackgroundPressed
                            },
                            action: sortOrder === 1 ? '' : this.events.sortBy
                        },
                        2: {
                            image: {
                                normal: this.images.sortByDate
                            },
                            backgroundImage: {
                                normal: sortOrder === 1 ? this.images.sortByDateBackgroundNormal :
                                    this.images.sortByDateBackgroundPressed,
                                pressed: this.images.sortByDateBackgroundPressed
                            },
                            action: sortOrder === 1 ? this.events.sortBy : ''
                        },
                        3:  {
                            image: {
                                normal: this.images.createStation
                            },
                            backgroundImage: {
                                normal: this.images.createStationBackgroundNormal,
                                pressed: this.images.createStationBackgroundPressed
                            },
                            action: this.events.createStation
                        },
                        12: this.getABCJumpButton()
                    });
                },

                /**
                 * @override
                 *
                 * @param items {Array}
                 * @param options {Object}
                 *
                 * @returns {Array}
                 */
                getItems: function (items, options) {
                    items = _.isArray(items) ? items : [];

                    return items.map(function (item, key) {
                        var result = {
                            text: item.text,
                            image1: this.getItemLeftImage(),
                            image2: this.getItemRightImage(item, options),
                            action: options.event || this.events.select,
                            value: item
                        };

                        if (item.allowDelete) {
                            var button = {};
                            button[key] = {
                                image: this.images.delete,
                                action: this.events.deleteClicked,
                                value: item
                            };
                            
                            // Attach buttons to the list item
                            result.buttons = button;
                        }
                        
                        return result;
                    }, this);
                },

                getItemLeftImage: function () {
                    return 0;
                },

                getItemRightImage: function (item, options) {
                    return this._getStationIcon(item, options.active);
                },

                getTitleBackgroundImage: function () {
                    return this.images.stationsTitleBackground;
                },

                deleteClicked: function (item) {
                    this.trigger(this.events.delete, item);
                    this.trigger(this.events.deleteClicked, item);
                },
    
                getImages: function (templateImages) {
                    var images = this._super(templateImages);
                    return _.extend(images, {
                        4: this.images.stationsBackground,
                        6: this.images.delete
                    });
                },
    
                generateTemplate: function (options) {
                    var template = this._super(options);
                    template.templateId = 'vp4-3-1';
    
                    return template;
                },

                /**
                 * This method needed here because of complex inheritance of this View class
                 */
                showKeyboard: function() {
                    this._super();
                }
            })
        );
});
