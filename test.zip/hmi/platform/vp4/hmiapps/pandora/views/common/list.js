define(['pandora/views/common/list', 'common/view/base'], function (BaseList, BaseView) {
    'use strict';
    
    return BaseList.extend({

        images: {
            back: 'file:///aq/images/buttons/normal/titlebar_button_back.png',
            backDisabled: 'file:///aq/images/buttons/normal/titlebar_button_back_disabled.png',
            buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
            listBackground: 'file:///aq/images/list_background.png',
            barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
            barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
            barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
            folder: 'file:///pandora/images/folder.png',
            player: 'file:///aq/images/buttons/normal/now_playing.png',
            playerDisabled: 'file:///aq/images/buttons/normal/now_playing_disabled.png',
            surface: 'file:///pandora/images/surface.png',
            titleBackground: 'file:///pandora/images/titlebar/med.png',
            scrollDownBtn: "file:///aq/images/buttons/normal/scroll_down.png",
            scrollDownBtnDisabled: "file:///aq/images/buttons/normal/scroll_down_disabled.png",
            scrollUpBtn: "file:///aq/images/buttons/normal/scroll_up.png",
            scrollUpBtnDisabled: "file:///aq/images/buttons/normal/scroll_up_disabled.png",
            scrollTrack: "file:///aq/images/scrollbar/slider_bg.png",
            scrollSlider: "file:///aq/images/scrollbar/slider.png",
            listCursorNormal: "file:///pandora/images/list/cursor.png",
            listCursorPressed: "file:///aq/images/list/cursor_active.png",
            abc: "file:///aq/images/popup/abc.png",
            popupModalBg: 'file:///pandora/images/modal_bg.png'
        },

        generateTemplate: function (options) {
            return {
                templateId: 'vp4-3',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: {
                        text: this.title || '',
                        backgroundImage: this.getTitleBackgroundImage()
                    },
                    main: {
                        images: this.getImages()
                    },
                    list: this.getItems(options.items, {active: options.activeStationToken}),
                    buttons: this.getButtons(),
                    cursor: this.getListCursor()
                }
            };
        },

        /**
         * @override
         * 
         * @param items {Array}
         * @param options {Object}
         * 
         * @returns {Array}
         */
        getItems: function (items, options) {
            items = _.isArray(items) ? items : [];
            
            return items.map(function (item) {
                return {
                    text: item.text,
                    image1: this.getItemLeftImage(),
                    image2: this.getItemRightImage(item, options),
                    action: options.event || this.events.select,
                    value: item
                };
            }, this);
        },

        getItemLeftImage: function () {
            return 0;
        },

        getItemRightImage: function (item) {
            return item.hasChildren ? this.images.folder : 0;
        },

        getTitleBackgroundImage: function () {
            return this.images.titleBackground;
        },

        getListCursor: function () {
            return {
                image: {
                    normal: this.images.listCursorNormal,
                    pressed: this.images.listCursorPressed
                }
            };
        },

        getButtons: function () {
            return {
                7: this.getScrollUpButton(),
                8: this.getScrollDownButton(),
                10: this.getBackButton(),
                11: this.getNowPlayingButton()
            };
        },

        getScrollUpButton: function () {
            return {
                image: {
                    normal: this.images.scrollUpBtn,
                    pressed: 0,
                    disabled: this.images.scrollUpBtnDisabled
                },
                scrollUp: true
            };
        },

        getScrollDownButton: function () {
            return {
                image: {
                    normal: this.images.scrollDownBtn,
                    pressed: 0,
                    disabled: this.images.scrollDownBtnDisabled
                },
                scrollDown: true
            };
        },

        getBackButton: function () {
            return {
                image: {
                    normal: this.isBackBtnDisabled ? this.images.backDisabled : this.images.back
                },
                action: this.isBackBtnDisabled ? '' : this.events.goBack
            };
        },

        getNowPlayingButton: function () {
            var isStationPlaying = this.model.isStationSet();
            return {
                image: {
                    normal: isStationPlaying ? this.images.player : this.images.playerDisabled
                },
                action: isStationPlaying ? this.events.player : ''
            };
        },

        getImages: function () {
            return {
                1: this.images.barFrameTop,
                2: this.images.barFrameBottom,
                3: this.images.barFrameRight,
                4: this.images.listBackground,
                5: this.images.buttonbarDivider,
                7: this.images.scrollTrack,
                8: this.images.scrollSlider
            };
        },

        showKeyboard: function() {
            var assetsData = {
                surface: this.images.surface,
                main: {
                    images: {
                        1: this.images.abc,
                        4: this.images.popupModalBg
                    }
                }
            };

            BaseView.prototype.showKeyboard.call(this, assetsData);
        }
    });
});
