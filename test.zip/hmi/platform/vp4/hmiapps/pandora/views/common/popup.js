define(['pandora/views/common/popup'], function (BasePopup) {
    'use strict';

    return BasePopup.extend({

        images: {
            close: 'file:///pandora/images/close.png',
            surface: 'file:///pandora/images/surface.png',
            modal_bg: 'file:///pandora/images/modal_bg.png'
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp4-1',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text,
                        images: {
                            4: this.images.modal_bg
                        }
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }

    });
});
