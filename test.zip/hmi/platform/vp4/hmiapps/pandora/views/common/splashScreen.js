define(['pandora/views/common/splashScreen'], function (BaseSplash) {
    'use strict';

    return BaseSplash.extend({

        images: {
            pandora: 'file:///pandora/images/splash_screen.png',
            surface: 'file:///pandora/images/black_bg_32_bit.png'
        },

        generateTemplate: function () {
            return {
                templateId: 'vp4-8',
                systemHeader: true,
                loadingType: 3,
                backgroundImage: this.images.surface,
                templateContent: {
                    main: {
                        text: {
                            1: $.t('connecting')
                        },
                        images: {
                            1: this.images.pandora
                        }
                    }
                }
            };
        }

    });
});
