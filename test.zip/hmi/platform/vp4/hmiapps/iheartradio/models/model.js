define(['iheartradio/models/model'], function (Model) {
    'use strict';

    return Model.extend({

        getButtonState: function () {
            var state = this._super();
            if(state) {
                state.goToFavorites = 0;
            }

            return state;
        }
    });
});