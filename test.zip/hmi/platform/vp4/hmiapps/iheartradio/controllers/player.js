define(['iheartradio/controllers/player'], function (Player) {
    'use strict';

    return Player.extend({

        tunerIndex: 2,
        
        startListening: function () {
            this._super();
            this.listenTo(this.view, this.view.events.goToFavorites, this.onGoToFavorites);
        },

        onGoToFavorites: function (data) {
            this.stopListening();
            this.trigger('show:menu', this.model.getFavoritesStations.bind(this.model), this._getMenuName(data));
        },

        _getMenuName: function (data) {
            data = data || {};
            return data.value;
        }
    });
});
