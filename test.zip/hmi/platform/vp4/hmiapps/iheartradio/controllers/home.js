define(['iheartradio/controllers/home'], function (Home) {
    'use strict';

    return Home.extend({

        startListening: function () {
            this._super();
            this.listenTo(this.view, this.view.events.goBack, this.onBack);
        },

        onBack: function () {
            this.trigger('show:player');
        }
    });
});
