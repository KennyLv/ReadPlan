define(['iheartradio/views/common/popup'], function (View) {
    'use strict';

    return View.extend({

        init: function (options) {
            this._super(options);
            this.images = _.extend(this.images, {
                modalBackground: 'file:///iheartradio/images/modal_bg.png',
                selected_pressed: 'file:///iheartradio/images/buttons/pressed/136x68.png'
            });
        },

        generateTemplate: function (buttons) {
            var tpl = this._super(buttons);
            tpl.templateId = 'vp4-1';
            tpl.templateContent.main.images = this.getImages();

            return tpl;
        },

        getImages: function () {
            return {
                4: this.images.modalBackground
            };
        }
    });
});