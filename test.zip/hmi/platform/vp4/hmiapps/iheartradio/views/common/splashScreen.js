define(['iheartradio/views/common/splashScreen'], function (Class) {
    'use strict';

    return Class.extend({

        generateTemplate: function () {
            var tpl = this._super();
            tpl.templateId = 'vp4-8';

            return tpl;
        }

    });
});