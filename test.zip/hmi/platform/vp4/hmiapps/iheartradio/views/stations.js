define(['iheartradio/views/common/list', 'common/view/base'], function (stations, BaseView) {
    'use strict';

    return stations.extend({

        init: function (display, title, model) {
            this._super(display, title, model);
            this.images = _.extend(this.images, {
                abc: "file:///aq/images/popup/abc.png",
                modalBackground: 'file:///iheartradio/images/modal_bg.png',
                arrow: "file:///iheartradio/images/list/list_icon-arrow.png",
                listBackground: 'file:///aq/images/list_background.png',
                headerBackground: 'file:///iheartradio/images/titlebar/med.png',
                barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
                barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
                barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
                buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
                scrollDownBtn: "file:///aq/images/buttons/normal/scroll_down.png",
                scrollDownBtnDisabled: "file:///aq/images/buttons/normal/scroll_down_disabled.png",
                scrollUpBtn: "file:///aq/images/buttons/normal/scroll_up.png",
                scrollUpBtnDisabled: "file:///aq/images/buttons/normal/scroll_up_disabled.png",
                scrollTrack: "file:///aq/images/scrollbar/slider_bg.png",
                scrollSlider: "file:///aq/images/scrollbar/slider.png",
                listCursorNormal: "file:///iheartradio/images/list/cursor.png",
                listCursorPressed: "file:///aq/images/list/cursor_active.png"
            });
        },

        generateTemplate: function (options) {
            var tpl = this._super(options);
            tpl.templateId = 'vp4-3';
            tpl.systemHeader = false;
            tpl.templateContent.title.backgroundImage = this.images.headerBackground;
            tpl.templateContent.main = {
                images: this.getImages()
            };
            tpl.templateContent.cursor = this.getListCursor();

            return tpl;
        },

        getListCursor: function () {
            return {
                image: {
                    normal: this.images.listCursorNormal,
                    pressed: this.images.listCursorPressed
                }
            };
        },

        getButtons: function (isAlphaJumpEnabled) {
            var alphaJumpButton = {
                    image:  {
                        normal: this.images.alphaJump
                    },
                    action: this.events.onAlphaJump
                },
                buttons = {
                    7: this.getScrollUpButton(),
                    8: this.getScrollDownButton(),
                    10: {
                        image: {
                            normal: this.images.back
                        },
                        action: this.events.goBack
                    },
                    11: {
                        image: {
                            normal: this.model.isStationSelected() ? this.images.nowPlaying : this.images.nowPlayingDisabled
                        },
                        action: this.events.nowPlaying,
                        stateEnabled: this.model.isStationSelected()
                    },
                    12: isAlphaJumpEnabled ? alphaJumpButton : {}
                };

            return buttons;
        },

        getItems: function (items) {
            return items ? items.map(function (item) {
                var commands = item.commands || {},
                    action = _.intersection(this.events, _.keys(item.commands))[0],
                    hasChildren = commands.select;
                return {
                    text: item.text,
                    image2: hasChildren ? this.images.arrow : '',
                    action: action,
                    value: item
                };
            }, this) : [{
                text: $.t('loading')
            }];
        },

        getImages: function () {
            return {
                1: this.images.barFrameTop,
                2: this.images.barFrameBottom,
                3: this.images.barFrameRight,
                4: this.images.listBackground,
                5: this.images.buttonbarDivider,
                7: this.images.scrollTrack,
                8: this.images.scrollSlider
            };
        },

        getScrollUpButton: function () {
            return {
                image: {
                    normal: this.images.scrollUpBtn,
                    pressed: 0,
                    disabled: this.images.scrollUpBtnDisabled
                },
                scrollUp: true
            };
        },
        
        getScrollDownButton: function () {
            return {
                image: {
                    normal: this.images.scrollDownBtn,
                    pressed: 0,
                    disabled: this.images.scrollDownBtnDisabled
                },
                scrollDown: true
            };
        },

        showKeyboard: function() {
            var assetsData = {
                surface: this.images.surface,
                main: {
                    images: {
                        1: this.images.abc,
                        4: this.images.modalBackground
                    }
                }
            };

            BaseView.prototype.showKeyboard.call(this, assetsData);
        }

    });
});
