define(['iheartradio/views/home'], function (View) {
    'use strict';

    return View.extend({

        init: function (display, model) {
            this._super(display, model);
            this.events = _.extend(this.events, {
                goBack: 'goBack'
            });
            this.images = _.extend(this.images, {
                header: 'file:///iheartradio/images/player/header.png',
                back: 'file:///iheartradio/images/list/sidebtn_icon-back.png',
                backDisabled: 'file:///iheartradio/images/list/sidebtn_icon-back_disabled.png',
                headerBackground: 'file:///iheartradio/images/titlebar/full.png',
                barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
                barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
                barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
                buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png'
            });
        },

        generateTemplate: function () {
            return {
                templateId: 'vp4-5',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header,
                        backgroundImage: this.images.headerBackground
                    },
                    main: {
                        images: this.getImages()
                    },
                    buttons: _.extend(this.getButtons(), {
                        10: this.getBackButton()
                    })
                }
            };
        },

        getButtons: function () {
            var buttons = this._super();
            buttons[4] = _.extend(buttons[4], this.getPlayButton());

            return buttons;
        },

        getBackButton: function() {
            var isStateEnabled = this.model.isStationSelected() && this.model.isPlaying();
            return {
                stateEnabled: isStateEnabled,
                image: isStateEnabled ? this.images.back : this.images.backDisabled,
                action: isStateEnabled ? this.events.goBack : ''
            };
        },

        getPlayButton: function() {
            var isStateEnabled = this.model.isStationSelected() && this.model.isPlaying();
            return {
                stateEnabled: isStateEnabled,
                image: isStateEnabled ? this.images.nowPlaying : this.images.nowPlayingDisabled,
                action: isStateEnabled ? this.events.goToNowPlaying : ''
            };
        },

        getImages: function () {
            return {
                3: this.images.barFrameTop,
                4: this.images.barFrameBottom,
                5: this.images.barFrameRight,
                6: this.images.buttonbarDivider
            };
        },

        goBack: function () {
            this.trigger('goBack');
        }
    });
});
