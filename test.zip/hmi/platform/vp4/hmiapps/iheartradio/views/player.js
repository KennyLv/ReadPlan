define(['iheartradio/views/player'], function (BasePlayerView) {
    'use strict';

    return BasePlayerView.extend({

        buttons: {
            custom: [
                ['skip', 'thumbsUp', 'thumbsDown']
            ],
            live: [
                ['scan', 'thumbsUp', 'thumbsDown']
            ],
            talk: [
                ['skip', 'thumbsUp', 'thumbsDown']
            ],
            default: [
                ['skip', 'thumbsUp', 'thumbsDown']
            ]
        },

        sideButtons: {
            custom: {
                20: 'goToFavorites',
                21: 'addToFavorites',
                22: 'createStation',
                23: 'discoveryTuner'
            },
            live: {
                20: 'goToFavorites',
                21: 'addToFavorites',
                22: 'createStation'
            },
            talk: {
                20: 'goToFavorites',
                21: 'addToFavorites'
            },
            default: {
                20: 'goToFavorites',
                21: 'addToFavorites',
                22: 'createStation',
                23: 'discoveryTuner'
            }
        },

        statusCodeDisabled: 2,

        init: function (display, model) {
            this._super(display, model);
            this.events = _.extend(this.events, {
                goToFavorites: 'goToFavorites'
            });
            this.images = _.extend(this.images, {
                header: 'file:///iheartradio/images/player/header.png',
                goToFavorites: 'file:///iheartradio/images/player/favorites/<%= code %>.png',
                headerBackground: 'file:///iheartradio/images/titlebar/full.png',
                buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
                barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
                barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
                barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png'
            });
        },

        startListening: function () {
            this._super();

            this.listenTo(this.display, this.display.getEnterEventName(), this.goToMainScreen);
        },

        generateTemplate: function () {
            return {
                templateId: 'vp4-6',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header,
                        backgroundImage: this.images.headerBackground
                    },
                    buttons: _.extend(this.getButtons(), this.getSideButtons(), {
                        10: {
                            image: this.images.source,
                            action: this.events.goToSourceScreen
                        }
                    }),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: this.getProgressBar()
                }
            };
        },

        getImages: function () {
            return {
                1: this.model.get('image') || this.images.logo,
                3: this.images.barFrameTop,
                4: this.images.barFrameBottom,
                5: this.images.barFrameRight,
                6: this.images.buttonbarDivider
            };
        },

        getButton: function (buttonName) {
            var buttonsState = this.model.getButtonState(),
                buttonState = (buttonsState && buttonsState[buttonName] !== undefined) ?
                    buttonsState[buttonName] : this.statusCodeDisabled,
                status = {
                    code: buttonState
                },
                data = {
                    image: {
                        normal: _.template(this.images[buttonName], status),
                        pressed: 0
                    },
                    value: buttonName === 'goToFavorites' ? $.t('menu.favoriteStations') : '',
                    action: this._getButtonAction(buttonName, status.code),
                    stateEnabled: status.code !== this.statusCodeDisabled
                };

            return this._handleStateEvent(buttonName, buttonState, data);
        },

        getSideButtons: function () {
            var buttons = {},
                stationType = this.model.getStationType();

            _.each(this.sideButtons[stationType], function (buttonName, index) {
                buttons[index] = this.getButton(buttonName);
            }, this);

            return buttons;
        },

        getProgressBar: function () {
            var progressBar = this._super();
            if(progressBar.color) {
                progressBar.color = this.display.constants.APP_LIST_COLOR.VP4.iheartradio;
            }

            return progressBar;
        }
    });
});