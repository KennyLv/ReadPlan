define(['slacker/models/constants'], function (Constants) {
    'use strict';

    return _.extend(Constants, {

        /**
         * Slacker album image size
         */
        STATION_IMG_SIZE: '136x150'

    });
});