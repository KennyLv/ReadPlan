define(['slacker/models/extension'], function (Extension) {
    'use strict';

    return Extension.extend({
        // removed this.get('olicensed') check because of it doesn't used on vp4
        onTrackStart: function (data) {
            // valid only if onDeckImage is set (exception is only first playing song)
            var onDeckImage = this.get('onDeckImage'),
                stationName = this.get('stationName'),
                stationId = this.get('stationId'),
                currentImage = this.get('currentImage'),
                previousBtnClicked = this.get('playPrevious'),
                trackName = this.get('trackName'),
                neededImage =  (trackName === data.trackName || _.isUndefined(onDeckImage) ) ?
                    currentImage : onDeckImage;

            if (previousBtnClicked && trackName !== data.trackName) {
                neededImage = "";
            }

            // Mark station as bookmarked if found in a list of bookmarked stations retrieved on app start
            var isBookmarked = !!_.find(this.bookmarkedStations, function (aStation) {
                return aStation.id === stationId;
            });
            
            // reset previous track data
            this.reset();
            
            this.set(_.extend(data, {
                playState: this.PLAYING_STATES.PLAY_STATE_PLAYING,
                currentImage: neededImage,
                stationName: stationName,
                stationId: stationId,
                onDeckImage: onDeckImage,
                isBookmarked: isBookmarked
            }));

            // store track info on TrackStart event
            // onDeckImage is current image for all songs except the one which playing first
            if (this.isSong()) {
                this.trackStorage.push({
                    artistName: this.get('artistName'),
                    trackName: this.get('trackName'),
                    trackID : this.get('trackID'),
                    image: neededImage
                });
            }
        }
    });
});
