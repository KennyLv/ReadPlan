define(['slacker/views/player'], function (BasePlayer) {
    'use strict';

    return BasePlayer.extend({

        init: function (display, model) {
            this._super(display, model);
            this.images = _.extend(this.images, {
                source: 'file:///aq/images/buttons/normal/source.png',
                headerBackground: 'file:///slacker/images/titlebar/full.png',
                buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
                barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
                barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
                barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
                bookmark:  'file:///slacker/images/player/player_btn_bookmark.png',
                bookmarkDisabled:  'file:///slacker/images/player/player_btn_bookmark_disabled.png',
                bookmarkSelected:  'file:///slacker/images/player/player_btn_bookmark_selected.png'
            });
        },

        getButtons: function () {
            return _.extend(this._getUserBarButtons(), {
                8: this.getPrevSongButton(),
                9: this.getNextSongButton(),
                10: this.getSourceButton()
            });
        },

        _getBasicUserBarButtons: function () {
            var basicUserBarButtons = this._super();
            basicUserBarButtons[6] = this.getBookmarkButton();
            return basicUserBarButtons;
        },

        _getPremiumUserBarButtons: function () {
            var premiumUserBarButtons = this._super();
            premiumUserBarButtons[7] = this.getBookmarkButton();
            return premiumUserBarButtons;
        },

        getBookmarkButton: function () {
            /**
             * We currently support bookmarking only for Stations.
             * @var {boolean}
             */
            var isStationBookmarkable = this.isSong && /^stations/.test(this.model.getStationId());
            var enabledBtnIcon = this.model.isBookmarked() ? this.images.bookmarkSelected : this.images.bookmark,
                actionName = this.model.isBookmarked() ? this.events.unBookmark : this.events.bookmark;

            return {
                image: {
                    normal: isStationBookmarkable ? enabledBtnIcon : this.images.bookmarkDisabled,
                    pressed: 0
                },
                action: isStationBookmarkable ? actionName : '',
                stateEnabled: isStationBookmarkable
            };
        },

        getPrevSongButton: function () {
            var prevTrack = this.model.getPrevSong();

            return this.isAudioAd ? {
                text: $.t('player.buttons.prev'),
                image: {
                    normal: this.images.default_art,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: prevTrack && prevTrack.image ? prevTrack.image : this.images.default_art,
                    pressed: 0
                },
                text: $.t('player.buttons.prev'),
                action: this.events.previousSong,
                stateEnabled : !!prevTrack,
                value: prevTrack ? {
                    song: 'Prev',
                    trackName: prevTrack.trackName,
                    artist: prevTrack.artistName,
                    image: prevTrack.image ? prevTrack.image : this.images.default_art
                } : ''
            };
        },

        getNextSongButton: function () {
            var trackName = this.model.getNextTrackName(),
                artist = this.model.getNextArtistName(),
                image = this.model.getOnDeckImage() || this.images.default_art,
                hasNextTrackInfo = this.model.hasNextTrackInfo();

            return this.isAudioAd ? {
                text: $.t('player.buttons.next'),
                image: {
                    normal: this.images.default_art,
                    pressed: 0
                },
                stateEnabled: false
            } : {
                image: {
                    normal: this.isBasicUser ? this.images.default_art : image,
                    pressed: 0
                },
                action: hasNextTrackInfo ? this.events.nextSong : '',
                stateEnabled: !!hasNextTrackInfo,
                text: $.t('player.buttons.next'),
                value: {
                    song: 'Next',
                    trackName: trackName,
                    artist: artist,
                    image: image
                }
            };
        },

        getProgressBar: function () {
            var duration = this.model.getDuration(),
                elapsed = this.model.getElapsedTime();

            return (_.isNumber(duration) && _.isNumber(elapsed)) ? {
                total: duration,
                elapsed: elapsed,
                color: 0xCD5718,
                active:  this.model.isPlaying()
            } : {};

        },

        getImages: function () {
            var currentImage = this.model.getCurrentImage();

            return {
                1: this.isAudioAd ? this.images.default_art : currentImage ? currentImage : this.images.default_art,
                3: this.images.barFrameTop,
                4: this.images.barFrameBottom,
                5: this.images.barFrameRight,
                6: this.images.buttonbarDivider
            };
        },

        generateTemplate: function () {
            // Rewrite hex value from string to Number
            var progressBar = this.getProgressBar();
            progressBar.color = 0xCD5718;
            this.maxButtonsInStripe = this.isPremiumUser ? 7 : 6;

            return {
                templateId: 'vp4-2',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.header,
                        backgroundImage: this.images.headerBackground
                    },
                    buttons: this.getButtons(),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: progressBar
                }
            };
        }

    });
});
