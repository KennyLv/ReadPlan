define(['slacker/views/common/list', 'common/view/base'], function (BaseList, BaseView) {
    'use strict';

    return BaseList.extend({

        images: {
            back: 'file:///slacker/images/general/btn_back.png',
            backDisabled: 'file:///slacker/images/general/btn_back_disabled.png',
            folder: 'file:///slacker/images/list/folder.png',
            player: 'file:///aq/images/buttons/normal/now_playing.png',
            playerDisabled: 'file:///aq/images/buttons/normal/now_playing_disabled.png',
            surface: 'file:///slacker/images/surface.png',
            playIcon: 'file:///slacker/images/list/icon_play.png',
            alphaJump: 'file:///slacker/images/list/sidebtn_icon-alpha_jump.png',
            buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
            listBackground: 'file:///aq/images/list_background.png',
            barFrameTop: 'file:///aq/images/buttonbar/bar_frame_top.png',
            barFrameBottom: 'file:///aq/images/buttonbar/bar_frame_bottom.png',
            barFrameRight: 'file:///aq/images/buttonbar/bar_frame_right.png',
            titleBackground: 'file:///slacker/images/titlebar/med.png',
            scrollDownBtn: "file:///aq/images/buttons/normal/scroll_down.png",
            scrollDownBtnDisabled: "file:///aq/images/buttons/normal/scroll_down_disabled.png",
            scrollUpBtn: "file:///aq/images/buttons/normal/scroll_up.png",
            scrollUpBtnDisabled: "file:///aq/images/buttons/normal/scroll_up_disabled.png",
            scrollTrack: "file:///aq/images/scrollbar/slider_bg.png",
            scrollSlider: "file:///aq/images/scrollbar/slider.png",
            listCursorNormal: "file:///slacker/images/list/cursor.png",
            listCursorPressed: "file:///aq/images/list/cursor_active.png",
            abc: "file:///aq/images/popup/abc.png",
            popupModalBg: 'file:///slacker/images/modal_bg.png'
        },

        generateTemplate: function (options) {
            //enable alpha jump only for My Stations list
            this.showAlphaJumpBtn = (options.categoryKey === 'mystations' && options.items.length > 5);

            return {
                templateId: 'vp4-3',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: {
                        text: this.title || '',
                        backgroundImage: this.getTitleBackgroundImage()
                    },
                    main: {
                        images: this.getImages()
                    },
                    list: this.getItems(options),
                    buttons: this.getButtons(),
                    cursor: this.getListCursor()
                }
            };
        },

        getTitleBackgroundImage: function () {
            return this.images.titleBackground;
        },

        getListCursor: function () {
            return {
                image: {
                    normal: this.images.listCursorNormal,
                    pressed: this.images.listCursorPressed
                }
            };
        },

        getImages: function () {
            return {
                1: this.images.barFrameTop,
                2: this.images.barFrameBottom,
                3: this.images.barFrameRight,
                4: this.images.listBackground,
                5: this.images.buttonbarDivider,
                7: this.images.scrollTrack,
                8: this.images.scrollSlider
            };
        },

        /**
         *
         * @param items {Array}
         * @param options {Object}
         * @returns {Array}
         */
        getItems: function (options) {
            options = options || {};
            var items = _.isArray(options.items) ? options.items : [];

            return items.map(function (item) {
                var name = item.name,
                    children = item.items,
                    childrenLength = children ? children.length : 0,
                    count = childrenLength ? ' (' + childrenLength + ')' : '';

                item.hasChildren = !!childrenLength;

                return {
                    text: name + count,
                    image1: this.getItemLeftImage(),
                    image2: this.getItemRightImage(item),
                    action: (options.event && !item.hasChildren) ? options.event : this.events.select,
                    value: {
                        name: name,
                        items: item.items,
                        id: item.id,
                        key : item.key
                    }
                };
            }, this);
        },

        getItemLeftImage: function () {
            return 0;
        },

        getItemRightImage: function (item) {
            return item.hasChildren ? this.images.folder : item.usePlayIcon ? this.images.playIcon : 0;
        },

        getButtons: function () {
            var buttons = {
                7: this.getScrollUpButton(),
                8: this.getScrollDownButton(),
                10: this.getBackButton(),
                11: this.getNowPlayingButton(),
                12: this.showAlphaJumpBtn ? this.getABCJumpButton() : {}
            };
            
            return buttons;
        },

        getScrollUpButton: function () {
            return {
                image: {
                    normal: this.images.scrollUpBtn,
                    pressed: 0,
                    disabled: this.images.scrollUpBtnDisabled
                },
                scrollUp: true
            };
        },

        getScrollDownButton: function () {
            return {
                image: {
                    normal: this.images.scrollDownBtn,
                    pressed: 0,
                    disabled: this.images.scrollDownBtnDisabled
                },
                scrollDown: true
            };
        },

        showKeyboard: function() {
            var assetsData = {
                surface: this.images.surface,
                main: {
                    images: {
                        1: this.images.abc,
                        4: this.images.popupModalBg
                    }
                }
            };

            BaseView.prototype.showKeyboard.call(this, assetsData);
        }
    });
});
