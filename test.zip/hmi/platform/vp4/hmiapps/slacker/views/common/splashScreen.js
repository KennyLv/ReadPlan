define(['slacker/views/common/splashScreen'], function (baseSplash) {
    'use strict';

    return baseSplash.extend({

        generateTemplate: function () {
            var tmpl = this._super();
            tmpl.templateId = 'vp4-8';
            return tmpl;
        }

    });
});