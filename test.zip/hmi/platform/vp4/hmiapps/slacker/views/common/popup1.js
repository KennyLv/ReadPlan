define(['slacker/views/common/popup1'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        images: {
            close: 'file:///slacker/images/close_btn.png',
            modal_bg: 'file:///slacker/images/modal_bg.png'
        },

        generateTemplate: function (buttons) {
            var tmpl = this._super(buttons);

            tmpl.systemHeader = true;
            tmpl.templateId = 'vp4-1';

            tmpl.templateContent.main.images = {
                4: this.images.modal_bg
            };

            return tmpl;
        }

    });
});