define(['slacker/views/common/popup2'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        title: {},

        init: function (display, model) {
            this.images = _.extend({
                modal_bg: 'file:///slacker/images/modal_bg.png'
            }, this.images);
            this._super(display, model);
        },

        generateTemplate: function (options) {
            var tmpl = this._super(options);

            tmpl.templateId = 'vp4-7';
            tmpl.systemHeader = true;
            tmpl.templateContent.main.images[4] = this.images.modal_bg;
            tmpl.templateContent.title = this.title;

            return tmpl;
        },

        getLabels: function (labels) {
            this.title = {
                text: labels.shift()
            };

            return labels.reduce(function (memo, value, key) {
                memo[key + 1] = value;
                return memo;
            }, {});
        }
    });
});