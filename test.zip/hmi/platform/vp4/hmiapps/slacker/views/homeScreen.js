define(['slacker/views/homeScreen'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        images: {
            surface: 'file:///slacker/images/surface.png',
            logo: 'file:///slacker/images/breadcrumbs/breadcrumbs_logo.png',
            play: 'file:///slacker/images/general/nowPlaying.png',
            play_disabled: 'file:///slacker/images/general/nowPlaying_disabled.png',
            titlebar_bg: 'file:///slacker/images/breadcrumbs/breadcrumbs_bg_full.png',
            back: 'file:///aq/images/buttons/normal/titlebar_button_back.png',
            back_disabled: 'file:///aq/images/buttons/normal/titlebar_button_back_disabled.png'
        },

        generateTemplate: function () {
            var tmpl = this._super();

            tmpl.templateId = 'vp4-5';
            tmpl.templateContent.title.backgroundImage = this.images.titlebar_bg;

            return tmpl;
        },

        getButtons: function () {
            var buttons = _.extend({}, this._super(), {
                10: this.getBackButton()
            });

            return buttons;
        },

        getPlayingBtn: function() {
            var isPlaying = this.model.isPlaying() || this.model.isPaused();
            return {
                text : $.t('nowPlaying'),
                stateEnabled: isPlaying,
                image: isPlaying ? this.images.play : this.images.play_disabled,
                action: this.events.goToPlayer
            };
        },

        getBackButton: function() {
            var isPlaying = this.model.isPlaying() || this.model.isPaused();
            return {
                stateEnabled: isPlaying,
                image: isPlaying ? this.images.back : this.images.back_disabled,
                action: this.events.goToPlayer
            };
        }
    });
});