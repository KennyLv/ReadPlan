define([
    'slacker/controllers/myMusic'
], function (myMusic) {
    'use strict';


    return myMusic.extend({

        MAX_RECENTLY_PLAYED_LENGTH: 1000
    });
});