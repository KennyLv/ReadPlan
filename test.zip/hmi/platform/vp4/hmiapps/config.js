define(function () {
    "use strict";
    
    // TODO: Put correct sizes of buttons
    return {
        buttonsBranding: {
            'vp4-1': {
                1: '62x65',
                2: '160x68',
                3: '160x68',
                4: '160x68',
                5: '160x68',
                6: '160x68'
            },
            'vp4-2': {
                8: '88x116',
                9: '88x116'
            },
            'vp4-3': {
                1: '136x68',
                2: '136x68',
                3: '136x68',
                4: '136x68',
                5: '136x68',
                6: '136x68',
                7: '85x70',
                8: '85x70',
                9: '136x68',
                10: '136x68'
            },
            'vp4-3-1': {
                1: '136x68',
                2: '136x68',
                3: '136x68',
                4: '136x68',
                5: '136x68',
                6: '136x68',
                7: '85x70',
                8: '85x70',
                9: '136x68',
                10: '136x68'
            },
            'vp4-4': {
                1: '62x65',
                2: '173x77',
                3: '77x77'
            },
            'vp4-5': {
                1: '190x116',
                2: '190x116',
                3: '190x116',
                4: '190x116',
                5: '190x116',
                6: '190x116',
                7: '190x116',
                8: '190x116',
                9: '190x116'
            },
            'vp4-6': {
                20: '136x68',
                21: '136x68',
                22: '136x68',
                23: '136x68'
            },
            'vp4-7': {
                1: '62x65',
                2: '136x68',
                3: '136x68',
                4: '136x68'
            },

            scrollBranding: '75x52', // NOTE: VP4 does not use this, this is just to not break inherited VP2C Views

            path: '/images/buttons/pressed/'
        },
        maxButtonsInPlayerStripe: 7
    };
});
