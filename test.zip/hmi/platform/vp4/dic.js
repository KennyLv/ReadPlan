/**
 * Dependency injection container
 */
define(function () {
    'use strict';

    var Dic = require('aq/di'),
        PlatformServices = require('aq/dic');
    
    return new Dic({
        appList: function () {
            var utils = PlatformServices.get('utils'),
                AppList = utils.getPlatform() === 'ios' ? require('vp4/home/ios/appList') :
                    require('vp4/home/android/appList');

            PlatformServices.registry.appList = new AppList({
                appManager: PlatformServices.get('appManager'),
                profile: PlatformServices.get('profile'),
                display: PlatformServices.get('display'),
                appContainer: PlatformServices.get('appContainer'),
                constants: PlatformServices.get('constants'),
                vr: this.get('VR'),
                Logger: PlatformServices.get('Logger'),
                fileReporter: PlatformServices.get('fileReporter'),
                Popup: this.get('Popup')
            });

            this.registry.appList = PlatformServices.registry.appList;

            return PlatformServices.registry.appList;
        },

        Popup: function () {
            var Popup = require('vp4/home/views/popup');
            return Popup.bind.apply(Popup, [null].concat(PlatformServices.get('display')));
        },

        VR: function () {
            var VR = require('vp4/api/hu/vr');

            return this.registry.vr = new VR(
                PlatformServices.get('transport'),
                PlatformServices.get('utils'),
                PlatformServices.get('constants'),
                PlatformServices.get('appManager')
            );
        },

        /**
        * @override We need it here because "images" are created in entry point - aq.js 
        * 
        * @return {Images}
        */
        images: function () {
            var Images = require('aq/images');
            
            PlatformServices.registry.images = new Images(
                PlatformServices.get('storage'),
                this.get('screen'),
                PlatformServices.get('profile'),
                PlatformServices.get('constants'),
                PlatformServices.get('Logger')
            );
        
            this.registry.images = PlatformServices.registry.images;
            
            return this.registry.images;
        },
        
        /**
        * @override
        * 
        * @return {*}
        */
        screen: function () {
            var Screen = require('vp4/api/hu/screen');
            
            PlatformServices.registry.screen = new Screen({
                transport: PlatformServices.get('transport'),
                storage: PlatformServices.get('storage'),
                utils: PlatformServices.get('utils'),
                constants: PlatformServices.get('constants'),
                appManager: PlatformServices.get('appManager')
            });
        
            this.registry.appList = PlatformServices.registry.appList;
            
            return PlatformServices.registry.screen;
        },
        
        ErrorHandler: function (options) {
            var GenericErrorHandler = PlatformServices.get('ErrorHandler');
            var dependencies = {
                popup: this.get('Popup'),
                profile: PlatformServices.get('profile'),
                translation: PlatformServices.get('translation'),
                homeApp: this.get('appList')
            };
            
            return PlatformServices.registry.ErrorHandler = new GenericErrorHandler(_.extend(dependencies, options));
        }
    });
});
