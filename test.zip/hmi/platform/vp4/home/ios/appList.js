/**
 * TODO rewrite this module later
 * iOS appList modules responsible for appLaunch and appContainer switching
 */

define(['vp4/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        // TODO move to constants
        homeApplicationContainerName: 'uconnect',

        /**
         * IOS error (appSwitch in case of screen locked device)
         */
        SCREEN_LOCKED_ERROR_CODE:  10008,

        init: function (options) {
            var display = options.display;
            display.showLoading();

            this.appContainer = options.appContainer;
            this._super(options);

            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.switchApplicationContainerTo(null, handsetAppName);
            }.bind(this));

            return this;
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                this.switchApplicationContainerTo(data.value.appName);
            });
        },

        /**
         * Listener to handle HUP application mode state changed event
         * 
         * @param response {Object} Possible values of response.data.state: 'start' | 'resume' | 'exit'
         */
        onAppModeStateChange: function (response) {            
            var state = response && response.data && response.data.state;

            /**
             * NOTE:
             * VP2C has some hack added to this method. @see "renderHomeScreen" variable there.
             * TODO: Check if this will be need for VP4 and iOS.
             */
            
            if (state === 'start' && !this.profileSyncInProgress) {
                // on iOS, ready() may or may not trigger profile sync...
                this.profile.ready();
            }
            
            if (state === 'resume') {
                this.display.showLoading();
                this.goToHomeScreen();
            } else if (state === 'exit' && !_.isEmpty(this.applications)) {
                this.appManager.suspendApp(this.appManager.currentAppName);
            }
        },

        startApplicationBy: function () {
            this.startApplicationByCurrentContainerName();
        },

        /**
         * Switch to OEM app or just show homeScreen
         */
        goToHomeScreen: function () {
            this.logger.log({'goToHomeScreen': 'goToHomeScreen'});

            this.appContainer.getApplicationContainerName().done(function (containerName) {
                if (containerName === this.homeApplicationContainerName) {
                    this.display.resetScreen();
                    this.renderHomeScreen();
                } else {
                    this.switchApplicationContainerTo(null, this.homeApplicationContainerName);
                }
            }.bind(this));
        },

        renderHomeScreen: function () {
            this.getAvailableApps().done(function () {
                this._super();
            }.bind(this));
        },

        /**
         * @param appName
         * @param handsetAppName
         */
        switchApplicationContainerTo: function (appName, handsetAppName) {
            var appNameMap = this.constants.APP_NAME_MAP;

            appName = appName || _.invert(appNameMap)[handsetAppName];
            handsetAppName = handsetAppName || appNameMap[appName];

            if (handsetAppName !== this.homeApplicationContainerName) {
                this.writeFirstUsageReport(appName);
            }

            // if handsetAppName defined - we need to switch to this smartphone app
            if (handsetAppName) {
                this.logger.log({'switchApplicationContainerTo': handsetAppName});
                this.appContainer.sendAppSwitchEvent()
                    .done(function () {
                        this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });
                        this.appContainer.switchApplicationContainerTo(handsetAppName)
                            .fail(function (content) {
                                var errorCode = content.error && content.error.code;
                                //show error popup
                                if (errorCode === this.SCREEN_LOCKED_ERROR_CODE) {
                                    this._handleError(errorCode);
                                }
                            }.bind(this)
                        );
                    }.bind(this)
                );
            } else {
                this.startApp(appName);
            }
        },

        _setVrAppLaunchByListOfApps: function (apps) {
            var appName = this.appManager.getCurrentApplicationName();
            // avoid setting vr commands when user is on pandora IOS (there is only one HMI Pandora)
            if (appName === this.constants.APP_NAME_MAP.uconnect) {
                this.vr.setVrAppLaunchByListOfApps(apps);
            }
        },

        /**
         * If we in OEM app - just show appList,
         * otherwise show loading and switch to needed container
         *
         * Invoked:
         *  - on profile sync complete
         */
        startApplicationByCurrentContainerName: function () {
            var appNameMap = _.invert(this.constants.APP_NAME_MAP);
            this.logger.log({'startApplicationByCurrentContainerName': ''});

            this.appContainer.getApplicationContainerName().done(function (containerName) {

                this.logger.log({'startApplicationByCurrentContainerName': containerName});

                this.display.resetScreen();

                if (containerName === this.homeApplicationContainerName) {
                    this.logger.log({'renderHomeScreen': 'render apps list'});
                    this.renderHomeScreen();
                } else {
                    this.logger.log({'startApp': appNameMap[containerName]});
                    this.startApp(appNameMap[containerName]);
                }

            }.bind(this));
        }

    });
});
