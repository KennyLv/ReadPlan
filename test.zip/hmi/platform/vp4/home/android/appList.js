define(['vp4/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        events: {
            start: 'start'
        },


        init: function (options) {
            this._super(options);
            this.getAvailableApps().done(this.startApplicationBy.bind(this));

            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.startApp(_.invert(this.constants.APP_NAME_MAP)[handsetAppName]);
            }.bind(this));

            return this;
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                var app = data.value || {};

                //avoid reporting for template suite
                if (app.appCategory === 'Music') {
                    this.writeFirstUsageReport(app.appName);
                }
                this.startApp(app.appName, app.appCategory);
            });
        },

        onAppModeStateChange: function (data) {
            var state =  data.data && data.data.state;
            // re-render home screen because HU just started or resumed from another screen
            // todo should we render home screen when HU focus is lost?
            if (state !== 'exit') {
                this.display.resetScreen();
                this.renderHomeScreen();
            } else if (state === 'exit' && !_.isEmpty(this.applications)) {
                this.appManager.suspendApp(this.appManager.currentAppName);
            }
        },

        startApplicationBy: function () {
            this.appManager.suspendApp();
            this.renderHomeScreen.apply(this, arguments);
        },

        /**
         * @param apps - list of app to set vr grammars on HU
         * @private
         */
        _setVrAppLaunchByListOfApps: function (apps) {
            this.vr.setVrAppLaunchByListOfApps(apps);
        },

        goToHomeScreen: function () {
            this.renderHomeScreen.apply(this, arguments);
        }
    });
});
