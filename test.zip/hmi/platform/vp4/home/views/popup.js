define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({
        events: {
            close: 'close'
        },

        images: {
            close: 'file:///aq/images/popup/close.png',
            surface: 'file:///aq/images/surface.png',
            modal_bg: 'file:///aq/images/popup/modal_bg.png'
        },

        init: function (display) {
            this._super(display, { appName: 'aq' });
            this.initButtons();
            this.template = {};
            this.display = display;
        },

        initButtons: function () {
            this.buttons = {
                exit: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                }
            };
        },

        render: function (options) {
            var delay = options.delay;
            this.text = options.text;
            this.title = options.title;

            this.template = this.generateTemplate(options.buttons);
            this.updateScreen(this.template);

            if (delay) {
                _.delay(this._triggerClose.bind(this), delay);
            }
        },

        _triggerClose: function () {
            this.display.trigger(this.events.close);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp4-1',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text,
                        images: {
                            4: this.images.modal_bg
                        }
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }
    });
});
