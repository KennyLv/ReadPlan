define(['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        events: {
            start: 'start',
            source: 'source'
        },

        /**
         *  key-value map
         *  key - code of HMI application, e.g. "pandora", "aq", etc...
         *  value - another object with values of appId and archiveId
         */
        archiveVersionIds: {},
        
        images: {
            titleBackground: 'file:///aq/images/titlebar/full.png',
            appLogo: 'file:///aq/images/aq.png',
            listBackground: 'file:///aq/images/list_background.png',
            backButton: 'file:///aq/images/buttons/normal/titlebar_button_back.png',
            buttonbarDivider: 'file:///aq/images/buttonbar/buttonbar_divider.png',
            scrollDownBtn: "file:///aq/images/buttons/normal/scroll_down.png",
            scrollDownBtnDisabled: "file:///aq/images/buttons/normal/scroll_down_disabled.png",
            scrollUpBtn: "file:///aq/images/buttons/normal/scroll_up.png",
            scrollUpBtnDisabled: "file:///aq/images/buttons/normal/scroll_up_disabled.png",
            scrollTrack: "file:///aq/images/scrollbar/slider_bg.png",
            scrollSlider: "file:///aq/images/scrollbar/slider.png",
            listCursorNormal: "file:///aq/images/list/cursor.png",
            listCursorPressed: "file:///aq/images/list/cursor_active.png"
        },

        init: function (options) {
            this.constants = options.constants;
            this.vr = options.vr;
            this.appManager = options.appManager;
            this.profile = options.profile;
            this.display = options.display;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'APP_LIST');
            this.Popup = options.Popup;
            this.firstUsageReport = options.fileReporter.reports.firstUsageReport;
            
            this._super(this.display, { appName: 'aq' });
            
            /**
             * [{
             *   appName: {string},
             *   appDisplayName: {string},
             *   appCategory: {string},
             *   appPath: {string}
             * }, ...]
             *
             */
            this.applications = [];
            this.needToRestart = false;

            this.profile.on(this.profile.events.profileStateChange, this.onProfileSyncStart, this);
            this.profile.on(this.profile.events.appModeStateChange, this.onAppModeStateChange, this);

            this.appManager.on(this.appManager.events.showHomeScreen, this.showHomeScreen, this);
            this.display.screen.on(this.display.screen.events.headUnitConnectionState,
                this.appManager.updateAppConfigs, this);

            this.profile.ready();
        },

        showHomeScreen: function (fetchAppList) {
            this.getAvailableApps(fetchAppList)
                .done(this.goToHomeScreen.bind(this));
        },

        startApplicationBy: function () {
            throw new Error('Abstract method');
        },

        goToHomeScreen: function () {
            throw new Error('Abstract method');
        },

        getAvailableApps: function (force) {
            return _.isEmpty(this.applications) || force ?
                this.profile.getApplicationList().done(this.saveAvailableApps.bind(this)) :
                $.when(this.applications);
        },

        saveAvailableApps: function (apps) {
            this.applications = this._processAppListItems(apps);
            this._setVrAppLaunchByListOfApps(this.applications);
        },

        /**
         * Uniforms a key by lowercasing `appName` value.
         * Used later to load configs based on such key.
         * 
         * @param apps {Array} List of objects with available app data
         * @private
         * 
         * @return {Array}
         */
        _processAppListItems: function (apps) {
            var appList = _.isArray(apps) ? apps : [];

            // Sort app list ASC
            if (appList.length > 0) {
                appList = _.sortBy(appList, function(appObj){
                    return appObj.appDisplayName.toLowerCase();
                });
            }
            
            return appList.map(function (item) {
                item.appName = item.appName ? item.appName.toLowerCase() : '';
                return item;
            });
        },

        startApp: function (appName, appCategory) {
            this.logger.log({'start::app': appName});

            this.stopListening();
            this.appManager.switchApp(appName, appCategory);

            this.logger.log({'started::app': appName});
        },

        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state;
            this.logger.log({'onAppModeStateChange': state});
            this._super(state);
        },

        onProfileSyncStart: function (response) {
            var content = response.data || {},
                profileSyncStatus = content.state,
                homeAppName = this.constants.APP_NAME_MAP.uconnect,
                currentAppName;

            this.logger.log({'onProfileSyncStart': content});

            this.profileSyncInProgress = true;

            switch (profileSyncStatus) {
            case "start":
                // todo what should we do when profile sync is started?
                break;

            case "inProgress":
                // todo need to put "aq" to constants
                // if host lib (AQ) updated - need to reload the page
                if (_.findWhere(content.updatingApps, {appName: 'aq'}) ||
                    _.findWhere(content.newApps, {appName: 'aq'})) {
                    this.needToRestart = true;
                    break;
                }

                // destroy applications that were loaded previously because of new version is available
                if (!_.isEmpty(content.updatingApps)) {
                    _.each(content.updatingApps, function (app) {
                        this.logger.log({'app:destroyed': app.appName});
                        this.appManager.destroyApp(app.appName.toLowerCase());
                    }, this);
                }
                break;

            case "complete":
                if (this.needToRestart) {
                    this.logger.log('[HMI][Re-Initialize][Refresh]');
                    window.location.reload();
                    break;
                }

                this.profileSyncInProgress = false;

                /**
                 * We should not render home screen 2nd time with exactly the same app list
                 * @see issue caused by 2 times rendering - https://airbiq.atlassian.net/browse/VPFR-1338
                 * 
                 * @note here we pre-process content.availableApps to be able to
                 * compare with current this.applications list, because
                 * @link this.saveAvailableApps() already did specific processing from the previous call
                 */
                if (_.isEqual(this.applications, this._processAppListItems(content.availableApps))) {
                    break;
                }
                
                this.saveAvailableApps(content.availableApps);
                this.startApplicationBy();

                currentAppName = this.appManager.getCurrentApplicationName();

                this.logger.log('before configs loaded:');
                this.logger.log({'currentAppName' : currentAppName});

                if (currentAppName === homeAppName) {
                    this.loadAppConfigs()
                        .done(function () {
                            this.logger.log({'configs loaded:': this.archiveVersionIds});
                            this.appManager.saveImageArchives(this.archiveVersionIds);
                        }.bind(this))
                        .fail(function () {
                            this.logger.log('HMI app configs are not loaded:');
                        }.bind(this));
                }
                
                break;

            default:
                // todo if something get wrong - trigger profile sync again
            }
        },

        renderHomeScreen: function (apps) {
            // home app name is needed to be set to prevent
            // other apps render calls to take focus from the background
            this._setHomeAppName();
            
            $.when(this.appManager.translation.reloadLocale("aq"))
                .done(function () {
                    var template = this._getHomeTemplate();
                    var filteredApps = _.chain(apps || this.applications)
                        .filter(function (app) {
                            return app.appName !== 'aq';
                        })
                        .sort(function (app) {
                            return app.appName;
                        })
                        .value();
                    
                    _.each(filteredApps, function (app) {
                        template.templateContent.list.push({
                            action: this.events.start,
                            value: app,
                            text: app.appDisplayName || '',
                            image1: 'file:///' + app.appName + '/images/launcher.png'
                        });
                    }, this);

                    // Always ignore partial update when sending home page screen, to avoid situations like:
                    // 1: @see https://airbiq.atlassian.net/browse/VPFR-1465
                    // 2: When user switches off all apps on the device at Manage My Apps screen,
                    //    HMI/HAP will send empty list what cause HUP show an App Setup page.
                    //    Next, after user has enabled at least one app, HMI/HAP sends a partial update
                    //    with only single item in app list.
                    template.ignorePartialUpdate = true;
                    
                    this.updateScreen(template);
                    this.startListening();
                }.bind(this));
        },


        /**
         * save first use data if every time application is used
         * do not save data if app runs twice and more times in a row
         * @param appName - application that was clicked on appList
         */
        writeFirstUsageReport: function (appName) {
            var appData = this.appManager.apps[appName];
            if (((!appData || appData.status !== this.constants.APP_STATUS.SUSPENDED)&&
                this.firstUsageReport.reportIsReady())) {
                this.logger.log({'Ready to write first use data: ': appName});
                this.firstUsageReport.writeReport(this.constants.APP_NAME_MAP[appName]);
            }
        },

        _setHomeAppName: function () {
            var currentAppName = this.appManager.getCurrentApplicationName(),
                homeAppName = this.constants.APP_NAME_MAP.uconnect;

            if (currentAppName !== homeAppName) {
                this.appManager.setCurrentApplicationName(homeAppName);
            }
        },

        _getHomeTemplate: function () {
            return {
                templateId: 'vp4-3',
                loadingType: 3,
                templateContent: {
                    title: {
                        text: $.t('title'),
                        image: this.images.appLogo,
                        backgroundImage: this.images.titleBackground
                    },
                    buttons: {
                        7: {
                            image: {
                                normal: this.images.scrollUpBtn,
                                disabled: this.images.scrollUpBtnDisabled
                            }
                        },
                        8: {
                            image: {
                                normal: this.images.scrollDownBtn,
                                disabled: this.images.scrollDownBtnDisabled
                            }
                        },
                        10: {
                            action: this.events.source,
                            value: null,
                            image: {
                                normal: this.images.backButton
                            }
                        }
                    },
                    main: {
                        images: {
                            4: this.images.listBackground,
                            5: this.images.buttonbarDivider,
                            7: this.images.scrollTrack,
                            8: this.images.scrollSlider
                        }
                    },
                    cursor: {
                        image: {
                            normal: this.images.listCursorNormal,
                            pressed: this.images.listCursorPressed
                        }
                    },
                    list: []
                }
            };
        },

        /**
         * loading configs for all available HMI apps
         * @returns {deferred}
         */
        loadAppConfigs: function () {
            var dfd = $.Deferred(),
                dfdList = [];
            
            this.getAvailableApps()
                .done(function () {
                    _.each(this.applications, function (app) {
                        dfdList.push(this.generateAppConfigLoadDfd(app.appName));
                    }, this);
                    
                    $.when.apply(null, dfdList)
                        .done(dfd.resolve)
                        .fail(dfd.reject);
                }.bind(this))
                .fail(dfd.reject);
            
            return dfd.promise();
        },

        /**
         * Loads and returns content of config file for requested HMI application
         * 
         * @param appName
         * 
         * @returns {deferred}
         */
        generateAppConfigLoadDfd: function (appName) {
            var path = this.constants.RELATIVE_APP_PATH(appName),
                configFile = this.constants.APP_CONFIG_NAME;

            return $.getJSON(path.concat(configFile))
                .done(function (cfgFile) {
                    var appId = parseInt(cfgFile.appId, 10),
                        archiveVersion = parseInt(cfgFile.imageVersion, 10),
                        platform;
                    
                    // Keep the reference to each app config
                    this.appManager.appConfigs[appName] = cfgFile;
                    
                    if (appName === 'aq') {
                        platform = cfgFile.platform;
                        this.appManager.setPlatform(platform);
                    }
                    
                    // Sending zip only for the full HMI applications, not for
                    if (archiveVersion) {
                        this.archiveVersionIds[appName] = {
                            "appId": appId,
                            "archiveVersion": archiveVersion
                        };
                    }
                    
                    this.logger.log({
                        'Successfully loaded config for app: ': appName,
                        'archiveVersionId for app: ': archiveVersion,
                        'appId for app: ': appId
                    });
                    this.logger.log(cfgFile);
                }.bind(this))
                .fail(function () {
                    this.logger.log({'Failed to load config for app: ': appName});
                }.bind(this));
        }
    });
});
