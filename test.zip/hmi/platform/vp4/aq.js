/**
 *
 */
define(function (require) {
    'use strict';

    var PlatformServices = require('aq/dic'),
        VP4Services = require('vp4/dic');
    
    //require('aq/kpi').init(PlatformServices);
    require('jsperanto');

    var commonLogger = new (PlatformServices.get('Logger'))('med', 'WEB_VIEW', 'CORE');
    window.onerror = function (errorMsg, url, lineNumber, columnNumber, error) {
        commonLogger.error("[HMI][ERROR]: "+ url +" line "+ lineNumber +": "+ errorMsg);
        if (error) {
            commonLogger.error("[HMI][ERROR][TRACE]: " + error.stack);
        }
    };

    commonLogger.log({
        msg: 'HMI CORE initialized',
        version: 'Version: <VERSION>'
    });

    // WARNING: creation order is important!

    // cache images
    VP4Services.create('images');

    // request available applications
    // and notify HAP that HMI is ready to process messages
    VP4Services.create('appList');
    
    // System wide error handler
    VP4Services.create('ErrorHandler');
});
