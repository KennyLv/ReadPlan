define(['shared/utils/class',
        'aq/templates/handlers/translators/vp4-1',
        'aq/templates/handlers/translators/vp4-2',
        'aq/templates/handlers/translators/vp4-3',
        'aq/templates/handlers/translators/vp4-3-1',
        'aq/templates/handlers/translators/vp4-4',
        'aq/templates/handlers/translators/vp4-5',
        'aq/templates/handlers/translators/vp4-6',
        'aq/templates/handlers/translators/vp4-7',
        'aq/templates/handlers/translators/vp4-8'
    ],
    function (Class) {
    'use strict';

    var templates = Array.prototype.slice.call(arguments, 1),
        screenId = 1;

    return Class.extend({

        init: function (storage, appManager) {
            this.appManager = appManager;
            this.storage = storage;
            this.templateTypes = {};
            _.each(templates, function (Template) {
                var tpl = new Template(storage);
                this.templateTypes[tpl.templateName.toLowerCase()] = tpl;
            }, this);
        },

        translate: function (data) {
            // Clear actions map
            this.storage.clearActions();

            var OEMAppId = 0x9999;
            data.appId = parseInt(this.appManager.getActiveAppId(), 10) || OEMAppId;
            data.screenId = screenId++;

            data.systemHeader = !!data.systemHeader;

            data.backgroundImage = this.storage.getImageId({
                data: data.backgroundImage,
                w: 800,
                h: 480
            });
            
            // Here we have to re-write our templateId prefix to be vp4
            data.templateId = data.templateId.replace(/(\w+)(?=(-\d{1,2})+)/, "vp4");

            var template = this.templateTypes[data.templateId.toLowerCase()];

            return template ? template.translate(data) : null;
        }
    });
});
