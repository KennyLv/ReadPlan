/*
 *  = List =
 *  
 *  Template VP4-3
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-3",
 *      "templateContent" : {
 *          "title" : {
 *              "backgroundImage": <number>,
 *              "text": <string>
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              ... 10
 *          },
 *          "list": {
 *              "activeListItem" : <int>, //index in the array of the element to be highlighted. Defaults to null.
 *              "items": [{
 *                  "image1": <number>, // optional
 *                  "image2": <number>, // optional
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>,
 *                  "buttons": { // optional
 *                      "1": {
 *                          "image": {
 *                              "normal": <number>,
 *                              "pressed": <number>
 *                          },
 *                          "backgroundImage": {
 *                              "normal": <number>,
 *                              "pressed": <number>
 *                          },
 *                          "text": <string>,
 *                          "action": <string>,
 *                          "value": <string>
 *                      },
 *                      ...
 *                  }
 *              }, ...]
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  Text char limit in list is 16 (truncated by HU)
 *  Title char limit is 16
 *
 *   ________________________________________________
 *  | _____   |                         _____  _____ |
 *  || b_1 |  |         title         | b_3 || b_2 | |
 *  ||_____|  |                       |_____||_____| |
 *  |         |--------------------------------------|
 *  | _____   |                                 | /\ |  
 *  || b_4 |  |                                 |    |
 *  ||_____|  | img1 | text      | img2 |[act1] |    |
 *  | _____   |                                 |    |
 *  || b_5 |  | img1 | text      | img2 |[act1] |    |
 *  ||_____|  |                                 |    |
 *  | _____   | img1 | text      | img2 |[act1] |    |
 *  || b_6 |  |                                 |    |
 *  ||_____|  | img1 | text      | img2 |[act1] | \/ |
 *  |_________|_________________________________|____|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        itemIconSize: {w: 56, h: 52},
        buttonSize: {w: 72, h: 52},
        tabButtonSize: {w: 105, h: 75},
        sideButtonSize: {w: 102, h: 75},
        titleLongButtonSize: {w: 110, h: 56},
        titleShortButtonSize: {w: 87, h: 56},
        listItemId: 101, // offset for list item actions
        listActionId: 200, // offset for item sub-actions
        scrollButtonSize: {w: 89, h: 75},
        images: {
            1: {w: 780, h: 8},
            2: {w: 780, h: 8},
            3: {w: 7, h: 65},
            4: {w: 697, h: 413},
            5: {w: 3, h: 56},
            6: {w: 56, h: 52},
            7: {w: 8, h: 180},
            8: {w: 8, h: 73}
        },
        titleImage: {w: 48, h: 52},
        titleBackgroundImage: {w: 466, h: 56},
        listCursorImage: {w: 658, h: 74}
    };

    return Base.extend({

        templateName: 'vp4-3',

        buttons: _.range(1, 13),

        translate: function (data) {
            var items,
                template = {},
                content = data.templateContent;

            content.main = content.main || {};
            template.main = {};

            var title = _.isUndefined(content.title) ? '' : (content.title.text || content.title);
            template.title = {
                text: title,
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                }),
                backgroundImage: this.storage.getImageId({
                    data: content.title && content.title.backgroundImage,
                    w: CONSTANTS.titleBackgroundImage.w,
                    h: CONSTANTS.titleBackgroundImage.h
                })
            };

            if (content.list && content.list.items) {
                items = content.list.items;
            } else {
                items = _.isArray(content.list) ? content.list : [];
            }

            template.list = {
                activeListItem: _.isNumber(content.list && content.list.activeListItem) ?
                    content.list.activeListItem : 0,
                items: this.processListItems(items)
            };

//            Process images - get corresponding ID from in-memory storage
            var imageIds = {};
            _.each(content.main.images, function (image, key) {
                if (!_.isUndefined(CONSTANTS.images[key])) {
                    imageIds[key] = this.storage.getImageId({
                        data: image,
                        w: CONSTANTS.images[key].w,
                        h: CONSTANTS.images[key].h
                    });
                }
            }, this);
            template.main.images = imageIds;

            // 1 - 12
            template.buttons = this.getButtons(content.buttons);

            if (content.cursor) {
                template.cursor = {
                    image: {
                        normal: this.storage.getImageId({
                            data: content.cursor.image.normal,
                            w: CONSTANTS.listCursorImage.w,
                            h: CONSTANTS.listCursorImage.h
                        }),
                        pressed: this.storage.getImageId({
                            data: content.cursor.image.pressed,
                            w: CONSTANTS.listCursorImage.w,
                            h: CONSTANTS.listCursorImage.h
                        })
                    }
                };
            }

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 2), CONSTANTS.tabButtonSize),
                this.processButtons(this.filterByRange(buttons, 3, 3), CONSTANTS.sideButtonSize),
                this.processButtons(this.filterByRange(buttons, 7, 8), CONSTANTS.scrollButtonSize),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.titleLongButtonSize),
                this.processButtons(this.filterByRange(buttons, 11, 11), CONSTANTS.titleLongButtonSize),
                this.processButtons(this.filterByRange(buttons, 12, 12), CONSTANTS.titleShortButtonSize)
            );
        },

        processListItems: function (content) {
            var list = [];
            content = _.isArray(content) ? content : [];
            content.forEach(function (listItem, key) {

                var item = {};

                var leftImage = listItem.image || listItem.image1,
                    rightImage =  listItem.image2;

                item.image1 = this.storage.getImageId({
                    data: leftImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.image2 = this.storage.getImageId({
                    data: rightImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.text = _.isString(listItem.text) ? listItem.text : "";

                // Save list actions
                if (listItem.action !== undefined || listItem.value !== undefined) {
                    this.storage.addAction(key + CONSTANTS.listItemId, listItem.action, listItem.value);
                }
                
                // Process sub-actions in a list items if there any
                if (listItem.buttons) {
                    _.each(listItem.buttons, function (actionItem, aKey, original) {
                        // Shift each button's ID by constant offset
                        original[parseInt(aKey, 10) + CONSTANTS.listActionId] = actionItem;
                        delete original[aKey];
                    }, this);
                    
                    // Create copy of buttons inside action list item
                    item.buttons = _.extend({}, this.processButtons(listItem.buttons, CONSTANTS.itemIconSize));
                }

                list.push(item);
            }, this);

            return list;
        }
    });
});
