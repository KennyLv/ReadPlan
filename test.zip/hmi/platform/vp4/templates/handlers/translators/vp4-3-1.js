/*
 *  = List =
 *
 *  Template VP4-3-1
 *
 *  NOTE:
 *  This is exactly the same as VP4-3, but we need it to distinguish Pandora's "My Station" list easily.
 *  We just update template name here.
 *  On HUP side it is hard to work with Pandora-like and General list in case of partial updates -
 *  in that case there is no way for them to determine which list is actually arrived.
 *  Previously hup determined type of list basing on presence button with ID 1 (a Tab "Date", see visual design specs).
 */

define(['aq/templates/handlers/translators/vp4-3'], function (BasicList) {
    'use strict';

    return BasicList.extend({
        templateName: 'vp4-3-1'
    });
});
