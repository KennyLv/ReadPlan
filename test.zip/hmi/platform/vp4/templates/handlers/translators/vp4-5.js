/*
 *  = Button Menu =
 *  
 *  Template VP4-5
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-5",
 *      "templateContent" : {
 *          "title": {
 *              "backgroundImage": <number>,
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 10
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *    _______________________________________________
 *   |   but_10  |                                   |
 *   |-----------------------------------------------|
 *   |   _ _ _ _ _ _    _ _ _ _ _ _    _ _ _ _ _ _   |
 *   |  |            | |            | |            | |
 *   |  |   but_1    | |   but_2    | |   but_3    | |
 *   |  |_ _ _ _ _ _ | |_ _ _ _ _ _ | |_ _ _ _ _ _ | |
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_4    | |   but_5    | |   but_6    | |
 *   |  |____________| |____________| |____________| |
 *   |_______________________________________________|
 *
 */

define(['aq/templates/handlers/translators/vp4-2'], function (Base) {
    'use strict';

    var CONSTANTS = {
        titleImage: {w: 270, h: 40},
        titleBackgroundImage: {w: 668, h: 56},
        backButton: {w: 110, h: 56}, // button 10
        actionButton: {w: 190, h: 116} // buttons 1 - 9
    };

    return Base.extend({

        templateName: 'vp4-5',

        buttons: _.range(1, 11),

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 9), CONSTANTS.actionButton),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.backButton)
            );
        }
    });
});
