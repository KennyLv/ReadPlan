/*
 *  = Popup =
 *  
 *  Template VP4-1
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-1",
 *      "templateContent" : {
 *          "title" : {
 *              "backgroundImage": <number>,
 *              "text": <string>
 *          },
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              },
 *              "images": {
 *                  "1": <number>,
 *                  ....
 *              }
 *          },
 *          "buttons" : {
 *              "1": { // This is a "Cross" button which just acts the same as "Cancel", closing the popup window
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
  *             ... 6
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  main text char limit is 85
 *  buttons text char limit is 14
 *    _______________________________________________
 *   |                                               |
 *   |-----------------------------------------------|
 *   |   _________________________________________   |
 *   |  |                                         |  |
 *   |  |              title                [ X ] |  |
 *   |  |                                         |  |
 *   |  |            main text                    |  |
 *   |  |                                         |  |
 *   |  | --------------------------------------- |  |
 *   |  |   button   |    button     |   button   |  |
 *   |  |_________________________________________|  |
 *   |_______________________________________________|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        buttons: {
            // 1
            close: {w: 66, h: 71}, // "Close" button
            // 2 - 6
            main: {w: 136, h: 68}
        },
        images: {
            4: { w: 780, h: 413 } // popup background
        }
    };

    return Base.extend({

        templateName: 'vp4-1',

        buttons: _.range(1, 7),

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.title = content.title || '';
            template.title = {
                text: content.title.text || content.title
            };

            content.main = content.main || {};
            var text = _.isObject(content.main.text) ? content.main.text[1] : content.main.text;
            template.main = {
                text: {
                    1: text
                }
            };
            template.buttons = this.getButtons(content.buttons);

            // Process images - get corresponding ID from in-memory storage
            var imageIds = {};
            _.each(content.main.images, function (image, key) {
                if (!_.isUndefined(CONSTANTS.images[key])) {
                    imageIds[key] = this.storage.getImageId({
                        data: image,
                        w: CONSTANTS.images[key].w,
                        h: CONSTANTS.images[key].h
                    });
                }
            }, this);
            template.main.images = imageIds;

            /*
            * ignorePartialUpdate is set to true here for a need on VPFR-1353
            * TODO: check if this fix will not produce some new bugs
            */

            data.ignorePartialUpdate = true;
            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons.close),
                this.processButtons(this.filterByRange(buttons, 2, 6), CONSTANTS.buttons.main)
            );
        }
    });
});
