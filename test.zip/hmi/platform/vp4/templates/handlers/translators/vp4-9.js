/*
 *  TODO: This is new sort of player, AHA radio.
 */
//define(['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, Utils) {
//    "use strict";
//    
//    return {};
//});
