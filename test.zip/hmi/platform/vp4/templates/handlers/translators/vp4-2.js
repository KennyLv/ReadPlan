/*
 *  = Player with side buttons =
 *  Template VP4-2
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-2",
 *      "templateContent" : {
 *          "title": {
 *              "backgroundImage": <number>,
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>,
                    "disabled" : < boolean >,
                    "active" : < boolean >
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>,
                    "disabled" : < boolean >,
                    "active" : < boolean >
 *              },
 *              ... 9
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "3": <string>
 *              },
 *              "images": {
 *                  "1" : <number>
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_10  |                                    |
 *   |-----------------------------------------------|
 *   | ____   _____________                     ____ |
 *   |     | |             |                   |     |
 *   |     | |             |  text_1           |     |
 *   | b_8 | | main_image  |  text_2           | b_9 |
 *   |     | |             |  text_3           |     |
 *   | ____| |             |                   |____ |
 *   |       |_____________|  [ progress ]           |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // 1 - 7
        stripeButton: {
            basic: {w: 130, h: 56},
            premium: {w: 108, h: 56}
        }, // TODO could be dynamic
        // 10
        button: {w: 110, h: 56},
        // 8, 9
        sideButton: {w: 92, h: 121},

        images: {
            1: {w: 138, h: 150}, // mainImageItem,
            2: {w: 40, h: 30},// sideImageItem
            3: {w: 780, h: 8}, // buttonbarFrameBorderImage
            4: {w: 780, h: 8}, // buttonbarFrameBorderImage
            5: {w: 7, h: 65}, // buttonbarFrameShadowImage
            6: {w: 3, h: 56} // buttonbarDivider
        },

        titleImage: {w: 270, h: 4},
        titleBackgroundImage: {w: 668, h: 56}
    };

    return Base.extend({

        templateName: 'vp4-2',

        buttons: _.range(1, 8),

        translate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = this.getButtons(buttons);


            content.main = content.main || {};
            content.main.text = content.main.text || {};
            template.main = {};

            var item,
                items = {};
            for (var i = 1; i < 4; i++) {
                item = content.main.text[i] || {};
                items[i] = item.text || '';
            }
            template.main.text = items;

            template.main.images = this.getImages(content.main.images);
            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                }),
                backgroundImage: this.storage.getImageId({
                    data: content.title && content.title.backgroundImage,
                    w: CONSTANTS.titleBackgroundImage.w,
                    h: CONSTANTS.titleBackgroundImage.h
                })
            };

            // progress bar
            template.progress = {};
            if (content.progress && content.progress.total) {
                template.progress = {
                    total: content.progress.total,
                    current: content.progress.elapsed / content.progress.total,
                    color: content.progress.color,
                    active: content.progress.active
                };
            }

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            var stripeButton = buttons[7] ? CONSTANTS.stripeButton.premium : CONSTANTS.stripeButton.basic;

            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 7), stripeButton),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.button),
                this.processButtons(this.filterByRange(buttons, 8, 9), CONSTANTS.sideButton)
            );
        },

        getImages: function (origTemplateImages) {
            var templateImages = origTemplateImages || {};

            // Process images - get corresponding ID from in-memory storage
            var imageIds = {};
            _.each(templateImages, function (image, key) {
                if (!_.isUndefined(CONSTANTS.images[key])) {
                    imageIds[key] = this.storage.getImageId({
                        data: image,
                        w: CONSTANTS.images[key].w,
                        h: CONSTANTS.images[key].h
                    });
                }
            }, this);

            return imageIds;
        }

    });
});
