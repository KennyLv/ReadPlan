/*
 *  = Player with side buttons =
 *  Template VP4-6
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-6",
 *      "templateContent" : {
 *          "title": {
 *              "backgroundImage": <number>,
 *              "image": <number>
 *          },
 *          "buttons" : {
 *              "1" : {
 *                  "image" : {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              "2" : {
 *                  "text": <string>,
 *                  "action" : <string>,
 *                  "value" : <string>
 *              },
 *              ... 10,
 *          },
 *          "main" : {
 *              "text": {
 *                  "1": <string>,
 *                  "2": <string>,
 *                  "3": <string>
 *              },
 *              "images": {
 *                  "1" : <number>
 *              }
 *          },
 *          "progress": {
 *              "color": <string>, //Hex color code, eg. "#FFFFFF"
 *              "current": <number>, // Between 0 and 1. For example, 0.5 == 50%
 *              "total": <number>, // Total length in seconds
 *              "active": <boolean>  // Playing or not
 *          }
 *      }
 *  }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   but_10  |                 | but_12 | but_11 |
 *   |-----------------------------------------------|
 *   | ________                            ________  |
 *   || but_20 |                          | but_21 | |
 *   ||________|                          |________| |
 *   | _____________                                 |
 *   ||             |                        . . .   |
 *   ||             |  text_1                . . .   |
 *   || main_image  |  text_2              ________  |
 *   ||             |  text_3             | but_23 | |
 *   ||             |                     |________| |
 *   ||_____________|                                |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | . . . | but_9 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 */

define(['aq/templates/handlers/translators/vp4-2'], function (Player) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 154, h: 56},
        // 10
        exitButton: {w: 110, h: 56},
        // 20 - 23...
        asideButton: {w: 136, h: 68},
        
        mainImageItem: {w: 138, h: 150},
        titleImage: {w: 270, h: 40}
    };

    return Player.extend({

        templateName: 'vp4-6',

        buttons: _.range(1, 23),

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 10, 10), CONSTANTS.exitButton),
                this.processButtons(this.filterByRange(buttons, 20, 23), CONSTANTS.asideButton)
            );
        }
    });
});
