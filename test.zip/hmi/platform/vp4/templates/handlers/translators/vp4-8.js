/*
 * = Loading screen =
 * 
 * Template VP4-8
 *
 * Sample JSON:
 
 *  {
 *      "templateId" : "VP4-8"
 *      "templateContent" : {
 *          "main": {
 *              "text": {
 *                  "1": <string>
 *              },
 *              "images": {
 *                  "1": <number>
 *              }
 *          }
 *      }
 *  }
 *
 *
 *
 *  item_1 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |                                               |
 *   |                 _____________                 |
 *   |                |             |                |
 *   |                |             |                |
 *   |                |  image_1    |                |
 *   |                |             |                |
 *   |                |_____________|                |
 *   |                                               |
 *   |                     text_1                    |
 *   |_______________________________________________|

 *
 *
 *
 */


define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        mainImageItem: { w: 520, h: 200 }
    };

    return Base.extend({

        templateName: 'vp4-8',

        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.main = content.main || {};
            template.main = {};

            if (content.main.images && content.main.images[1]) {
                template.main.images = {
                    "1": this.storage.getImageId(_.extend({
                        data: content.main.images[1]
                    }, CONSTANTS.mainImageItem))
                };
            }
            if (content.main.text && content.main.text[1]) {
                template.main.text = template.main.text || {};
                template.main.text[1] = content.main.text[1];
            }

            data.templateContent = template;
            
            return data;
        }
    });
});
