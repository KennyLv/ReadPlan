/*
 *  = Popup with images =
 *  
 *  Template VP4-7
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP4-7"
 *      "templateContent" : {
 *          "title" : {
 *              "backgroundImage": <number>,
 *              "text": <string>
 *          },
 *          "main": {
 *              "text": {
 *                  "1": <string>,
 *                  ... 3
 *              },
 *              "images": {
 *                  "1": <number>,
 *                  "4": <number>
 *              }
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal" : <number>,
 *                      "pressed" : <number>
 *                  },
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              "2": {
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *             ... 4
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        images: {
            1: { w: 138, h: 150 }, // preview image, like - next station for Slacker
            4: { w: 790, h: 240 } // background image for the whole popup
        },
        buttons: {
            1: {w: 66, h: 71}, // [ X ] button
            2: {w: 136, h: 68}, // Next/Prev buttons
            // 3 - 4
            standard: {w: 136, h: 68}
        }
    };

    return Base.extend({

        templateName: 'vp4-7',

        buttons: _.range(1, 5),

        translate: function (data) {

            var template = {}, key,
                content = data.templateContent;

            content.title = content.title || '';
            template.title = {
                text: content.title.text || content.title
            };

            content.main = content.main || {};
            content.main.text = content.main.text || {};
            content.main.images = content.main.images || {};

            template.main = {
                text: {},
                images: {}
            };

            for (key = 1; key < 4; key++) {
                template.main.text[key] =  content.main.text[key] || "";
            }

            // Process images - get corresponding ID from in-memory storage
            var imageIds = {};
            _.each(content.main.images, function (image, key) {
                if (!_.isUndefined(CONSTANTS.images[key])) {
                    imageIds[key] = this.storage.getImageId({
                        data: image,
                        w:    CONSTANTS.images[key].w,
                        h:    CONSTANTS.images[key].h
                    });
                }
            }, this);
            template.main.images = imageIds;

            template.buttons = this.getButtons(content.buttons);

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons[1]),
                this.processButtons(this.filterByRange(buttons, 2, 2), CONSTANTS.buttons[2]),
                this.processButtons(this.filterByRange(buttons, 3, 4), CONSTANTS.buttons.standard)
            );
        }
    });
});
