/*
 *  = Keyboard =
 *  
 *  Template VP4-4
 *
 *  The sample JSON:
 *
 * {
 *      "templateId": "VP4-4",
 *      "partialUpdate": < boolean >, //optional. Defaults to false
 *      "appId": < int >,
 *      "screenId": < int >,
 *      "backgroundImage": < int >, //optional. Defaults to default background image.
 *      "systemHeader": < boolean >,
 *      "templateContent": {
 *          "title": {
 *              "text": < string >
 *          },
 *          "main": {
 *              "images": {
 *                  1: < int >, // imageId,
 *                  ....
 *              }
 *          },
 *          "buttons": {
 *              1: {
 *                  "image": {
 *                      "normal": < int >, // imageId
 *                      "pressed": < int >, // imageId - optional. If not passed, or passed as 0,
 *                                                   nothing happens when user touches the given button
 *                      "disabled" : < int > // imageId - optional
 *                  },
 *                  "backgroundImage": { // optional
 *                      "normal": < int >, // imageId
 *                      "pressed": < int >, // imageId - optional. If not passed, or passed as 0,
 *                                                      nothing happens when user touches the given button
 *                      "disabled": < int > // imageId - optional
 *                  }
 *              },
 *              2: { ... },
 *              3: { ... } This is only a single button, information from which will be used to render HUP buttons
 *          }
 *      }
 * }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *    _______________________________________________
 *   |                                               |
 *   |-----------------------------------------------|
 *   |   _________________________________________   |
 *   |  |                                         |  |
 *   |  |  | A |  | B |  | C | ... | K |          |  |
 *   |  |   .........................             |  |
 *   |  |            main text                    |  |
 *   |  |  | btn |  | btn |  | btn | ... | Z |    |  |
 *   |  |                                         |  |
 *   |  |                             [ SWITCH |  |  |
 *   |  |_________________________________________|  |
 *   |_______________________________________________|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        buttons: {
            // 1
            close: {w: 66, h: 71}, // "Close" button
            // 2
            switch: {w: 173, h: 77},
            // 3+
            keyboard: {w: 77, h: 77}
        },
        images: {
            1: {w: 90, h: 52}, // ABC Icon
            4: {w: 780, h: 413} // popup background
        }
    };
    
    return Base.extend({

        templateName: 'vp4-4',
        
        translate: function (data) {

            var template = {},
                content = data.templateContent;

            content.title = content.title || '';
            template.title = {
                text: content.title.text || content.title
            };

            content.main = content.main || {};
            template.main = {};
            template.buttons = this.getButtons(content.buttons);

            // Process images - get corresponding ID from in-memory storage
            var imageIds = {};
            _.each(content.main.images, function (image, key) {
                if (!_.isUndefined(CONSTANTS.images[key])) {
                    imageIds[key] = this.storage.getImageId({
                        data: image,
                        w: CONSTANTS.images[key].w,
                        h: CONSTANTS.images[key].h
                    });
                }
            }, this);
            template.main.images = imageIds;

            return this._super(data, template);
        },

        getButtons: function (buttons) {
            buttons = buttons || {};
            
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 1), CONSTANTS.buttons.close),
                this.processButtons(this.filterByRange(buttons, 2, 2), CONSTANTS.buttons.switch),
                this.processButtons(this.filterByRange(buttons, 3, 3), CONSTANTS.buttons.keyboard)
            );
        }
    });
});
