define(['shared/utils/class', 'aq/templates/handlers/translator', 'aq/templates/handlers/partialUpdate'],
    function (Class, Translator, PartialUpdate) {
    'use strict';

	var handlers = [];

    return Class.extend({

        init: function (displayedTemplateData, storage, appManager) {

            displayedTemplateData.LastUpdate = {};

            this.addHandler(new Translator(storage, appManager))
                .addHandler(new PartialUpdate({
                    cache: displayedTemplateData,
                    expand: {
                        buttons: true,
                        // main > main.images and main.text
                        main: true,
                        images: true,
                        text: true
                    }
                }));
        },

        addHandler: function (handler) {
            handlers.push(handler);
            return this;
        },

        process: function (indata) {
            var data = $.extend(true, {}, indata);
            handlers.forEach(function (handler) {
                data = $.extend(true, {}, handler.translate(data));
            });

            return data;
        }
    });
});
