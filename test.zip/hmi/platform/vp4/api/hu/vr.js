/**
 * @override VoiceRecognition module for applications launch
 * 
 * VP4 platform uses simple app name (pandora, iheartradio, etc.) as a launch name used by HUP.
 * @see 
 * @link https://airbiq.atlassian.net/wiki/display/VP465/HMI+to+HUP#HMItoHUP-9.VRUpdateEvent-TBD      
 * @link https://airbiq.atlassian.net/browse/VPFR-1219
 */

define(['aq/api/hu/vr'], function (BaseVr) {
    'use strict';

    return BaseVr.extend({

        init: function (transport, utils, constants, appManager) {
            this.appManager = appManager;
            this._super(transport, utils, constants);
        },

        /**
         * @override
         *  
         * @param apps {Array}
         * [
         *   appDisplayName: <appDisplayName>,
         *   appName: <appName>
         * ]
         */
        setVrAppLaunchByListOfApps: function (apps) {
            var appNameMap = this.constants.APP_NAME_MAP,
                vrAppList = {};

            // filter out not needed apps from list of all available apps
            var allowedVrApps = apps.filter(function (app) {
                return appNameMap[app.appName];
            });
            
            _.each(allowedVrApps, function (app) {
                var appConfig = this.appManager.appConfigs[app.appName];
                if (!_.isUndefined(appConfig)) {
                    vrAppList[parseInt(appConfig.appId, 10)] = {
                        displayName: app.appName,
                        launchName: appNameMap[app.appName]
                    };
                }
            }, this);

            this.setVrAppLaunch(vrAppList);
        },

        /**
         * @override
         * @param map {Object}
         * <code>
         * { <int>: {
         *      displayName: <string>,
         *      launchName: <handsetAppNAme>,
         *   }
         * }
         * </code>
         * <example>
         * {...,
         *    3: { displayName: "iheartradio", launchName: "com.clearchannel.iheartradio"},
         *  ...}
         * </example>
         *
         * @returns {$.Deferred}
         */
        setVrAppLaunch: function (list) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'setVrAppLaunch',
                    data: list
                }
            });
        }
    });
});
