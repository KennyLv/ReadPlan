/**
 * This is to override VP4 specific method of the Screen module
 */
define(['aq/api/hu/screen'], function (BaseScreen) {
    "use strict";

    return BaseScreen.extend({

        /**
         * @override
         * 
         * @param requestContent {Object} - { "appName": <String>, ... }
         * @param sequenceNumber {Number}
         * 
         * @returns Deferred
         */
        sendImageArchive: function (requestContent, sequenceNumber) {
            var requestData = requestContent && requestContent.data,
                appData = this.zipMap[requestData.appName],
                path = this.constants.URL.filePath,
                archiveType= this.constants.IMAGE_ARCHIVE.JAR;

            if (this.utils.getPlatform() === "android") {
                path = this.constants.URL.androidPath;
            }
            path = path + requestData.appName + "/assets_" + parseInt(appData.appId + "" + appData.archiveVersion, 10) +
                "." + archiveType;

            this.appManager.logger.log({
                'sendImageArchive': path
            });

            return this._transport._onSendRequest({
                "path": "thor/file",
                "headers": {"Content-Type": "application/" + archiveType},
                "method": "POST",
                "sequenceNumber": sequenceNumber,
                "code": 200,
                "status": "OK",
                "responseHandler": {
                    'name': 'file',
                    'params': {
                        url: path
                    }
                }
            });
        },

        /**
         * @override
         * 
         * @param zipMap {Object}
         * 
         * @returns {jqXHR|jQuery.Deferred}
         */
        saveZip: function (zipMap) {
            this.zipMap = zipMap;

            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "saveFile",
                    "data": {
                        "fileIds" : zipMap
                    }
                }
            });
        }
        
    });
});
