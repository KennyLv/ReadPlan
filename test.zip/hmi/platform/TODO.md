## TODO

* unit tests
* git hooks (jshint + tests)
* finish readme
* use jscs as code style guide
* use wrappers for jquery deferred and ajax
* move build files to own directory
* adjust profileStateChange logic
* general error handling (3.4 from spec, p. 41)
