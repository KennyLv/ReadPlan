define(function () {
    "use strict";
    
    return {
        title: 'Works!'
    };
});
