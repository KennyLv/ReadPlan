define('aq/utils',[],function () {
    'use strict';

    return {

        /**
         * Parse a string as JSON. If the JSON is invalid, this function throws
         * a SyntaxError unless the safe option is set.
         *
         * @param {string} json The JSON string
         * @param {function} [reviver] prescribes how the value originally produced by parsing is transformed
         * @param {boolean} [safe=true] True to return null, false to throw an exception
         * @returns {object} returns the Object corresponding to the given JSON text or null
         */
        parseJSON: function (json, reviver, safe) {
            safe = safe !== false;

            try {
                return JSON.parse(json, reviver);
            } catch (e) {
                if (safe === true) {
                    return null;
                }
                throw e;
            }
        },

        /**
         * Convert value to JSON like string
         *
         * @param json {string|boolean|object}
         * @param [replacer] {function}
         * @param [space] {number}
         * @param [safe] {boolean} true by default. suppress any exceptions
         * @returns {json|error} return converted json or throw exception
         */
        toJSON: function (json, replacer, space, safe) {
            space = typeof space !== 'number' ? 2 : space;
            safe = safe !== false;

            try {
                var result = JSON.stringify(json, replacer, space);
                if (result === undefined) {
                    throw new Error('undefined cant be converted to json');
                }
                return result;
            } catch (e) {
                if (safe === true) {
                    return JSON.stringify({});
                }
                throw e;
            }
        },

        /**
         * @param list {Array}
         */
        toObject: function (list) {
            return _.reduce(list, function (memo, val, index) {
                memo[index] = val;
                return memo;
            }, {});
        },

        /**
         * @fixme: This method should not be here because it is not a kind of general purpose util method
         */
        isReportDataEmpty: function(data) {
            return !_.contains(_.map(data, function(value) {
                return isFinite(value) && !_.isArray(value) ? false : _.isEmpty(value);
            }), false);
        },

        /**
         *
         * @returns {string} android || ios
         */
        getPlatform: function () {
            return this.platfrom || this._getPlatform();
        },

        _getPlatform: function () {
            var ios = /iPhone/i;

            this.platfrom = ios.test(window.navigator.userAgent) ? 'ios' : 'android';
            return this.platfrom;
        },

        isEqual: function (a, b) {
            return this.toJSON(a) === this.toJSON(b);
        },

        ellipsis: function (str, length) {
            str = typeof str !== 'string' ? '' : str;
            return str.length > length ? str.substring(0, length).concat('...') : str;
        },
        
        freeze: function (o) {
            return Object.freeze ? this._freeze(o) : o;
        },

        _freeze: function (o) {
            Object.freeze(o);

            Object.getOwnPropertyNames(o).forEach(function (prop) {
                if (o.hasOwnProperty(prop) && o[prop] !== null &&
                    (typeof o[prop] === "object") && !Object.isFrozen(o[prop])) {
                    this._freeze(o[prop]);
                }
            }, this);

            return o;
        },

        /**
         * Check that passed object contain given path
         *
         * @param o {Object}
         * @param p {String}
         */
        resolve: function (o, p) {
            o = Object.prototype.toString.call(o) === "[object Object]" ? o : {};

            var delimiter = ".",
                path = String.prototype.split.call(p || "", delimiter);

            return path.reduce(function (obj, key) {
                return (obj !== undefined && obj !== null) ? obj[key] : obj;
            }, o);
        }

    };
});
