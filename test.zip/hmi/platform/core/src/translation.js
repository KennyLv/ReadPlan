/**
 * Translation module
 *
 * @export $.t
 */
define('aq/translation',['shared/utils/class'], function (Class) {
    'use strict';

    var lang = 'en-us',
        fallbackLang = lang,

        localesBaseFolder = 'locales',
        inMovingLocalesFolder = localesBaseFolder + '/' + 'moving',
        localesFolder = localesBaseFolder;

    return Class.extend({

        init: function (profile, constants, navigation) {

            /**
             * collection for loaded locales in format
             *
             * {
             *   appName: locale,
             *   ...
             * }
             */
            this.loaded = {};
            this.currAppName = false;
            
            this.config = constants;
            this.profile = profile;
            this.navigation = navigation;

            this.profile.on(this.profile.events.headUnitLanguage, this.onLanguageChanged, this);
            this.navigation.on(this.navigation.events.vehicleState, this.onVehicleStateChanged, this);


            // fetch language and vehicle state on head unit connection
            this.profile.on(this.profile.events.appModeStateChange, function (response) {
                if (response.data.state === 'start') {
                    this.navigation.getVehicleState();
                    this.profile.getLanguage();
                }
            }.bind(this));

            // and in case if page was reloaded due to update - fetch language and vehicle state immediately
            this.navigation.getVehicleState();
            this.profile.getLanguage();

            //init AQ locale for OEM app

        },

        _setLanguage: function (language) {
            lang = language;
        },

        _setLocalesFolder: function (state) {
            var isMoving = state === this.navigation.vehicleStates.moving;
            localesFolder = isMoving ? inMovingLocalesFolder : localesBaseFolder;
        },

        getLanguage: function () {
            return lang;
        },

        getLocalesFolder: function () {
            return localesFolder;
        },

        onVehicleStateChanged: function (data) {
            this._setLocalesFolder(data.state);
            _.each(this.loaded, function (locale, appName) {
                this.initLocale(appName);
            }.bind(this));
        },

        onLanguageChanged: function (response) {
            var code = response.data.code;
            this._setLanguage(code);
            _.each(this.loaded, function (locale, appName) {
                this.initLocale(appName);
            }.bind(this));
        },

        /**
         * Download translation file according to current language and application name
         * then store it locally and init $.esperanto
         * @param appName
         * @returns {$.Deferred}
         */
        initLocale: function (appName) {
            var path = this.config.RELATIVE_APP_PATH(appName),
                dfd = $.Deferred(),
                options = {
                    lang: lang,
                    fallbackLang: lang,
                    dicoPath: path + this.getLocalesFolder()
                };

            var onSuccess = function (data) {
                this.loaded[appName] = data;
                if(this.currAppName){
                    this.reloadLocale(this.currAppName);
                }
                dfd.resolve();
            }.bind(this);

            $.jsperanto.init(function () {}, options)
                .done(onSuccess)
                .fail(function () {
                    // try to use fallback lang
                    $.jsperanto.init(function () {
                        var isSuccess = $.jsperanto.lang();
                        return isSuccess ? dfd.resolve() : dfd.reject();
                    }, _.extend(options, {lang: fallbackLang})).done(onSuccess);
                });

            return dfd.promise();
        },

        /**
         * Init $.esperanto with the translation file according to given appName and current language
         * If translation file not loaded yet - load it
         * @param appName
         * @returns {*}
         */
        reloadLocale: function (appName) {
            this.currAppName = appName;
            return this.loaded[appName] ? $.jsperanto.init(function () {}, {
                dictionary: this.loaded[appName]
            }) : this.initLocale(appName);
        }

    });

});
