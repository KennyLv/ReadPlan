define('aq/appManager', ['shared/thor_interface/appManager', 'aq/eventEmitter'], function (AppManager, EventEmitter) {
	'use strict';

	/**
	 * @classdesc HMI application manager. Used to manage HMI application
	 *
	 * Each application should have next mandatory methods:
	 *
	 * -> start() (called when application is about started)
	 * -> onSuspend() (called when user starts another application, thus current one goes to 'suspended' state)
	 * -> onClose() (called when application is about closed, e.g. user presses 'Exit' button, etc)
	 *
	 */
	return EventEmitter.extend(AppManager).extend({

		events : {
			showHomeScreen : 'showHomeScreen'
		},

		/**
		 * apps: {
		 *      home: {
		 *      status: [active|suspended|closed],
		 *      type: [cloud|extension|base],
		 *      id: {String}
		 * }
		 */
		apps : {},

		/**
		 * Keep configs of each available HMI app
		 */
		appConfigs : {},

		/**
		 * @constructor
		 *
		 * @param options {object}
		 */
		init : function (options) {
			this.dic = options.dic;
			this.constants = options.constants;
			this.logger = new(this.dic.get('Logger'))('high', 'WEB_VIEW', 'APP_MANAGER');
			this.translation = options.translation;
			this.currentAppName = this.constants.APP_NAME_MAP.uconnect;
		},

		/**
		 * Start HMI application
		 *
		 * @param {object} params
		 *
		 * @example
		 * {
		 *   "appName": "iheartradio"
		 * }
		 */
		startApp : function (params) {
			var self = this,
			appName = params.appName,
			images = self.dic.get('images');

			self.setCurrentApplicationName(appName);
			self.logger.log({
				'Before app loaded: ' : appName
			});

			// application was never loaded before
			if (!self.apps[appName]) {
				self.loadProfile(appName)
				.done(function (cfg) {
					console.log("========appManager===loadProfile====done================" + appName);
					cfg = cfg[0];
					self._injectAllScript(cfg.files).done(function () {
						self.logger.log({
							'LOADED: ' : {
								appName : appName,
								version : cfg.version
							}
						});

						console.log("=====appManager===_injectAllScript===done================");

						setTimeout(function () {

							var app = self.apps[appName] = require(appName),
							appImages = cfg.images || {},
							imageIds;
							
							app.appId = cfg.appId;
							app.cfg = cfg;
							app.type = cfg.type;

							app.on('suspend', function () {
								self.suspendApp(appName);
							});

							app.on('close', function () {
								self.closeApp(appName);
								self.trigger(self.events.showHomeScreen);
							});

							// We have to pre-fill local in-memory storage with ID <-> filePath before starting HMI app
							imageIds = images.addImageIdsToLocalStore(appImages, app.appId);

							$.when(self._startApp(app, appName)).done(function () {
								images.cacheAppImages(imageIds, app.appId);
							}
								.bind(self));

						}, 2000);

					});
				})
				.fail(function (res) {
					console.log("===========falied================");
					self.logger.error({
						"Can't load application assets for: " : appName
					});
					self.logger.error(res ? res.responseText : 'net::ERR_FILE_NOT_FOUND');
					self.trigger(self.events.showHomeScreen, true);
				});

			} else {
				this._startApp(self.apps[appName], appName);
			}
		},

		_startApp : function (app, appName) {
			var returnObj = {};

			this.translation.reloadLocale(appName);
			returnObj = app.start(this.dic);
			app.status = this.constants.APP_STATUS.RUNNING;
			this.logger.log({
				'Started: ' : appName
			});

			return returnObj;
		},

		/**
		 * Close HMI application by name
		 *
		 * @param {string} appName
		 */
		closeApp : function (appName) {
			var app = this.apps[appName || this.getCurrentApplicationName()];
			if (app) {
				if (_.isFunction(app.onClose))
					app.onClose();
				app.status = this.constants.APP_STATUS.CLOSED;
			}
			this.logger.log({
				"closed app: " : appName || this.getCurrentApplicationName()
			});
		},

		/**
		 * Suspend HMI application by name
		 *
		 * @param appName
		 */
		suspendApp : function (appName) {
			var app = this.apps[appName || this.getCurrentApplicationName()];
			if (app) {
				if (_.isFunction(app.onSuspend))
					app.onSuspend();
				app.status = this.constants.APP_STATUS.SUSPENDED;
			}
			this.logger.log({
				"suspended app: " : appName || this.getCurrentApplicationName()
			});
		},

		destroyApp : function (appName) {
			this.closeApp(appName);

			// explicitly unloading modules and their dependencies
			// so that they can be garbage-collected
			var pattern = new RegExp('^' + appName);
			_.each(require._defined, function (module, name) {
				if (pattern.test(name)) {
					delete require._defined[name];
				}
			});
			if (this.apps[appName]) {
				this.apps[appName].off();
				this.apps[appName] = {};
				delete this.apps[appName];
			}
		},

		/**
		 * Switch application
		 *
		 * @param {string} appName
		 * @param {string} appCategory
		 *
		 * @return {string} new application name
		 */
		switchApp : function (appName, appCategory) {
			this.logger.log({
				"switchApp: " : appName
			});

			// suspend current app
			this.suspendApp();

			if (this.getCurrentApplicationName() !== appName) {

				// and if the current application is an audio app
				// and requested to open application is also audio app - stop/close current
				var playingApp = this.isAudioAppPlaying(),
				isAudioApp = appCategory === 'Music';
				// do not close app if we switch to the same app as currently playing
				if (playingApp && isAudioApp && playingApp !== appName) {
					this.closeApp(playingApp);
				}
			}

			this.startApp({
				appName : appName
			});
		},

		/**
		 * Loads application resources (app config, locales and code)
		 * If no application name specified current application will be fetched
		 *
		 * @param {string} [appName]
		 *
		 * @returns {jQuery.Deferred}
		 */
		loadProfile : function (appName) {
			this.logger.log({
				'Loading: ' : appName
			});

			appName = appName || this.getCurrentApplicationName();

			var path = this.constants.RELATIVE_APP_PATH(appName),
			configFile = this.constants.APP_CONFIG_NAME,
			applicationFile = this.constants.APP_FILE_NAME;

			return $.when(
				// app config
				$.getJSON(path.concat(configFile)),

				// app translation file
				this.translation.initLocale(appName)

				// all app code
				//this._injectScript(path.concat(applicationFile))

				// app code
				//this._injectScript(path.concat(applicationFile))
			);
		},

		//TODO : Add all script code
		//this._injectAllScript(allFiles.files)
		_injectAllScript : function (files) {
			var dfd = $.Deferred(),
			token = (+new Date()); // to avoid cache
			for (var i = 0; i < files.length; i++) {
				var script = document.createElement('script');
				script.src = '../' + files[i];
				//script.onload = dfd.resolve;
				//script.onerror = dfd.reject;
				window.document.head.appendChild(script);
			}
			dfd.resolve();
			return dfd.promise();
		},

		_injectScript : function (src) {
			var dfd = $.Deferred(),
			token = (+new Date()), // to avoid cache
			script = document.createElement('script');

			script.src = src + '?' + token;
			//script.onload = dfd.resolve;
			//script.onerror = dfd.reject;
			window.document.head.appendChild(script);
			return dfd.promise();
		},

		/**
		 * Get current running application name
		 *
		 * @return {string} name of current running application
		 */
		getCurrentApplicationName : function () {
			return this.currentAppName;
		},

		/**
		 * Set current running application name
		 *
		 * @param {string} appName
		 */
		setCurrentApplicationName : function (appName) {
			this.currentAppName = appName;
		},

		getActiveAppId : function () {
			return this.apps[this.currentAppName] && this.apps[this.currentAppName].appId;
		},

		saveImageArchives : function (archivesVersionMap) {
			var images = this.dic.get('images');
			this.logger.info({
				"saveImageArchives from the map: " : archivesVersionMap
			});
			images.sendImageArchives(archivesVersionMap);
		},

		getPlatform : function () {
			return this.platform;
		},

		/**
		 * setting platform type (vp4 or vp2c)
		 * @param platform string
		 */
		setPlatform : function (platform) {
			this.platform = platform;
		},

		/**
		 * start application on IOS appSwitch failure
		 */
		startAppAfterAppSwitchFailure : function () {
			this.startApp({
				appName : this.getCurrentApplicationName()
			});
		},

		/**
		 *
		 * @returns {String} playing application name
		 */
		isAudioAppPlaying : function () {
			var appNames = _.keys(this.apps),
			apps = this.apps,
			closed = this.constants.APP_STATUS.CLOSED;
			return _.find(appNames, function (appName) {
				return apps[appName].type === 'extension' && apps[appName].status !== closed;
			});
		},

		/**
		 * NOTE: `this` is an instance of appList here!
		 * @param data {Object}
		 *
		 * @return void
		 */
		updateAppConfigs : function (data) {
			if (data && data.state === 'connected') {
				// Only load config files for all application if it is the very first connection
				if (_.isEqual(this.appManager.appConfigs, {})) {
					this.loadAppConfigs();
				}
			}
		}
	});

});
