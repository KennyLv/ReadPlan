/**
 * Dependency injection container
 */
define('aq/dic',['require','aq/di','aq/storage','aq/view','aq/api/hu/audio','aq/api/hu/vr','aq/api/hu/navigation','aq/utils','aq/api/progressCounter','aq/api/logger','aq/api/commandControl','aq/appManager','aq/policy','aq/api/hap/appContainer','aq/translation','aq/images','aq/constants','aq/api/hap/fileManager','aq/api/hap/fileReporter','aq/api/hap/reports/firstUsageReport','aq/api/hap/reports/idcEventsReport','aq/api/hu/reportMetadata','aq/api/hu/baseMetaReporter','aq/api/hu/metaReporters/firstUsageMetaReporter','aq/api/hu/metaReporters/idcEventsMetaReporter','aq/api/hap/profile','aq/api/hu/controls','aq/api/hu/screen','aq/templates/processor','aq/api/transport/transport','aq/api/transport/ios','aq/api/transport/android','aq/api/transport/queue','aq/api/choreo','aq/errorHandler'],function (require) {
    'use strict';

    var Dic = require('aq/di');

    return new Dic({

        storage: function () {
            var Storage = require('aq/storage');
            return (this.registry.storage = new Storage(
                this.get('transport'),
                this.get('constants'),
                this.get('utils')
            ));
        },

        display: function () {
            var View = require('aq/view');
            this.registry.display = new View({
                utils:             this.get('utils'),
                storage:           this.get('storage'),
                constants:         this.get('constants'),
                controls:          this.get('controls'),
                screen:            this.get('screen'),
                appManager:        this.get('appManager'),
                TemplateProcessor: this.get('TemplateProcessor'),
                Logger:            this.get('Logger')
            });
			
			
			console.log("====================================this.registry.display=============================");
			console.log(this.registry.display);
			
            return this.registry.display;
        },

        audio: function () {
            var Audio = require('aq/api/hu/audio');
            return (this.registry.audio = new Audio(this.get('transport')));
        },

        vr: function () {
            var VR = require('aq/api/hu/vr');
            return (this.registry.vr = new VR(
                this.get('transport'), this.get('utils'), this.get('constants')));
        },

        navigation: function () {
            var Navigation = require('aq/api/hu/navigation');
            return (this.registry.navigation = new Navigation(this.get('transport')));
        },

        utils: function () {
            var utils = require('aq/utils');
            return (this.registry.utils = utils);
        },

        progressCounter: function() {
            var ProgressCounter = require('aq/api/progressCounter');
            return (this.registry.progressCounter = ProgressCounter);
        },

        Logger: function () {
            var Logger = require('aq/api/logger');
            return Logger.bind(Logger, this.get('transport'));
        },

        CommandControl: function () {
            return require('aq/api/commandControl');
        },
        /////////////////////////////////////

        appManager: function () {
            var AppManager = require('aq/appManager');
            var appManager = new AppManager({
                dic:         this,
                constants:   this.get('constants'),
                translation: this.get('translation')
            });

            return (this.registry.appManager = appManager);
        },

        appContainer: function () {
            var AppContainer = require('aq/api/hap/appContainer');
            return (this.registry.appContainer = new AppContainer(this.get('transport')));
        },

        translation: function () {
            var Translation = require('aq/translation');
            return (this.registry.translation = new Translation(
                this.get('profile'), this.get('constants'), this.get('navigation')));
        },


		policy:function(){
           var Policy = require('aq/policy');
		   return (this.registry.policy = new Policy(
						{
            navigation : this.get('navigation'),
            appManager : this.get('appManager'),
            transport  : this.get('transport')
						}
		   ));
		},
        images: function () {
            var Images = require('aq/images');
            return (this.registry.images = new Images(
                this.get('storage'),
                this.get('screen'),
                this.get('profile'),
                this.get('constants'),
                this.get('Logger')
            ));
        },

        constants: function () {
            return require('aq/constants');
        },

        fileManager: function () {
            var FileManager = require('aq/api/hap/fileManager');
            return (this.registry.fileManager = new FileManager({
                    transport:   this.get('transport'),
                    huMetaData:  this.get('reportMetadata'),
                    Logger:      this.get('Logger')
                }));
        },

        fileReporter: function () {
            var FileReporter = require('aq/api/hap/fileReporter');
            return (this.registry.fileReporter = new FileReporter({
                initData: {
                    transport:   this.get('transport'),
                    huMetaData:  this.get('reportMetadata'),
                    Logger:      this.get('Logger'),
                    fileManager: this.get('fileManager')
                },
                reports: {
                    firstUsageReport: require('aq/api/hap/reports/firstUsageReport'),
                    idcEventsReport: require('aq/api/hap/reports/idcEventsReport')
                }
            }));
        },

        reportMetadata: function () {
            var ReportMetadata = require('aq/api/hu/reportMetadata');
            return (this.registry.reportMetadata = new ReportMetadata({
                initData: {
                    transport:   this.get('transport'),
                    Logger:      this.get('Logger'),
                    controls: this.get('controls'),
                    appManager: this.get('appManager')
                },
                metaReporters: {
                    baseMetaReporter: require('aq/api/hu/baseMetaReporter'),
                    firstUsageMetaReporter: require('aq/api/hu/metaReporters/firstUsageMetaReporter'),
                    idcEventsMetaReporter: require('aq/api/hu/metaReporters/idcEventsMetaReporter')
                }
            }));
        },

        profile: function () {
            var Profile = require('aq/api/hap/profile');
            return (this.registry.profile = new Profile(this.get('transport')));
        },

        controls: function () {
            var Controls = require('aq/api/hu/controls');
            this.registry.controls = new Controls(this.get('storage'), this.get('constants'), this.get('transport'));
            return this.registry.controls;
        },

        screen: function () {
            var Screen = require('aq/api/hu/screen');
            this.registry.screen = new Screen({
                transport: this.get('transport'),
                storage: this.get('storage'),
                utils: this.get('utils'),
                constants: this.get('constants'),
                appManager: this.get('appManager')
            });
            return this.registry.screen;
        },

        TemplateProcessor: function () {
            return require('aq/templates/processor');
        },

        transport: function () {
            var Transport = require('aq/api/transport/transport'),
                utils = this.get('utils'),
                platform = utils.getPlatform() === 'ios' ? require('aq/api/transport/ios')
                    : require('aq/api/transport/android');

            this.registry.transport = new Transport(
                utils, require('aq/api/transport/queue'), platform
            );

            return this.registry.transport;
        },

        Choreo: function () {
            return require('aq/api/choreo');
        },
        
        ErrorHandler: function() {
            return require('aq/errorHandler');
        }

    });
});
