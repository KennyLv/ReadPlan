define('aq/constants',['aq/utils'], function (utils) {
    'use strict';

    /**
     * @const
     */
    return utils.freeze({

        APP_STATUS: {
            RUNNING: "running",
            CLOSED: "closed",
            SUSPENDED: "suspended"
        },

        PLATFORM: {
            VP2C : 'vp2c',
            VP4 : 'vp4'
        },

        IMAGE_ARCHIVE: {
            ZIP: 'zip',
            JAR: 'jar'
        },

        RELATIVE_APP_PATH: function (appName) {
            return "../<appName>/".replace(/<appName>/, appName);
        },

        APP_FILE_NAME: "src/app.js",
        APP_CONFIG_NAME: "app.json",

        /**
         * <appName>: <handsetAppName>
         *
         * appName - hmi app name
         * handsetAppName - handset app name that is used for appLaunch and meha messages
         */
        APP_NAME_MAP: {
            pandora : 'pandora',
            slacker : 'com.slacker.radio.Slacker',
            iheartradio : 'com.clearchannel.iheartradio',
            uconnect: 'uconnect'
        },

        APPS_GRAMMAR: {
            pandora: [
                "#'lOnt&S_p@n.'dO.R+$#", // "Launch Pandora"
                "#'lOnt&S_p@n.'dO.R+$_'va&I.$_'mo&U.b$l#", // "Launch Pandora Via Mobile"
                "#'o&U.p$n_p@n.'dO.R+$#", // "Open Pandora"
                "#'o&U.p$n_p@n.'dO.R+$_'va&I.$_'mo&U.b$l#" // "Open Pandora Via Mobile"
            ],
            slacker: [
                "#'lOnt&S_'sl@.k$R+#", // "Launch Slacker"
                "#'lOnt&S_'sl@.k$R+_'R+e&I.di.o&U#", // "Launch Slacker Radio"
                "#'lOnt&S_'sl@.k$R+_'va&I.$_'mo&U.b$l#", // "Launch Slacker Via Mobile"
                "#'o&U.p$n_'sl@.k$R+#", //  "Open Slacker"
                "#'o&U.p$n_'sl@.k$R+_'R+e&I.di.o&U#", // "Open Slacker Radio"
                "#'o&U.p$n_'sl@.k$R+_'va&I.$_'mo&U.b$l#" // "Open Slacker Via Mobile"
            ],
            iheartradio: [
                //old phonems
                "#'lOnt&S_'a&I.h$R+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Launch IHeartRadio Via Mobile"
                "#'lOnt&S_'a&I.h$R+t#", // "Launch iheart"
                "#'lOnt&S_'a&I.h$R+t_'va&I.$_'mo&U.b$l#", // "Launch iheart via Mobile"
                "#'lOnt&S_'2a&I.h$R+.'tR+e&I.di.o&U#", // "Launch iheartradio"
                "#'o&U.p$n_'a&I.'hAR+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Open iHeartRadio Via Mobile"
                "#'o&U.p$n_'a&I.h$R+t#", // "Open iheart"
                "#'o&U.p$n_'a&I.h$R+t_'va&I.$_'mo&U.b$l#", // "Open iheart via Mobile"
                "#'o&U.p$n_'2a&I.h$R+.'tR+e&I.di.o&U#", // "Open iheartradio"
                //new phonems added (according to cv-1961)
                "#'lOnt&S_'a&I.h$R+t.'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Launch IHeartRadio Via Mobile"
                "#'lOnt&S_'a&I_'hAR+t#", // "Launch iheart"
                "#'lOnt&S_'a&I_'hAR+t_'va&I.$_'mo&U.b$l#", // "Launch iheart via Mobile"
                "#'l@nt&S_'a&I_'hAR+t_'R+e&I.di.o&U#", // "Launch iheartradio"
                "#'o&U.p$n_'a&I_'hAR+t_'R+e&I.di.o&U_'va&I.$_'mo&U.b$l#", // "Open iHeartRadio Via Mobile"
                "#'o&U.p$n_'a&I_'hAR+t#", // "Open iheart"
                "#'o&U.p$n_'a&I_'hAR+t_'va&I.$_'mo&U.b$l#", // "Open iheart via Mobile"
                "#'o&U.p$n_'a&I_'hAR+t_'R+e&I.di.o&U#" // "Open iheartradio"
            ]
        },

        HARD_KEYS: {
            "h1": "back",
            "h2": "seekUp",
            "h3": "seekDown",
            "h4": "preset",
            "h5": "scroll",
            "h6": "unmute",
            "h7": "mute",
            "h8": "enter"
        },

        HARD_KEY_NAMES: {
            back: "back",
            seekUp: "seekUp",
            seekDown: "seekDown",
            preset: "preset",
            scroll: "scroll",
            unmute: "unmute",
            mute: "mute",
            enter: "enter"
        },

        /**
         * app switch btn (typeOfScreen value in applicationModeStateChange)
         */
        SWITCH_BTN_TYPES: {
            hard_btn: true,
            soft_btn: false
        },

        APP_LIST_COLOR: {
            VP2C: {
                uconnect: '#80b5ff',
                pandora: '#00adef',
                iheartradio: '#900e1a',
                slacker: '#cd5718'
            },
            VP4: {
                uconnect: 0x80b5ff,
                pandora: 0x00adef,
                iheartradio: 0x900e1a,
                slacker: 0xcd5718,
                aha: 0xb8741b
            }
        },

        URL: {
            filePath : "file:///",
            androidPath : "file:///HMI_ROOT/www/"
        },
		
				POLICY_ACTIONS:{
					IMAGE_STATION_LOGO: 'IMAGE.STATION_LOGO',
					IMAGE_ARTIST_IMAGE: 'IMAGE.ARTIST_IMAGE',
					IMAGE_USER_ICON: 'IMAGE.USER_ICON',
					IMAGE_POI_ICON: 'IMAGE.POI_ICON',
					IMAGE_DISABLED_WHILE_DRIVING: 'IMAGE.DISABLED_WHILE_DRIVING',
					IMAGE_HEADER: 'IMAGE.HEADER',
					IMAGE_RATINGS: 'IMAGE.RATINGS',
					IMAGE_DIRECTION_ARROW: 'IMAGE.DIRECTION_ARROW',
					IMAGE_TRACK: 'IMAGE.TRACK',
					IMAGE_ALBUM_ART: 'IMAGE.ALBUM_ART',
					IMAGE_ANIMATION: 'IMAGE.ANIMATION',
					IMAGE_BACKGROUND: 'IMAGE.BACKGROUND',
					BUTTON_THUMBS_UP: 'BUTTON.THUMBS_UP',
					BUTTON_THUMBS_DOWN: 'BUTTON.THUMBS_DOWN',
					BUTTON_MENU_ITEM: 'BUTTON.MENU_ITEM',
					BUTTON_MENU: 'BUTTON.MENU',
					BUTTON_PLAY: 'BUTTON.PLAY',
					BUTTON_STOP: 'BUTTON.STOP',
					BUTTON_FAVORITE: 'BUTTON.FAVORITE',
					BUTTON_BOOKMARK: 'BUTTON.BOOKMARK',
					BUTTON_DISABLED_WHILE_DRIVING: 'BUTTON.DISABLED_WHILE_DRIVING',
					BUTTON_SETTINGS: 'BUTTON.SETTINGS',
					BUTTON_SKIP: 'BUTTON.SKIP',
					BUTTON_PRESETS: 'BUTTON.PRESETS',
					BUTTON_PAGE_UP: 'BUTTON.PAGE_UP',
					BUTTON_PAGE_DOWN: 'BUTTON.PAGE_DOWN',
					BUTTON_SETLOCATION: 'BUTTON.SETLOCATION',
					TEXT_BUTTON: 'TEXT.BUTTON',
					TEXT_POI_NAME: 'TEXT.POI_NAME',
					TEXT_USER_NAME: 'TEXT.USER_NAME',
					TEXT_TRACK_NAME: 'TEXT.TRACK_NAME',
					TEXT_NAME: 'TEXT.NAME',
					TEXT_ADDRESS: 'TEXT.ADDRESS',
					TEXT_SHORT_DESCRIPTION: 'TEXT.SHORT_DESCRIPTION',
					TEXT_LONG_DESCRIPTION: 'TEXT.LONG_DESCRIPTION',
					TEXT_DATE: 'TEXT.DATE',
					TEXT_DISABLED_WHILE_DRIVING: 'TEXT.DISABLED_WHILE_DRIVING',
					TEXT_HEADER: 'TEXT.HEADER',
					TEXT_SCROLLING_HEADER: 'TEXT.SCROLLING_HEADER',
					TEXT_SCROLLING: 'TEXT.SCROLLING',
					TEXT_PRICE: 'TEXT.PRICE',
					TEXT_DISTANCE: 'TEXT.DISTANCE',
					TEXT_CITY: 'TEXT.CITY',
					TEXT_STATE: 'TEXT.STATE',
					TEXT_ZIPCODE: 'TEXT.ZIPCODE',
					TEXT_TIME: 'TEXT.TIME',
					TEXT_PHONE_NUMBER: 'TEXT.PHONE_NUMBER',
					TEXT_EMAIL_ADDRESS: 'TEXT.EMAIL_ADDRESS',
					TEXT_BACKGROUND: 'TEXT.BACKGROUND',
					LIST_ITEM_SELECT: 'LIST.ITEM_SELECT',
					LIST_PAGE_BY_PAGE_SCROLLING: 'LIST.PAGE_BY_PAGE_SCROLLING',
					LIST_ITEM_BY_ITEM_SCROLLING: 'LIST.ITEM_BY_ITEM_SCROLLING',
					TTS: 'TTS',
					KEYBOARD: 'KEYBOARD',
					VB_MAKE: 'VB.MAKE',
					VB_CONNECT_METHOD: 'VB.CONNECT_METHOD',
					VB_GPS_LOCATION: 'VB.GPS_LOCATION',
					VB_SPEED: 'VB.SPEED',
					VB_DRIVER_SEAT_OCCUPIED: 'VB.DRIVER_SEAT_OCCUPIED',
					VB_PASSENGER_SEAT_OCCUPIED: 'VB.PASSENGER_SEAT_OCCUPIED',
					VB_DOOR_OPEN: 'VB.DOOR_OPEN',
					VB_HEADUNIT_NAME: 'VB.HEADUNIT_NAME',
					VB_HEADUNIT_DIMENSIONS: 'VB.HEADUNIT_DIMENSIONS',
					VB_HEADUNIT_RESOLUTION: 'VB.HEADUNIT_RESOLUTION',
					VB_RPM: 'VB.RPM',
					VB_FUEL_LEVEL: 'VB.FUEL_LEVEL',
					VB_TOTAL_MILEAGE: 'VB.TOTAL_MILEAGE',
					VB_COOLANT_TEMPERATURE: 'VB.COOLANT_TEMPERATURE',
					VB_AIR_INTAKE_TEMPERATURE_OR_PRESSURE: 'VB.AIR_INTAKE_TEMPERATURE/VB.AIR_INTAKE_PRESSURE',
					VB_ENGINE_MAL_FUNCTION: 'VB.ENGINE_MAL_FUNCTION',
					VB_CAN_BUS_DATA: 'VB.CAN_BUS_DATA',
					VB_MODEL: 'VB.MODEL'
				},
        EMPTY_IMAGE_ID: 0

    });
});
