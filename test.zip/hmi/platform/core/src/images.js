/**
 *
 */
define('aq/images',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (storage, screen, profile, constants) {
            var self = this;

            this.storage = storage;
            this.screen = screen;
            this.constants = constants;

            var configLoaded = $.getJSON(this.constants.APP_CONFIG_NAME);

            configLoaded
                .done(function(response) {
                    var sharedImages = response && response.images;
                    self.sharedImageIds = self.addImageIdsToLocalStore(sharedImages, "00");
                })
                //TODO: Log error message
                .fail();

            // collection of cached images
            // <appId>: {
            //   hash: <String>
            //   progress: <Deferred>
            // }
            this.apps = {};

            // on initial head unit connection cache aq shared images
            profile.on(profile.events.appModeStateChange, function (response) {
                if (response.data.state === 'start') {
                    this.cacheSharedImages();
                }
            }.bind(this));
        },

        /**
         *  key - value map
         *  key - zipId (assets_zipId)
         *  value - appName assosiated with zipId
         */
        zipIdsMap: {},

        cacheAppImagesByApps: function (apps, index) {
            var app = apps[index],
                self = this;

            if (app) {
                var appName = app.appName.toLowerCase(),
                    path = self.constants.RELATIVE_APP_PATH(appName),
                    configFile = self.constants.APP_CONFIG_NAME;

                $.getJSON(path.concat(configFile))
                    .done(function (cfg) {
                        var appImages = cfg.images || {},
                            appId = cfg.appId;

                        self.cacheAppImages(appImages, appId)
                            .always(self.cacheAppImagesByApps.bind(self, apps, index + 1));

                    })
                    .fail(self.cacheAppImagesByApps.bind(self, apps, index + 1));
            }
        },

        cacheAppImages: function (imageIds, appId) {
            var app = this.apps[appId] || {},
                isImagesChanged = JSON.stringify(imageIds) !== app.hash,
                isImageCacheFailed = app.progress ? app.progress.state() === 'rejected' : false,
                needToCache = isImagesChanged || isImageCacheFailed;

            return needToCache ? this.cacheImages(imageIds, appId) : $.when(app.progress);
        },

        sendImageArchives: function (zipIdsMap) {
            if (!_.isEqual(this.zipIdsMap, zipIdsMap)) {
                this.zipIdsMap = zipIdsMap;
                this.screen.saveZip(zipIdsMap);
            }
        },

        /**
         * @returns {$.Deferred}
         */
        cacheSharedImages: function () {
            return this.screen.cacheImages(this.sharedImageIds, "00");
        },

        /**
         *
         * Cache images by application id
         *
         * @param images {List} Collection of imageIds connected to the full image path
         * @param appId {String}
         * @returns {$.Deferred}
         */
        cacheImages: function (imageIds, appId) {
            this.apps[appId] = {
                hash: JSON.stringify(imageIds),
                progress: this.screen.cacheImages(imageIds)
            };
            return this.apps[appId].progress;
        },

        /**
         * Add image
         * @param images {Object} Collection of imageIds connected to the full image path
         * @param appId {String}
         * @returns {Array} imageIds in the following format: <appID><imgID><imgVer>
         */
        addImageIdsToLocalStore: function (images, appId) {
            var ids = [],
                imgId;

            _.each(images, function (url, id) {
                imgId = parseInt(appId + id, 10);
                this.storage.addLocalImageId(url, imgId);
                ids.push(imgId);
            }, this);

            return ids;
        }
    });

});
