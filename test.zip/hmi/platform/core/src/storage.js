/**
 * @Singleton
 */
define('aq/storage',['aq/api/storage'], function (Storage) {
    'use strict';

    var _storage = {

        image: {
            COUNT: 0
        },
        actions: {}

    };

    return Storage.extend({

        init: function (transport, constants, utils) {
            this.constants = constants;
            this.utils = utils;
            this._super(transport);
        },

        /**
         * Looks for the id for the given value in the images hash map.
         * If no ids found, it will generate a new id and add it
         * to the hash map and return the new id.
         * @param image {Object}
         * @returns {number}
         */
        getImageId: function (image) {

            if(!_.isString(image.data) || _.isEmpty(image.data)) {
                return this.constants.EMPTY_IMAGE_ID;
            }

            var imgUrl = this.utils.toJSON({data: image.data}, undefined, 0),
                imgData = this.utils.toJSON(image, undefined, 0);

            return _storage.image[imgUrl] || _storage.image[imgData] || this.addValue(imgData, 'image');
        },

        addLocalImageId: function (url, id) {
            return _storage.image[this.utils.toJSON({data: url}, undefined, 0)] = id;
        },

        /**
         * Retrieves the value based on the given id and type
         * @param id
         * @param type
         * @returns {string|undefined}
         */
        getValue: function (id, type) {
            var storage = _.invert(_storage[type] || {});
            return storage[id];
        },

        /**
         * Adds a new entry to the hash map and returns the newly generated id.
         * @param value {json}
         * @param type {string}
         * @returns {number} id
         */
        addValue: function (value, type) {
            return _storage[type][value] || this._addValue(value, type);
        },

        _addValue: function (value, type) {
            _storage[type][value] = ++_storage[type].COUNT;
            return _storage[type].COUNT;
        },

        /**
         *
         * @param id {number}
         * @param type {string}
         * @returns {boolean}
         */
        removeValue: function (id, type) {
            if (type !== 'COUNT') {
                for (var key in _storage[type]) {
                    if (_storage[type][key] === id) {
                        delete _storage[type][key];
                        return true;
                    }
                }
            }
            return false;
        },

        /**
         * Save action and value for on-screen soft button
         * @param keyId {number}
         * @param action {string}
         * @param value {string}
         */
        addAction: function (keyId, action, value) {
            _storage.actions[keyId] = {
                action: action,
                value: value
            };
        },

        /**
         * Get action and value by id for pressed on-screen soft button
         * @param keyId {number}
         * @returns {object}
         */
        getAction: function (keyId) {
            return _.extend({}, _storage.actions[keyId]);
        },

        clearActions: function () {
            delete _storage.actions;
            _storage.actions = {};
        }


    });
});