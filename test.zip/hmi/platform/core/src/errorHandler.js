define('aq/errorHandler',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    
    var eventMap = {};

    return EventEmitter.extend({
        init: function (dependencies) {
            this.Popup = dependencies.popup;
            this.Profile = dependencies.profile;
            this.homeApp = dependencies.homeApp;
            this.translation = dependencies.translation;
            
            // Loop through all dependencies and create a map of object -> eventName
            _.each(dependencies, function (anObject, objectName) {
                if (anObject.events) {
                    _.each(anObject.events, function (internalEvtName, externalEvtName) {
                        // build a name of possible eventHandler
                        var handlerName = "_" + externalEvtName + "EventHandler";
                        if (!eventMap[objectName]) {
                            eventMap[objectName] = {};
                        }
                        eventMap[objectName][externalEvtName] = {
                            internalEvtName: internalEvtName,
                            handler: handlerName,
                            self: anObject
                        };
                    });
                }
            });
            
            // FIXME: Once moved to some config, replace "AQ"
            this.translation.initLocale("aq");
            
            this.handle();
        },

        /**
         * Attach event listeners to all possible events defined in each component passed in dependencies
         * 
         * @public
         * @return void
         */
        handle: function () {
            _.each(eventMap, function (objectEvents) {                
                _.each(objectEvents, function (evtConfig) {
                    if (_.isFunction(this[evtConfig.handler])) {
                        this.listenTo(evtConfig.self, evtConfig.internalEvtName, this[evtConfig.handler]);
                    }
                }, this);
            }, this);
        },

        /**
         * Choreo Event Hadler
         * 
         * @param data {Object}
         * @private
         * 
         * @return void
         */
        _choreoEventHandler: function (data) {
            this._handleError(data && data.code);
        },
        
        /**
         * Shows a popup with text determined from errorCode passed as argument
         * 
         * @param {string|number} errorCode
         * @private
         * 
         * @return void
         */
        _handleError: function (errorCode) {
            var title = $.t(['error', errorCode, 'title'].join('.'), {defaultValue: ''});
            var text = $.t(['error', errorCode, 'text'].join('.'), {
                defaultValue: $.t('error.generic.text')
            });
            
            this.showPopup({title: title, text: text}, 35000);
        },

        /**
         * Shows a popup with passed text.
         * 
         * Popup will close after `delay` time (seconds) if passed.
         * Additionally and `action` could be passed - what should happen after popup is closed,
         * by default user will be redirected back to the main Home page with available application list.
         * 
         * @param text {String}
         * @param delay {Number}. Optional. Delay in seconds after which an `action` will be triggered.
         * @param action {String} Optional. Defines which action should be done after popup is closed.
         * 
         * @public
         * 
         * @return {Popup}
         */
        showPopup: function (texts, delay, action) {
            var popup = new this.Popup();

            action = action || this.homeApp.renderHomeScreen.bind(this.homeApp, null);

            popup.render({
                title: texts.title,
                text: texts.text,
                buttons: [popup.buttons.exit]
            });

            this.listenToOnce(popup.display, popup.events.close, action);

            if (delay) {
                _.delay(action, delay);
            }

            return popup;
        }
    });
});
