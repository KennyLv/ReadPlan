define('aq/api/choreo',['jquery', 'shared/thor_interface/choreo', 'aq/mixins/events'], function ($, Choreo, Events) {
    'use strict';

    /**
     * @class
     */
    return Choreo.extend({
        /** @lends Choreo */

        /**
         * Property required for compatibility with shared modules
         * @type {string}
         */
        baseUrl: '',

        /**
         * @constructs Choreo
         * @param {Transport} transport
         * @param {Profile} profile
         * @param {Object} options
         *
         */
        init: function (transport, profile, options) {
            options = options || {};

            this.contentType = options || "application/json";

            this._transport = transport;
            this._profile = profile;
        },


        /**
         *
         * @param params {Object}
         * @returns {$.Deferred}
         */
        sendRequest: function (params) {
            params = params || {};

            params.method = params.method || "GET";
            params.path =  "choreo";

            return this.getParams()
                .then(function (choreoParams) {

                    params.url = choreoParams.url+ '/' + params.url;
                    params.headers = $.extend({}, choreoParams.headers, params.headers);

                    return this._transport.sendRequest(params);
                }.bind(this));
        },


        /**
         * Get image from Choreo proxy
         *
         * @name Choreo#getExternalImageByUrl
         * @function
         *
         * @param {String} url
         * @param {Boolean} [encode]
         *
         * @returns {jQuery.Deferred}
         */
        getExternalImageByUrl: function (url, encode) {
            return this.getExternalImagesByUrl([url], encode)
                .then(function (urls) {
                    return urls[0];
                });
        },

        /**
         * Get array of images from Choreo proxy
         *
         * @name Choreo#getExternalImagesByUrl
         * @function
         *
         * @param {Array} urls
         * @param {Boolean} [encode]
         *
         * @returns {jQuery.Deferred}
         */
        getExternalImagesByUrl: function (urls, encode) {
            var _this = this,
                proxiedLinks = [];
            encode = !!encode;

            return this.getParams()
                .then(function (params) {
                    $.each(urls, function (index, url) {
                        if (!url) {
                            proxiedLinks.push('');
                        } else {
                            proxiedLinks.push(
                                params.url + '/mip_services/core/api/1.0/miscellaneous/image?' +
                                $.param({
                                    to_encode: encode,
                                    auth_token: params.headers['Auth-Token'],
                                    mip_id: params.headers['Mip-Id'],
                                    image_url: url.replace(/ /g, '%20')
                                })
                            );
                        }
                    });

                    //if we need encoded images - then we should fetch all base64 data from Choreo
                    if (encode) {
                        var queue = proxiedLinks.map(function (url, key) {
                            //TODO set small timeout for fast resolve
                            var def = $.Deferred();
                            _this._transport.sendRequest({
                                method: "GET",
                                path: "choreo",
                                url: url
                            })
                                .then(function (data) {
                                    proxiedLinks[key] = data;
                                }, function () {
                                    proxiedLinks[key] = '';
                                })
                                .always(function () {
                                    def.resolve();
                                });

                            return def.promise();
                        });

                        return $.when.apply(null, queue).then(function () {
                            return proxiedLinks;
                        });
                    } else {
                        return proxiedLinks;
                    }
                });
        },

        /**
         * @TODO add some kind of cache
         *
         * Get Choreo request parameters.
         *
         * @name Choreo#getParams
         * @function
         *
         * @returns {jQuery.Deferred}
         */
        getParams: function () {
            var _this = this;
            if (!this._cachedParams) {

                this._cachedParams = this._profile.getClientGateway()
                    .done(function () {
                        setTimeout(function () {
                            _this._cachedParams = null;
                        }, 60000);
                    });
            }
            return _this._cachedParams;
        },

        /**
         * Terminate all current requests for appName if specified or all current commands
         * May be used when application changes route or shutting down
         *
         * @name Choreo#abortApplicationRequests
         * @this Choreo
         * @function
         *
         */
        abortApplicationRequests: function(){
            this._transport.abortRequests();
        }

    }).extend(Events);
});