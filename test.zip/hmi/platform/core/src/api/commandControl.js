define('aq/api/commandControl',['shared/thor_interface/commandControl', 'aq/mixins/events'], function (CommandControl, Events) {
    'use strict';

    return CommandControl.extend({

        init: function (transport, options) {
            options = options || {};

            this.appName = options.appName || this.appName;

            // e.g. application/octet-stream, application/json
            this.contentType = options.contentType || this.contentType;

            // e.g. base64
            this.contentTransferEncoding = options.transferEncoding || this.transferEncoding;

            this._initTransport(transport);
        },

        _initTransport: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this.handleNotification);
        },

        /**
         *
         * @param content {Object}
         * @returns {$.Deferred}
         */
        sendCommand: function (content) {
            var headers = {
                "App-Name": this.appName,
                "Content-Type": this.contentType
            };
            if (this.contentTransferEncoding) {
                headers["Content-Transfer-Encoding"] = this.contentTransferEncoding;
            } else {
                headers["Content-Length"] = encodeURI(JSON.stringify(content)).split(/%..|./).length - 1;
            }

            return this._transport.sendRequest({
                path: "meha",
                method: "POST",
                headers: headers,
                content: content
            });
        },

        handleNotification: function () {
            throw new Error('not implemented');
        },

        abortApplicationRequests: function(){
            throw new Error('not implemented');
        }

    }).extend(Events);
});
