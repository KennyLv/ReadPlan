define('aq/api/logger',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        /**
         * Indicate which env use to logging:
         * webView to send log messages directly to web view
         * otherwise print messages to js console
         */
        env: 'WEB_VIEW',

        /**
         * Possible values: none, high, med, low
         */
        levels: {
            high: ['debug', 'info', 'log', 'warn', 'error'],
            med: ['log', 'warn', 'error'],
            low: ['warn', 'error'],
            none: []
        },

        /**
         * Available log methods
         */
        loggers: ['debug', 'info', 'log', 'warn', 'error'],

        /**
         * @constructor
         * @param transport {Transport}
         * @param level {string} Logger level
         * @param env {string} Which env use to logging
         * @param prefix {string} Prefix
         */
        init: function (transport, level, env, prefix) {

            this._super(transport);
            this._prefix = prefix || '';
            this.setEnvironment(env);
            this.setLevel(level);

            // init loggers
            this.loggers.forEach(function (logLevel) {
                this[logLevel] = function (data) {
                    return this._log(logLevel, data);
                };
            }, this);
        },

        setLevel: function (level) {
            this.level = this.levels[level] ? level : 'low';
        },

        setEnvironment: function (env) {
            this.env = env;
            this.logger = this.env === 'WEB_VIEW' ? this._sendRequest.bind(this) : function (data, level) {
                window.console[level](this._prefix, data);
            };
        },

        _log: function (logger, data) {
            var level = this.levels[this.level],
                isLoggerTypePresent = level && level.indexOf(logger) > -1;
            return level && isLoggerTypePresent ? this.logger(data, logger) : false;
        },

        /**
         * iOS HAP uses JSLog as a tag for js logs
         * android HAP uses JS_LOG as a tag for js logs
         *
         * @param data
         */
        _sendRequest: function (data) {
            var msg = {};
            msg[this._prefix || 'JS_LOG'] = data;
            return this._transport.sendLogRequest(msg);
        }
    });
});