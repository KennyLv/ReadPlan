/**
 * iOS native transport layer
 */
define('aq/api/transport/ios',[],function () {
    'use strict';

    // save the cached iframe el
    var iframe = window.document.createElement('iframe');

    return {

        /**
         * Send messages to native ios layer
         * @param data {json}
         */
        send: function (data) {
            try {
                var frame = iframe.cloneNode();
                frame.setAttribute('src', 'update:' + encodeURIComponent(data));
                window.document.documentElement.appendChild(frame);
                frame.parentNode.removeChild(frame);
                frame = null;
            } catch (e) {
                console.error(e);
            }

        },

        /**
         * Send log to the native env
         * @param msg {*}
         */
        log: function (msg) {
            this.send(JSON.stringify({
                "path": "/hap/api/1.0/log",
                "headers": {"Content-Type": "text/plain"},
                "method": "POST",
                "content": {
                    msg: this.ejectImage($.extend(true, {}, msg)),
                    time: +new Date()
                }
            }));
        },

        ejectImage: function (msg) {
            _.each(msg, function (val, key) {
                if (_.isObject(val)) {
                    this.ejectImage(val);
                } else {
                    if (_.isString(val) && val.length > 10000) msg[key] = 'base64/image';
                }
            }, this);
            return msg;
        }
    };

});