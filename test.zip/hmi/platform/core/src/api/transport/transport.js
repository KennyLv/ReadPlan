/**
 * @Singleton
 *
 * Low level transport responsible for communication between HAP and HMI
 * Entry point for all incoming and outcoming calls
 *
 */
define('aq/api/transport/transport',['shared/thor_interface/transport', 'aq/mixins/events'], function (Trasnport, events) {
    'use strict';

    var instance;

    return Trasnport.extend({

        waitBeforeResolve: 20 * 1000,

        /**
         * @constructor
         */
        init: function (utils, RequestsQueue, platfrom) {

            if (instance) {
                return instance;
            }
            instance = _.extend(this, events);

            this._utils = utils;
            this._platform = platfrom;
            this._requests = new RequestsQueue(this);
            this._timeoutIds = [];

            // entry point for all incoming messages
            window.onNotification = this._onReceiveResponse.bind(this);
            return this;
        },

        /**
         * @param data {Object}
         * @param callback {Function} optional, deprecated
         *
         * @return {$.Deferred}
         */
        sendRequest: function (data, callback) {
            var deferred = this._requests.add(data);
            data.requestNumber = deferred.requestNumber;

            // stringify data, send to native layer
            this._onSendRequest(data);

            // compatibility support
            if (typeof callback === 'function') {
                callback(data.requestNumber);
            }

            // automatically reject by timeout if deferred still in pending state
            var wait = this.waitBeforeResolve;
            this._timeoutIds.push(setTimeout(function () {
                if (deferred.state() === 'pending') {
                    var error = {
                        error: {
                            // Request timed out
                            code: 170000,
                            description: 'Rejected by timeout',
                            timeout: wait,
                            request: data
                        }
                    };
                    this.sendLogRequest({'[Transport][Request][Timeout]': error});
                    deferred.reject(error);
                }
            }.bind(this), wait));

            return deferred
                .always(this.handleNotification.bind(this))
                .promise();
        },

        /**
         * Send log request to native layer
         * @param data {Object}
         */
        sendLogRequest: function (data) {
            this._platform.log(data);
        },

        /**
         *
         * @param content {Object}
         * @param notification {Object} full response from HAP
         */
        handleNotification: function (content, notification) {
            var isThorEvent = /thor\/event$/.test(notification && notification.path),
                isMEHAEvent = /meha\/event$/.test(notification && notification.path),
                needToRespond = isThorEvent || isMEHAEvent,
                responseStatus = {
                    code: 200,
                    status: 'OK'
                };

            try {
                this.trigger('notification', content, notification);
            } catch (e) {
                this.sendLogRequest({
                    ERROR: {
                        msg: e.toString(),
                        stack: e.stack || ''
                    }
                });
                responseStatus = {
                    code: 400,
                    status: 'Bad Request'
                };
            } finally {
                if (needToRespond) {
                    this._platform.send(this._utils.toJSON(_.extend({
                        sequenceNumber: notification.sequenceNumber,
                        headers: {
                            'Content-Length': 0
                        }
                    }, responseStatus)));
                }
            }
        },

        abortRequests: function () {
            this._timeoutIds.forEach(window.clearTimeout);
            this._requests.clear();
        },

        /**
         * Send all messages to the native layer
         * @private
         */
        _onSendRequest: function (data) {
            var headers = data.headers || {"Content-Type": "application/json"};
            var path = '/hap/api/1.0/' + data.path;
            var json = _.extend(data, {
                "path": path,
                "headers": headers
            });
            this._platform.send(this._utils.toJSON(json));
            this.sendLogRequest({'[Transport][onSendRequest]': json});
        },

        /**
         * Receive all messages from the native layer
         *
         * @param response {JSON|Object}
         *
         * {
         *   "sequenceNumber": <Number>,
         *   "requestNumber": <Number>,
         *   "path": <String>,
         *   "headers" : {
         *        "Content-type" : "application/json"
         *   },
         *   "content" : {
         *        "type" : <String>,
         *        "data" : <Object>,
         *        "error" : {
         *            "code" : <Error Code: section 3.4>,
         *            "description" : "<Error Description: section 3.4>"
         *        }
         *   }
         * }
         */
        _onReceiveResponse: function (response) {
            response = _.isString(response) ? this._utils.parseJSON(response) : response;
            this.sendLogRequest({'[Transport][onNotification]': response});

            if (response === null) throw new Error("[Transport][onNotification] Can't parse JSON");

            var content = response.content || {},
                deferred = this._requests.get(response.requestNumber);

            // completely async notification
            if (!deferred) return this.handleNotification(content, response);

            return this._isFail(content)  ? this._onFailure(content, deferred) : this._onSuccess(content, deferred);
        },

        _isFail: function (content) {
            var error = content.error;
            // android HAP always send error code(for success responses also)
            // 150000 is a success response

            var successCode = 150000;
            return error && error.code && error.code !== successCode;
        },

        _onSuccess: function (content, deferred) {
            deferred.resolve(content);
        },

        _onFailure: function (content, deferred) {
            console.error('[Transport][Request][Resolved][Fail]', content.error);
            deferred.reject(content);
        }

    });

});