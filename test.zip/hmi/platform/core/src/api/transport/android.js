/**
 * Android native transport layer
 */
define('aq/api/transport/android',[],function () {
    'use strict';

    return {

        /**
         * Send messages to native android layer
         * @param data {json}
         */
        send: function (data) {
            try {
                window.android.exec(data);
            } catch (e) {
                console.error('[EXEC ERROR]', e);
                console.trace();
            }
        },

        /**
         * Send log to the native env
         * @param msg {*}
         */
        log: function (msg) {
            try {
                msg = JSON.stringify(this.ejectImage($.extend(true, {}, msg)), null, 2);
                window.android.log(msg);
            } catch (e) {
                console.error('[LOG ERROR]', e);
            }

        },

        ejectImage: function (msg) {
            _.each(msg, function (val, key) {
                if (_.isObject(val)) {
                    this.ejectImage(val);
                } else {
                    if (_.isString(val) && val.length > 10000) msg[key] = 'base64/image';
                }
            }, this);
            return msg;
        }
    };
});
