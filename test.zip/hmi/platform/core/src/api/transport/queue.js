/**
 * Collection of stored deferred for each request
 */
define('aq/api/transport/queue',['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        /**
         * @constructor
         */
        init: function () {
            this._queuee = {};
            this._requestNumber = 0;
        },

        /**
         * Create and put into queue deferred object
         * @returns {$.Deferred}
         */
        add: function () {
            var currentRequestNumber = this._requestNumber++;
            var deferred = $.Deferred();

            deferred.requestNumber = currentRequestNumber;
            this._queuee[currentRequestNumber] = deferred;

            return deferred;
        },

        /**
         * Get and remove deferred object from queue
         * @param requestNumber
         * @returns {$.Deferred}
         */
        get: function (requestNumber) {
            var deferred = this._queuee[requestNumber];
            this._remove(requestNumber);
            return deferred;
        },

        /**
         * Cleanup and release memory
         */
        clear: function () {
            $.each(this._queuee, this._remove.bind(this));
            this._queuee = {};
        },

        /**
         * @param requestNumber
         */
        _remove: function (requestNumber) {
            this._queuee[requestNumber] = null;
            delete this._queuee[requestNumber];
        }
    });

});