define('aq/api/hap/fileReporter',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        reports: {},

        init: function (options) {
            this._super(options.initData.transport);
            this.huMetaData = options.initData.huMetaData;
            this.logger = new options.initData.Logger('high', 'WEB_VIEW', 'FILE_REPORTER');
            try {
                this.reports = this._initReports(options.reports, options.initData);
            }
            catch (err) {
                throw new Error(err.stack);
            }

            this.listenTo(
                this.huMetaData,
                this.huMetaData.events.readyToSubmitReport,
                this.submitReportFiles,
                this);
        },

        _initReports: function(reports, initData) {
            for(var report in reports) {
                if(reports.hasOwnProperty(report)) {
                    reports[report] = new reports[report](initData);
                }
            }

            return reports;
        },

        /**
         *write and submit data to the service on disconnection
         */
        submitReportFiles: function (reportId) {
            if (this.reports.hasOwnProperty(reportId)) {
                this.reports[reportId].submitReportFile();
            }
        }
    });
});