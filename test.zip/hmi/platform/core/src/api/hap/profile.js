define('aq/api/hap/profile',['shared/thor_interface/profile', 'aq/api/base'], function (Profile, Base) {
    'use strict';

    return Profile.extend(Base.extend({

        events: {
            appModeStateChange: 'appModeState:change',
            profileStateChange: 'profileState:change',
            choreoError: 'choreo:error',
            applicationListResponse: 'applicationList:response',
            clientGatewayInfoResponse: 'clientGatewayInfo:response',
            headUnitLanguage: 'language:change',
            choreo: 'choreo:notification'
        },

        init: function (transport) {
            this._super(transport);
        },

        getHupInfo: function () {
            return $.when(
                this.getClientGateway(),
                this.getApplicationList(),
                this.getLanguage()
            );
        },

        /**
         * Get available application list
         * [
         *  "appName": <appName>,
         *  "appDisplayName": <appDisplayName>,
         *  "appCategory": <appCategory>,
         *  "appPath": <appPath>
         * ]
         *
         * @returns {$.Deferred}
         */
        getApplicationList: function () {
            return this._transport.sendRequest({
                "path" : "profile",
                "method" : "GET"
            }).then(function (response) {
                return response.data;
            }, function (response) {
                return response && response.error;
            });
        },

        /**
         * data: {
         *   url: <Client Gateway URL>,
         *   headers: {
         *     "Access-Key-Id": <Access-Key-Id>,
         *     "App-Token": <App-Token>,
         *     "Auth-Token": <Auth-Token>,
         *     "Hu-Id": <Head Unit ID>,
         *     "Mip-Id": <MIP ID>
         *   }
         * }
         *
         * @returns {$.Deferred}
         */
        getClientGateway: function () {
            return this._transport.sendRequest({
                "path" : "clientGatewayInfo",
                "method" : "GET"
            });
        },

        /**
         *
         * TODO this is head unit call
         *
         * @returns {$.Deferred}
         */
        getLanguage: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "getLanguage"
                }
            });
        },

        /**
         * Notify that js is ready to processing messages
         */
        ready: function () {
            return this._transport.sendRequest({
                "path": "thorState",
                "method": "POST",
                "content": {
                    "state": "ready"
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content.type;
            
            if (!!notificationName && Object.keys(this.events).indexOf(notificationName) !== -1) {
                this.trigger(this.events[notificationName], content);
            } else if(content.name && content.data && content.data.type &&
                    content.name === "ERROR" && content.data.type === "choreo"){
                this.trigger(this.events.choreoError, content);
            }
        }
    }).prototype);
});
