define('aq/api/hap/baseReport',['aq/api/base'], function (Base) {
    'use strict';
    // require uuid module
    var uuid = require('uuid');

    return Base.extend({
        /**
         * name of the report file
         */
        _fileName: null,

        /**
         * report file name prefix
         */
        _reportName: 'baseReport_',

        /**
         * url to submit file to
         */
        _pathToSubmit: null,

        /**
         * data to report
         */
        _reportData: [],

        /**
        * corresponding to current report metaReporter's name
        */
        _metaReporterName: null,

        /**
        * corresponding to current report metaReporter
        */
        _metaReporter: null,

        init: function (options) {
            this.uuid = uuid;
            this._super(options.transport);
            this.huMetaData = options.huMetaData;
            this.fileManager = options.fileManager;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'REPORT', this._reportName);

            this._setMetaReporter();
        },


        /**
         * check if data is redy to be submitted (data is empty while running emulator and pressing F5,
         * bluetooth reconnection needed to trigger headUnitConnectionState event )
         * @returns {boolean}
         */
        reportIsReady: function () {
            throw new Error('[BaseReport] ready check is not implemented');
        },

        /**
         * storing data to the usageReport object
         * @param appName
         */
        writeReport: function () {
            throw new Error('[BaseReport] writing is not implemented');
        },

        submitReportFile:function () {
            if (this.reportIsReady()) {
                var defferedSubmit = this.fileManager.submitReportFile(this._getSubmissionReportData());
                if (defferedSubmit) {
                    defferedSubmit.always(this._clearReportData.bind(this));
                }
            }
        },

        _setMetaReporter: function() {
            if (this.huMetaData.metaReporters.hasOwnProperty(this._metaReporterName)) {
                this._metaReporter = this.huMetaData.metaReporters[this._metaReporterName];
            }
            else {
                throw new ReferenceError(
                    "[BaseReport] check MetaReportes names - there's no such MetaReporter: " +
                    this._metaReporterName
                    );
            }
        },

        _getSubmissionReportData: function() {
            this._fileName = 'report_' + this._reportName + new Date().getTime().toString();

            return {
                reportData:     this.getReportData(),
                reportName:     this._reportName,
                fileName:       this._fileName,
                pathToSubmit:   this._pathToSubmit,
                uuid:           this.uuid,
                handsetProfile: this._metaReporter.getHandsetProfile()
            };
        },

        getReportData: function() {
            throw new Error('[BaseReport] get_report_data is not implemented');
        },

        _clearReportData: function() {
            throw new Error('[BaseReport] clearing_data is not implemented');
        }
    });
});