define('aq/api/hap/fileManager',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (options) {
            this._super(options.transport);
            this.huMetaData = options.huMetaData;
            this._utils = options.transport._utils;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'FILE_MANAGER');
        },

        /**
         *write and submit data to the service on disconnection
         */
        submitReportFile: function (options) {
            var reportData = options.reportData,
                reportName = options.reportName,
                fileName = options.fileName,
                pathToSubmit = options.pathToSubmit,
                uuid = options.uuid,
                handsetProfile = options.handsetProfile;

            if (this._utils.isReportDataEmpty(reportData)) {
                return;
            }

            // 1. creates a file
            // 2. writes data to it
            // 3. submits it to pathToSubmit
            return this.createFile({
                    fileName:   fileName,
                    reportName: reportName
                }).done(
                    function () {
                        this.writeToFile({
                            fileName: fileName,
                            data:     reportData
                        }).done(
                            function() {
                                this.submitFile({
                                    fileName:       fileName,
                                    handsetProfile: handsetProfile,
                                    pathToSubmit:   pathToSubmit,
                                    uuid: uuid
                                });
                            }.bind(this));
                    }.bind(this));
        },

        /**
         * not used
         * checking if file is empty
         * @returns jQuery.Deferred
         */
        isFileEmpty: function (options) {
            var fileName = options.fileName;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "isEmpty"
                }
            }).done(function (data) {
                    var isEmpty = data.data && data.data.isEmpty;
                    this.logger.log({'File is empty: ': fileName});
                    this.logger.log({'File is empty: ' : isEmpty});
                }.bind(this))
                .fail(function () {
                    this.logger.log({'File is not empty: ': fileName});
                }.bind(this));
        },

        /**
         * creating file to write into
         * @returns jQuery.Deferred
         */
        createFile: function (options) {
            var fileName = options.fileName;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "create"
                }
            }).done(function () {
                this.logger.log({'File created: ': fileName});
            }.bind(this))
            .fail(function () {
                this.logger.log({'File not created: ': fileName});
            }.bind(this));
        },

        /**
         * writes data to file
         * @returns {jqXHR|jQuery.Deferred|}
         */
        writeToFile: function (options) {
            var fileName = options.fileName,
                data = options.data;
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "write",
                    "data": data
                }
            }).done(function () {
                this.logger.log({'Report Data written: ': data});
            }.bind(this)).fail(function () {
                this.logger.log({'Report Data not written: ': data});
            }.bind(this));
        },

        /**
         * removing report file
         * @returns jQuery.Deferred
         */
        deleteFile: function (fileName) {
            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "delete"
                }
            }).done(function () {
                this.logger.log({'Report file removed: ': fileName});
            }.bind(this));
        },

        /**
         * submit data usage report to service and remove report file in both success and fail cases
         * url - string (url link for report submission)
         * @returns jQuery.Deferred
         */
        submitFile: function (options) {
            var fileName = options.fileName,
                pathToSubmit = options.pathToSubmit,
                uuid = options.uuid,
                handsetProfile = options.handsetProfile,
                hostToSubmit = handsetProfile.backendInfo && handsetProfile.backendInfo.clientGatewayUrl,
                hostLength;

            //TODO: fix url on IOS HAP
            if (hostToSubmit) {
                hostLength = hostToSubmit.length;
                if (hostToSubmit[hostLength - 1] !=='/') {
                    hostToSubmit +='/';
                }
                hostToSubmit = hostToSubmit + pathToSubmit + uuid.v1() + "?client-type=phone";
            } else {
                this.logger.log({'URL FOR REPORT SUBMISION NOT VALID':''});
                this.logger.log({'Report data not submitted, because URL is not valid ': hostToSubmit});
                return;
            }

            return this._transport.sendRequest({
                "path": "fileIo",
                "method": "POST",
                "content": {
                    "name" : fileName,
                    "action": "put",
                    "data" : hostToSubmit
                }
            }).done(function () {
                this.logger.log({'Report data submitted: ': hostToSubmit});
            }.bind(this)).fail(function () {
                this.logger.log({'Report data not submitted': hostToSubmit});
            }.bind(this)).always(function () {
                //todo uncoment file deletion (tmp for debugging purposes)
                //this.deleteFile(fileName);
            }.bind(this));
        }

    });
});
