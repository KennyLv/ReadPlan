/**
 * iOS only application container module
 */

define('aq/api/hap/appContainer',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (transport) {
            this._super(transport);
        },

        /**
         *
         * @returns {$.Deferred}
         */
        getApplicationContainerName: function () {
            return this._transport.sendRequest({
                "path": "appName",
                "method": "GET"
            }).then(function (content) {
                return content.data.appName;
            });
        },

        /**
         * send notification to HU to show loading screen while bluetooth is off
         * @returns {$.Deferred}
         */
        sendAppSwitchEvent: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "appSwitch"
                }
            });
        },


        /**
         *
         * @param appContainerName {String}
         * @returns {$.Deferred}
         */
        switchApplicationContainerTo: function (appContainerName) {
            return this._transport.sendRequest({
                "path" : "appSwitch",
                "method" : "POST",
                "content": {
                    "appName" : appContainerName
                }
            });
        }
    });
});