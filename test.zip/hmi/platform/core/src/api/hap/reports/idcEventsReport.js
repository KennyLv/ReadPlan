define('aq/api/hap/reports/idcEventsReport', ['aq/api/hap/baseReport'], function (BaseReport) {
    'use strict';

    return BaseReport.extend({
        /**
         * name of the report file
         */
        _fileName:         null,

        /**
         * report file name prefix
         */
        _reportName:       'idcEvents_',

        /**
         * url to submit file to
         */
        _pathToSubmit:     'mip_services/core/api/1.0/miscellaneous/file/',

        /**
         * data to report
         */
        _reportData: {
            events: []
        },

        /**
        * corresponding to current report metaReporter's name
        */
        _metaReporterName: 'idcEventsMetaReporter',
        
        /**
        * corresponding to current report metaReporter
        */
        _metaReporter: null,

        init: function(options) {
            this._super(options);

            this.listenTo(
                this._metaReporter,
                this._metaReporter.events.idcEventsDataUpdated,
                this.writeReport,
                this);
        },
        /**
         * check if data is ready to be submitted (data is empty while running emulator and pressing F5,
         * bluetooth reconnection needed to trigger headUnitConnectionState event )
         * @returns {boolean}
         */
        reportIsReady: function () {
            return !_.isNull(this._metaReporter.getHuInfo()) && !_.isNull(this._metaReporter.getHandsetProfile());
        },

        /**
         * storing data to the usageReport object
         *
         */
        writeReport: function () {
            this._reportData = this._metaReporter.generateReportData();
        },

        getReportData: function() {
            return this._reportData;
        },

        _clearReportData: function() {
            this._reportData.events = [];
            this._metaReporter._resetMetaData();
        }
    });
});