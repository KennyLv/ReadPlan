/*
*   Track Progress Counter
*
*   This module's creation is related to CV-2314
*   please view the ticket for more details
*
*/

define('aq/api/progressCounter',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        // better not change this
        // we should constraint
        // to 3rd partys tick length
        // which is equal to webkit's
        TICK_LENGTH: 1000,

        _active: false,

        _elapsedTime: 0,

        _totalTime: 0,

        _timer: null,

        init: function () {
        },

        /*
        * Starts the timer
        * @param {
        *           elapsedTime: number,
        *           totalTime: number
        *       }
        */
        start: function(data) {
            this.update(data);
            this.on();
        },

        /*
        * Rest timer to initial values
        * can be used on closing current app
        */
        reset: function() {
            this.off();
            this.setElapsedTime(0);
            this.setTotalTime(0);
        },

        /*
        * Switch timer on
        */
        on: function() {
            this._active = true;
            this.tick();
        },

        /*
        * Switch timer off
        */
        off: function() {
            this._active = false;
            this._killTimer();
        },

        /*
        * Timer handler
        */
        tick: function(){
            if(this._active) {
                if (this._elapsedTime <= this._totalTime) {
                    this._timer = setTimeout(this._onTick.bind(this), this.TICK_LENGTH);
                }
                else {
                    this.off();
                }
            }
        },

        /*
        * Timer tick handler
        */
        _onTick: function() {
            this._elapsedTime++;
            this._killTimer();
            this.tick();
        },

        /*
        * Timer killer
        * prevents several timer to tick
        * at the same time
        */
        _killTimer: function () {
            if (this._timer) {
                clearTimeout(this._timer);
                this._timer = null;
            }
        },

        /*
        * Update the timer
        * @param {
        *           elapsedTime: number,
        *           totalTime: number
        *       }
        */
        update: function(data) {
            this.setElapsedTime(data.elapsedTime);
            this.setTotalTime(data.totalTime);
        },

        /*
        * Elapsed time setter
        */
        setElapsedTime: function(elapsedTime) {
            this._elapsedTime = +elapsedTime || 0;
        },

        /*
        * Total time setter
        */
        setTotalTime: function(totalTime) {
            this._totalTime = +totalTime || 0;
        },

        /*
        * Elapsed time getter
        */
        getElapsedTime: function() {
            return this._elapsedTime <= this._totalTime ?
                this._elapsedTime : this._elapsedTime = this._totalTime;
        },

        /*
        * Total time getter
        */
        getTotalTime: function() {
            return this._totalTime;
        },

        /*
        * Is timer active
        */
        isActive: function() {
            return this._active;
        }
    });
});