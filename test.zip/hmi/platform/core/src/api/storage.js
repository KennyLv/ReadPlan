define('aq/api/storage',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        init: function (transport) {
            this._super(transport);
        },

        /**
         * Permanently saves a JSON value. (The value will persist until the app is uninstalled)
         * @param key
         * @param json
         * @returns {jqXHR|jQuery.Deferred|*|$.Deferred}
         */
        saveJSON: function (key, json) {
            var data = {};
            data[key] = json;
            return this._transport.sendRequest({
                "path": "storage",
                "method": "POST",
                "content": data
            });
        },

        /**
         * Retrieve a previously saved JSON value by key
         * @param key {string} Key for the value to be retrieved.
         * @param defaultValue {object|string} value used for the key, if it has not been set yet
         * @returns {jqXHR|jQuery.Deferred|*|$.Deferred}
         */
        getJSON: function (key, defaultValue) {
            return this._transport.sendRequest({
                "path" : "storage",
                "method" : "GET",
                "content": {
                    "key" : key,
                    "defaultValue": defaultValue
                }
            });
        }
    });
});