/**
 * Indicate hard or soft key clicks
 * Used internally in view(display)
 */
define('aq/api/hu/controls',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            buttonEvent: 'onButtonPress',
            soft: 'onSoftButtonPress',
            hard: 'onHardButtonPress',
            keyboard: 'keyboard',
            volumeUpdate: 'onVolumeUpdate'
        },

        init: function (storage, constants, transport) {
            this.constants = constants;
            this.storage = storage;
            this._super(transport);
        },

        onButtonPress: function (content) {
            this.trigger(this.events.buttonEvent, content);
            this[this.events[content.data.buttonType]](content);
        },

        onSoftButtonPress: function (content) {
            var softKey = this.storage.getAction(content.data.buttonId);

            this.trigger(this.events.soft, {
                content: content,
                action: softKey.action,
                value: softKey.value
            });
        },

        onHardButtonPress: function (content) {
            var keyId = content.data.buttonId,
                name = this.constants.HARD_KEYS[keyId];

            this.trigger(this.events.hard, {
                content: content,
                button: name
            });
        },
        
        onVolumeUpdate: function (content) {
            var toMute = content.data && content.data.isMute;
            
            _.throttle(this.trigger.bind(this, this.events.hard, {
                content: content,
                /**
                 * FIXME: Obviously, we should just trigger "unmute" event, because it is an expected behavior for user
                 */
                button: toMute ? this.constants.HARD_KEY_NAMES.mute : this.constants.HARD_KEY_NAMES.unmute
            }), 2000);
        },

        startListenTo: function (to) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'startListen',
                    to: to
                }
            });
        },

        stopListenTo: function (to) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'stopListen',
                    to: to
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content.type;

            switch(notificationName) {
                case this.events.keyboard:
                    this.trigger(this.events.keyboard, content.data);
                    break;
                case 'buttonEvent':
                    this.onButtonPress(content);
                    break;
                default:
                    if (_.isFunction(this[this.events[notificationName]])) {
                        this[this.events[notificationName]](content);
                    }
            }
        }

    });
});
