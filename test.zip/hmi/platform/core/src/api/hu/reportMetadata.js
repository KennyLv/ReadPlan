define('aq/api/hu/reportMetadata',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            'readyToSubmitReport' : 'readyToSubmitReport'
        },

        metaReporters: null,

        init: function (options) {
            this._super(options.initData.transport);
            this.metaReporters = options.metaReporters;
            this.logger = new options.initData.Logger('high', 'WEB_VIEW', 'METAREPORT MANAGER');
            this.listenTo(this, this.events.headUnitConnectionState, this.onConnectionStateChange);
            try {
                this.metaReporters = this._initMetaReporters(this.metaReporters, options.initData);
            }
            catch (err) {
                throw new Error(err.stack);
            }
        },

        _initMetaReporters: function(metaReports, initData) {
            for(var metaReport in metaReports) {
                if(metaReports.hasOwnProperty(metaReport)) {
                    metaReports[metaReport] = new metaReports[metaReport](
                        initData.transport,
                        initData.controls,
                        initData.appManager
                    );
                    this.listenTo(metaReports[metaReport], this.events.readyToSubmitReport, this.readyToSubmitReport);
                }
            }

            return metaReports;
        },

        readyToSubmitReport: function(reportData) {
            this.trigger(this.events.readyToSubmitReport, reportData);
        }
    });
});