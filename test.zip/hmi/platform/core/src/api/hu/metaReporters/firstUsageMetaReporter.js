define('aq/api/hu/metaReporters/firstUsageMetaReporter',['aq/api/hu/baseMetaReporter'], function (BaseMetaReporter) {
    'use strict';

    return BaseMetaReporter.extend({

        /**
         * HAP api_path to get _metaData
         */
        _apiPath:   'handsetProfile',

        /**
         * id of corresponding report module
         */
        _reportId:  'firstUsageReport',

        /**
         * handsetProfile
         */
        _handsetProfile: null,

        init: function (transport) {
            this._super(transport);
        },

        /**
         * report data to submit,
         *data {
         *  vin: "vin",
         *  countryCode: "countryCode",
         *  huType: "huType",
         *  huId: "huId",
         *  mipId: "mipId",
         *  appName: "appName",
         *  launchTime: "Date ISO standart"
         * }
         */
        generateReportData: function (appName) {
            var userInfo = this._handsetProfile && this._handsetProfile.userInfo,
                handsetInfo = this._handsetProfile && this._handsetProfile.handsetInfo,
                mipId = userInfo && userInfo.mipId,
                country = handsetInfo && handsetInfo.oemAppCountry,
                huType = this._huInfo && this._huInfo.headUnitType,
                huId = this._huInfo && this._huInfo.headUnitSerialNumber,
                vin = this._huInfo && this._huInfo.vin;

            return {
                countryCode: country,
                appName: appName,
                huType: huType,
                huId: huId,
                launchTime: new Date().toISOString(),
                mipId: mipId,
                vin: vin
            };
        },

        _getMetaData: function () {
            return this._transport.sendRequest({
                "path": this._apiPath,
                "method": "GET"
            }).done(function (responseData) {
                //TODO: fix ios handsetProfile on IOS HAP
                if (responseData.data) {
                    this._handsetProfile = responseData.data;
                } else {
                    this._handsetProfile = responseData;
                }

                //submit report on disconnected state
                if (this._connectionsState && this._connectionsState === this._huState.disconnected) {
                    this.trigger(this.events.readyToSubmitReport, this._reportId);
                }
            }.bind(this));
        },

        /**
         *
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * }
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            //submit report on disconnected state
            if (this._connectionsState === this._huState.disconnected) {
                this.trigger(this.events.readyToSubmitReport, this._reportId);
            }
        }
    });
});