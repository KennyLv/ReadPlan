define('aq/api/hu/metaReporters/idcEventsMetaReporter',['aq/api/hu/baseMetaReporter'], function (BaseMetaReporter) {
    'use strict';

    return BaseMetaReporter.extend({

        /**
         * data to report
         */
        _metaData: {
            events: []
        },

        _connectionEventType: {
            connected: 'headUnitConnect',
            disconnected: 'headUnitDisconnect'
        },

        /**
         * HAP api_path to get _metaData
         */
        _apiPath: "idcEvents",

        /**
         * id of corresponding report module
         */
        _reportId: "idcEventsReport",

        /**
         * handsetProfile
         */
        _handsetProfile: null,

        init: function (transport, controls, appManager) {
            this._super(transport);
            this.controls = controls;
            this.appManager = appManager;
            this.listenTo(this.controls, this.controls.events.soft, this.processSoftButtonEvent);
        },

        processSoftButtonEvent: function (data) {
            if (data.content) {
                var buttonName = data.button || data.action;
                var eventObject = {
                    time: new Date().toISOString(),
                    type: 'appEvent',
                    data: {
                        appName: this.appManager.getCurrentApplicationName(),
                        appVersion: 'version',
                        appEventType: 'softButtonPressed',
                        appEventDetails: buttonName
                    }
                };
                this._metaData.events.push(eventObject);
            }
        },

        processConnectionStateEvent: function () {
            //todo vehicleInfo, profileInfo
            this._metaData.events.push({
                time:        new Date().toISOString(),
                type:        this._connectionEventType[this._connectionsState],
                location:    this.getLocation(),
                handsetInfo: this.getHandsetProfile(),
                huInfo:      this.getHuInfo(),
                //TODO: vehicleInfo: this.getVehicleInfo(), - there's no info in onConnectionsStateChange data
                //TODO: profileInfo: this.getProfileInfo(), - TBD
            });
        },

        /**
         * generate idcEvents report
         * @return events 
         * [
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    },
         *
         *    ...
         *
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    }
         * ]
         */
        generateReportData: function () {
            return this._metaData;
        },

        resetMetaData: function() {
            this._metaData.events = [];
        },

        _getMetaData: function () {
            var bufferedIdcEventsLength = this._metaData.events.length;
            
            this._isReceivingIdcEvents = true;
            return this._transport.sendRequest({
                "path": this._apiPath,
                "method": "GET"
            }).done(function (responseData) {
                this._setIdcEvents(responseData.data.events);
                this._isReceivingIdcEvents = false;

                if(bufferedIdcEventsLength !== this._metaData.events.length) {
                    this.trigger(this.events.idcEventsDataUpdated);
                }

                //submit report on disconnected state
                if (this._connectionsState && this._connectionsState === this._huState.disconnected) {
                    this.trigger(this.events.readyToSubmitReport, this._reportId);
                }
            }.bind(this));
        },

        /**
         * set idcEvents info on every notification and uniqueness check
         * @param events 
         * [
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    },
         *
         *    ...
         *
         *    {
         *         "time": <Device system time in UTC>
         *         "type": <Event Type>
         *         "data": <Event Data>
         *    }
         * ]
         * @private
         */
        _setIdcEvents: function(events) {
            return this._metaData.events = _.uniq(
                    this._metaData.events.concat(events),
                    function(item) {
                        return JSON.stringify(item);
                    }
                );
        },

        _resetMetaData:function() {
            this._metaData.events = [];
        },

        /**
         *
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * }
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            this.processConnectionStateEvent();
            //submit report on disconnected state if it is not empty
            if (!this._utils.isReportDataEmpty(this._metaData) &&
                this._connectionsState === this._huState.disconnected) {
                this.trigger(this.events.idcEventsDataUpdated);
                this.trigger(this.events.readyToSubmitReport, this._reportId);
            }
        }
    });
});