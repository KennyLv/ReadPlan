define('aq/api/hu/navigation',['shared/thor_interface/navigation', 'aq/mixins/events'], function (Navigation, events) {
    'use strict';

    return Navigation.extend({

        LOCATION_TYPE: {
            'CURRENT': 'current',
            'DESTINATION': 'destination'
        },

        events: {
            vehicleState: 'vehicleState:changed'
        },

        vehicleStates: {
            moving: 'moving',
            stopped: 'stopped'
        },

        init: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this._onNotification);
        },


        getLocation: function (locationType) {
            //TODO check, is Alpine HU support this feature
            if (locationType === this.LOCATION_TYPE.DESTINATION) {
                return this.getDestinationLocation();
            } else {
                return this.getCurrentLocation();
            }
        },

        getDestinationLocation: function () {
            console.error('Not implemented yet');
            return false;
        },

        /**
         * response:
         *
         * {
         *   content: {
         *     data: { latitude : <Latitude>, longitude: <Longitude> },
         *     error: {}
         *   }
         * }
         *
         * @returns {$.Deferred}
         */
        getCurrentLocation: function () {
            return this._transport.sendRequest({
                "path" : "location",
                "method" : "GET"
            });
        },

        /**
         * Return vehicle state:
         *  - moving
         *  - stopped
         *
         * @returns {$.Deferred}
         */
        getVehicleState: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method" : "POST",
                "content": {
                    "type": "getVehicleState"
                }
            });
        },

        _onNotification: function (content) {
            var notificationName = content && content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }

    }).extend(events);

});