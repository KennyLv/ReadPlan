/**
 * Audio focus
 */

define('aq/api/hu/audio',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            audioFocus: 'audioFocus'
        },

        init: function (transport) {
            this._super(transport);
        },

        /**
         *
         * @returns {$.Deferred}
         */
        focus: function () {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'audioFocus',
                    state: 'acquire'
                }
            });
        },

        /**
         *
         * @returns {$.Deferred}
         */
        releaseFocus: function () {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'audioFocus',
                    state: 'release'
                }
            });
        },

        /**
         *
         * @param content {Object}
         * {
         *    "type": "audioFocus",
         *    "data": {
         *        "state" : "<Audio Focus State>"
         *        "status" : "<Status of the request>"
         *    }
         * }
         *
         * <Audio Focus State>: release || acquire
         *
         * @private
         */
        _onNotification: function (content) {
            var notificationName = content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }
    });
});