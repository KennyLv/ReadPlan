/**
 * Transport for screen updates api
 * Used internally
 */
define('aq/api/hu/screen',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        /**
         *  key - value map
         *  key - zipId (assets_zipId)
         *  value - appName
         */
        zipMap:  {},

        events: {
            screenUpdateComplete: 'updateScreen:complete',
            image: 'image:request',
            imageRequest: 'image:request',
            file: 'file:request',
            archiveRequest: 'file:request',
            imageResponse: 'image:response',
            saveImageComplete: 'saveImageComplete',
            saveFileComplete: 'saveFileComplete',
            deleteImageComplete: 'deleteImageComplete',
            headUnitConnectionState: 'headUnitConnectionState'
        },

        init: function (options) {
            this.storage = options.storage;
            this._super(options.transport);
            this.utils = options.utils;
            this.constants = options.constants;
            this.appManager = options.appManager;

            this.listenTo(this, this.events.imageRequest, this.onImageRequest);
            this.listenTo(this, this.events.archiveRequest, this.onArchiveRequest);
            this.listenTo(this, this.events.saveFileComplete, this.onSaveFileComplete);
        },

        /**
         * Send template to the head unit.
         * Head unit should send as a response the screenUpdateComplete event
         * when template processing will be completed.
         *
         * @param data {Object} template
         * @returns {$.Deferred}
         */
        updateScreen: function (data) {
            var content = {
                "type": "screenUpdate",
                "data": data
            };

            return this._transport.sendRequest({
                "path": "headunit/event",
                "headers": {
                    "Content-Type": "application/json",
                    "Content-Length": encodeURI(JSON.stringify(content)).split(/%..|./).length - 1
                },
                "method": "POST",
                "content": content
            });
        },

        displayMediaSourceScreen: function () {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "goToMediaSourcePage"
                }
            });
        },

        displayKeyboardScreen: function (keyboardBgImg1, keyboardBgImg2) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "goToKeyboard",
                    "imageId1": this.storage.getImageId({data: keyboardBgImg1}) || 101004,
                    "imageId2": this.storage.getImageId({data: keyboardBgImg2}) || 102000
                }
            });
        },

        /**
         *
         * Show or hide the system loading screen
         *
         * @param state {Number}
         * @param text {String}
         * @returns {$.Deferred}
         */
        displaySystemScreen: function (state, text) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "systemScreen",
                    "state": state,
                    "text": text
                }
            });
        },

        /**
         * Send the image to the head unit
         *
         * @params options {Object}
         *
         * @returns {$.Deferred}
         */
        updateImage: function (options, sequenceNumber) {
            // TODO: Calling private _onSendRequest()? Create public method like sendAsyncRequest()
            return this._transport._onSendRequest({
                "path": "thor/image",
                "headers": {"Content-Type": "image/png"},
                "method": "POST",
                "sequenceNumber": sequenceNumber,
                "code": 200,
                "status": "OK",
                "responseHandler": {
                    "name": "imageResponse",
                    "params": options
                }
            });
        },

        /**
         * @param requestContent - request content
         * {
         *  fileId - zipId identifier (assets_zipId)
         * }
         *
         * @param sequenceNumber
         * @returns {*}
         */
        sendImageArchive: function (requestContent, sequenceNumber) {
            var zipId = requestContent.fileId,
                appName = this.zipMap[zipId],
                path = this.constants.URL.filePath,
                archiveType = this.constants.IMAGE_ARCHIVE.ZIP;

            if(this.utils.getPlatform() === "android") {
                path = this.constants.URL.androidPath;
            }
            path = path + appName + "/assets_" + zipId + "." + archiveType;

            this.appManager.logger.log({'sendImageArchive' : 'sendImageArchive'});
            this.appManager.logger.log({'path' : path});

            return this._transport._onSendRequest({
                "path": "thor/file",
                "headers": {"Content-Type": "application/" + archiveType},
                "method": "POST",
                "sequenceNumber": sequenceNumber,
                "code": 200,
                "status": "OK",
                "responseHandler": {
                    'name': 'file',
                    'params': {
                        url: path
                    }
                }
            });
        },

        onSaveFileComplete: function () {
            this.appManager.logger.log({'onSaveFileComplete' : 'onSaveFileComplete'});
        },

        cacheImages: function (images) {
            return this._cacheImages(images);
        },

        onArchiveRequest: function (content, notification) {
            this.sendImageArchive(content, notification.sequenceNumber);
        },

        onImageRequest: function (content, notification) {
            var imgId = content.imageId,
                imgData = this.storage.getValue(imgId, 'image'),
                appId = content.appId,
                constants = this.constants;

            imgData = this.utils.parseJSON(imgData);

            if (!imgData) return;

            // TODO figure out available image formats
            var format = /^file:\/\//.test(imgData.data) ? 'file' : 'base64';

            // TODO taken from DA
            if(this.utils.getPlatform() === "android") {
                // Replace file:///  with  file:///HMI_ROOT/www/
                imgData.data = imgData.data ?
                    imgData.data.replace(constants.URL.filePath, constants.URL.androidPath) : "";
            }

            this.updateImage({
                imageId: imgId,
                url: imgData.data,
                format: format,
                appId: appId,
                width: imgData.w || 0,
                height: imgData.h || 0
            }, notification.sequenceNumber);
        },

        /**
         *
         * @param images {Array}
         */
        _cacheImages: function (images) {
            var dfd = $.Deferred(),
                cacheImages = this._transport.sendRequest({
                    "path": "headunit/event",
                    "method": "POST",
                    "content": {
                        "type": "saveImages",
                        "data": {
                            "imageIds": images
                        }
                    }
                });

            cacheImages
                .done(function () {
                    this.once(this.events.saveImageComplete, dfd.resolve);
                    // reject by timeout if image caching not completed
                    // TODO figure out timeout time and should we show any error message
                    _.delay(dfd.reject, 30000);
                }.bind(this))
                .fail(dfd.reject);

            return dfd.promise();
        },


        /**
         *
         * @returns {jqXHR|jQuery.Deferred}
         */
        saveZip: function (zipMap) {
            var zipIds = Object.keys(zipMap).map(function (zipId) {
                return parseInt(zipId, 10);
            });
            
            this.zipMap = zipMap;
            
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "saveFile",
                    "data": {
                        "fileIds" : zipIds
                    }
                }
            });
        },

        /**
         *
         * @param images {Array}
         */
        invalidateImagesCache: function (images) {
            return this._transport.sendRequest({
                "path": "headunit/event",
                "method": "POST",
                "content": {
                    "type": "deleteImages",
                    "data": {
                        "imageIds": images
                    }
                }
            });
        },

        _onNotification: function (content, notification) {
            var notificationName = content.type ||
                _.last(notification && notification.path && notification.path.split('/'));
            if (Object.keys(this.events).indexOf(notificationName) !== -1) {
                this.trigger(this.events[notificationName], content, notification);
            }
        }

    });
});
