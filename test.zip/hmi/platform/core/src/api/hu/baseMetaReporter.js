define('aq/api/hu/baseMetaReporter',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            'headUnitConnectionState':  'headUnitConnectionState',
            'readyToSubmitReport':      'readyToSubmitReport',
            'idcEventsDataUpdated':     'idcEventsDataUpdated',
            'locationDataUpdated':      'locationDataUpdated'
        },

        _huState: {
            connected:    'connected',
            disconnected: 'disconnected'
        },

        /**
         * headUnitInfo (on headUnitConnectionState event)
         */
        _huInfo:            null,

        /**
         * handsetProfile
         */
        _handsetProfile:    null,

        /**
         * device location
         */
        _location:    null,

        /**
         * data to report
         */
        _metaData:          null,

        /**
         * HAP api_path to get _metaData
         */
        _apiPath:           null,

        /**
         * id of corresponding report module
         */
        _reportId:          "baseReport",

        /**
         * bluetooth connection state
         */
        _connectionsState:  null,

        _utils: null,

        init: function (transport) {
            this._super(transport);
            this._utils = transport._utils;
            this.listenTo(this, this.events.headUnitConnectionState, this.onConnectionStateChange);

            this._getHandsetProfile();
            this._getLocation();
        },

        getHuInfo: function () {
            return this._huInfo;
        },

        getHandsetProfile: function () {
            return this._handsetProfile;
        },

        getLocation: function () {
            return this._location;
        },

        /**
         * report data to submit,
         *data {
         *  vin: "vin",
         *  countryCode: "countryCode",
         *  huType: "huType",
         *  huId: "huId",
         *  mipId: "mipId",
         *  appName: "appName",
         *  launchTime: "Date ISO standart"
         * }
         */
        generateReportData: function () {
            throw new Error('[BaseReport] writing is not implemented');
        },

        resetMetaData: function() {
            throw new Error('[BaseReport] writing is not implemented');
        },

        /**
         * set HU info on connectionState === connected
         * @param huInfo
         * {
         *    data: {
         *      headUnitInfo: "key:val, key: val",
         *
         *    state: "connected" or "disconnected"
         *    }
         * }
         * @private
         */
        _setHUInfo: function (huInfo) {
            if (huInfo.state === this._huState.connected && huInfo.headUnitInfo) {
                this._huInfo = huInfo.headUnitInfo;
                this._getHandsetProfile();
            }
        },

        _getMetaData: function() {
            throw new Error('[BaseReport] writing is not implemented');
        },

        _getHandsetProfile: function () {
            return this._transport.sendRequest({
                "path": 'handsetProfile',
                "method": "GET"
            }).done(function (responseData) {
                //TODO: fix ios handsetProfile on IOS HAP
                if (responseData.data) {
                    this._handsetProfile = responseData.data;
                } else {
                    this._handsetProfile = responseData;
                }
            }.bind(this));
        },

        _getLocation: function() {
            return this._transport.sendRequest({
                "path": 'location',
                "method": "GET"
            }).done(function (responseData) {

                if (responseData.data) {
                    this._location = responseData.data;
                } else {
                    this._location = responseData;
                }
            }.bind(this));
        },

        /**
         * Handler listening to "headUnitConnectionState" event,
         * e.g. "state":"connected"
         * 
         * @param huInfo: {
         *  headUnitSerialNumber: "string",
         *  headUnitType: "VP2C",
         *  huFirmwareVersion: "string",
         *  huPartNumber: "string",
         *  hupPlatformName: "string",
         *  hupPlatformVersion: "string",
         *  vechicleMake: "string",
         *  vin: "string"
         *
         * @example
         * <pre>
         * "headUnitInfo":{
         *      "hupPlatformVersion":"1.0.0",
         *      "vehicleMake":"10",
         *      "headUnitType":"VP4_6_5",
         *      "vin":"1C6RR6MT1DS1031UC",
         *      "hupPlatformName":"VP4_6_5",
         *      "huPartNumber":"735601023 ",
         *      "headUnitSerialNumber":"T00BE351390163",
         *      "huFirmwareVersion":"-1.-1.-1"}
         *  }
         *  </pre>
         *
         * TODO: HUP has an issue of sending disconnected state before connected on connecting device.
         *       report this to HUP team.
         *
         *  @return void
         */
        onConnectionStateChange: function (huInfo) {
            this._huInfo = huInfo.headUnitInfo;
            this._connectionsState = huInfo.state;
            if (this._utils.isReportDataEmpty(this._handsetProfile)) {
                this._getHandsetProfile();
            }
        },

        _onNotification: function (content) {
            var notificationName = content.type;
            if (notificationName) {
                if (this.events[notificationName]) {
                    this.trigger(this.events[notificationName], content.data);
                }
            }
        }
    });
});
