/**
 * VR module for applications launch
 */

define('aq/api/hu/vr',['aq/api/base'], function (Base) {
    'use strict';

    return Base.extend({

        events: {
            vrAppLaunch: 'vrAppLaunch'
        },

        init: function (transport, utils, constants) {
            this.constants = constants;
            this.utils = utils;
            this._super(transport);
        },

        /**
         *
         * @param apps {Array}
         * [
         *   appDisplayName: <appDisplayName>,
         *   appName: <appName>
         * ]
         */
        setVrAppLaunchByListOfApps: function (apps) {
            // apps that could be launched through VR
            var appsList = this.constants.APPS_GRAMMAR;

            var appNameMap = this.constants.APP_NAME_MAP;

            // filter out not needed apps from list of all available apps
            var vrApps = apps.filter(function (app) {
                return appsList[app.appName];
            });

            this.setVrAppLaunch(vrApps.map(function (app) {
                return {
                    displayName: app.appDisplayName,
                    launchName: appNameMap[app.appName],
                    grammar: appsList[app.appName]
                };
            }));
        },

        /**
         *
         * @param list {Array}
         * [
         *   displayName: <string>,
         *   launchName: <handsetAppNAme>,
         *   grammar: []
         * ]
         *
         * @returns {$.Deferred}
         */
        setVrAppLaunch: function (list) {
            return this._transport.sendRequest({
                path: 'headunit/event',
                method: 'POST',
                content: {
                    type: 'setVrAppLaunch',
                    data: this.utils.toObject(list)
                }
            });
        },

        /**
         *
         * @param content {Object}
         * {
         *    "type": "vrAppLaunch",
         *    "data": {
         *        "launchName" : "<handsetAppName>"
         *    }
         * }
         *
         * @private
         */
        _onNotification: function (content) {
            var notificationName = content.type;
            if (this.events[notificationName]) {
                this.trigger(this.events[notificationName], content.data);
            }
        }
    });
});