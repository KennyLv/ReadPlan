define('aq/api/base',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (transport) {
            this._initTransport(transport);
        },

        _initTransport: function (transport) {
            this._transport = transport;
            this.listenTo(this._transport, 'notification', this._onNotification);
        },

        /**
         * _onNotification should be implemented in inherited class
         */
        _onNotification: function () {

        }

    });
});