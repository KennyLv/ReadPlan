/**
 * Injectable hook for storing and calculating responsiveness on user actions
 * Not for production builds
 */
define('aq/kpi',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    var KPI = EventEmitter.extend({

        captureEvents: {
            screenUpdate: 'screenUpdate',
            thirdParty: /meha$/,
            // todo add time processing
            saveImages: 'saveImages'
        },

        init: function (dic) {
            this.dic = dic;
            this.transport = this.dic.get('transport');
            this.controls = this.dic.get('controls');

            /**
             * {
             *   seqId: <number>,
             *   hmi: {
             *     receive: <Date>,
             *     respond: [<Date>, <Date>, ...]
             *     thirdParty: [[{start: <Date>, end: <Date>}], ...]
             *   }
             * }
             */
            this.kpi = {};

            /**
             * {
             *    appStart: Date,
             *    appName: app name,
             *    buttonName: 'buttonCommandSend' // button name was requested by AQ
             *  }
             * @type {null}
             */
            this.appStart = null;

            this.listenTo(this.controls, this.controls.events.soft, this.start);
            this.listenTo(this.controls, this.controls.events.hard, this.start);

            // monkey patching, re-write to more elegant solution later
            this._onSendRequest = this.transport._onSendRequest.bind(this.transport);
            this.transport._onSendRequest = this.onSendRequest.bind(this);
            // todo test stuff, remove later
            // this.counter = 1;
        },

        /**
         * capturing any soft or hard btn event
         * Start
         */
        start: function (data) {
            // todo test stuff, remove later
            //data.content.KPI = {
            //    seqId: this.counter++
            //};
            data = data || {};

            if (data.content && data.content.KPI) {
                var buttonName = data.button || data.action;
                this.kpi = data.content.KPI;
                this.kpi.hmi = {
                    buttonName: buttonName,
                    receive: Date.now(),
                    respond: [],
                    diff: [],
                    thirdParty: [[]]
                };
            } else if (data.action === 'start') {
                // click event on app list
                this.appStart = {
                    appStart: Date.now(),
                    appName: data.value.appName,
                    buttonName: 'buttonCommandSend'
                };
            }
        },

        onSendRequest: function (data) {
            var isScreenUpdateEvent = (data.content && data.content.type) === this.captureEvents.screenUpdate;

            if (this.kpi && this.kpi.hmi) {
                var dfd = this.transport._requests._queuee[data.requestNumber],
                    kpi = this.kpi,
                    screenUpdateCount = kpi.hmi.respond.length,
                    thirdParty = kpi.hmi.thirdParty,
                    thirdPartyEnd,
                    respondEnd,
                    thirdPartyStart,
                    index;

                if (this.captureEvents.thirdParty.test(data.path)) {
                    thirdPartyStart = Date.now();
                    index = thirdParty[screenUpdateCount].push({start: thirdPartyStart});

                    dfd.always(function () {
                        thirdPartyEnd = thirdParty[screenUpdateCount][index - 1].end = Date.now();
                        thirdParty[screenUpdateCount][index - 1].diff = thirdPartyEnd - thirdPartyStart;
                    });
                } else if (isScreenUpdateEvent) {
                    respondEnd = Date.now();
                    kpi.hmi.respond.push(respondEnd);
                    thirdParty.push([]);

                    if (kpi.hmi.diff.length === 0) {
                        kpi.hmi.diff.push(respondEnd - kpi.hmi.receive);
                    }
                    data.content.KPI = this.kpi;
                }
            // logging app start on first screenUpdate
            } else if (this.appStart && isScreenUpdateEvent) {
                data.content.KPI = {
                    hmi: this.appStart
                };
                this.appStart = null;
            }
            this._onSendRequest(data);
        }
    });

    return {
        init: function (dic) {
            return new KPI(dic);
        }
    };
});