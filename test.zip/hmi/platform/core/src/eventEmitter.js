define('aq/eventEmitter',['shared/utils/class', 'aq/mixins/events'], function (Class, events) {
    'use strict';

    return Class.extend(events);

});
