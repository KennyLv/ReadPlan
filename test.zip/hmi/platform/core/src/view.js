define('aq/view',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    var currentlyDisplayingTemplate = {
        data: {},
        LastUpdate: {},
        screenId: null
    };

    var isReady = true,  // is head unit ready to process screen update messages
        waitTime = 100;  // interval for sending to head unit screen update messages

    return EventEmitter.extend({


        /**
         * active events - bind event list
         *
         */
        activeEvents: [],

        /**
         *
         * @param options {object}
		 {
                utils:             this.get('utils'),
                storage:           this.get('storage'),
                constants:         this.get('constants'),
                controls:          this.get('controls'),
                screen:            this.get('screen'),
                appManager:        this.get('appManager'),
                TemplateProcessor: this.get('TemplateProcessor'),
                Logger:            this.get('Logger')
            }
         */
        init: function (options) {
            this.utils = options.utils;
            this.constants = options.constants;
            this.storage = options.storage;
            this.controls = options.controls;
            this.screen = options.screen;
            this.templateProcessor = new options.TemplateProcessor(
                currentlyDisplayingTemplate, options.storage, options.appManager
            );

            this.logger = new options.Logger('high', 'WEB_VIEW', 'SCREEN');

            this.listenTo(this.screen, this.screen.events.screenUpdateComplete, this.onScreenUpdated);

            this.listenTo(this.controls, this.controls.events.soft, this.onSoftButtonPress);
            this.listenTo(this.controls, this.controls.events.hard, this.onHardButtonPress);
            this.listenTo(this.controls, this.controls.events.keyboard, this.onKeyboardButtonPress);

            this._updateScreen = _.throttle(this._updateScreen.bind(this), waitTime);
        },

        onSoftButtonPress: function (data) {
            var content = data.content && data.content.data,
                btnClickOnScreenId = content && content.screenId,
                currentScreenId = currentlyDisplayingTemplate.screenId;

            this.logger.info({onSoftButtonPress: data});

            // avoid clicking on a rendering screen (which is not yet displayed)
            if (!!btnClickOnScreenId && !!currentScreenId &&
                parseInt(btnClickOnScreenId, 10) !== parseInt(currentScreenId, 10)) {
                return false;
            }
            this.trigger(data.action, {
                value: data.value
            });
        },

        onHardButtonPress: function (data) {
            this.logger.info({onHardButtonPress: data});

            this.trigger(data.button, {
                type: "hardButtonPressed"
            });
        },

        onKeyboardButtonPress: function (data) {
            this.logger.info({onKeyboardButtonPress: data});

            this.trigger(this.controls.events.keyboard, {
                letter: data.value,
                type: "hardButtonPressed"
            });
        },

        /**
         * Start list to specified head unit hard control
         */
        startListenTo: function (hardControl) {
            var to = {};
            to[hardControl] = true;
            if (this.activeEvents.indexOf(hardControl) === -1) {
                this.activeEvents.push(hardControl);
                return this.controls.startListenTo(to);
            }
        },

        /**
         * Stop list to specified head unit hard control
         * If no argument passed stop listen to all specific head unit hard controls
         */
        stopListenTo: function (hardControl) {
            var to = {},
                activeEventIndex = this.activeEvents.indexOf(hardControl);
            if (hardControl && activeEventIndex !== -1) {
                to[hardControl] = true;
                this.activeEvents.splice(activeEventIndex, 1);
            }
            return this.controls.stopListenTo(to);
        },

        getKeyboardButtonEventName: function () {
            return this.controls.events.keyboard;
        },

        getBackButtonEventName: function () {
            return this.constants.HARD_KEY_NAMES.back;
        },

        getScrollEventName: function () {
            return this.constants.HARD_KEY_NAMES.scroll;
        },
        
        getPresetAdvEventName: function () {
            return this.constants.HARD_KEY_NAMES.preset;
        },

        getSeekUpEventName: function () {
            return this.constants.HARD_KEY_NAMES.seekUp;
        },

        getSeekDownEventName: function () {
            return this.constants.HARD_KEY_NAMES.seekDown;
        },

        getUnMuteEventName: function(){
            return this.constants.HARD_KEY_NAMES.unmute;
        },

        getMuteEventName: function(){
            return this.constants.HARD_KEY_NAMES.mute;
        },

        getEnterEventName: function(){
            return this.constants.HARD_KEY_NAMES.enter;
        },

        showLoading: function (text) {
		
		console.log("=============in aq view show loading======================");
		
            this.resetScreen();
            this._displaySystemScreen('show', text);
        },

        hideLoading: function () {
            this._displaySystemScreen('hide', '');
        },

        showKeyboard: function (keyboardBgImg1, keyboardBgImg2) {
            this.screen.displayKeyboardScreen(keyboardBgImg1, keyboardBgImg2);
        },

        showMediaSourceScreen: function () {
            this.screen.displayMediaSourceScreen();
        },

        _displaySystemScreen: function (state, text) {
            text = typeof text === 'string' ? text : '';
            state = ['hide', 'show'].indexOf(state) !== -1 ? state : 'show';
            this.screen.displaySystemScreen(state, text);
        },

        resetScreen: function () {
            currentlyDisplayingTemplate.data = {};
            currentlyDisplayingTemplate.LastUpdate = {};
            currentlyDisplayingTemplate.screenId = null;
        },

        getCurrentTemplate: function () {
            return $.extend(true, {}, currentlyDisplayingTemplate.data);
        },

        /**
         * Process the template and updates the screen with the generated data.
         * @param template {object}
         * @returns {boolean}
         */
        updateScreen: function (template) {
            this.logger.info({
                msg: 'updateScreen: unbind and invoke _updateScreen',
                tpl: template
            });
            this.off();
            return this._updateScreen($.extend(true, {}, template));
        },

        onScreenUpdated: function () {
            isReady = true;
        },

        isCurrentTemplateIsEqualToGenerated: function(generatedTemplate) {
            return this.utils.isEqual(generatedTemplate, currentlyDisplayingTemplate.data);
        },

        _updateScreen: function (template) {
            var nextTemplate;
            this.logger.info({"before template processing" : {
                tpl: template
            }});

            // When rendering list with active item selected, this equality check
            // may not be enough to determine if screen need to be updated.
            // See CV-1997 for this particular use case.
            if (!/vp.+?-3/i.test(template.templateId) && this.isCurrentTemplateIsEqualToGenerated(template)) {
                this.logger.info({"_updateScreen" : "this template is exactly the same as previous one."});
                return false;
            }
console.log("-====-core _updateScreen=-=-==-=---");
            nextTemplate = this.templateProcessor.process(template);
console.log(nextTemplate);
            this.screen.updateScreen(nextTemplate);
            this.hideLoading();
            currentlyDisplayingTemplate.data = template;
            currentlyDisplayingTemplate.screenId = nextTemplate.screenId;

            return true;
        }

    });
});
