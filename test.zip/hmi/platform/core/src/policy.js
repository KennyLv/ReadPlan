/**
 *
 */
define('aq/policy',['aq/eventEmitter'], function (EventEmitter) {
    'use strict';
    var policies = {};
    var clickCounter = 0;
    var debug = 1;
    var dummyData = [
    {
        "category": "Graphic",
        "action": "IMAGE.ALBUM_ART",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "IMAGE.STATION_LOGO",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "IMAGE.ARTIST_IMAGE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "IMAGE.USER_ICON",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "IMAGE.POI_ICON",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "IMAGE.DISABLED_WHILE_DRIVING",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "IMAGE.HEADER",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.THUMBS_UP",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.THUMBS_DOWN",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.MENU_ITEM",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.PLAY",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.STOP",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.FAVORITE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.BOOKMARK",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "BUTTON.DISABLED_WHILE_DRIVING",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "TEXT.NAME",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "TEXT.ADDRESS",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "TEXT.SHORT_DESCRIPTION",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "TEXT.LONG_DESCRIPTION",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "TEXT.DATE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "TEXT.DISABLED_WHILE_DRIVING",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "TEXT.HEADER",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "TEXT.SCROLLING_HEADER",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "TEXT.SCROLLING",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "LIST.ITEM_SELECT",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Graphic",
        "action": "LIST.PAGE_BY_PAGE_SCROLLING",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Graphic",
        "action": "LIST.ITEM_BY_ITEM_SCROLLING",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Audio",
        "action": "TTS",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Input",
        "action": "KEYBOARD",
        "vehicleState": "MOVING",
        "allowed": true
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.MAKE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.CONNECT_METHOD",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.GPS_LOCATION",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.SPEED",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.DRIVER_SEAT_OCCUPIED",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.PASSENGER_SEAT_OCCUPIED",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.DOOR_OPEN",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.HEADUNIT_NAME",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.HEADUNIT_DIMENSIONS",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.HEADUNIT_RESOLUTION",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.RPM",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.FUEL_LEVEL",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.TOTAL_MILEAGE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.COOLANT_TEMPERATURE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.AIR_INTAKE_TEMPERATURE/VB.AIR_INTAKE_PRESSURE",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.ENGINE_MAL_FUNCTION",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.CAN_BUS_DATA",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Vehicle Bus",
        "action": "VB.MODEL",
        "vehicleState": "MOVING",
        "allowed": false
    },
    {
        "category": "Input",
        "action": "CLICKCOUNT",
        "vehicleState": "MOVING",
        "allowed": true,
        "value": "5"
    }
];
    return EventEmitter.extend({

        init: function (options) {
            this.navigation = options.navigation;
            this.appManager = options.appManager;
            this.transport = options.transport;
            this.vehicleState = null;
            
            this.navigation.on(this.navigation.events.vehicleState, this.onVehicleStateChanged, this);
            this.countLimit = 0;
        },
        
        setVehicleState: function(state){
             this.vehicleState = state;
         },
        
        /**
         *
         * Cache policy by application name
         *
         * @param policy {List} Collection of policies belong to current APP
         * @param clear {Bool} flag to clear policy cache
         * @returns null
         */
        setPolicy: function(policy, clear){
            var appName = this.appManager.getCurrentApplicationName();
            if (clear) delete policies[appName];
            if (!policy) return;
            policies[appName] = policy;
            return;
        },
        
        /**
         *
         * get cached policy by application name
         *
         * @returns {list} or false
         */
        getPolicy: function(){
            var appName = this.appManager.getCurrentApplicationName();
            if (policies[appName]) return policies[appName];
            return false;
        },
        /*
         * Sendrequest get policy according to appname
         * 
         * @returns {defferd} 
         */
        requestPolicy: function(){
            var appName = this.appManager.getCurrentApplicationName();
            var self = this;
            if (!this.transport && !this.transport.sendRequest && !debug) return false;
            if (debug) {
                $.when().done(function(){self.setPolicy(dummyData);});
            } else {
                this.transport.sendRequest({url:"/policy/"+appName}).done(
                    function(resp){
                        self.setPolicy(JSON.parse(resp));
                    }
                );
            }
        },
        
        /*
         * Modify template with policy, 
         * 
         * @param {Obj} template
         * @returns {Obj} template modified from policy
         */
        generateTemplateWithPolicy: function(template){
            var templateContent= template.templateContent;
            for(var i in templateContent){
                var contents = templateContent[i];
                if(_.isObject(contents)&&_.isObject(contents[0])){
                for(var j in contents){
                    if(contents[j].tag){
                        contents[j].policyEnabled = this.isPolicyAllow(contents[j].tag);
                    }
                }
                }else if(_.isObject(contents)){
                    if(contents.tag){
                        contents.policyEnabled = this.isPolicyAllow(contents.tag);
                    }
                }
                template.templateContent[i] = contents;
            }
            return template;
        },
        
        isPolicyAllow: function (tag){
            var policies = this.getPolicy();
            // TODO: catch up no policy cases
            if(!policies || this.vehicleState !== this.navigation.vehicleStates.moving){
                return true;
            }else{
                for(var i in policies){
                    if(policies[i].action === tag){
                        return policies[i].allowed;
                    }
                }
                /*
                 *TODO: when not match is found will enable that buttun 
                 */
                return true;
            }
        },
        
        getClickCounter: function(){
            return clickCounter;
        },
        
        setClickCounter: function(number){
            clickCounter = number;
        },
        
        checkClickExceed: function(){
            var policy = this.getPolicy();
            if (!policy || this.vehicleState !== this.navigation.vehicleStates.moving) {
                return false;
            }
            for(var i in policy){
                if(policy[i].action === "CLICKCOUNT"){
                    this.countLimit = policy[i].value;
                }
            }
            this.increaseCounter();
            return clickCounter>= this.countLimit;
        },
        
        increaseCounter: function(){
            clickCounter++;
        },
        
        onVehicleStateChanged:function (data){
            this.vehicleState = data.state;
        },

        /**
         *
         * Cache images by application id
         *
         * @param images {List} Collection of imageIds connected to the full image path
         * @param appId {String}
         * @returns {$.Deferred}
         */
        cacheImages: function (imageIds, appId) {
            this.apps[appId] = {
                hash: JSON.stringify(imageIds),
                progress: this.screen.cacheImages(imageIds)
            };
            return this.apps[appId].progress;
        }

    });

});
