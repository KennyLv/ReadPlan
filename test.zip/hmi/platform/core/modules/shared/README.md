# Shared HMI libraries and utils

## 1. Thor interface

`thor_interface` directory contains all common interfaces that should be implemented for all platforms.

### Thor allows you to

 * write platform independent HMI based on Thor interface

### Assumptions 

* You use RequireJS
* You name this package in RequireJS configuration as thor_interface
* You use Microevent
* You use jQuery


## Implementation and configuration

 * Download this package to shared libs directory of your project
 * Configure RequireJS package:

    	packages: [
			{
				name	 : 'shared',
				location : 'path_to_root_of_this_package'
			}
		]

 * Implement thor_interface, and update RequireJS configuration:

		packages: [
			{
				name	 : 'shared',
				location : 'path_to_root_of_this_package'
			},
			{
				name	 : 'thor',
				location : 'path_to_thor_implementation_directory'
			}
		]

## Basic usage

	// in abstract
	require(['shared/thor/{implemented_thor_interface_component}'], function (Implemented_thor_interface_component) {
		var implemented_thor_interface_component = new Implemented_thor_interface_component();
		// your HMI application magic
	});

	// CommandControl example
	require(['shared/thor/commandControl'], function (CommandControl) {
		var commandControl = new CommandControl();
		// your HMI application magic
	});

## Documentation

To get latest Thor interface documentation clone this repository and run:

	jsdoc ./thor_interface ./README.md -d ./jsdoc

from repository root

## 2. Apps

`apps` directory contains shared code for HMI applications

## 3. Utils

Shared HMI utilities and libraries (like DI container library)


# Contributing

1. Validate your code using `jshint` tool. `.jshintrc` is in the root directory.
2. If interface of any component is changed, bump version number in `package.json` and push a new tag with version number.  
Version number should always be an integer.
3. Create a merge request to `master` branch.
