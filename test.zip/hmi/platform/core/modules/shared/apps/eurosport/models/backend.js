define(["jquery", "shared/utils/class"], function($, Class) {
	'use strict';

	return Class.extend({

		eurosportUrl: '/mip_services/content/api/1.0/eurosport/',

		/**
		 * @param {Object} choreo
		 * @param {string} language  Choreo Language/Country code. Format: ISO-639-1 (_) ISO 3166-1
		 */
		init: function(choreo, language){
			this.choreo = choreo;
			this.language = language;
		},

		/**
		 * @return {$.Deferred}
		 */
		_sendRequest: function(resource){
			return this.choreo.sendRequest({
				url: this.choreo.baseUrl + this.eurosportUrl + resource
			});
		},

		getHeadlines: function(){
			return this._sendRequest('headlines/language/' + this.language);
		},

		/**
		 * Retrieves the headlines in a specific language for a specific sport
		 * @param  {int} sportId
		 * @return {$.Deferred}
		 */
		getSportHeadlines: function(sportId){
			return this._sendRequest('sport_headlines/language/' + this.language + '/sport/' + sportId);
		},

		/**
		 * @return {$.Deferred}
		 */
		getCategories: function(){
			return this._sendRequest('categories/language/' + this.language);
		},

		/**
		 * Requests category list from server and caches it while app is open
		 * @return {$.Deferred}
		 */
		getCachedCategories: function(){
			var self = this;

			if (this.cachedCategories) {
				return $.when(this.cachedCategories);
			} else {
				return this.getCategories().done(function(data){
					self.cachedCategories = data;
				});
			}
		},

		/**
		 * @param  {int} storyId
		 * @param  {int} languageId
		 * @return {$.Deferred}
		 */
		getStory: function(storyId, languageId){
			return this._sendRequest('story/languageId/' + languageId + '/storyId/' + storyId);
		},

		/**
		 * Returns Image URL of specified format
		 * If image is not found, function returns null
		 *
		 * @param  {Object} storyObject The same object as it is returned from Choreo
		 * @param  {int} formatId
		 * @return {string}
		 */
		getStoryImageUrl: function(storyObject, formatId) {
			try {
				var formats = storyObject.story.picture.formats;
				for (var i = 0; i < formats.length; i++) {
					if (formats[i].id === formatId) {
						return formats[i].imageUrl;
					}
				}
			} catch (e) {}

			return null;
		}

	});

});