define(['shared/apps/inrix/fixtures/mobile.incidents.box'], function(incidents){
	return {"routes":[{
		"summary":"Via Schwere-Reiter-Straße, Ackermannstraße and Karl-Theodor-Straße",
		"incidents": incidents.incidents,
		"travelTimeMinutes":10,
		"distance":2.3,
		"id":644394502
	},
	{
		"summary":"Via Schwere-Reiter-Straße, Hohenzollernstraße and Leopoldstraße",
		"incidents":[],
		"travelTimeMinutes":30,
		"distance":2.6,
		"id":644394503
	}]};
});
