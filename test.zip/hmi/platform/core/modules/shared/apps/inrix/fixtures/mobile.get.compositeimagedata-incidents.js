/* jshint maxlen: 500 */
define(['shared/apps/inrix/fixtures/mobile.incidents.box'], function(incidents){
	return {
		"images": [
			{
				"routeId": "b23b399e-3aba-464c-af14-b9262f0df2af",
				"imageKey": "b23b399e-3aba-464c-af14-b9262f0df2af",
				"imageUrl": "inrix/InrixIncidents.jpg",
				"height": 190,
				"width": 190
			}
		],
		"incidents": incidents.incidents,
		"routes": []
	};
});

