define(['shared/apps/inrix/fixtures/mobile.incidents.box'], function(incidents){
	return {
		"images": [
			{
				"routeId": "517d07d7-2832-49e8-9974-b4528dcccdbc_route",
				"imageKey": "517d07d7-2832-49e8-9974-b4528dcccdbc_route",
				"imageUrl": "inrix/InrixImage.jpg",
				"height": 400,
				"width": 400
			},
			{
				"routeId": "517d07d7-2832-49e8-9974-b4528dcccdbc_altroute",
				"imageKey": "517d07d7-2832-49e8-9974-b4528dcccdbc_altroute",
				"imageUrl": "inrix/InrixImage.jpg",
				"height": 400,
				"width": 400
			}
		],
		"incidents": [],
		"routes": [
			{
				"summary": "Via A 9, A 10 and A 113",
				"id": "517d07d7-2832-49e8-9974-b4528dcccdbc_route",
				"incidents": incidents.incidents,
				"distance": 366.9731,
				"travelTimeMinutes": 309
			},
			{
				"summary": "Via A 93, A 72 and A 13",
				"id": "517d07d7-2832-49e8-9974-b4528dcccdbc_altroute",
				"incidents": [],
				"distance": 393.08078,
				"travelTimeMinutes": 356
			}
		]
	};
});