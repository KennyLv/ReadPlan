define([
	"shared/utils/class",
	"jquery",
	"shared/utils/latLon"
], function(Class, $, LatLon) {
	'use strict';

	return Class.extend({
		errorCode: {
			unroutableWaypoint: 121
		},

		commandPrefix: 'INRIXAutoLink://',

		searchRadius: 15, // Default radius in miles. Used for searching for incidents

		/**
		 * @deprecated Use getIncidentType() instead
		 */
		incidentType: {
			1: 'Construction',
			2: 'Event',
			3: 'Congestion',
			4: 'Accident',
			6: 'Police',
			8: 'Hazard'
		},

		/**
		 * Return incident type
		 * Possible return values: values of this.incidentType and 'Closure'
		 *
		 * @param  {Number} [type=Null]
		 * @param  {Number} [eventCode=Null]
		 * @return {string}
		 */
		getIncidentType: function(type, eventCode) {
			var closureEvents = [16, 24, 25, 240, 241, 246, 401, 735, 947, 957];
			// as suggested by Inrix developers, if event code is one of the closureEvents,
			// define type as "closure"
			if (eventCode && closureEvents.indexOf(eventCode) > -1) {
				return 'Closure';
			}

			return type && this.incidentType[type];
		},

		/**
		 * @param {Object} options
		 * @param {Object} options.commandControl thor/commandControl
		 * @param {Object} options.navigation thor/navigation
		 * @param {Object} options.profile thor/profile
		 * @param {Object} options.sharedHelper shared/utils/helper
		 */
		init: function(options){
			this.commandControl = options.commandControl;
			this.navigation = options.navigation;
			this.profile = options.profile;
			this.helper = options.sharedHelper;
		},

		/**
		 * Abstraction on commandControl.sendCommand().
		 * It rejects deferred if Inrix responds with an errorCode
		 *
		 * @param  {Object} reqObject
		 * @return {$.promise}
		 */
		sendCommand: function(reqObject){
			var dfrd = new $.Deferred(),
				self = this;
			this.commandControl.sendCommand(reqObject)
				.done(function(data){
					if (data.errorCode === self.errorCode.unroutableWaypoint) {
						// return empty array if "unroutable waypoint" error occurs
						dfrd.resolve({routes: []});
					} else if (!data.errorCode) {
						dfrd.resolve(data);
					}  else  {
						dfrd.reject(data);
					}
				})
				.fail(function(data){
					dfrd.reject(data);
				});
			return dfrd.promise();
		},

		/**
		 * Returns saved locations with `route` object for each of them
		 * @return {$.Promise}
		 */
		getSavedLocations: function(){
			return this._getSavedLocations()
				.then(this.updateLocationsWithRoutes.bind(this));
		},

		/**
		 * Send HU registration command
		 * @param  {string} huId
		 * @param  {string} vendor
		 * @param  {string} huType
		 * @return {$.Promise}
		 */
		sendRegisterCommand: function(huId, vendor, huType){
			return this.sendCommand({
				command: this.commandPrefix + 'mobile.headunit.register?' + $.param({
					huid: huId,
					vendor: vendor,
					hutype: huType
				})
			});
		},

		/**
		 * Updates saved locations, which come from server, with a `route` object
		 * @param  {Object} data
		 * @return {$.Promise}
		 */
		updateLocationsWithRoutes: function(data){
			var self = this;

			if(!data || !data.locations || !data.locations.length) {
				// return empty object if there is no locations
				return $.when({});
			}

			return this.navigation.getCurrentLocation()
				.then(function(currentLocation){

					// add `route` object
					var routeDfrds = data.locations.map(function(loc){
						return self.findRoute(loc.id, currentLocation).done(function(route){
							loc.route = route;
						});
					});

					// resolve when all routes are added
					return $.when.apply($, routeDfrds).then(function(){
						return data;
					});
				});
		},

		/**
		 * Updates saved locations, which come from server, with a `route` object and map images
		 * @param  {Object}   savedLoc         Object that comes in response to mobile.location.get
		 * @param  {Number}   width            [64, 1024]
		 * @param  {Number}   height           [64, 1024]
		 * @param  {boolean} [nightMode=false]
		 * @return {$.Promise}
		 */
		updateLocationsWithRoutesAndMaps: function(savedLoc, width, height, nightMode){
			var self = this;

			if(!savedLoc || !savedLoc.locations || !savedLoc.locations.length) {
				// return empty object if there is no locations
				return $.when({});
			}

			return this.navigation.getCurrentLocation()
				.then(function(cur){

					// add `route` object
					var routeDfrds = savedLoc.locations.map(function(loc){
						var dest = {
							lat: loc.latitude,
							lon: loc.longitude
						};
						return self.findRouteMap(cur, dest, width, height, nightMode).done(function(route){
							loc.route = route;
						});
					});

					// resolve when all routes are added
					return $.when.apply($, routeDfrds).then(function(){
						return savedLoc;
					});
				});
		},

		/**
		 * Find a route
		 *
		 * @param  {int} locationId
		 * @param  {Object} currentLocation
		 * @return {$.promise}
		 */
		findRoute: function(locationId, currentLocation){
			var params = {
				wp_1: currentLocation.lat + '|' + currentLocation.lon,
				wp_2id: locationId
			};

			return this.sendCommand({
					command: this.commandPrefix + 'mobile.route.find?' + $.param(params)
				});
		},

		/**
		 * Find a route (with a map)
		 *
		 * @param  {Object}  cur            current location
		 * @param  {Number}  cur.lat
		 * @param  {Number}  cur.lon
		 * @param  {Object}  dest           destination location
		 * @param  {Number}  dest.lat
		 * @param  {Number}  dest.lon
		 * @param  {Number}  width          [64, 1024]
		 * @param  {Number}  height         [64, 1024]
		 * @param  {boolean} [nightMode=false]
		 * @return {$.promise}
		 */
		findRouteMap: function(cur, dest, width, height, nightMode){
			var params = {
				location: cur.lat + '|' + cur.lon,
				destination: dest.lat + '|' + dest.lon,
				width: width,
				height: height,
				mapstyle: nightMode ? 'night' : 'day'
			};

			return this.sendCommand({
					command: this.commandPrefix + 'mobile.get.compositeimagedata?' + $.param(params)
				});
		},

		getTrafficQuality: function(){
			var self = this;
			return this.navigation.getCurrentLocation().then(function(currentLocation){
				return self.sendCommand({
					command: self.commandPrefix + 'mobile.traffic.quality?' + $.param({
						center: currentLocation.lat + '|' + currentLocation.lon
					})
				});
			});
		},

		/**
		 * Request saved locations from Inrix
		 * @return {$.Promise}
		 */
		_getSavedLocations: function(){
			return this.sendCommand({
				command: this.commandPrefix + 'mobile.location.get'
			});
		},

		/**
		 * Return corner coordinates for visible region on the head unit
		 *
		 * @return {object}, e.g., {lat: 12.3, lon: 14.1}
		 */
		_getRectangleCoordinates: function(location){
			var current = new LatLon(location.lat, location.lon),
				searchRadius = this.searchRadius * 1.61; // convert mi to km

			return {
				corner1: current.destinationPoint(360-45, searchRadius),
				corner2: current.destinationPoint(90+45, searchRadius)
			};
		},

		/**
		 * Return incidents on the road
		 * @return {$.Promise}
		 */
		getIncidents: function(){
			var self = this;

			return this.navigation.getCurrentLocation().then(function(location){
				var rect = self._getRectangleCoordinates(location),
					params = {
						corner1: rect.corner1.lat + '|' + rect.corner1.lon,
						corner2: rect.corner2.lat + '|' + rect.corner2.lon,
						location: location.lat + '|' + location.lon
					};

				return self.sendCommand({
					command: self.commandPrefix + 'mobile.incidents.box?' + $.param(params)
				});
			});

		},

		/**
		 * Update floating car data(should be send every 5 sec due to documentation,
		 * implement this interval in your own controller)
		 */
		sendFcd: function(){
			var self = this;

			return this._getCurrentVehicleState()
				.then(function (location, bearing, speed) {
					var params = {
						latitude: location.lat,
						longitude: location.lon,
						speed: self.helper.convertKmphtoMps(speed),
						bearing: bearing,
						time: self._getTimeForFcd()
					};

					return self.sendCommand({
						command: self.commandPrefix + 'mobile.send.fcd?' + $.param(params)
					});
			});
		},

		_getCurrentVehicleState: function () {
			return $.when(
				this.navigation.getCurrentLocation(),
				this.navigation.getVehicleHeading(),
				this.navigation.getVehicleSpeed('KMPH')
			);
		},

		/**
		 * Returns UTC time in format YYYY-MM-DDTHH:mm:ssZ
		 * @return {string}
		 */
		_getTimeForFcd: function(){
			var time = new Date().toISOString();
			return time.replace(/\.\d+Z/, 'Z'); // remove a decimal fraction of a second
		},

		/**
		 * Return incidents nearby and URL to Inrix map
		 *
		 * @param  {Number}  width          [64, 1024]
		 * @param  {Number}  height         [64, 1024]
		 * @param  {boolean} [nightMode=false]
		 */
		getNearbyIncidentsWithMap: function(width, height, nightMode){
			var self = this;

			return this.navigation.getCurrentLocation().then(function(location){
				var rect = self._getRectangleCoordinates(location),
					params = {
						corner1: rect.corner1.lat + '|' + rect.corner1.lon,
						corner2: rect.corner2.lat + '|' + rect.corner2.lon,
						location: location.lat + '|' + location.lon,
						width: width,
						height: height,
						mapstyle: nightMode ? 'night' : 'day'
					};

				return self.sendCommand({
					command: self.commandPrefix + 'mobile.get.compositeimagedata?' + $.param(params)
				}).done(function(data){
					// append location and corner coordinates to the result
					data.location = location;
					data.corner1 = rect.corner1;
					data.corner2 = rect.corner2;
				});
			});
		}

	});

});
