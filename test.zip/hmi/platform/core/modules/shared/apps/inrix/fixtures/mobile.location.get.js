define({
	"locations":[{
		"address":"Münchner Freiheit 20, Munich, Germany",
		"id":3079845,
		"latitude":48.163324,
		"longitude":11.587532,
		"name":"Home",
		"order":0,
		"type":1
	}
	]
});
