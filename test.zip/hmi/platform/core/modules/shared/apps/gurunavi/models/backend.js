define(['shared/baseCloudService', 'jquery'], function(BaseCloudService, $) {
  'use strict';

  return BaseCloudService.extend({

    init: function(choreo, navigation, config) {
      this._super(choreo, config.apiVersion);
      this.navigation = navigation;
      this.config = config;

      this.appName = 'gurunavi';
      this.cachedPois = [];
    },

    /**
     * Searches POIs by search query and refines results if needed
     * @param  {string} query       Search query
     * @param  {object} refinements Object which specifies a refinements for search
     * @param  {string} [refinements.sortBy] Field name for sorting
     * @param  {string} [refinements.order] Sort direction
     * @return {jQuery.Promise}
     */
    searchFor: function(query, refinements) {
      return this.searchResultsService({query: query}, refinements);
    },

    /**
     * Searches POIs by category and refine results if needed
     * @param  {string} name       Category name, ex: "hotels"
     * @param  {object} refinements Object which specifies a refinements for search
     * @param  {string} [refinements.sortBy] Field name for sorting
     * @param  {string} [refinements.order] Sort direction
     * @return {jQuery.Promise}
     */
    findByCategory: function(name, refinements) {
      return this.searchResultsService({category: name}, refinements);
    },

    searchByChosenLocation: function(refinements) {
      return this.searchResultsService(null, refinements);
    },

    /**
     * Gets already cached poi by id
     * @param  {number} id       POI id
     * @return {object}
     */
    getPoiById: function(id) {
      var d = new $.Deferred();
      d.resolve(this.cachedPois[id]);
      return d.promise();
    },

    searchResultsService: function(params, refinements) {
      return this.navigation.getLocation(this.config.locationType)

        .then(function(location) {

          var args = $.extend({
            latitude: location.lat,
            longitude: location.lon,
          }, params);

          return this.sendRequest('/search?' + $.param(args));

        }.bind(this))

        .then(function(data) {
          this.cache(data.pois);
          return this.refine(data.pois, refinements);
        }.bind(this));
    },

    refine: function(list, refinements) {
      if (refinements.order === 'asc') {
        // || 0 because of possible NaN
        list.sort(function(item1, item2) {
          return parseFloat(item1[refinements.sortBy] || 0) - parseFloat(item2[refinements.sortBy] || 0);
        });
      } else {
        list.sort(function(item1, item2) {
          return parseFloat(item2[refinements.sortBy] || 0) - parseFloat(item1[refinements.sortBy] || 0);
        });
      }

      return list;
    },

    cache: function(pois) {
      pois.forEach(function(poi) {
        this.cachedPois[poi.id] = poi;
      }.bind(this));
    },

  });
});
