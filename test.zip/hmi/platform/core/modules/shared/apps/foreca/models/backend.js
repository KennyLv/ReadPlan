define(['shared/baseCloudService', 'jquery'], function(BaseCloudService, $) {
	'use strict';

	return BaseCloudService.extend({

		/**
		 * @param  {object} choreo     thor interface implementation of choreo
		 *                             for certain platform(LCN, MCN2KAI etc.)
		 * @param  {object} navigation thor interface implementation of navigation
		 *                             for certain platform(LCN, MCN2KAI etc.)
		 * @param {object} profile     thor interface implementation of profile
		 *                             (application configuration: distance unit,
		 *                             temperature unit etc.)
		 */
		init: function(choreo, navigation, profile) {
			this._super(choreo, '1.0');
			this.navigation = navigation;
			this.profile = profile;
			this.appName = 'weather';
		},

		/**
		 * gets location according to type: 0 - current location, 1 - destination
		 * @param  {number} type type of location(current, destination)
		 * @return {$.Deferred}
		 */
		getLocation: function(type) {
			return this.navigation.getLocation(type);
		},


		/**
		 * sends request to Choreo using thor/choreo module
		 * 
		 * @param {object} location       latitude and longitude of target location
		 * @param {number} location.lat   latitude
		 * @param {number} location.lon   longitude
		 * @return {$.Promise}
		 */
		getWeather: function(location) {
			var units = this.profile.getUnitsOfMeasurement();
			return this.sendRequest('/current?' + $.param({
				tempunit: units.tempUnit,
				windunit: units.speedUnit,
				latitude: location.lat,
				longitude: location.lon
			}));
		},

		/**
		 * sends request to Choreo using thor/choreo module
		 * 
		 * @param {number} day            serial number of day(1-5) (1(today), 2(tomorrow) etc.).
		 *                                See ICD for details
		 * @param {object} location       latitude and longitude of target location
		 * @param {number} location.lat   latitude
		 * @param {number} location.lon   longitude
		 * @return {$.Promise}
		 */
		getForecastDetails: function(day, location) {
			var units = this.profile.getUnitsOfMeasurement();
			return this.sendRequest('/forecast/detail?' + $.param({
				day: day,
				tempunit: units.tempUnit,
				windunit: units.speedUnit,
				latitude: location.lat,
				longitude: location.lon
			}));
		}
	});
});