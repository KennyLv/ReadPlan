define(['shared/baseCloudService', 'jquery'], function(BaseCloudService, $) {
  'use strict';

  return BaseCloudService.extend({

    /**
     * @param  {ChoreoInterface} choreo
     * @param  {NavigationInterface} navigation
     * @param  {object} appState Stores current application state
     * @param  {int} [appState.locationType] Chosen location type for all requests. It could be 0 (CURRENT_LOCATION)
     *   or 1 (DESTINATION_LOCATION)
     * @param  {string} [appState.language] Current HU's language. Should be in format like en_us, ja_jp, etc
     */
    init: function(choreo, navigation, appState) {
      this._super(choreo, appState.apiVersion);
      this.navigation = navigation;
      this.appState = appState;

      this.appName = 'trip_advisor';
    },

    /**
     * Searches POIs by search query and refines results if needed
     * @param  {string} query       Search query
     * @param  {object} refinements Object which specifies a refinements for search
     * @param  {string} [refinements.sortBy] Field name for sorting
     * @param  {string} [refinements.order] Sort direction
     * @return {jQuery.Promise}
     */
    searchFor: function(query, refinements) {
      return this.searchResultsService({keyword: query}, refinements);
    },

    /**
     * Searches POIs by category and refine results if needed
     * @param  {string} name       Category name, ex: "hotels"
     * @param  {object} refinements Object which specifies a refinements for search
     * @param  {string} [refinements.sortBy] Field name for sorting
     * @param  {string} [refinements.order] Sort direction
     * @return {jQuery.Promise}
     */
    findByCategory: function(name, refinements) {
      return this.searchResultsService({category: name}, refinements);
    },

    /**
     * Gets POI by id from Choreo
     * @param  {number} id POI id
     * @return {object}
     */
    getPoiById: function(id){
      return this.navigation.getLocation(this.appState.locationType)
        .then(function(location){
          return this.sendRequest('/location/' + id + '?' + $.param({
            latitude: location.lat,
            longitude: location.lon,
            language: this.appState.language,
            unit: this.convertDistanceUnit(this.navigation.getDistanceUnit())
          }));
        }.bind(this));
    },

    searchResultsService: function(params, refinements) {
      return this.navigation.getLocation(this.appState.locationType)

        .then(function(location) {

          var args = $.extend({
            latitude: location.lat,
            longitude: location.lon,
            language: this.appState.language,
            unit: this.convertDistanceUnit(this.navigation.getDistanceUnit())
          }, params);

          return this.sendRequest('/location/search?' + $.param(args));

        }.bind(this))

        .then(function(data) {
          return this.refine(data.results, refinements);
        }.bind(this));
    },

    convertDistanceUnit: function(unit) {
      if (unit === 'mi') {
        return 'M';
      } else {
        return 'K';
      }
    },

    refine: function(list, refinements) {
      if (refinements.order === 'asc') {
        // || 0 because of possible NaN
        list.sort(function(item1, item2) {
         return parseFloat(item1[refinements.sortBy] || 0) - parseFloat(item2[refinements.sortBy] || 0);
        });
      } else {
        list.sort(function(item1, item2) {
          return parseFloat(item2[refinements.sortBy] || 0) - parseFloat(item1[refinements.sortBy] || 0);
        });
      }

      return list;
    },

  });
});
