define(["shared/utils/class", "jquery"], function(Class, $) {
	'use strict';

	return Class.extend({
		/**
		 * @param {Object} commandControl
		 * @param {Object} navigation
		 * @param {String} language Language code in ISO 639-1 format
		 */
		init: function(commandControl, navigation, language) {
			this.commandControl = commandControl;
			this.navigation = navigation;
			this.language = language;
		},

		_getDistanceUnit: function(){
			// pakopedia API expected K or M as unit distance
			return this.navigation.getDistanceUnit() === 'KM' ? 'K' : 'M';
		},

		sendCommand: function(reqObject){
			var dfrd = new $.Deferred();
			this.commandControl.sendCommand(reqObject)
				.done(function(data){
					// due to Android and iOS API inconsistency,
					// fall back to errorcode (Android) value if errcode (iOS) is undefined
					var isAndroid = typeof data.errorcode != 'undefined';
					data.errorcode = Number(isAndroid ? data.errorcode : data.errcode);

					// dfrd should be resolve when Parkopedia API returns
					// Error 5 for android and Error 3 for iOS - spaces not found
					if (data.status == 'OK' || data.errorcode == (isAndroid ? 5 : 3)) {
						dfrd.resolve(data);
					}  else  {
						dfrd.reject(data);
					}
				})
				.fail(function(data){
					data.errorcode = Number(typeof data.errorcode != 'undefined' ? data.errorcode : data.errcode);
					dfrd.reject(data);
				});
			return dfrd;
		},

		/**
		 * Searches parkings list
		 * @param {object} location  Location coordinates
		 * @param {number} location.lat
		 * @param {number} location.lon
		 * @param {string} sort      Sort option "distance" | "price"
		 * @param {number} [max=20]  Max. returned elements quantity
		 * @return {$.Deferred}
		 */
		getParkingsList: function(location, sort, max) {
			return this.sendCommand({
				op: 'search',
				lat: location.lat,
				lng: location.lon,
				unit: this._getDistanceUnit(),
				sort: sort,
				maxr: max || 20,
				lang: this.language
			});
		},

		/**
		 * Get favorites list
		 * @return {$.Deferred}
		 */
		getFavoriteParkings: function(){
			return this.sendCommand({
				op: 'favorites/list',
				unit: this._getDistanceUnit()
			});
		},

		/**
		 * Add item to favorite list
		 * @return {$.Deferred}
		 */
		addToFavorite: function(id){
			return this.sendCommand({
				op: 'favorites/add',
				id: id
			});
		},

		/**
		 * Remove item from favorite list
		 * @return {$.Deferred}
		 */
		removeFromFavorite: function(id){
			return this.sendCommand({
				op: 'favorites/del',
				id: id
			});
		}
	});
});
