define(['jquery', 'shared/baseCloudService'], function($, BaseCloudService) {
	'use strict';

	return BaseCloudService.extend({

		/**
		 * @param {Object} choreo
		 * @param {Object} navigation
		 * @param {Object} appState
		 * {
		 *		language : {string} language  Choreo Language/Country code. Format: ISO-639-1 (_) ISO 3166-1,
		 *		distanceUnit : {string} 'KM' | 'M'
		 * }
		 */
		init: function(choreo, navigation, appState){
			this._super(choreo, '1.0');
			this.navigation = navigation;
			this.appState = appState;

			this.appName = 'yelp';
		},

		/**
		 * Get search results by given requestData and location, if no location provided, current location will be used
		 * @private
		 *
		 * @param  {object} requestData             a data for request
		 * @param  {object} [requestData.category]  a category for searching
		 * @param  {object} [requestData.keyword]   a keyword for searching
		 * @param  {object} location                current location or location of destination
		 *
		 * @return {jQuery.Promise}
		 */
		_getSearchResults: function(requestData, location) {
			var that = this;
			return this.navigation.getLocation(this.appState.locationType)
				.then(function(lastLocation){
					location = location ? location : lastLocation;
					if(requestData === undefined){
						requestData = {};
					}
					var param = $.param({
						category   : requestData.category || '',
						keyword    : requestData.keyword || '',
						latitude   : location.lat,
						longitude  : location.lon,
						unit       : that.appState.distanceUnit || 'KM',
						language   : that.appState.language || 'en'
					});
					return that.sendRequest('/search?' + param);
				});
		},

		/**
		 * Get all nearby Yelp staff 
		 *
		 * @return {jQuery.Promise}
		 */
		getNearby: function() {
			return this._getSearchResults();
		},

		/**
		 * Get all nearby Yelp staff by search word
		 *
		 * @param  {string} word a keyword for searching
		 *
		 * @return {jQuery.Promise}
		 */
		searchByWord: function(word) {
			return this._getSearchResults({ keyword : word });
		}
	});
});
