define(function () {
	return {
		/**
		 * converts from km/h unit to meter/sec unit
		 * @param  {number} speed value in km/h
		 * @return {number}       value in meter/sec
		 */
		convertKmphtoMps: function (speed) {
			return speed*1000/3600;
		},

		/**
		 * converts from km/h unit to miles/h unit
		 * @param  {number} speed value in km/h
		 * @return {number}       value in miles/h
		 */
		convertKmphtoMph: function (speed) {
			return speed / 1.609344;
		},

		/**
		 * converts from miles/h unit to km/h unit
		 * @param  {number} speed value in miles/h
		 * @return {number}       value in km/h
		 */
		convertMphtoKmph: function (speed) {
			return speed * 1.609344;
		}
	};
});
