define('shared/baseCloudService',['shared/utils/class', 'jquery'], function(Class, $) {
  'use strict';

  /**
   * @classdesc Base class to be inherited for all cloud applications.
   * It encapsulates all basic staff needed for implementing cloud client.
   *
   * @name BaseCloudService
   * @constructor
   */
  return Class.extend(
    {
       /**
       * Initializes cloud service.
       *
       * @name BaseCloudService#init
       * @function
       *
       * @param {Choreo} choreo - Thor Choreo instance
       * @param {string} contentApiVersion - Version of Choreo Content Api, ex: "1.0"
       */
      init: function(choreo, contentApiVersion) {
        this.choreo = choreo;
        this.contentApiVersion = contentApiVersion;

        this.contentPath = '/mip_services/content/api/' + this.contentApiVersion;
        this.cachedData = {};
      },

      /**
       * Sends request to specific content resource using Choreo API
       * If such request was sent previously method returns cached response 
       * @name BaseCloudService#sendRequest
       * @function
       *
       * @param {string} resourcePath - resource path for specific content service described in cloud service ICD.
       * For example: /search?query=hello&perPage=20
       * @param {object} [requestParams] - additional request parameters, compatible with jQuery.ajax parameters.
       * Caution! requestParams.url will  be overwritten
       *
       * @returns {jQuery.Deferred}
       */
      sendRequest: function(resourcePath, requestParams) {
        if (this.cachedData[resourcePath]) {
          var dfrd = new $.Deferred();
          dfrd.resolve(this.cachedData[resourcePath]);
          return dfrd.promise();
        }

        if (!this.appName) {
          throw new Error('"appName" is mandatory for "BaseCloudService". Please specify appName when creating model');
        }

        requestParams = requestParams || {};
        requestParams.url = this.choreo.baseUrl + this.contentPath + '/' + this.appName + resourcePath;

        return this.choreo.sendRequest(requestParams).done(function(data) {
          this.cachedData[resourcePath] = data;
        }.bind(this));
      },

      /**
       * cleans cachedData, if id is passed then cleans only certain cachedData
       * @param  {string} [id]- additional parameter, specified certain cachedData
       */
      clearCache: function(id) {
        if (id) {
          this.cachedData[id] = null;
        } else {
          this.cachedData = {};
        }
      }
    });
});