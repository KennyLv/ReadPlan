/* jshint undef: false*/
module.exports = function(grunt) {
	grunt.initConfig({
		jshint: {
			src: [
				'**/*.js'
			],
			options: {
				jshintrc: '.jshintrc',
				ignores: [
					'node_modules/**',
					'utils/class.js'
				]
			}
		}
	});
	grunt.loadNpmTasks('grunt-contrib-jshint');
	grunt.registerTask('default', ['jshint']);
};