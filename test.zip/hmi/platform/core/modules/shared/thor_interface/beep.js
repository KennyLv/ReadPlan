define(['shared/utils/class'], function(Class) {
	'use strict';

	return Class.extend({
		/**
		 * Generates beep according to the specified beep type or by default beep sound
		 *
		 * @name Beep#generate
		 * @function
		 * @abstract
		 * @example
		 * beep.generate(beep.CLICK)
		 *
		 * Possible types:
		 * 
		 * - ERROR
		 * - ROGER
		 * - WARN
		 * - CLICK
		 * - POI
		 * - SDS_END
		 * - SMS_INCOMING
		 * - SMS_SEND
		 * - URGENT
		 * - SPEED_WARN
		 * - CURVE_WARN
		 * - AVM_OPERATION
		 * - AVM_ERROR
		 * - VOL
		 * - SPEED_HINT
		 * - CURVE_HINT
		 * - SDS_START
		 *
		 * Some of beep types can't be supported by some platform
		 *
		 * @param {object} type The type of beep sound. 
		 */
		generate: function() {
			throw new Error('Beep.generate() not implemented');
		}

	});

});