/* jshint unused:false*/
define('shared/thor_interface/profile',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Access layer for fetching HUP data and back-end HMI settings
	 *
	 * @todo Profile interface may be extended by more partial HUP data fetching functions like language info
	 *
	 * @name Profile
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Get all HUP information: HMI applications list, statuses e.t.c.
		 * Contents of response is platform-dependent
		 *
		 * @name Profile#getHupInfo
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		getHupInfo: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get units of measurement
		 * Contents of response has to be
		 *  {
		 *      speedUnit: 'MPH'(or KMH),
		 *      tempUnit: 'F'(or C)
		 *  }
		 *
		 * @name Profile#getUnitsOfMeasurement
		 * @function
		 * @abstract
		 *
		 * @returns {object}
		 */
		getUnitsOfMeasurement: function () {
			throw new Error('not implemented');
		}
	});
});
