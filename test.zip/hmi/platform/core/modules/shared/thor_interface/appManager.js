/* jshint unused:false*/
define('shared/thor_interface/appManager',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc HMI application manager. Used to manage HMI application
	 *
	 * @name AppManager
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Start HMI application
		 *
		 * @name AppManager#startApp
		 * @function
		 * @abstract
		 *
		 * @param {object} params
		 *
		 * @example
		 * {
		 * "appName": "iheartradio",
		 * "notificationType": "launchApp",
		 * "path": "file:///data/data/abq/hup/iheartradio/7.18.0"
		 * }
		 */
		startApp: function () {
			throw new Error('not implemented');
		},

		/**
		 * Close current HMI application
		 *
		 * @name AppManager#closeApp
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		closeApp: function () {
			throw new Error('not implemented');
		},

		/**
		 * Load application policy. If no application name specified current application policy will be fetched
		 *
		 * @name AppManager#loadPolicy
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName]
		 *
		 * @returns {jQuery.Deferred}
		 */
		loadPolicy: function () {
			throw new Error('not implemented');
		},

		/**
		 * Loads application profile. If no application name specified current application profile will be fetched
		 *
		 * @name AppManager#loadProfile
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName]
		 *
		 * @returns {jQuery.Deferred}
		 */
		loadProfile: function () {
			throw new Error('not implemented');
		},

		/**
		 * Switch application
		 *
		 * @name AppManager#switchApp
		 * @function
		 * @abstract
		 *
		 * @param {string} appName
		 *
		 * @return {string} new application name
		 */
		switchApp: function(){
			throw new Error('not implemented');
		},

		/**
		 * Get current running application name
		 *
		 * @name AppManager#getCurrentApplicationName
		 * @function
		 * @abstract
		 *
		 * @return {string} name of current running application
		 */
		getCurrentApplicationName: function(){
			throw new Error('not implemented');
		},

		/**
		 * Set current running application name
		 *
		 * @name AppManager#setCurrentApplicationName
		 * @function
		 * @abstract
		 *
		 * @param {string} appName
		 */
		setCurrentApplicationName: function(){
			throw new Error('not implemented');
		}
	});
});
