/* jshint unused:false*/
define(['shared/utils/class'], function(Class) {
  'use strict';

  /**
   * @classdesc Represents real-world cell phone.
   *
   * @name Phone
   * @constructor
   */
  return Class.extend({

    /**
     * Dials a phone number using user's cell phone
     * @param  {string} phone Phone number to be dialed
     * @param  {string} [name] Contact name from the phonebook
     */
    dialPhoneNumber: function(phone, name) {
      throw new Error('not implemented');
    },

    /**
     * Does HMI has permission to call?
     * @return {Boolean}
     */
    hasCallPermission: function() {
      throw new Error('not implemented');
    },

    /**
     * Sends a sms using user's cell phone
     * @param  {string} phone Phone number
     * @param  {string} message SMS message text
     */
    sendSmsTo: function(phone, message) {
      throw new Error('not implemented');
    },

    /**
     * Does HMI has permission to send sms?
     * @return {Boolean}
     */
    hasSmsPermission: function() {
      throw new Error('not implemented');
    },

  });
});