/**
 * A module representing application configuration.
 * Contents of current imported object is skeleton to implementation
 * @module config
 * @example
 * {
 *	// Environment variables
 *	"hupUrl": "http://localhost:9000/",
 *	"gatewayUrl": "https://localhost:7070/",
 *	"commandControlUrl": "http://localhost:6060/hap/api/1.0/commandControl/",
 *	"rootPath":"file:///data/data/abq/hup/",
 *	"homeAppName":"hmihome",
 *	"ajaxSetupOptions" : {...}
 * };
 */
/* jshint unused:false*/
define(function(){
		return {
			"hupUrl": "",
			"gatewayUrl": "",
			"commandControlUrl": "",
			"rootPath":"",
			"homeAppName":"",
			"ajaxSetupOptions" : {}
		};
	}
);
