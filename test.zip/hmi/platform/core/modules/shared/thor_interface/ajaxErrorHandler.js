/* jshint unused:false*/
define(['shared/utils/class'], function (Class) {

	/**
	 * @classdesc AjaxErrorHandler - handle AJAX errors.
	 *
	 * @name AjaxErrorHandler
	 * @constructor
	 * @param {Object} options
	 */
	return Class.extend({
		/**
		 * Handle AJAX error
		 *
		 * @name AjaxErrorHandler#handle
		 * @function
		 * @abstract
		 */
		handle: function(){
			throw new Error('not implemented');
		}
	});

});
