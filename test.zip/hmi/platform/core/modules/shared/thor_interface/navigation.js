/* jshint unused:false*/
define('shared/thor_interface/navigation',['shared/utils/class', 'jquery'], function (Class, $) {
	'use strict';

	/**
	 * @typedef {object} Navigation#DestinationType
	 * @property {string} NONE
	 * @property {string} WAY_POINT_DESTINATION
	 * @property {string} FINAL_DESTINATION
	 * @property {string} DESTINATION_ON_MAP
	 */

	/**
	 * @typedef {object} Navigation#LocationType
	 * @property {string} CURRENT_LOCATION
	 * @property {string} DESTINATION_LOCATION
	 */

	return Class.extend(
		{

			init: function () {
				this.directions = ['n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'];
			},

			/**
			 * Starts navigation using coordinates and address
			 * @param  {number} lat     Latitude coordinate
			 * @param  {number} lon     Longitude coordinate
			 * @param  {string} address Full address of POI
			 */
			start: function (lat, lon, address) {
				throw new Error('not implemented');
			},

			/**
			 * Add waypoint to the map using coordinates and address
			 * @param  {number} lat     Latitude coordinate
			 * @param  {number} lon     Longitude coordinate
			 * @param  {string} address Full address of POI
			 */
			addWaypoint: function (lat, lon, address) {
				throw new Error('not implemented');
			},

			/**
			 * Gets last received location by type.
			 * This method will not request actual coordinates from HU, it will return
			 * already cached results of location coordinates.
			 *
			 * @param {Navigation#DestinationType} type Destination type
			 */
			getLastReceivedLocation: function (type) {
				throw new Error('not implemented');
			},

			/**
			 * Requests current location from the HU
			 * @return {jQuery.Promise} - return value should match type of object {lat: number, lon: number}
			 */
			getCurrentLocation: function () {
				throw new Error('not implemented');
			},

			/**
			 * Requests destination location from the HU
			 * @return {jQuery.Promise} - return value should match type of object {lat: number, lon: number}
			 */
			getDestinationLocation: function () {
				throw new Error('not implemented');
			},

			/**
			 * Requests location form the HU by type
			 * @param {Navigation#LocationType} type Location type
			 * @return {jQuery.Promise} return value should match type of object {lat: number, lon: number}
			 */
			getLocation: function (type) {
				throw new Error('not implemented');
			},

			/**
			 * gets vehicle heading in degrees(from 0 to 315 with step 45)
			 * @return {jQuery.Deferred} Value should be a number: 0(due north), 45(due north-east), 90(due east), 135,
			 * 180 ..., 315
			 */
			getVehicleHeading: function () {
				throw new Error('not implemented');
			},

			/**
			 * Get vehicle's speed in km/h by default
			 *
			 * @param {string} [unit=KMPH] - Unit type, possible values: KMPH, MPH
			 * @return {jQuery.Deferred} Value should be a number
			 */
			getVehicleSpeed: function (unit) {
				throw new Error('not implemented');
			},

			/**
			 * Convertes radians to degress
			 * @param  {number} n Radian to be converted
			 * @return {number}
			 */
			toDeg: function (n) {
				return n * 180 / Math.PI;
			},

			/**
			 * Convertes degress to radians
			 * @param  {number} n Degree to be converted
			 * @return {number}
			 */
			toRad: function (n) {
				return n * Math.PI / 180;
			},

			/**
			 * @return value "M" or "KM"
			 */
			getDistanceUnit: function () {
				throw new Error('not implemented');
			},

			preciseRound: function (num, decimals, toFixed) {
				var sign = num >= 0 ? 1 : -1,
					value;
				value = (Math.round((num * Math.pow(10, decimals)) + (sign * 0.001)) / Math.pow(10, decimals));
				value = (toFixed) ? value.toFixed(decimals) : value;

				return value;
			},

			/**
			 * Calculates bearing between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			getBearing: function (from, to) {
				var dLon = this.toRad(to.lon - from.lon),
					lat1 = this.toRad(from.lat),
					lat2 = this.toRad(to.lat),
					y = Math.sin(dLon) * Math.cos(lat2),
					x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon),
					brng = this.toDeg(Math.atan2(y, x));

				return (brng + 360) % 360;
			},

			/**
			 * Calculates direction between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			calcDirection: function (from, to) {
				var bearing = this.getBearing(from, to),
					dirIndex = Math.round(bearing / 45) % 8;

				return this.directions[dirIndex] || "";
			},

			/**
			 * Calculates distance between two points
			 * @param {object} from First point coordinates
			 * @param {number} [from.lat]
			 * @param {number} [from.lon]
			 * @param {object} to   Second point coordinates
			 * @param {number} [to.lat]
			 * @param {number} [to.lon]
			 * @return {number}
			 */
			calcDistance: function (from, to) {
				var radlat1 = Math.PI * from.lat / 180,
					radlat2 = Math.PI * to.lat / 180,
					theta = from.lon - to.lon,
					radtheta = Math.PI * theta / 180,
					dist;

				dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) *
				Math.cos(radtheta);
				dist = Math.acos(dist);
				dist = dist * 180 / Math.PI;
				dist = dist * 60 * 1.1515;

				return this.preciseRound(dist, 2, false);
			}

		});
});