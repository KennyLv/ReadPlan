/* jshint unused:false*/
define('shared/thor_interface/commandControl',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc CommandControl adapter. Responsible for interaction with third party applications.
	 * Used to send commands to third party applications and handle asynchronous messages from them.
	 *
	 * @name CommandControl
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send command to 3rd-party applications
		 *
		 * @name CommandControl#sendCommand
		 * @function
		 * @abstract
		 *
		 * @param  {object} command - Command to 3rd-party app
		 *
		 * @returns {jQuery.Deferred}
		 */
		sendCommand: function (command) {
			throw new Error('not implemented');
		},

		/**
		 * Bind callback function to async event from 3rd-party applications
		 *
		 * @name CommandControl#onAsyncEvent
		 * @function
		 * @abstract
		 *
		 * @param {Function} callback
		 */
		onAsyncEvent: function () {
			throw new Error('not implemented');
		},

		/**
		 * Terminate all current commands to 3rd-party applications for appName if specified or all current commands
		 * May be used when application changes route or shutting down
		 *
		 * @name CommandControl#abortApplicationCommands
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName] - HMI application name
		 */
		abortApplicationCommands: function(){
			throw new Error('not implemented');
		}
	});
});
