/* jshint unused:false*/
define('shared/thor_interface/transport',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Transport class. Low level private interface used to provide http connection with HUP.
	 * May be used by Choreo, huApi, CommandControl interfaces to send http requests to HUP.
	 *
	 * @name Transport
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send request using current transport options. From application name.
		 * appName also can be used as custom identifier of group of requests.
		 *
		 * @name Transport#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {Object} options
		 * @param {String} appName
		 *
		 * @returns {jqXHR}
		 */
		sendRequest: function() {
			throw new Error('not implemented');
		},

		/**
		 * Aborts all application requests. Or all if no application name specified
		 * May be used when application changes route or shutting down
		 *
		 * @name Transport#abortRequests
		 * @function
		 * @abstract
		 *
		 * @param {String} [appName]
		 */
		abortRequests: function() {
			throw new Error('not implemented');
		}
	});
});
