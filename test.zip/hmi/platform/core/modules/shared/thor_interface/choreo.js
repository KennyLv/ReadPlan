/* jshint unused:false*/
define('shared/thor_interface/choreo',['shared/utils/class'], function (Class) {

	/**
	 * @classdesc Choreo requests adapter. Implements access layer to Choreo API.
	 * Uses Transport as http transport layer abstraction
	 *
	 * @name Choreo
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send request to Choreo API gateway
		 *
		 * @name Choreo#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {object} params
		 * @param {string} params.url
		 * @param {string} [params.method] GET or POST
		 * @param {object} [params.data]
		 *
		 * @returns {jQuery.Deferred}
		 */
		sendRequest: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get image from Choreo proxy
		 *
		 * @name Choreo#sendRequest
		 * @function
		 * @abstract
		 *
		 * @param {object} url
		 *
		 * @returns {jQuery.Deferred}
		 */
		getExternalImageByUrl: function () {
			throw new Error('not implemented');
		},

		/**
		 * Get Choreo request parameters.
		 *
		 * @name Choreo#getParams
		 * @function
		 * @abstract
		 *
		 * @returns {jQuery.Deferred}
		 */
		getParams: function () {
			throw new Error('not implemented');
		},

		/**
		 * Terminate all current requests for appName if specified or all current commands
		 * May be used when application changes route or shutting down
		 *
		 * @name Choreo#abortApplicationRequests
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName] - HMI application name
		 */
		abortApplicationRequests: function(){
			throw new Error('not implemented');
		}
	});
});
