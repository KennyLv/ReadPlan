/* jshint unused:false*/
define(['shared/utils/class'], function (Class) {

	/**
	 * @classdesc HeadUnits control adapter. Implements access layer to HU API.
	 * Used to send commands to HUP and receive notifications from HUP
	 *
	 * @name HuApi
	 * @constructor
	 */
	return Class.extend({

		/**
		 * Send command to HeadUnit API.
		 *
		 * @name HUApi#sendCommand
		 * @function
		 * @abstract
		 *
		 * @param {object} params - Command parameters
		 *
		 * @returns {jQuery.Deferred}
		 */
		sendCommand: function () {
			throw new Error('not implemented');
		},

		/**
		 * Handle notifications from HeadUnit
		 *
		 * @name HUApi#handleNotification
		 * @function
		 * @abstract
		 *
		 * @param {object} notification  - Data, obtained in notifications from HU
		 *
		 * @example
		 * notification {
		 *   appName: "iheartradio",
		 *   type: "KEYBOARD_OK_CLICKED",
		 *   data: {
		 *     cursorIndex: 15,
		 *     text: "HGY65RVGV66ghhu"
		 *   },
		 *   rawData: {}
		 * }
		 */
		handleNotification: function () {
			throw new Error('not implemented');
		},

		/**
		 * Terminate all current commands to HUP for appName if specified or all current commands
		 * May be used when application changes route or shutting down
		 *
		 * @name HUApi#abortApplicationCommands
		 * @function
		 * @abstract
		 *
		 * @param {string} [appName] - HMI application name
		 */
		abortApplicationCommands: function(){
			throw new Error('not implemented');
		}
	});
});
