### Platform description

AQ core library that provide API for communication between HAP, HUP and HMI.

Communication layer between HAP and HMI is native calls to java or objectiveC layers.

HMI code running in android or iOS webView.

---

### How to build
**development build with sourcemaps:**
    `npm install`
    `grunt dev`
    
**production build**
    `npm install`
    `grunt prod`

**how to install/update bower packages**
    `bower install`

**how to build custom jQuery**
    `clone jQuery to libs/jquery`
    `npm install`
    `grunt custom:-attributes,-css,-data,-effects,-manipulation,-sizzle,-traversing,-deprecated,-offset,-selector-native,-selector-sizzle,-wrap`
---

### Templates section

* templates description
---

## AQ public APIs
    require('aq/dic').get('storage'); // (Service to work with a local storage to cache images)
    require('aq/dic').get('display'); // (Service to work with a HU Display or Browser Emulator)
    ...


### display
___

**showLoading** show the loading screen

    display.showLoading(state, text)

**updateScreen** update current screen

    display.updateScreen(template)

**on**  subscribe to soft or hard buttons clicks

    display.on(eventName, callback)


### appManager
___

**switchApp** start new application by name(re-start or start)

    appManager.switchApp(appName)

**closeApp** trying to close application by name, expected to call .close() method of application

    appManager.closeApp(appName)

**suspendApp** trying to suspend application by name, expected to call .suspend() method of application

    appManager.suspendApp(appName)


### storage
___

**saveJSON** store the value to phone memory permanently

    @param data {object|string}
    @param key {string}

    storage.saveJSON(key, data)
    @return promise

**getJSON** get the value from phone memory by key

    storage.getJSON(key, defaultValue)
    @return promise

**addValue** store the value available to internal hash, available only during current session

    @param value {object|string}
    @param type {string}

    storage.addValue(value, type)
    @returns id

**getValue** get previously stored value by id and type

    @param id {number}

    storage.getValue(id, type)
    @returns value

**removeValue**

    storage.removeValue(id, type)
    @returns success or fail
    

### settings
___

**getApplicationList** get the current set of HMI applications support for the current user’s profile.

    settings.getApplicationList()
    @returns promise

**getClientGateway** get the URL and common headers necessary for the Client Gateway

    settings.getClientGateway()
    @returns promise

**ready** notify HAP that JS is ready to process events

    settings.ready()
    

### utils
___

> Collection of useful utils methods:

> **toJSON(object)**, **parseJSON(json)**, **isEqual(a, b)** etc


### Logger
___

Helper that provide logging.
Logs could be sent to the native layer or directly to js console.

    new Logger(level, env, prefix)

>    **level** high, med, low, none

>    **env** 'WEB_VIEW' or 'CONSOLE'

>    **prefix** {string}

**Methods:**

>    **logger.debug(data)**

>    **logger.info(data)**

>    **logger.log(data)**

>    **logger.warn(data)**

>    **logger.error(data)**

>    **logger.setLevel(loggingLevel)**
