/*
 *  Template Template2
 *
 *  The sample JSON:
 *
 *  {
 *    "title": {
 *        "image": "<image id>",
 *        "text": "<title text>"
 *    },
 *    "buttons": {
 *        "1": {
 *            "text": "<optional text>",
 *            "line02": "<optional second line for Template 2>",
 *            "image": {
 *                "normal": "< int image normal optional >" ,
 *                "pressed": "< int button pressed image optional >"
 *            },
 *            "backgroundImage": {
 *                "normal": "< int image normal optional >" ,
 *                "pressed": "< int button pressed image optional >"
 *            },
 *            "scrollUpButton": "< true | false >",
 *            "scrollDownButton": "< true | false >",
 *            "enabled": "< true | false >"
 *        }
 *    }
 *  }
 *
 *  Buttons can be text, image.or both
 *
 *    _______________________________________________
 *   |   title  |                                    |
 *   |-----------------------------------------------|
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_1    | |   but_2    | |   but_3    | |
 *   |  |____________| |____________| |____________| |
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_4    | |   but_5    | |   but_6    | |
 *   |  |____________| |____________| |____________| |
 *   |   ____________   ____________   ____________  |
 *   |  |            | |            | |            | |
 *   |  |   but_7    | |   but_8    | |   but_9    | |
 *   |  |____________| |____________| |____________| |
 *   |_______________________________________________|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        bigButton: {w: 118, h: 51}, // buttons 1 - 9
        button: {w: 72, h: 52}, // button 10
        titleImage: {w: 376, h: 77}
    };

    return Base.extend({

        templateName: 'Template2',

        buttons: _.range(1, 10),

        processTemplate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 9), CONSTANTS.bigButton)
            );


            if (content.title) {
                if (content.title.image) {
                    template.title = {
                        image: this.storage.getImageId({
                            data: content.title.image,
                            w: CONSTANTS.titleImage.w,
                            h: CONSTANTS.titleImage.h
                        })
                    };
                } else {
                    template.title = {
                        text: content.title.text || ''
                    };
                }
            }

            return template;
        }
    });
});