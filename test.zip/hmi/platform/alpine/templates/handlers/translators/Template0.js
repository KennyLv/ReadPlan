/* jshint ignore:start */
/*
 *  Template0
 *
 *  The sample JSON:
 *
 * {
 *     "path": "/hup/api/1.0/ApplicationList",
 *     "Applications": {
 *         "Application": {
 *             "Name": "<Name>",
 *             "Icon": "<Image Id>",
 *             "Type": "<Audio | POI | Social | News | Sports  | Stocks | Navigation | Traffic | Fuel | Parking | SpeedCameras | Weather | Flights | VRTTS | Movies>",
 *             "Languages": [{
 *                     "Language": "<ISO 639 identifier>",
 *                     "Local Name": "<Name>"
 *             }]
 *         }
 *     }
 * }
 *
 */
/* jshint ignore:end */

define(['aq/templates/handlers/translators/base', 'aq/utils'], function (Base) {
    'use strict';

    var CONSTANTS = {
        listItemId: 101
    };

    return Base.extend({

        templateName: 'ApplicationList',


        processTemplate: function (data) {
            var template = {
                    "Applications": {}
                },
                content = data.templateContent;

            var apps = (_.isArray(content.list) ? content.list : []);


            apps.forEach(function (app, key) {
                template.Applications[app.name] = {
                    "Name": app.name,
                    "Icon": this.storage.getImageId({
                        data: app.image1
                    }),
                    "Type": app.category,
                    "Languages": [
                        {
                            // TODO i18n
                            "Language": "en", //<ISO 639 identifier>
                            "Local Name": _.isString(app.text) ? app.text : ""
                        }
                    ]
                };

                //Save list actions
                if (app.action !== undefined || app.value !== undefined) {
                    this.storage.addAction(key + CONSTANTS.listItemId, app.action, app.value);
                }
            }.bind(this));


            return template;
        }
    });
});