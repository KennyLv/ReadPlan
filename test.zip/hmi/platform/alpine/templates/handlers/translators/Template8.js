/*
 * Template Template8
 * Loading screen
 *
 *  The sample JSON:
 *
 *  {
 *      "templateContent" : {
 *          "title": {
 *              "image": <image id>,
 *              "text": <title text>,
 *           },
 *          "text01": "<text 01">,
 *          "img01": <image id>,
 *          "img02": <image id>
 *      }
 *  }
 *
 *
 *
 *    ________________________________________________
 *   |  ____________________________________________  |
 *   | | Image1                                     | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |____________________________________________| |
 *   |________________________________________________|
 *
 *   OR
 *
 *    ________________________________________________
 *   |  ____________________________________________  |
 *   | | Image2                                     | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |                                            | |
 *   | |____________________________________________| |
 *   | |                   text_1                   | |
 *   | |____________________________________________| |
 *   |________________________________________________|
 *
 *
 */


define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        titleImage: {w: 250, h: 45},
        firstImageItem: { w: 478, h: 233},
        secondImageItem: { w: 478, h: 185}
    };

    return Base.extend({

        templateName: 'Template8',

        processTemplate: function (data) {

            var template = {},
                hasText = false,
                content = data.templateContent;

            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            content.main = content.main || {};

            if (content.main.text && content.main.text[1]) {
                template.text = content.main.text[1];
                hasText = true;
            }

            if (content.main.images && content.main.images[1]) {
                if (hasText){
                    template.image2 = this.storage.getImageId(_.extend({
                        data: content.main.images[1]
                    }, CONSTANTS.secondImageItem));
                } else {
                    template.image1 = this.storage.getImageId(_.extend({
                        data:content.main.images[1]
                    }, CONSTANTS.firstImageItem));
                }
            }

            return template;
        }
    });
});
