/*
 *  Template Template1
 *
 *  The sample JSON:
 *
 *   {
 * "title" : {
 * "image" : <image id>,
 * "text" : "<title text>"
 * },
 * "img01" : <image id>,
 * "img02" : <image id>,
 * "buttons" : {
 * "1": {
 * "text" : "<optional text>",
 * "image" : {
 * "normal" : <int image normal optional>,
 * "pressed" : <int button pressed image optional>
 * },
 * "backgroundImage" : {
 * "normal" : <int image normal optional>,
 * "pressed" : <int button pressed image optional>
 * },
 * "scrollUpButton" : <true | false>,           // optional defaults false
 * "scrollDownButton" : <true | false>,       // optional defaults false
 * "enabled" : <true | false>                      // optional defaults true
 * }
 * "2" : {..},
 * ...
 * "6" : {..}
 * "*7" : {..}
 * "*8" : {..}
 * },
 * "text01" : "<text 01">,
 * "text02" : "<text 02">,
 * "text03" : "<text 03">,
 * "text04" : "<text 04">,
 * "progress" : {
 * "color" : <Hex color e.g "#FEFEFE" >,
 * "totalSeconds" : <total seconds>,
 * "current" :           <0.0 to 1.0>,
 * "active" :              <true | false>
 * }
 * }
 *
 *  Buttons 1-6: are of flexible size. HU will resize the button bar based on the total number of buttons.
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  item_1 char limit is 19 (truncated by HU)
 *  item_2 char limit is 19 (truncated by HU)
 *  item_3 char limit is 19 (truncated by HU)
 *
 *    _______________________________________________
 *   |   Title  |                                    |
 *   |-----------------------------------------------|
 *   | ____   _____________                     ____ |
 *   |     | |             |                   |     |
 *   |     | |             |  text_1           |     |
 *   |b_7* | | main_image  |  text_2           |b_8* |
 *   |     | |             |  text_3           |     |
 *   | ____| |             |   _________       |____ |
 *   |       |_____________|  |progress| text_4      |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        // 1 - 6
        stripeButton: {w: 61, h: 52}, // TODO could be dynamic
        // 7, 8
        sideButton: {w: 52, h: 52},

        mainImageItem: { w: 75, h: 75},
        sideImageItem: {w: 25, h: 25},
        titleImage: {w: 324, h: 32}
    };

    return Base.extend({

        templateName: 'Template1',

        buttons: _.range(1, 9),

        processTemplate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = this.getButtons(buttons);

            content.main = content.main || {};
            content.main.text = content.main.text || {};

            var item;
            for (var i = 1; i <= 4; i++) {
                item = content.main.text[i] || {};
                template['text0' + i] = item.text || '';
            }


            var images = this.getImages(content.main.images);
            template.img01 = images[1];
            template.img02 = images[2];

            template.title = {
                image: this.storage.getImageId({
                    data: content.title && content.title.image,
                    w: CONSTANTS.titleImage.w,
                    h: CONSTANTS.titleImage.h
                })
            };

            // progress bar
            template.progress = {};
            if (content.progress && content.progress.total) {
                template.progress = {
                    totalSeconds: content.progress.total,
                    current: content.progress.elapsed / content.progress.total,
                    color: content.progress.color,
                    active: content.progress.active
                };
            }

            return template;
        },

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.stripeButton),
                this.processButtons(this.filterByRange(buttons, 7, 8), CONSTANTS.sideButton)
            );
        },

        getImages: function (templateImages) {
            var images = {};
            templateImages = templateImages || {};

            images[1] = this.storage.getImageId({
                data: templateImages[1],
                w: CONSTANTS.mainImageItem.w,
                h: CONSTANTS.mainImageItem.h
            });

            images[2] =  this.storage.getImageId({
                data: templateImages[2],
                w: CONSTANTS.sideImageItem.w,
                h: CONSTANTS.sideImageItem.h
            });

            return images;
        },


        applyVp2cAlpineMigration: function (data) {
            if (Object.keys(data.templateContent.buttons).length >= 7) {
                var tmpButtons = _.toArray(data.templateContent.buttons);
                tmpButtons.splice(6, 1);
                data.templateContent.buttons = _.object(tmpButtons.map(function (value, key) {
                    return key + 1;
                }), tmpButtons);
            }
            return data;
        }


    });
});