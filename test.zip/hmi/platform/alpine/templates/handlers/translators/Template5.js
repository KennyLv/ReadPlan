/*
 *  Template Template5
 *
 *  The sample JSON:
 *
 * {
 *     "title": {
 *         "image": "<image id>",
 *         "text": "<title text>"
 *     },
 *     "text01": "<text 01>",
 *     "buttons": {
 *         "1": {
 *             "text": "<optional text>",
 *             "image": {
 *                 "normal": "<int image normal optional>",
 *                 "pressed": "<int button pressed image optional>"
 *             },
 *             "backgroundImage": {
 *                 "normal": "<int image normal optional>",
 *                 "pressed": "<int button pressed image optional>"
 *             }
 *         },
 *         "2":{...},
 *         "6":{...}
 *     }
 * }
 *
 *  Buttons can be text, image.or both.
 *
 *    _______________________________________________
 *   |   Title  |                                    |
 *   |-----------------------------------------------|
 *   |                                               |
 *   |                                               |
 *   |                                               |
 *   |                    <text01>                   |
 *   |                                               |
 *   |                                               |
 *   |                                               |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';

    var CONSTANTS = {
        button: {w: 76, h: 60},
        titleImage: {w: 250, h: 45}
    };

    return Base.extend({

        templateName: 'Template5',

        //maximum 6 buttons
        buttons: _.range(1, 7),

        processTemplate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), CONSTANTS.button)
            );


            template.text01 = content.text || '';

            if (content.title) {
                if (content.title.image) {
                    template.title = {
                        image: this.storage.getImageId({
                            data: content.title.image,
                            w: CONSTANTS.titleImage.w,
                            h: CONSTANTS.titleImage.h
                        })
                    };
                } else {
                    template.title = {
                        text: content.title.text || ''
                    };
                }
            }

            return template;
        }
    });
});