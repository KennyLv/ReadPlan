/*
 *  Template Template6
 *
 *  The sample JSON:
 * {
 *     "title": {
 *         "image": "< image id >",
 *         "text": "<title text>"
 *     },
 *     "line02": {
 *         "text": "<text>",
 *         "image": "< image id >"
 *     },
 *     "img01": "< image id >" ,
 *     "text01": "<text 01>",
 *     "text03": "<text 03>",
 *     "buttons": {
 *         "1": {
 *             "text": "<optional text>",
 *             "image": {
 *                 "normal": "< int image normal optional >" ,
 *                 "pressed": "< int button pressed image optional >""
 *             },
 *             "backgroundImage": {
 *                 "normal": "< int image normal optional >" ,
 *                 "pressed": "< int button pressed image optional >"
 *             }
 *         },
 *         "2": "{..}",
 *         "6": "{..}"
 *     }
 * }
 *
 *  Buttons can be text, image or both
 *
 *    _______________________________________________
 *   |   Title  |                                    |
 *   |-----------------------------------------------|
 *   |   ________                                    |
 *   |  |       |    <text01>                        |
 *   |  | img01 |    <line02>                        |
 *   |  |_______|    ______________________________  |
 *   |              |                              | |
 *   |              |        <text03>              | |
 *   |              |______________________________| |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 *
 */

define(['aq/templates/handlers/translators/base'], function (Base) {
    'use strict';


    return Base.extend({
        CONSTANTS: {
            // 1 - 6
            stripeButton: {w: 76, h: 60},

            mainImage: {w: 80, h: 80},
            line02Image: {w: 378, h: 22},
            titleImage: {w: 250, h: 45}
        },

        templateName: 'Template6',

        buttons: _.range(1, 7),

        processTemplate: function (data) {
            var template = {},
                content = data.templateContent;

            var buttons = content.buttons;
            template.buttons = _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), this.CONSTANTS.button)
            );


            template.text01 = content.text01 || '';
            template.line02 = {
                text: content.line02.text || '',
                image: content.line02.image ? this.storage.getImageId({
                    data: content.line02.image,
                    w: this.CONSTANTS.line02Image.w,
                    h: this.CONSTANTS.line02Image.h
                }) : 0
            };
            template.text03 = content.text03 || '';

            template.img01 = content.img01 ? this.storage.getImageId({
                data: content.img01,
                w: this.CONSTANTS.mainImage.w,
                h: this.CONSTANTS.mainImage.h
            }) : 0;


            //TODO check, could title has both image and text data
            if (content.title) {
                if (content.title.image) {
                    template.title = {
                        image: this.storage.getImageId({
                            data: content.title.image,
                            w: this.CONSTANTS.titleImage.w,
                            h: this.CONSTANTS.titleImage.h
                        })
                    };
                } else {
                    template.title = {
                        text: content.title.text || ''
                    };
                }
            } else {
                template.title = {
                    text: '',
                    image: 0
                };
            }

            return template;
        },

        getButtons: function (buttons) {
            return _.extend({},
                this.processButtons(this.filterByRange(buttons, 1, 6), this.CONSTANTS.stripeButton)
            );
        }
    });
});