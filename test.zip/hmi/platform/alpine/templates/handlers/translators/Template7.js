/*
 *  Template Template7
 *
 *  The sample JSON:
 * {
 *     "title": {
 *         "image": "< image id >",
 *         "text": "<title text>"
 *     },
 *     "line02": {
 *         "text": "<text>",
 *         "image": "< image id >"
 *     },
 *     "img01": "< image id >" ,
 *     "text01": "<text 01>",
 *     "text03": "<text 03>",
 *     "buttons": {
 *         "1": {
 *             "text": "<optional text>",
 *             "image": {
 *                 "normal": "< int image normal optional >" ,
 *                 "pressed": "< int button pressed image optional >""
 *             },
 *             "backgroundImage": {
 *                 "normal": "< int image normal optional >" ,
 *                 "pressed": "< int button pressed image optional >"
 *             }
 *         },
 *         "2": "{..}",
 *         "6": "{..}"
 *     }
 * }
 *
 *  Buttons can be text, image or both
 *
 *    _______________________________________________
 *   |   Title  |                                    |
 *   |-----------------------------------------------|
 *   |  ____________                                 |
 *   | |           |    <text0                       |
 *   | |           |    <line0                       |
 *   | |           |    ___________________________  |
 *   | |   img01   |   |                           | |
 *   | |           |   |        <text03>           | |
 *   | |___________|   |___________________________| |
 *   |_______________________________________________|
 *   | but_1 | but_2 | but_3 | but_4 | but_5 | but_6 |
 *   |_______|_______|_______|_______|_______|_______|
 *
 *
 */

define(['aq/templates/handlers/translators/Template6'], function (Template6) {
    'use strict';

    return Template6.extend({
        templateName: 'Template7',
        CONSTANTS: {
            // 1 - 6
            stripeButton: {w: 76, h: 60},

            mainImage: {w: 80, h: 80},
            line02Image: {w: 378, h: 22},
            titleImage: {w: 250, h: 45}
        }
    });
});