/*
 *  Template VP2C-3
 *
 *  The sample JSON:
 *
 *  {
 *      "templateId" : "VP2C-3",
 *      "templateContent" : {
 *          "title" : {
 *              "text": <string>
 *          },
 *          "buttons" : {
 *              "1": {
 *                  "image": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "backgroundImage": {
 *                      "normal": <number>,
 *                      "pressed": <number>
 *                  },
 *                  "scrollUp": <boolean>,
 *                  "scrollDown": <boolean>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              },
 *              ... 10
 *          },
 *          "list": {
 *              "activeListItem" : <int>, //index in the array of the element to be highlighted. Defaults to null.
 *              "items": [{
 *                  "image1": <number>,
 *                  "image2": <number>,
 *                  "text": <string>,
 *                  "action": <string>,
 *                  "value": <string>
 *              }, ...]
 *          }
 *      }
 *  }
 *
 *  Buttons can be either text or an image. Cannot be both.
 *
 *  Text char limit in list is 16 (truncated by HU)
 *  Title char limit is 16
 *
 *   ________________________________________________
 *  | _____   |         title                   |    |
 *  ||b_200|  |---------------------------------| /\ |
 *  ||_____|  |                                 |    |
 *  |         | img1 | text              | img2 |    |
 *  | _____   |                                 |    |
 *  || b_2 |  | img1 | text              | img2 |    |
 *  ||_____|  |                                 |    |
 *  | _____   | img1 | text              | img2 |    |
 *  || b_1 |  |                                 |    |
 *  ||_____|  | img1 | text              | img2 | \/ |
 *  |_________|_________________________________|____|
 *
 */

define(['aq/templates/handlers/translators/base', 'aq/utils'], function (Base, utils) {
    'use strict';

    var CONSTANTS = {
        titleItemsLimit: 20,
        titleCharLimit: 16,
        itemIconSize: {w: 32, h: 32},
        buttonSize: {w: 72, h: 52},
        listItemId: 101
    };

    return Base.extend({

        templateName: 'Template3',

        buttons: _.range(1, 7),

        processTemplate: function (data) {
            var template = {},
                content = data.templateContent;

            var title = _.isUndefined(content.title) ? '' : (content.title.text || content.title);
            template.title = {
                text: utils.ellipsis(title, CONSTANTS.titleCharLimit)
            };

            var items = content.list.items || (_.isArray(content.list) ? content.list : []);
            template.list = {
                activeListItem: _.isNumber(content.list && content.list.activeListItem) ?
                    content.list.activeListItem : null,
                items: this.processListItems(items)
            };

            // 1 - 9
            template.buttons = this.processButtons(content.buttons, CONSTANTS.buttonSize);

            return template;
        },

        processListItems: function (content) {
            var list = [];
            content = _.isArray(content) ? content : [];

            content.forEach(function (listItem, key) {
                //we have to remove unnecessary items
                if ((key + 1) > CONSTANTS.titleItemsLimit){
                    return false;
                }

                var item = {};

                var leftImage = listItem.image || listItem.image1,
                    rightImage =  listItem.image2;


                item.image1 = this.storage.getImageId({
                    data: leftImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.image2 = this.storage.getImageId({
                    data: rightImage,
                    w: CONSTANTS.itemIconSize.w,
                    h: CONSTANTS.itemIconSize.h
                });

                item.text = _.isString(listItem.text) ? listItem.text : "";

                //Save list actions
                if (listItem.action !== undefined || listItem.value !== undefined) {
                    this.storage.addAction(key + CONSTANTS.listItemId, listItem.action, listItem.value);
                }

                list.push(item);

            }, this);

            return list;
        }

    });
});