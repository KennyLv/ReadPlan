/**
 * Partial update can be applicable for the templates with the same type and with at least one the same element.
 *
 * Diff for partial update should be calculated using following rules:
 *
 * Buttons:
 *  If the button parameter is missing, then assume that it has not been changed.
 *  If the button parameter is an empty JSON {}, then assume that it has been removed.
 *  If the button parameter is a valid JSON with new values, then assume that it has been updated.
 *
 * Text:
 *  If the text parameter is missing, then assume that it has not been changed.
 *  If the text value is an empty string, then assume that it has been removed and display the empty string.
 *  If the text value is a valid string, then assume that it has been updated and display the provided string.
 *
 * Images:
 *  If the image key parameter is missing, then assume that it has not been changed.
 *  If the image id is 0, then assume that it has been removed
 *  and display an empty placeholder/image (remove the image if it was populated previously).
 *  If the image id is >0, then assume that it has been updated and display the given image.
 *
 * List:
 *  If the list parameter is missing, then assume that it has not been changed.
 *  If the list parameter value is an empty array, then assume that it has been updated and display an empty list.
 *  If the list parameter value is a valid array of JSONs,
 *  then assume that it has been updated and display the updated list.
 */

define(['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        init: function (cf) {
            this.cf = cf;
        },

        translate: function (template) {
            var appID = template.appID,
                templateId = template.templateId,
                id = appID + ':' + templateId,
                cf = this.cf,
                self = this;

            var originalTpl = $.extend(true, {}, template.templateContent),
                requestedToDisplayTpl = template.templateContent,
                displayingTpl = cf.cache.LastUpdate && cf.cache.LastUpdate.template;

            template.partialUpdate = false;

            if (this.isPartialUpdateApplicable(id)) {

                var walk = function walk (next, current) {
                    _.each(next, function (nextItem, key) {
                        //if (cf.expand[key] && _.isObject(item) && _.isObject(current[key])) {
                        if (cf.expand[key] && _.isObject(nextItem) && _.isObject(current[key])) {
                            walk(nextItem, current[key]);
                        } else {
                            // if currently displayed template has this element
                            if (current[key]) {
                                // and this element is the same as in requested to display template
                                if (self.isEqual(current[key], nextItem)) {
                                    // remove this element and set partial update flag
                                    delete next[key];
                                    template.partialUpdate = true;
                                    template.loadingType = 3;
                                }
                            }
                        }
                    });
                };

                // walk through template and remove elements that has not changed
                walk(requestedToDisplayTpl, displayingTpl);
            }

            // store requested to display template for further use
            cf.cache.LastUpdate = {
                id: id,
                template: originalTpl
            };

            return template;
        },

        /**
         * Apply partial update only when we are trying to render
         * template with the same id more than once
         *
         * @param id {String}
         * @returns {boolean}
         */
        isPartialUpdateApplicable: function (id) {
            var lastUpdate = this.cf.cache.LastUpdate || {};
            return _.isObject(lastUpdate.template) && lastUpdate.id === id;
        },

        isEqual: function (a, b) {
            return JSON.stringify(a) === JSON.stringify(b);
        }
    });

});