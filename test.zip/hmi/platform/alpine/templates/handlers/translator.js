define(['shared/utils/class',
        'aq/templates/handlers/translators/Template0',
        'aq/templates/handlers/translators/Template1',
        'aq/templates/handlers/translators/Template2',
        'aq/templates/handlers/translators/Template3',
        'aq/templates/handlers/translators/Template5',
        'aq/templates/handlers/translators/Template6',
        'aq/templates/handlers/translators/Template7',
        'aq/templates/handlers/translators/Template8'
    ],
    function (Class) {
    'use strict';

    var templates = Array.prototype.slice.call(arguments, 1),
        screenID = 1,
        templatesMap = {
            'vp2c-2':'Template1',
            'vp2c-3':'Template3',
            'vp2c-8':'Template8'
        };

    return Class.extend({

        init: function (storage, appManager) {
            this.appManager = appManager;
            this.storage = storage;
            this.templateTypes = {};
            _.each(templates, function (Template) {
                var tpl = new Template(storage);
                this.templateTypes[tpl.templateName.toLowerCase()] = tpl;
            }, this);
        },

        translate: function (data) {
            //Clear the actions map
            this.storage.clearActions();

            var OEMAppId = 0x9999;
            data.appID = parseInt(this.appManager.getActiveAppId(), 10) || OEMAppId;
            data.screenID = screenID++;

            /** Loading type:
             *   * 1 - show loading screen while populating the screen;
             *         hide loading once everything is loaded including images.
             *   * 2 - show loading while loading text, and hide it;
             *         Images will be displayed dynamically as downloaded.
             *   * 3 - do not show loading animation during screen transition.
             */
            data.loadingType = _.contains([1,2,3], data.loadingType) ? data.loadingType : 1;

            data.systemHeader = !!data.systemHeader;

            data.backgroundImage = this.storage.getImageId({
                data: data.backgroundImage,
                w: 400,
                h: 240
            });

            //use templates names from VP2C
            var templateId = data.templateId;
            if (templatesMap[templateId]){
                templateId = templatesMap[templateId];
                //patch object
                data.templateId = templateId;
            }

            var template = this.templateTypes[templateId.toLowerCase()];

            return template ? template.translate(data) : null;
        }
    });
});