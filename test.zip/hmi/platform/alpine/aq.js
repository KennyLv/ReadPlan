/**
 *
 */
define(function () {
    'use strict';

    /*jshint ignore:start*/

    var platformServices = require('aq/dic'),
        alpineServices = require('alpine/dic');

    //TODO aazarov: we should fix this workaround immediately
    //patch platform/core/src/api/hu/screen.js
    var screen = platformServices.get('screen');
    screen.updateScreen = function (data) {
        var content = {
            "type": "screenUpdate",
            "data": data
        };

        return this._transport.sendRequest({
            //TODO temporary solution: @see transport#_onSendRequest
            "target": "hup",
            "path": data.templateId,
            "headers": {
                "Content-Type": "application/json",
                "Content-Length": encodeURI(JSON.stringify(content)).split(/%..|./).length - 1
            },
            "method": "POST",
            "content": content
        });
    };

    //require('aq/kpi').init(platformServices);
    require('jsperanto');

    var commonLogger = new (platformServices.get('Logger'))('med', 'WEB_VIEW', 'CORE');
    window.onerror = function (errorMsg, url, lineNumber, columnNumber, error) {
        commonLogger.error("[HMI][ERROR]: "+ url +" line "+ lineNumber +": "+ errorMsg);
        if (error) {
            commonLogger.error("[HMI][ERROR][TRACE]: " + error.stack);
        }
    };

    commonLogger.log({
        msg: 'HMI CORE initialized',
        version: 'Version: <VERSION>'
    });

    // WARNING: creation order is important!
    var images = platformServices.create('images'), // cache images
        appManager = platformServices.create('appManager'),
        appList = alpineServices.create('appList');

    // request available applications
    // and notify HAP that HMI is ready to process messages
    appList.profile.ready();

    /*jshint ignore:end*/
});
