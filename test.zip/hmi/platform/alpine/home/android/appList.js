define(['alpine/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        events: {
            start: 'start'
        },


        init: function (options) {
            this._super(options);
            this.getAvailableApps().done(this.startApplicationBy.bind(this));

            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.startApp(_.invert(this.constants.APP_NAME_MAP)[handsetAppName]);
            }.bind(this));

            return this;
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                var app = data.value || {};

                //avoid reporting for template suite
                if (app.appCategory === 'Music') {
                    this.writeReport(app.appName);
                }
                this.startApp(app.appName, app.appCategory);
            });
        },

        onAppModeStateChange: function () {
            // re-render home screen because HU just started or resumed from another screen
            // todo should we render home screen when HU focus is lost?
            this.display.resetScreen();
            this.renderHomeScreen();
        },

        startApplicationBy: function () {
            this.appManager.suspendApp();
            this.renderHomeScreen.apply(this, arguments);
        },

        goToHomeScreen: function () {
            this.renderHomeScreen.apply(this, arguments);
        }
    });
});
