/**
 * TODO rewrite this module later
 * iOS appList modules responsible for appLaunch and appContainer switching
 */

define(['alpine/home/appList'], function (AppList) {
    'use strict';

    return AppList.extend({

        // TODO move to constants
        homeApplicationContainerName: 'uconnect',

        init: function (options) {
            var display = options.display;
            display.showLoading();

            this.appContainer = options.appContainer;
            this._super(options);

            // todo iOS related workaround
            // todo if AQ was updated and page get refreshed
            // todo hap doesn't send any notifications
            // todo so we need to start application / render home screen manually
            _.delay(function () {
                if (_.isEmpty(display.getCurrentTemplate()) && !this.profileSyncInProgress) {
                    this.startApplicationByCurrentContainerName();
                }
            }.bind(this), 1000);

            this.vr.on(this.vr.events.vrAppLaunch, function (response) {
                var handsetAppName = response.launchName;
                this.switchApplicationContainerTo(null, handsetAppName);
            }.bind(this));

            return this;
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.display, this.events.start, function (data) {
                this.switchApplicationContainerTo(data.value.appName);
            });
        },

        /**
         *
         * @param state {String} state === 'start' || state === 'resume' || state === 'exit'
         */
        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state;
            if (state === 'start' && !this.profileSyncInProgress) {
                this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen before ready: ': state});
                // ready will trigger profile sync or not trigger (iOS only)
                this.profile.ready();
            }
            this.logger.log({'onAppModeStateChangeInIosBeforeRenderHomeScreen: ': state});
            // render home screen(and switch to oem branded app) because HU lost focus (the user clicks the apps button)
            if (state === 'exit') {
                this.logger.log({'onAppModeStateChangeInIos ': state});
                this.display.showLoading();
                this.goToHomeScreen();
            }
        },

        startApplicationBy: function () {
            this.startApplicationByCurrentContainerName();
        },

        /**
         * Switch to OEM app or just show homeScreen
         */
        goToHomeScreen: function () {
            this.logger.log({'goToHomeScreen': 'goToHomeScreen'});

            this.appContainer.getApplicationContainerName().done(function (containerName) {
                if (containerName === this.homeApplicationContainerName) {
                    this.display.resetScreen();
                    this.renderHomeScreen();
                } else {
                    this.switchApplicationContainerTo(null, this.homeApplicationContainerName);
                }
            }.bind(this));
        },

        renderHomeScreen: function () {
            this.getAvailableApps().done(function () {
                this._super();
            }.bind(this));
        },

        /**
         * @param appName
         * @param handsetAppName
         */
        switchApplicationContainerTo: function (appName, handsetAppName) {
            var appNameMap = this.constants.APP_NAME_MAP;

            appName = appName || _.invert(appNameMap)[handsetAppName];
            handsetAppName = handsetAppName || appNameMap[appName];

            if (handsetAppName !== this.homeApplicationContainerName) {
                this.writeReport(appName);
            }

            // if handsetAppName defined - we need to switch to this smartphone app
            if (handsetAppName) {
                this.logger.log({'switchApplicationContainerTo': handsetAppName});
                this.appContainer.sendAppSwitchEvent().done(function () {
                    this.logger.log({"ApplicationSwitchEvent to HU ": "ApplicationSwitchEvent to HU" });
                    this.appContainer.switchApplicationContainerTo(handsetAppName);
                }.bind(this));
            } else {
                this.logger.log({'no handset app name': "no handset"});
                this.logger.log({'app name': "app name"});

                this.startApp(appName);
            }
        },

        /**
         * If we in OEM app - just show appList,
         * otherwise show loading and switch to needed container
         *
         * Invoked:
         *  - on profile sync complete
         */
        startApplicationByCurrentContainerName: function () {
            var appNameMap = _.invert(this.constants.APP_NAME_MAP);
            this.logger.log({'startApplicationByCurrentContainerName': ''});

            this.appContainer.getApplicationContainerName().done(function (containerName) {

                this.logger.log({'startApplicationByCurrentContainerName': containerName});

                this.display.resetScreen();

                if (containerName === this.homeApplicationContainerName) {
                    this.logger.log({'renderHomeScreen': 'render apps list'});
                    this.renderHomeScreen();
                } else {
                    this.logger.log({'startApp': appNameMap[containerName]});
                    this.startApp(appNameMap[containerName]);
                }

            }.bind(this));
        }

    });
});
