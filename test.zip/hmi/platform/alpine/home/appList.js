define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        events: {
            start: 'start'
        },

        init: function (options) {
            this.constants = options.constants;
            this.vr = options.vr;
            this.appManager = options.appManager;
            this.profile = options.profile;
            this.display = options.display;
            this.logger = new options.Logger('high', 'WEB_VIEW', 'APP_LIST');
            this.fileManager = options.fileManager;

            /**
             * [{
             *   appName: {string},
             *   appDisplayName: {string},
             *   appCategory: {string},
             *   appPath: {string}
             * }, ...]
             *
             */
            this.applications = [];
            this.needToRestart = false;

            this.profile.on(this.profile.events.profileStateChange, this.onProfileSyncStart, this);
            this.profile.on(this.profile.events.appModeStateChange, this.onAppModeStateChange, this);

            this.appManager.on(this.appManager.events.showHomeScreen, this.showHomeScreen, this);

            this.profile.ready();
        },

        showHomeScreen: function (fetchAppList) {
            this.getAvailableApps(fetchAppList)
                .done(this.goToHomeScreen.bind(this));
        },

        startApplicationBy: function () {
            throw new Error('Abstract method');
        },

        goToHomeScreen: function () {
            throw new Error('Abstract method');
        },

        getAvailableApps: function (force) {
            return _.isEmpty(this.applications) || force ?
                this.profile.getApplicationList().done(this.saveAvailableApps.bind(this)) :
                $.when(this.applications);
        },

        saveAvailableApps: function (apps) {
            apps = _.isArray(apps) ? apps : [];
            this.applications = apps.map(function (item) {
                item.appName = item.appName ? item.appName.toLowerCase() : '';
                return item;
            });
            this.vr.setVrAppLaunchByListOfApps(this.applications);
        },

        startApp: function (appName, appCategory) {
            this.logger.log({'start::app': appName});

            this.stopListening();
            this.appManager.switchApp(appName, appCategory);

            this.logger.log({'started::app': appName});
        },

        onAppModeStateChange: function (response) {
            var state = response && response.data && response.data.state;
            this.logger.log({'onAppModeStateChange': state});

            if (response.data.state === 'start' && !_.isEmpty(this.applications)) {
                this.vr.setVrAppLaunchByListOfApps(this.applications);
            }
            this._super(state);
        },

        onProfileSyncStart: function (response) {
            var content = response.data || {},
                profileSyncStatus = content.state;

            this.logger.log({'onProfileSyncStart': content});

            this.profileSyncInProgress = true;

            switch (profileSyncStatus) {
            case "start":
                // todo what should we do when profile sync is started?
                break;

            case "inProgress":
                // todo need to put "aq" to constants
                // if host lib (AQ) updated - need to reload the page
                if (_.findWhere(content.updatingApps, {appName: 'aq'}) ||
                    _.findWhere(content.newApps, {appName: 'aq'})) {
                    this.needToRestart = true;
                    break;
                }

                // destroy applications that were loaded previously because of new version is available
                if (!_.isEmpty(content.updatingApps)) {
                    _.each(content.updatingApps, function (app) {
                        this.logger.log({'app:destroyed': app.appName});
                        this.appManager.destroyApp(app.appName.toLowerCase());
                    }, this);
                }
                break;

            case "complete":
                if (this.needToRestart) {
                    this.logger.log('[HMI][Re-Initialize][Refresh]');
                    window.location.reload();
                    break;
                }

                this.profileSyncInProgress = false;
                this.saveAvailableApps(content.availableApps);
                this.startApplicationBy();
                break;

            default:
                // todo if something get wrong - trigger profile sync again
            }
        },

        renderHomeScreen: function (apps) {
            console.log(apps);
            apps = apps || this.applications;
            var template = this._getHomeTemplate();
            _.each(apps, function (app) {

                // TODO manually filter out aq from appList
                if (app.appName !== 'aq') {
                    template.templateContent.list.push({
                        action: this.events.start,
                        value: app,
                        name: app.appName,
                        //TODO verify from where category should come
                        category: app.appCategory,
                        text: app.appDisplayName || '',
                        image1: 'file:///aq/images/' + app.appName.toLowerCase() + '.png'
                    });
                }
            }, this);
            this.display.updateScreen(template);
            this.startListening();
        },


        /**
         * save first use data if every time application is used
         * do not save data if app runs twice and more times in a row
         * @param app - application that was clicked on appList
         */
        writeReport: function (appName) {
            var appData = this.appManager.apps[appName];
            if (((!appData || appData.status !== this.constants.APP_STATUS.SUSPENDED)&&
                this.fileManager.reportIsReady())) {
                this.logger.log({'Ready to write first use data: ': appName});
                this.fileManager.writeReport(this.constants.APP_NAME_MAP[appName]);
            }
        },

        _getHomeTemplate: function () {
            return {
                templateId: 'ApplicationList',
                loadingType: 3,
                templateContent: {
                    list: []
                }
            };
        }

    });
});
