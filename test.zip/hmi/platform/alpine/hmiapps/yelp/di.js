define(function () {
    'use strict';

    var Dic = require('aq/di'),
        aq = require('aq/dic');

    return new Dic({
        'config': {
            module: require('yelp/config')
        },
        'backend': function () {
            var BackendModel = require('yelp/models/backend');
            if (!this.registry.backendModel) {
                this.registry.backendModel = new BackendModel(
                    this.get('choreo'),
                    this.get('navigation'),
                    this.get('config')
                );
            }

            return this.registry.backendModel;
        },
        'navigation': function () {
            return aq.get('navigation');
        },
        'choreo': function () {
            var Choreo = require('aq/api/choreo');

            if (!this.registry.choreo) {
                this.registry.choreo = new Choreo(
                    aq.get('transport'),
                    aq.get('profile')
                );
            }

            return this.registry.choreo;
        },
        'router': function () {
            var Router = require('yelp/router');

            if (!this.registry.router) {
                this.registry.router = new Router({
                    dic: this,
                    backend: this.get('backend'),
                    homeMenu: this.get('controller/homeMenu')
                });
            }

            return this.registry.router;
        },
        'controller/homeMenu': function () {
            var HomeMenu = require('yelp/controllers/homeMenu');
            return (this.registry['controller/homeMenu'] = new HomeMenu({
                homeMenu: this.get('views/homeMenu')
            }));
        },
        'controller/searchResults': function () {
            var SearchResults = require('yelp/controllers/searchResults');
            return (this.registry['controller/searchResults'] = new SearchResults({
                backend: this.get('backend'),
                view: this.get('views/searchResults'),
                appState: this.get('config')
            }));
        },
        'controller/categories': function () {
            var Categories = require('yelp/controllers/categories');
            return (this.registry['controller/categories'] = new Categories({
                config: this.get('config'),
                view: this.get('views/categories')
            }));
        },
        'controller/search': function () {
            var Search = require('yelp/controllers/search');
            return (this.registry['controller/search'] = new Search({
                view: this.get('views/search')
            }));
        },
        'controller/setLocation': function () {
            var SetLocation = require('yelp/controllers/setLocation');
            return (this.registry['controller/setLocation'] = new SetLocation({
                backend: this.get('backend'),
                view: this.get('views/setLocation'),
                appState: this.get('config')
            }));
        },
        'controller/details': function () {
            var Details = require('yelp/controllers/details');
            return (this.registry['controller/details'] = new Details({
                view: this.get('views/details'),
                appState: this.get('config')
            }));
        },
        'views/homeMenu': function () {
            var HomeMenu = require('yelp/views/homeMenu');
            return (this.registry['views/homeMenu'] = new HomeMenu(aq.get('display')));
        },
        'views/searchResults': function () {
            var SearchResults = require('yelp/views/searchResults');
            return (this.registry['views/searchResults'] = new SearchResults(aq.get('display'), this.get('choreo')));
        },
        'views/categories': function () {
            var SearchResults = require('yelp/views/categories');
            return (this.registry['views/categories'] = new SearchResults(aq.get('display')));
        },
        'views/search': function () {
            var SearchView = require('yelp/views/search');
            return (this.registry['views/search'] = new SearchView(aq.get('display')));
        },
        'views/setLocation': function () {
            var SetLocationView = require('yelp/views/setLocation');
            return (this.registry['views/setLocation'] = new SetLocationView(aq.get('display')));
        },
        'views/details': function () {
            var DetailsView = require('yelp/views/details');
            return (this.registry['views/details'] = new DetailsView(aq.get('display')));
        }
    });
});