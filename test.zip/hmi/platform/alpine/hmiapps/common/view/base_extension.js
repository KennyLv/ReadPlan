// TODO: Put an extension define block herefor view/base.js here with all platform specific overwrites
define(['aq/eventEmitter'], function (EventEmitter) {
    return EventEmitter;
});