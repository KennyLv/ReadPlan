define(function () {
    "use strict";

    // TODO: Put correct sizes of buttons
    return {
        buttonsBranding: {
            'Template0': {},
            'Template1': {},
            'Template2': {},
            'Template3': {},
            'Template4': {},
            'Template5': {},
            'Template6': {},
            'Template7': {},
            'Template8': {},
            path: '/images/buttons/pressed/'
        }
    };
});
