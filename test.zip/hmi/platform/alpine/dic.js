/**
 * Dependency injection container
 */
define(function () {
    'use strict';

    var Dic = require('aq/di'),
        platformServices = require('aq/dic');
    
    return new Dic({
        appList: function () {
            var utils = platformServices.get('utils'),
                AppList = utils.getPlatform() === 'ios' ? require('alpine/home/ios/appList') :
                    require('alpine/home/android/appList');

            platformServices.registry.appList = new AppList({
                appManager: platformServices.get('appManager'),
                profile: platformServices.get('profile'),
                display: platformServices.get('display'),
                appContainer: platformServices.get('appContainer'),
                constants: platformServices.get('constants'),
                vr: platformServices.get('vr'),
                Logger: platformServices.get('Logger'),
                fileManager: platformServices.get('fileManager')
            });

            return platformServices.registry.appList;
        }
    });
});
