module.exports = function (config) {
    "use strict";
    
    config.set({
        basePath: './',
        singleRun: true,
        colors: true,
        logLevel: config.LOG_INFO,
        
        // WARN: Order of framework matters!!! @see https://github.com/xdissent/karma-chai/issues/5
        frameworks: ['requirejs', 'mocha', 'sinon-chai'],
        
        client: {
            mocha: {
                ui: 'bdd'
            }
        },
        
        browsers: ['PhantomJS'],

        preprocessors: {
            // source files, that you wanna generate coverage for
            // do not include tests or libraries
            // (these files will be instrumented by Istanbul)
            '**/src/**/*.js': ['coverage']
        },

        reporters: ['progress', 'junit', 'coverage'],

        // optionally, configure the reporter
        junitReporter: {
            outputFile: "reports/test-results.xml"
        },
        coverageReporter: {
            reporters: [
                {type: 'html', dir: './reports/coverage/'},
                {type: 'cobertura'} // jenkins format
                //{type: 'teamcity'} // teamcity format
            ]
        }
    });
};
