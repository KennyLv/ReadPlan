# HMI Applications Overview

HMI Apps (Human Mobile Interface) is a set of applications which run on Mobile Handset.
  
___

### Start development

Clone project from the gitlab repository:
    > git clone --recursive git@agile.airbiquity.com:hmi/vp2c-hmiapps.git

### Building with Grunt

    // install project decencies
    npm install

    // development build
    grunt dev

    // production build
    grunt release

### Builds from jenkins

    - stable http://jen3.airbiquity.com:8080/view/VP2C%20HMI/job/vp2c_hmi_stable/
    - dev http://jen3.airbiquity.com:8080/view/VP2C%20HMI/job/vp2c_hmi_dev/



## HMI Application Tree Structure
___

Each HMI Application has to have such directory and files:
>  /application_root_dir  
>      |--resources (static resources like images, json files)  
>      |--metadata (data describing application)  


## HMI Application Principles
___

Each application is actually is a stack of views. Only one view could be shown to the user at the moment. 
It is like developing application for Android - almost same principles applied to Views stack and View lifecycle.

### View lifecycle

1. Init - called when the View instance is created for the very first time
2. Start - called when View has been just created or restored back from views stack
3. Suspend - called when current View is being put into views stack when user triggers "next action" thus next screen 
4. Close - called when user presses "Back" button in current View.
   Current View will be closed and the topmost View from the stack will pop up and render itself to the user.

