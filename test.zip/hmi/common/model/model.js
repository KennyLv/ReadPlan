define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        _data: {},

        init: function(options) {
            options = options || {};
            this._data = options.data || {};
        },

        /**
         *
         * @param key - object or string
         * @param val - object or primitive value
         * @returns boolean
         * @private
         */
        _equals: function (key, val) {
            if (_.isObject(key)) {
                return this._objectComparator(key, this._data);
            } else {
                return _.isEqual(this._data[key], val);
            }
        },

        /**
         *
         * @param obj1
         * @param obj2
         * @returns boolean
         * @private
         */
        _objectComparator: function (obj1, obj2) {
            return _.isUndefined(_.find(obj1, function(attr, key) {
                if (_.isObject(attr) && obj2[key]) {
                    return !_.isUndefined(this._objectComparator(attr, obj2[key]));
                } else if (_.isObject(attr)) {
                    return true;
                } else {
                    return attr !== obj2[key];
                }
            }, this));
        },

        /**
         *
         * @param key - string or object
         * @param val - string or object (available only if key is string)
         * @explanation it is possible to set:
         *      - object set({key1: "val1", key2: "val2"}),
         *      - object set("key", {key1: "val1", key2: "val2"}),
         *      - primitive value set("key", primitiveValue)
         */
        set: function (key, val) {
            if (this._equals(key, val)) {
                return;
            }
            if (_.isObject(key) && !val) {
                _.each(key, function (value, fieldName) {
                    this._data[fieldName] = value;
                }, this);
            } else {
                this._data[key] = val;
            }

            this.trigger('changed');
        },

        get: function (key) {
            return this._data[key];
        },

        reset: function () {
            this._data = {};
            this.trigger('reset');
        }
    });
});
