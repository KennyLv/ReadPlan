define('common/view/baseListView',['common/view/base'], function (BaseView) {
    'use strict';

    return BaseView.extend({

        baseEvents: {
            _select: 'select'
        },

        images: {},

        init: function (display, model) {
            this.template = {};
            this.model = model;
            this.display = display;
            if (this.events) {
                this.events = this._extendEvents(this.baseEvents, this.events);
            }
            this._super(display);
        },

        _render: function (options) {
            options = options || {};
            this.startListening();
        },

        start: function () {
            this.startListening(this.events);
        },

        startListening: function (events) {
            this.stopListening();
            var eventsToListen = events || this.events;
            _.each(eventsToListen, function (eventToListenTo, callbackName) {
                if (this[callbackName]) {
                    this.listenTo(this.display, eventToListenTo, this[callbackName].bind(this));
                }
            }, this);
            this.listenToOnce(this.display, this.display.getBackButtonEventName(), this.goBack);
        },

        /**
         * extends class instance events with class's baseEvents
         *
         * @param objectToExtend {Object}
         * @param objectToExtendBy {Object}
         * @returns {Object}
         */
        _extendEvents: function(objectToExtend, objectToExtendBy) {
            return _.extend(objectToExtend, objectToExtendBy);
        },

        /**
         * gets current list's(template) items
         *
         * @returns {Array}
         */
        _getCurrentListItems: function () {
            return this.template.templateContent.list;
        },

        /**
         * fetches the selected item in current list
         *
         * @param item {Object}
         * @returns {Object}
         */
        _fetchItemInCurrentList: function(item) {
            var currentList = this._getCurrentListItems(),
                nameValue = null;
            if (item.value.text) {
               nameValue = item.value.text;
            }
            else if (item.value.name ) {
                // Slaker returns .name as selected item's name string
                nameValue = item.value.name;
            }
            return _.first(
                _.where(
                    this.template.templateContent.list,
                    {text: nameValue}
                ));
        },

        /**
         * get item's index in current list
         *
         * @param item {Object}
         * @returns {Number}
         */
        _getItemIndex: function(item) {
            var itemInCurrentList = this._fetchItemInCurrentList(item),
                currentList = this._getCurrentListItems(),
                itemIndexInCurrentList;

                itemIndexInCurrentList = _.indexOf(currentList, itemInCurrentList);
            return itemIndexInCurrentList >= 0 ? itemIndexInCurrentList : null;
        },

        _select: function (item) {
            var itemIndexInCurrentList = this._getItemIndex(item);
            this.template.templateContent.list.activeListItem = this.selectedItem = itemIndexInCurrentList;
        },

        /**
         * checks if there is an actual text in list to display
         *
         * @param items {Array}
         * @returns {Boolean}
         */
        _isThereInfoToDisplay: function(data) {
            return _.any(_.reject(data, function(val){
                return !val.hasOwnProperty('text') &&
                val.text !== '' ||
                val.text === undefined;
            }));
        },

        /**
         * get selected item's index in current list
         *
         * @returns {Number}
         */
        getSelectedListItem: function() {
            return this.selectedItem;
        },

        /**
         *
         * @param items {Array}
         * @param options {Object}
         * @returns {Array}
         */
        getItems: function (options) {
            throw Error('method not implemented');
        },

        getButtons: function () {
            throw Error('method not implemented');
        },

        getBackButton: function () {
            throw Error('method not implemented');
        },

        getNowPlayingButton: function () {
            throw Error('method not implemented');
        },

        getABCJumpButton: function () {
            throw Error('method not implemented');
        },

        renderPrevious: function () {
            throw Error('method not implemented');
        },

        setTitle: function (title) {
            throw Error('method not implemented');
        },

        generateTemplate: function (options) {
            throw Error('method not implemented');
        },

        player: function (item) {
            throw Error('method not implemented');
        },

        goBack: function (item) {
            throw Error('method not implemented');
        }

    });
});
