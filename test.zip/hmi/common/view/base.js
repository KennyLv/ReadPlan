define('common/view/base',['common/view/config', 'aq/eventEmitter', 'aq/dic', 'common/view/base_extension'],
    function (Config, EventEmitter, dic, PlatformExtension) {
    'use strict';

    var appManager;
    //var constants = dic.get('constants'); // FIXME: Not used?

    return EventEmitter.extend({

        /**
         * View options
         */
        useButtonsBranding: true,

        branding: Config.buttonsBranding,
        maxButtonsInStripe: Config.maxButtonsInPlayerStripe || 6,

        init: function (display, options) {
            options = options || {};
            this.useButtonsBranding = options.useButtonsBranding || this.useButtonsBranding;
            //setting appName in case of aq templates branding
            this.appName = options.appName;
            this.display = display;
            if(options.branding) {
                this.branding = this._updateSubProperty(this.branding, options.branding);
            }
        },

        updateScreen: function (template) {
            template = this.useButtonsBranding ? this.applyButtonsBranding(template) : template;
            this._template = $.extend(true, {}, template);
            return this.display.updateScreen(template);
        },

        /**
         * On alpha jump (ABC jump) press
         */
        onAlphaJump: function () {
            this.showKeyboard();
        },

        showKeyboard: function (keyboardBgImg1, keyboardBgImg2) {
            this.display.showKeyboard(keyboardBgImg1, keyboardBgImg2);
            this.listenTo(this.display, this.display.getKeyboardButtonEventName(), this._onKeyboardButtonPressed);
            this.trigger('keyboard:shown');
        },

        hideKeyboard: function () {
            this.updateScreen(this._template);
            if (this.startListening) this.startListening();
            this.trigger('keyboard:hidden');
        },

        applyButtonsBranding: function (template) {
            // Lazy load. We need this to be able to run unit tests without Error about calling
            // "undefined" while evaluating window.android.exec and window.android.log methods.
            // FIXME: Base view should not know anything about appManager...
            if (_.isUndefined(appManager)) {
                appManager = require('aq/dic').get('appManager');
            }

            var appName = appManager.getCurrentApplicationName(),
                branding = this.branding[template.templateId];

            // apply buttons branding only if buttons set
            if (template.templateContent.buttons) {
                template.templateContent.buttons =
                    this._applyCommonBranding(template.templateContent.buttons, branding, appName);
            }

            return template;
        },

        /**
         *
         * @param buttons {Object} Numeric collection of buttons
         * @param branding {Object}
         * @param appName {String}
         * @returns {Object} Numeric collection of buttons
         * @private
         */
        _applyCommonBranding: function (buttons, branding, appName) {
            appName = this.appName ? this.appName : appName;
            var pathToButtonsBrandingPressedState = 'file:///' + appName + this.branding.path,
                // todo move to constants
                pathToButtonsBrandingNormalState = 'file:///aq/images/buttons/normal/',
                getStripeButtonNameByKey = this._getStripeButtonNameByKey(buttons);

            _.each(buttons, function (button, key) {
                // overwrite default backgroundImage
                if (!button.backgroundImage) {
                    button.backgroundImage = {
                        normal: pathToButtonsBrandingNormalState +
                            (branding[key] || getStripeButtonNameByKey(key)) + '.png',
                        pressed: pathToButtonsBrandingPressedState +
                            (branding[key] || getStripeButtonNameByKey(key)) + '.png'
                    };
                }
            });

            return buttons;
        },

        _getStripeButtonNameByKey: function (buttons) {
            var buttonsStripeCount = _.filter(buttons, function (button, key) {
                    return parseInt(key, 10) <= this.maxButtonsInStripe;
                }, this).length;

            return function (key) {
                key = parseInt(key, 10);
                var postfix = (key === 1) ? 'left' : key === buttonsStripeCount ? 'right' : 'center';
                return 'stripe_' + buttonsStripeCount + '_' + postfix;
            };
        },

        /**
         * Handle click on a button in the Keyboard popup
         * @param data
         * @returns {*}
         * @private
         */
        _onKeyboardButtonPressed: function (data) {
            var input = "" + data.letter,
            templateContent = this._template.templateContent;

            // pressed close button
            if (!input || input === 'exit' || input === 'null') {
                return this.hideKeyboard();
            }

            var letter = input.toUpperCase();
            letter = letter[0] || "";

            // sort items
            var items = _.isArray(templateContent.list) ? templateContent.list : templateContent.list.items;
            items = _.isArray(items) ? items : [];
            
            // select item to match lower and upper cases
            var index = _.sortedIndex(_.pluck(items, 'text'), letter, function (item) {
                return item[0].toUpperCase().charCodeAt(0);
            });
            
            // Workaround for Pandora's MyStation list where first element is always Shuffle thus should be skipped,
            // in other words, index should be shift by one if the very first element should be highlighted
            if (items[0] && items[0].text && (items[0].text.toLowerCase().indexOf("shuffle") !== -1) && index === 0) {
                index++;
            }

            // update template with the new sorted items and set activeListItem
            templateContent.list = {
                activeListItem: index,
                items: items
            };

            this.hideKeyboard();
        },

        /**
        *
        * Update common subproperties such as 'branding'
        * @param propertyToUpdate {Object}
        * @param updateWith {Object}
        *
        **/
        _updateSubProperty: function(propertyToUpdate, updateWith) {
            _.each(updateWith, function(newValue, keyToUpdate) {
                if (propertyToUpdate.hasOwnProperty(keyToUpdate)) {
                    if (typeof propertyToUpdate[keyToUpdate] === 'object') {
                        propertyToUpdate[keyToUpdate] = this._updateSubProperty(propertyToUpdate[keyToUpdate],
                            newValue);
                    }
                    else {
                        propertyToUpdate[keyToUpdate] = newValue;
                    }
                }
            }, this);

            return propertyToUpdate;
        },

        bindScrollEvent: function () {
            this.display.startListenTo(this.display.getScrollEventName());
        },

        unbindScrollEvent: function () {
            this.display.stopListenTo(this.display.getScrollEventName());
        },

        render: function(options) {
            if (this.config && this.config.appName) {
                if(this.isCurrentApplication(this.config.appName)) {
                    this._render(options);
                }
                else {
                    return false;
                }
            }
            else {
                this._render(options);
            }
        },

        isCurrentApplication: function (appName) {
            if (_.isUndefined(appManager)) {
                appManager = require('aq/dic').get('appManager');
            }
            return appName === appManager.getCurrentApplicationName();
        }
    }).extend(PlatformExtension.prototype);
});
