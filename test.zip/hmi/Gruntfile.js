module.exports = function (grunt) {

    grunt.initConfig({

        buildFolder: "dist",

        // build everything
        hub: {
            options: {
                concurrent: 5
            },
            
            // We have to build platform first, because all apps depend on it
            platformDev: {
                src:   ["platform/Gruntfile.js"],
                tasks: ["dev:chdir"]
            },
            platformRelease: {
                src:   ["platform/Gruntfile.js"],
                tasks: ["release:chdir"]
            },
            // Build apps and platform again?! FIXME: Think about nice solution to no build `platform` twice 
            default: {
                src:   ["*/Gruntfile.js"],
                tasks: ["release:chdir"]
            },
            dev: {
                src:   ["*/Gruntfile.js"],
                tasks: ["dev:chdir"]
            },
            testing: {
                src:   ["testing/*/Gruntfile.js"],
                tasks: ["dev:chdir"]
            },
            release: {
                src:   ["*/Gruntfile.js"],
                tasks: ["release:chdir"]
            },
            releasePretty: {
                src: ["*/Gruntfile.js"],
                tasks: ["release-pretty:chdir"]
            }
        },

        // copy aq to build folder
        copy: {
            dev: {
                expand: true,
                cwd: "platform/<%= buildFolder %>/aq",
                src: "**",
                dest: "<%= buildFolder %>/aq"
            },
            release: {
                expand: true,
                cwd: "platform/<%= buildFolder %>/",
                src: "**",
                dest: "<%= buildFolder %>/"
            }
        },

        // todo refactor to watch all apps using node 'fs' module
        watch: {
            src: {
                files: ['templates/**/*.js',
                        "platform/**/*.js",
                        "slacker/**/*.js",
                        "iheartradio/**/*.js",
                        "pandora/**/*.js",
                        "common/**/*.js"
                        ],
                tasks: ["clean", "hub:platformDev", "hub:dev", "copy:dev"],
                options: {
                    debounceDelay: 500
                }
            }
        },

        clean: ["<%= buildFolder %>"],
        
        trimtrailingspaces: {
            main: {
                src: ['js/**/*.js'],
                options: {
                    filter: 'isFile',
                    encoding: 'utf8',
                    failIfTrimmed: false
                }
            }
        }
    });

    grunt.loadNpmTasks("grunt-contrib-copy");
    grunt.loadNpmTasks("grunt-hub");
    grunt.loadNpmTasks("grunt-contrib-watch");
    grunt.loadNpmTasks("grunt-contrib-clean");

    grunt.registerTask("default", ["clean", "hub:platformDev", "hub:default"]);
    grunt.registerTask("dev", ["clean", "hub:platformDev", "hub:dev", "copy:dev"]);
    grunt.registerTask("testing", ["clean", "hub:platformDev", "hub:testing", "copy:dev"]);
    grunt.registerTask("live", ["dev", "watch"]);
    grunt.registerTask("release", ["clean", "hub:platformRelease", "hub:release", "copy:release"]);
    grunt.registerTask("release-pretty", ["clean", "hub:platformRelease", "hub:releasePretty", "copy:release"]);

    grunt.event.on('watch', function (action, filepath, target) {
        grunt.log.writeln(target + ': ' + filepath + ' has ' + action);
    });

};
