define(['iheartradio/controllers/common/controller'], function (BaseController) {
    'use strict';

    return BaseController.extend({

        tunerIndex: 4,
        tunerDelay: 10000,

        init: function (options) {
            this.Player = options.Player;
            this.Popup = options.Popup;
            this.model = options.model;
            this.config = options.config;
        },

        start: function () {
            this.showPlayer();
            this.fetchPlayerInfo();
            this.startListening();
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.model, 'changed', this.updatePlayer);
            this.listenTo(this.model, 'error', this.onError);
            this.listenTo(this.model, 'onDMCASkipFail', this.onDMCASkipFail);

            this.listenTo(this.view, this.view.events.play, this.play);
            this.listenTo(this.view, this.view.events.pause, this.pause);
            this.listenTo(this.view, this.view.events.addToFavorites, this.addToFavorites);
            this.listenTo(this.view, this.view.events.removeFromFavorites, this.removeFromFavorites);
            this.listenTo(this.view, this.view.events.discoveryTuner, this.discoveryTuner);
            this.listenTo(this.view, this.view.events.scan, this.scan);
            this.listenTo(this.view, this.view.events.createStation, this.createStation);
            this.listenTo(this.view, this.view.events.scrubBackward, this.scrubBackward);
            this.listenTo(this.view, this.view.events.scrubForward, this.scrubForward);
            this.listenTo(this.view, this.view.events.skip, this.skip);
            this.listenTo(this.view, this.view.events.thumbsDown, this.thumbsDown);
            this.listenTo(this.view, this.view.events.thumbsUp, this.thumbsUp);

            this.listenToOnce(this.view, this.view.events.onSuspend, this.onSuspend);
            this.listenToOnce(this.view, this.view.events.goToMainScreen, this.onGoToHome);
            this.listenToOnce(this.view, this.view.events.goToSourceScreen, this.onGoToSourceScreen);

            this._super();
        },

        onSuspend: function () {
            this.stopListening();
            this.trigger('suspend');
        },

        suspend: function () {
            this.stopListening();
        },

        close: function () {
            this.stopListening();
        },

        onGoToHome: function () {
            this.stopListening();
            this.trigger('show:home');
        },

        onGoToSourceScreen: function () {
            this.onSuspend();
        },

        showPlayer: function () {
            this.view = this.view || new this.Player(this.model);
            this.view.start();
        },

        onError: function (error) {
            this._showPopup(error);
        },

        fetchPlayerInfo: function () {
            this.model.getPlayerState()
                .done(function () {
                    var image = this.model.get('image'),
                        imgCommand = this.model.getImageCommand();
                    if (!image && imgCommand) {
                        this.model.getImage(imgCommand);
                    }
                }.bind(this));
        },

        onDMCASkipFail: function(data) {
            this._showPopup({
                title: $.t('error.' + data.eventData.dmca.modalScreen.key + '.title'),
                message: $.t('error.' + data.eventData.dmca.modalScreen.key + '.message')
            });
        },

        onNetworkState: function(){
            if(this.model.isConnectedToNetwork()){
                this.fetchPlayerInfo();
            }
        },

        /**
         * onPlayerStateChanged: isPlayerPlaying, buttonsState
         * onStationChanged station, buttonsState
         * onScanAvailableChanged
         * onBufferingStart
         * onMetadataChanged
         */
        updatePlayer: function () {
            this.view.render();
        },

        play: function () {
            this.model.play();
        },

        pause: function () {
            this.model.pause();
        },

        addToFavorites: function () {
            this.model.addFavorite().done(function (response) {
                this._showResponsePopup(response, {
                    message: {
                        name: this.model.getStationName()
                    }
                });
            }.bind(this));
        },

        removeFromFavorites: function () {
            this.model.removeFavorite().done(function (response) {
                this._showResponsePopup(response, {
                    message: {
                        name: this.model.getStationName()
                    }
                });
            }.bind(this));
        },

        discoveryTuner: function () {
            this.model.getDiscoveryMenu().done(function(response){
                this._showTunerModalScreen(response);
            }.bind(this));
        },

        scan: function () {
            this.model.scan();
        },

        createStation: function () {
            this.model.createStation().done(function(response){
                this._showNewStationModalScreen(response);
            }.bind(this));
        },

        scrubBackward: function () {
            this.model.scrubBackward();
        },

        scrubForward: function () {
            this.model.scrubForward();
        },

        skip: function () {
            this.model.skipSong();
        },

        thumbsDown: function () {
            this.model.thumbsDown().done(function (response) {
                this._showResponsePopup(response);
            }.bind(this));
        },

        thumbsUp: function () {
            this.model.thumbsUp().done(function (response) {
                this._showResponsePopup(response);
            }.bind(this));
        },

        /**
         * send command to play newly created station
         * or hides popUp if new station already plays
         * 
         * @param  {[string]} command  stringified command object
         */
        _playNewStation: function (command) {
            var cmd = JSON.parse(command.value),
                stationId = this.model.get("station").id;
            if (cmd.args.stationId === stationId) {
                this.updatePlayer();
            } else {
                this.model.reset();
                this.model.exec(cmd);
            }
        },

        _setVarietyLevel: function (command) {
            this.model.exec(JSON.parse(command.value));
            this.updatePlayer();
        },

        /**
         * Display popup on response
         * @param {object} response
         * @param {object} [options]
         * @private
         */
        _showResponsePopup: function (response, options) {
            options = options || {};

            this._showPopup({
                title: $.t('player.' + response.modalScreen.key + '.title', options.title),
                message: $.t('player.' + response.modalScreen.key + '.message', options.message)
            });
        },

        _showNewStationModalScreen: function (response) {
            var popup = new this.Popup(),
                key = response.modalScreen.key,
                button0 = response.modalScreen.buttons[0],
                button1 = response.modalScreen.buttons[1],
                title = $.t('player.' + key + '.title'),
                text = $.t('player.' + key + '.message', {name: this.model.get("track").title ||
                    this.model.get("track").songTitle});

            popup.render({
                title: title,
                text: text,
                buttons: [
                    {
                        2: {
                            action: popup.events.playNewStation,
                            text:  $.t('player.' + key + '.buttons.' + button0.key),
                            value: JSON.stringify(button0.selectCommand)
                        }
                    },
                    {
                        3: {
                            action: popup.events.close,
                            text: $.t('player.' + key + '.buttons.' + button1.key),
                            value: ''
                        }
                    }
                ]
            });

            this.listenToOnce(popup.display, popup.events.playNewStation, this._playNewStation);
            this.listenToOnce(popup.display, popup.events.close, this.updatePlayer);
        },

        _showTunerModalScreen: function (response) {
            var popup = new this.Popup(),
                title = $.t('player.tuner.title'),
                text = '"' + this.model.get("station").name + '"';


            popup.render({
                title: title,
                text: text,
                delay: this.tunerDelay,
                buttons: this._getTunerPopupButtons(response.menu, popup.events.setVarietyLevel, popup.images)
            });

            this.listenToOnce(popup.display, popup.events.setVarietyLevel, this._setVarietyLevel);
            this.listenToOnce(popup.display, popup.events.close, this.updatePlayer);
        },

        _getTunerPopupButtons: function (menu, tunerEvent, images) {
            var buttons = menu.map(function(item, index){
                var button = {},
                    buttonIndex = index + this.tunerIndex;
                button[buttonIndex] = {
                    action: tunerEvent,
                    text:  $.t('player.tuner.buttons.' + item.key),
                    image: '',
                    value: JSON.stringify(item.commands.select)
                };
                if (item.selected) {
                    button[buttonIndex].backgroundImage = {
                        normal: images.selected_pressed,
                        pressed: images.selected_pressed
                    };
                }
                return button;
            }, this);
            return buttons;
        },

        _showPopup: function (info) {
            var title = info.statusCode === -1 ? $.t('error.noResponse.title') : info.title,
                text = info.statusCode === -1 ? $.t('error.noResponse.message') : info.message;

            this.showPopup({
                title: title,
                text: text,
                delay: this.config.popupTimeoutClose,
                onClose: this.updatePlayer.bind(this)
            });
        }
    });
});
