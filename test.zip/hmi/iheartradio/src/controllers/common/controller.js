define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({
        init: function () {

        },

        startListening: function () {
            this.listenTo(this.model, 'onNetworkState', this.onNetworkState);
            this.listenTo(this.model, 'onReadyStateChanged', this.onReadyStateChanged);
        },

        onNetworkState: function (data) {
            var networkState = data.eventData && data.eventData.networkState;

            if (networkState === "disconnected") {
                this.showPopup({
                    title: $.t('error.NoNetworkConnection.title'),
                    text: $.t('error.NoNetworkConnection.message'),
                    onClose: this.trigger.bind(this, "show:home")
                });
            }
        },

        onReadyStateChanged: function (data, prevState, playOnReconnect) {
            var readyState = data.eventData.readyState && data.eventData.readyState.state,
                reasonCode = data.eventData.readyState && data.eventData.readyState.reasonCode;

            if (readyState === prevState) {
                return;
            }

            // ready state changed to disconnected
            if (readyState === '0' && reasonCode === '3') {
                this.showPopup({
                    title: $.t('error.onReadyStateChanged.title'),
                    text: $.t('error.onReadyStateChanged.message'),
                    onClose: this.trigger.bind(this, "close")
                });
            }
            else if (readyState === '1') {
                if (playOnReconnect) {
                    this.model.play();
                }
            }
        },

        /**
         * Display popup
         *
         * @param options
         * @returns {Popup}
         */
        showPopup: function (options) {
            var popup = new this.Popup();

            options = _.extend({
                title: $.t('error.generic.title'),
                text: $.t('error.generic.message'),
                delay: null,
                buttons: [popup.buttons.exit],
                onClose: function () {
                }
            }, options);

            popup.render({
                title: options.title,
                text: options.text,
                delay: options.delay,
                buttons: options.buttons
            });

            this.listenToOnce(popup.display, popup.events.close, options.onClose);

            return popup;
        }
    });
});
