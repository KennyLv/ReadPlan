define(['iheartradio/controllers/common/controller'], function (BaseController) {
    'use strict';

    return BaseController.extend({

        init: function (options) {
            this.Popup = options.Popup;
            this.View = options.MainScreen;
            this.model = options.model;
            this.config = options.config;
        },

        start: function () {
            this.view = new this.View(this.model);
            this.view.render();
            this.startListening();
        },

        startListening: function () {
            this.stopListening();
            this.listenTo(this.view, this.view.events.goToRecentStations, this.onGoToRecentStations);
            this.listenTo(this.view, this.view.events.goToFavorites, this.onGoToFavorites);
            this.listenTo(this.view, this.view.events.goToShows, this.onGoToShows);
            this.listenTo(this.view, this.view.events.goToCreateStations, this.onGoToCreateStations);
            this.listenTo(this.view, this.view.events.goToLiveRadio, this.onGoToLiveRadio);
            this.listenTo(this.view, this.view.events.goToNowPlaying, this.onGoToPlayer);

            this.listenTo(this.model, 'changed', this.view.render.bind(this.view));
            this.listenTo(this.view, 'all', this.suspend);

            this._super();
        },

        suspend: function () {
            this.stopListening();
        },

        close: function () {
            this.stopListening();
        },

        onGoToRecentStations: function (data) {
            this.trigger('show:menu', this.model.getRecentStations.bind(this.model), this._getMenuName(data));
        },

        onGoToFavorites: function (data) {
            this.trigger('show:menu', this.model.getFavoritesStations.bind(this.model), this._getMenuName(data));
        },

        onGoToShows: function (data) {
            this.trigger('show:menu', this.model.getShowsMenu.bind(this.model), this._getMenuName(data));
        },

        onGoToCreateStations: function (data) {
            this.trigger('show:menu', this.model.getCreateStationMenu.bind(this.model), this._getMenuName(data));
        },

        onGoToLiveRadio: function (data) {
            this.trigger('show:menu', this.model.getLiveRadioMenu.bind(this.model), this._getMenuName(data));
        },

        onGoToPlayer: function () {
            this.trigger('show:player');
        },

        _getMenuName: function (data) {
            data = data || {};
            return data.value;
        }

    });
});
