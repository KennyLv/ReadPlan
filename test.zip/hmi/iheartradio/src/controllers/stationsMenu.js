define(['iheartradio/controllers/common/controller', 'aq/utils'], function (BaseController, utils) {
    'use strict';

    return BaseController.extend({

        init: function (options) {
            this.List= options.List;
            this.Popup = options.Popup;
            this.model = options.model;
            this.config = options.config;
        },

        start: function (stationsToFetch, stationTitle) {
            stationTitle = stationTitle.replace('\n', ' ');
            this.views = [];

            this.view = new this.List(stationTitle, this.model);
            this.view.render();
            this.startListening();

            this.requestInProgress = stationsToFetch()
                .done(this.updateList.bind(this))
                .fail(this.onError.bind(this));
        },

        startListening: function () {
            this.stopListening();

            this.listenTo(this.view, this.view.events.select, this.onSelectItem);
            this.listenTo(this.view, this.view.events.create, this.onCreateStation);
            this.listenTo(this.view, this.view.events.play, this.onPlayStation);

            this.listenTo(this.view, this.view.events.nowPlaying, this.onGoToPlayer);
            this.listenTo(this.view, this.view.events.goBack, this.onBack);

            this._super();
        },

        onReadyStateChanged: function (data, prevState, playOnReconnect) {
            var readyState = data.eventData.readyState && data.eventData.readyState.state,
                reasonCode = data.eventData.readyState && data.eventData.readyState.reasonCode;

            if (readyState === prevState) {
                return;
            }

            // ready state changed to disconnected
            if (readyState === '0' && reasonCode === '3') {

                this.showPopup({
                    title: $.t('error.onReadyStateChanged.title'),
                    text: $.t('error.onReadyStateChanged.message'),
                    onClose: this.trigger.bind(this, "close")
                });
            }
            else if (readyState === '1') {
                if (playOnReconnect) {
                    this.model.play();
                }
                this._destroy();
                this.trigger('show:home');
            }
        },

        suspend: function () {
            this._destroy();
        },

        close: function () {
            this._destroy();
        },

        _destroy: function () {
            this.view = null;
            this.views = [];
            this.stopListening();
        },

        onError: function (error) {
            this.stopListening();
            this._showPopup(error);
        },

        /**
         * Update current view with the new data
         * @param data {Object}
         */
        updateList: function (data) {
            var isAborted = data === null;
            if (this.view && !isAborted) {
                this.view.render({items: data.menu});
            }
        },

        /**
         * render new list and save current
         */
        onForward: function (title) {
            this.views.push(this.view);
            this.view = new this.List(title, this.model);
            this.view.render();
            this.startListening();
        },

        /**
         * get previous list and restore/re-render it
         */
        onBack: function () {
            // abort request in progress
            if (this.requestInProgress) this.requestInProgress.resolve(null);
            this.view = this.views.pop();

            if (this.view) {
                this.view.start();
                this.startListening();
            } else {
                this._destroy();
                this.trigger('show:home');
            }
        },

        onSelectItem: function (data) {
            var select = utils.resolve(data, 'value.commands.select');

            if (select) {
                this.onForward(data.value.text);
                this.requestInProgress = this.model.exec(select);
                this.requestInProgress
                    .done(this.updateList.bind(this))
                    .fail(this.onError.bind(this));
            }
        },

        /**
         * Create station
         * Available only for logged-in users
         * @param data
         */
        onCreateStation: function (data) {
            var create = utils.resolve(data, 'value.commands.create');

            if (create) {
                var isSelectedStationPlaying = this.isStationPlaying(data.value.key, 'seedValue', 'seedShow'),
                    stationType = create.cmd === 'createCustomStation' ? 'custom' :
                        create.cmd === 'createTalkStation' ? 'talk' : false;
                this.execStationCommand(create, data.value, isSelectedStationPlaying, stationType);
            }
        },

        onPlayStation: function (data) {
            var play = utils.resolve(data, 'value.commands.play');

            if (play) {
                var isSelectedStationPlaying = this.isStationPlaying(play.args.stationId, 'id');
                this.execStationCommand(play, data.value, isSelectedStationPlaying, play.args.stationType);
            }
        },

        execStationCommand: function (command, data, isSelectedStationPlaying, stationType) {
            command.args.playStation = true;

            return isSelectedStationPlaying ? this.onGoToPlayer() : this.model.exec(command)
                .done(function () {
                    this.model.reset();
                    this.model.set('stationType', stationType);
                    this.model.set('isPlaying', true);
                    this.onGoToPlayer(data);
                }.bind(this))
                .fail(function (error) {
                    this._showPopup(error, this.view.start.bind(this.view));
                }.bind(this));
        },

        isStationPlaying: function () {
            var args = _.toArray(arguments),
                val = args.shift(),
                station = this.model.get('station') || {};

            return args.some(function (item) {
                return station[item] === val;
            });
        },

        onGoToPlayer: function (options) {
            this._destroy();
            this.trigger('show:player', options);
        },

        _showPopup: function (error, handler) {
            var title = error.statusCode === -1 ? $.t('error.noResponse.title') : error.title,
                text = error.statusCode === -1 ? $.t('error.noResponse.message') : error.message,
                closeHandler = handler || this.onBack.bind(this);

            this.showPopup({
                title: title,
                text: text,
                delay: this.config.popupTimeoutClose,
                onClose: closeHandler
            });
        }
    });
});