define(function () {
    'use strict';

    return {
        appName: 'iheartradio',

        clientId: 'Y2hyeXNsZXItYWJxLXZwMmMtY3AuYXV0by51cw==',
        apiVersion: '2.0',
        profileName: 'DA',

        profileOptions: {
            imageWidth: 75,
            imageHeight: 75
        },

        popupTimeoutClose: 3 * 1000
    };

});