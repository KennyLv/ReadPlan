define(['aq/api/commandControl', 'aq/utils', 'aq/constants'], function (CommandControl, utils, constants) {
    'use strict';

    return CommandControl.extend({

        systemEvents: {
           buttonEvent: "buttonEvent"
        },

        init: function (transport) {
            this.appName = 'com.clearchannel.iheartradio';
            this.contentType = 'application/JSON';
            this._initTransport(transport);
        },

        onAsyncEvent: function (data, eventName) {
            if (eventName) {
                this.trigger(eventName, data);
            }
        },

        handleNotification: function (notification, response) {
            var appName = utils.resolve(response, 'headers.app-name') || utils.resolve(response, 'headers.App-Name');
            if (appName === this.appName || notification.elapsedTime) {
                var eventName;
                //TODO: elapsed time notification
                if (notification && notification.elapsedTime) {
                    eventName = 'onElapsedTime';
                } else {
                    eventName = this._getEventName(response);
                }
                this.onAsyncEvent(this._getNotification(notification), eventName);
            }
            else if(notification.type && this.systemEvents[notification.type]) {
                this._handleSystemNotification(notification);
            }
        },

        _handleSystemNotification: function(notification) {
            var buttonEventName = constants.HARD_KEYS[notification.data.buttonId];
            if(buttonEventName) {
                this.onAsyncEvent(this._getNotification(notification), buttonEventName);
            }
        },

        _getEventName: function (data) {
            return (data.content && data.content.eventId) ? data.content.eventId :
                (data.headers['content-type'] || data.headers['Content-Type']);
        },

        /**
         * FIXME
         * iOS workaround because of iOS native layer stringified data twice
         * need to remove when iOS fix the issue
         */
        _getNotification: function (notification) {
            return _.isString(notification) ? (utils.parseJSON(notification) || notification) : notification;
        }
    });
});