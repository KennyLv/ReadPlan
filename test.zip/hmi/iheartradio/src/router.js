define(['aq/eventEmitter'], function (EventEmitter) {
    'use strict';

    return EventEmitter.extend({

        init: function (options) {

            this.dic = options.dic;
            this.model = this.dic.get('model');

            this.routes = {
                'show:menu': this.goToStationsMenu,
                'show:player': this.goToPlayer,
                'show:home': this.goToHome,
                'close': this._onClose,
                'suspend': this._onSuspend
            };
        },

        start: function () {
            this.model.initSession()
                .then(this.goToHome.bind(this))
                .then(this.model.startListening.bind(this.model))
                .then(this.model.getPlayerState.bind(this.model))
                .then(this.model.getUserSettings.bind(this.model))
                .then(this.play.bind(this))
                .fail(this.onConnectionError.bind(this));
        },

        //The following is redundant with what the API Play command currently doing
        //But CV-1973 insist on being done this way.
        play: function () {
            if (this.model.isPlayOnStartup()) {
                return this.model.getLastRecentStations()
                    .done(function (data) {
                        if (data.menu && data.menu.length >= 1) {
                            this.model.play(data.menu[0].commands.play.args);
                        } else {
                            this.model.play();
                        }
                    }.bind(this));
            }
        },

        navigate: function (name) {
            if (this.routes[name]) {
                this.stopListening();
                this.routes[name].apply(this, Array.prototype.slice.call(arguments, 1));
            }
        },

        suspend: function () {
            this.stopListening();
            if (this.model.isScanning()) {
                this.model.play();
            }
        },

        close: function () {
            this.suspend();
        },

        _onSuspend: function () {
            this.trigger('suspend');
        },

        _onClose: function () {
            this.trigger('close');
        },

        resume: function () {
            this.controller.view.start();
            this.controller.startListening();
            this.listenTo(this.controller, 'all', this.navigate);
        },

        onConnectionError: function () {
            var popup = this.showPopup(
                $.t('error.noResponse.title'),
                $.t('error.noResponse.message')
            );

            this.listenToOnce(popup.display, popup.events.close, this._onClose);
        },

        showPopup: function (title, text) {
            var popup = new (this.dic.get('Popup'))();
            popup.render({
                title: title,
                text: text,
                buttons: [popup.buttons.exit]
            });
            return popup;
        },

        goToHome: function () {
            this.controller = this.dic.get('controller/home');
            this.listenTo(this.controller, 'all', this.navigate);
            this.controller.start();
        },

        /**
         *
         * @param stationsTypeToFetch {Function}
         * @param stationsTypeName {String}
         */
        goToStationsMenu: function(stationsTypeToFetch, stationsTypeName) {
            this.controller = this.dic.get('controller/stationsMenu');
            this.listenTo(this.controller, 'all', this.navigate);
            this.controller.start(stationsTypeToFetch, stationsTypeName);
        },

        goToPlayer: function (options) {
            this.controller = this.dic.get('controller/player');
            this.listenTo(this.controller, 'all', this.navigate);
            this.controller.start(options);
        }
    });

});