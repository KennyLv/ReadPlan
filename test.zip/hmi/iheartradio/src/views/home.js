define(['common/view/base'], function (View) {
    'use strict';

    return View.extend({

        events: {
            // select and play
            goToLiveRadio: 'goToLiveRadio',
            goToShows: 'goToShows',

            // select and crete and then play
            goToCreateStations: 'goToCreateStations',

            // just play
            goToRecentStations: 'goToRecentStations',
            goToFavorites: 'goToFavorites',

            goToNowPlaying: 'goToNowPlaying'
        },

        images: {
            surface: 'file:///iheartradio/images/surface.png',
            title: 'file:///iheartradio/images/home/title.png',
            nowPlaying: 'file:///iheartradio/images/home/now_playing.png',
            nowPlayingDisabled: 'file:///iheartradio/images/home/now_playing_disabled.png'
        },

        init: function (options, model) {
            this.isPlaying = false;

            this.template = {};
            this.model = model;
            this._super(options.display, {useButtonsBranding: true});

            this.config = options.config;
        },

        _render: function () {
            this.template = this.generateTemplate();
            this.start();
        },

        start: function () {
            this.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                var handler = this[method] ?  this[method].bind(this) : this.trigger.bind(this, event);
                this.listenTo(this.display, event, handler);
            }, this);
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-5',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.title
                    },
                    buttons: this.getButtons()
                }
            };
        },

        getButtons: function () {
            return {
                1: {
                    text: $.t('menu.liveRadio'),
                    value: $.t('menu.liveRadio'),
                    action: this.events.goToLiveRadio
                },
                2: {
                    text: $.t('menu.createStation'),
                    value: $.t('menu.createStation'),
                    action: this.events.goToCreateStations
                },
                3: {
                    text: $.t('menu.shows'),
                    value: $.t('menu.shows'),
                    action: this.events.goToShows
                },
                4: {
                    text: $.t('nowPlaying'),
                    image: this.model.isStationSelected() ?
                        this.images.nowPlaying : this.images.nowPlayingDisabled,
                    action: this.events.goToNowPlaying,
                    stateEnabled: this.model.isStationSelected()
                },
                5: {
                    text: $.t('menu.favoriteStations'),
                    value: $.t('menu.favoriteStations'),
                    action: this.events.goToFavorites
                },
                6: {
                    text: $.t('menu.recentStations'),
                    value: $.t('menu.recentStations'),
                    action: this.events.goToRecentStations
                }
            };
        }

    });
});