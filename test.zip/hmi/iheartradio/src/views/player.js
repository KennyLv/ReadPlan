define(['common/view/base'], function (View) {
    'use strict';

    return View.extend({

        events: {
            goToSourceScreen: 'goToSourceScreen',
            goToMainScreen: 'goToMainScreen',

            moreButtonsOption: 'moreButtonsOption',

            play: 'play',
            pause: 'pause',
            stop: 'stop',
            addToFavorites: 'addToFavorites',
            removeFromFavorites: 'removeFromFavorites',
            createStation: 'createStation',
            discoveryTuner: 'discoveryTuner',
            scan: 'scan',
            scrubBackward: 'scrubBackward',
            scrubForward: 'scrubForward',
            skip: 'skip',
            thumbsDown: 'thumbsDown',
            thumbsUp: 'thumbsUp'
        },

        images: {
            surface: 'file:///iheartradio/images/surface.png',
            title: 'file:///iheartradio/images/player/title.png',
            logo: 'file:///iheartradio/images/player/logo.png',
            menu: 'file:///iheartradio/images/player/menu.png',
            source: 'file:///iheartradio/images/player/source.png',
            play: 'file:///iheartradio/images/player/play.png',
            pause: 'file:///iheartradio/images/player/pause.png',
            stop: 'file:///iheartradio/images/player/stop.png',

            btn_more_left: 'file:///iheartradio/images/player/btn_more_left.png',
            btn_more_right: 'file:///iheartradio/images/player/btn_more_right.png',

            addToFavorites: 'file:///iheartradio/images/player/addToFavorites/<%= code %>.png',
            createStation: 'file:///iheartradio/images/player/createStation/<%= code %>.png',
            discoveryTuner: 'file:///iheartradio/images/player/discoveryTuner/<%= code %>.png',
            scan: 'file:///iheartradio/images/player/scan/<%= code %>.png',
            scrubBackward: 'file:///iheartradio/images/player/scrubBackward/<%= code %>.png',
            scrubForward: 'file:///iheartradio/images/player/scrubForward/<%= code %>.png',
            skip: 'file:///iheartradio/images/player/skip/<%= code %>.png',
            thumbsDown: 'file:///iheartradio/images/player/thumbsDown/<%= code %>.png',
            thumbsUp: 'file:///iheartradio/images/player/thumbsUp/<%= code %>.png'
        },

        // buttons that have different behaviour depending on state
        stateEvent: {
            addToFavorites: {
                0: "addToFavorites",
                1: "removeFromFavorites"
            },
            scan: {
                0: "scan",
                1: "play"
            }
        },

        buttons: {
            custom: [
                ['skip', 'thumbsUp', 'thumbsDown'],
                ['createStation', 'addToFavorites', 'discoveryTuner']
            ],
            live: [
                ['scan', 'thumbsUp', 'thumbsDown'],
                ['createStation', 'addToFavorites']
            ],
            talk: [
                ['skip', 'thumbsUp', 'thumbsDown'],
                ['scrubBackward', 'scrubForward', 'addToFavorites']
            ],
            default: [
                ['thumbsUp', 'thumbsDown', 'addToFavorites']
            ]
        },

        init: function (options, model) {
            this.template = {};
            this.model = model;
            this._super(options.display, {useButtonsBranding: true});

            this.config = options.config;
        },

        start: function () {
            this.moreBtnIsPressed = false;
            this.render();
        },

        _render: function (options) {
            options = options || {};
            this.template = this.generateTemplate();
            this.updateScreen(this.template);
            this.startListening();
        },

        startListening: function () {
            _.each(this.events, function (method, event) {
                var handler = this[method] ?  this[method].bind(this) : this.trigger.bind(this, event);
                this.listenTo(this.display, event, handler);
            }, this);
            this.listenTo(this.display, this.display.getBackButtonEventName(), this.goToMainScreen);
            this.bindScrollEvent();
            this.listenToOnce(this.display, this.display.getScrollEventName(), this.goToMainScreen);
            
            this.listenToOnce(this.display, this.display.getPresetAdvEventName(), this.onPresetAdvPressed.bind(this));
            this.listenToOnce(this.display, this.display.getSeekUpEventName(), this.onSeekUpPressed.bind(this));
        },
        
        onPresetAdvPressed: function () {
            this.model.playNextInFav();
        },

        onSeekUpPressed: function () {
            this.model.skipSong();
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-2',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        image: this.images.title
                    },
                    buttons: _.extend(this.getButtons(), {
                        7: {
                            image: this.images.source,
                            action: this.events.goToSourceScreen
                        }
                    }),
                    main: {
                        text: this.getText(),
                        images: this.getImages()
                    },
                    progress: this.getProgressBar()
                }
            };
        },

        getText: function () {
            if(this.model.getBufferingState() || !this.model.isConnectedToNetwork()) {
                return _.extend(
                    this.getBufferingMessage()
                );
            }
            else {
                return _.extend(
                    this.getStationName(),
                    this.getStationTextInfo()
                );
            }
        },

        getBufferingMessage: function () {
            var bufferingMessageKey = 'Buffering';
            return  {
                1: {
                    text:  $.t('player.' + bufferingMessageKey + '.title')
                },
                2: {
                    text:  $.t('player.' + bufferingMessageKey + '.message')
                }
            };
        },

        getStationName: function () {
            return {
                1: {
                    text: this.model.getStationName()
                }
            };
        },

        getStationTextInfo: function () {
            var info = this.model.getStationTextInfo();
            return  {
                2: {
                    text: info[0]
                },
                3: {
                    text: info[1]
                }
            };
        },

        getButtons: function () {
            var stationType = this.model.getStationType(),
                buttonsLines, buttonState = {}, buttonsContainer = [],
                statusCodeDisabled = 2;

            buttonsLines = this.buttons[stationType];
            buttonState = this.model.getButtonState()  || this._getDefaultButtons(buttonsLines);

            _.each(buttonsLines, function (buttons, index) {
                buttonsContainer[index] = buttons.map(function (button) {
                    var status = {
                            code: buttonState[button]
                        },
                        data = {
                            image: {
                                normal: _.template(this.images[button], status),
                                pressed: 0
                            },
                            action: this._getButtonAction(button, status.code),
                            stateEnabled: status.code !== statusCodeDisabled
                        };
                    data = this._handleStateEvent(button, buttonState[button], data);
                    return data;
                }, this);
            }, this);

            buttonsContainer[0].unshift(this.getPlayToggleButton(buttonState));
            buttonsContainer[0].unshift(this.getMenuButton());

            if (buttonsContainer.length > 1) {
                buttonsContainer[0].push(this.getMoreButton());
                buttonsContainer[1].push(this.getMoreButton());
            }

            return this.moreBtnIsPressed ? this._toButtonsObject(buttonsContainer[1]) :
                this._toButtonsObject(buttonsContainer[0]);
        },

        _getDefaultButtons: function (lines) {
            var buttonState = {},
                disabled = 2;
            _.each(lines, function(buttons) {
                _.each(buttons, function(button) {
                    buttonState[button] = disabled;
                });
            });
            return buttonState;
        },

        /**
         * Substitute button action depending on current buttons state
         * @param {string} button
         * @param {number} state
         * @param {object} data Button data to be rendered
         * @returns {object}
         * @private
         */
        _handleStateEvent: function (button, state, data) {
            if (this.stateEvent[button] && this.stateEvent[button][state]) {
                button = this.stateEvent[button][state];
                data.action = this.events[button];
            }

            return data;
        },

        _getButtonAction: function (button, code) {
            return code === 0 ? this.events[button] : '';
        },

        getMenuButton: function () {
            return {
                image: {
                    normal: this.images.menu
                },
                action: this.events.goToMainScreen
            };
        },

        getPlayToggleButton: function (buttonSate) {
            var isPlaying = this.model.isPlaying(),
                stopImage = _.isNumber(buttonSate[this.events.stop]) ? this.images.stop : this.images.pause;
            return {
                image: {
                    normal: isPlaying ? stopImage : this.images.play,
                    pressed: 0
                },
                action: isPlaying ? this.events.pause : this.events.play
            };
        },

        getMoreButton: function() {
            var moreIsActive = this.moreBtnIsPressed;
            return {
                image: {
                    normal: moreIsActive ? this.images.btn_more_left : this.images.btn_more_right,
                    pressed: 0
                },
                action: this.events.moreButtonsOption
            };

        },

        getProgressBar: function () {
            var duration = this.model.getTrackDuration(),
                // todo iHR API doesn't provide us track elapsed time
                // todo as a workaround we can calculate elapsed time from beginning of each track
                // todo or disable progress bar at all
                elapsed = this.model.getTrackElapsedTime(),
                red = 'FF0000';

            return (_.isNumber(duration) && _.isNumber(elapsed) && elapsed !== duration) ? {
                total: duration,
                elapsed: elapsed,
                color: red,
                active: this.model.isPlaying()
            } : {};

        },

        getImages: function () {
            return {
                1: this.model.get('image') || this.images.logo
            };
        },

        /**
         * On more options btn click
         */
        moreButtonsOption: function () {
            this.moreBtnIsPressed = !this.moreBtnIsPressed;
            this.render();
            this.trigger('moreButtons');
        },

        goToMainScreen: function () {
            this.unbindScrollEvent();
            this.trigger(this.events.goToMainScreen);
        },

        goToSourceScreen: function () {
            this.display.showMediaSourceScreen();
        },

        /**
         *
         * @param buttons {Array}
         * @return buttons {Object}
         */
        _toButtonsObject: function (buttons) {
            return buttons.reduce(function (memo, button, index) {
                memo[index + 1] = button;
                return memo;
            }, {});
        }

    });
});