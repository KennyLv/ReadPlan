define(['shared/utils/class'], function (Class) {
    'use strict';

    return Class.extend({

        images: {
            logo: 'file:///iheartradio/images/splash_screen.png',
            background: 'file:///iheartradio/images/black-bg-32-bit.png'
        },

        init: function (options) {
            this.display = options.display;
        },

        render: function () {
            this.template = this.generateTemplate();
            this.display.updateScreen(this.template);
        },

        generateTemplate: function () {
            return {
                templateId: 'vp2c-8',
                systemHeader: true,
                loadingType: 3,
                backgroundImage: this.images.background,
                templateContent: {
                    main: {
                        text: {
                            1: $.t('connecting')
                        },
                        images: {
                            1: this.images.logo
                        }
                    }
                }
            };
        }

    });
});