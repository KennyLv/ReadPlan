define(['common/view/base'], function (View) {
    'use strict';

    return View.extend({

        events: {
            close: 'close',
            playNewStation: 'playNewStation',
            setVarietyLevel: 'setVarietyLevel'
        },

        images: {
            close: 'file:///iheartradio/images/close.png',
            surface: 'file:///iheartradio/images/surface.png',
            selected: 'file:///iheartradio/images/buttons/selected/selected_state.png',
            selected_pressed: 'file:///iheartradio/images/buttons/pressed/106x52.png'
        },

        init: function (options) {
            this.initButtons();
            this.template = {};
            this._super(options.display, {useButtonsBranding: true});
            this.config = options.config;
        },

        initButtons: function () {
            this.buttons = {
                exit: {
                    1: {
                        action: this.events.close,
                        image: {
                            normal: this.images.close
                        }
                    }
                },
                cancel: {
                    3: {
                        action: this.events.close,
                        text: $.t('buttons.cancel')
                    }
                }
            };
        },

        _render: function (options) {
            var delay = options.delay;
            this.text = options.text;
            this.title = options.title;

            this.template = this.generateTemplate(options.buttons);
            this.updateScreen(this.template);

            if (delay) {
                _.delay(this._triggerClose.bind(this), delay);
            }
        },

        _triggerClose: function () {
            this.display.trigger(this.events.close);
        },

        getButtons: function (buttons) {
            buttons = _.isArray(buttons) ? buttons : [];
            return buttons.reduce(function (memo, next) {
                var key = Object.keys(next)[0];
                memo[key] = next[key];
                return memo;
            }, {});
        },

        generateTemplate: function (buttons) {
            return {
                templateId: 'vp2c-1',
                backgroundImage: this.images.surface,
                loadingType: 3,
                templateContent: {
                    title: this.title,
                    main: {
                        text: this.text
                    },
                    buttons: this.getButtons(buttons)
                }
            };
        }

    });
});