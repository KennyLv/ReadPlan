define(['common/view/baseListView', 'aq/utils'], function (BaseListView, utils) {
    'use strict';

    return BaseListView.extend({

        events: {
            goBack: 'goBack',
            nowPlaying: 'nowPlaying',
            onAlphaJump: 'onAlphaJump',
            select: 'select',
            create: 'create',
            play: 'play'
        },

        images: {
            surface: 'file:///iheartradio/images/surface.png',
            folder: 'file:///iheartradio/images/list/list_icon-folder.png',
            nowPlaying: 'file:///iheartradio/images/list/sidebtn_icon-now_playing.png',
            nowPlayingDisabled: 'file:///iheartradio/images/list/sidebtn_icon-now_playing_disabled.png',
            back: 'file:///iheartradio/images/list/sidebtn_icon-back.png',
            alphaJump: 'file:///iheartradio/images/list/sidebtn_icon-alpha_jump.png',
            alphaJumpDisabled: 'file:///iheartradio/images/list/sidebtn_icon-alpha_jump_disabled.png',
            keyboardPressedId1: 'file:///iheartradio/images/buttons/pressed/56x56.png',
            keyboardPressedId2: 'file:///iheartradio/images/buttons/pressed/75x52.png'
        },

        init: function (options, title, model) {
            this._super(options.display, model);
            this.title = title || '';
            this.template = {};
            this.config = options.config;
        },

        _render: function (options) {
            options = options || {};
            this.template = this.generateTemplate(options);
            this.start();
        },

        showKeyboard: function() {
            this._super(this.images.keyboardPressedId1, this.images.keyboardPressedId2);
        },

        create: function(item) {
            this.trigger('create', item);
        },

        nowPlaying: function(options) {
            this.trigger('nowPlaying', options);
        },

        play: function(options) {
            this.trigger('play', options);
        },

        /**
         * Update screen with the already generated template and bind UI elements
         */
        start: function () {
            this.updateScreen(this.template);
            this.startListening(this.events);
        },

        select: function (item) {
            this.trigger('select', item);
        },

        generateTemplate: function (options) {
            var listItems = this.getItems(options.items),
                buttons = this.getButtons(this.isAlphaJumpEnabled(options.items)),
                selectedListItem = _.isNumber(this.getSelectedListItem()) && this.getSelectedListItem();

            if (selectedListItem && listItems.length >= selectedListItem) {
                listItems.activeListItem = selectedListItem;
            }

            return {
                templateId: 'vp2c-3',
                backgroundImage: this.images.surface,
                systemHeader: true,
                loadingType: 3,
                templateContent: {
                    title: {
                        text: this.title
                    },
                    list: listItems,
                    buttons: buttons
                }
            };
        },

        getButtons: function (isAlphaJumpEnabled) {
            var buttons = {
                1: {
                    image: {
                        normal: this.images.back
                    },
                    action: this.events.goBack
                },
                4: {
                    image: {
                        normal: this.model.isStationSelected() ? this.images.nowPlaying : this.images.nowPlayingDisabled
                    },
                    action: this.events.nowPlaying,
                    stateEnabled: this.model.isStationSelected()
                }
            };
            if (isAlphaJumpEnabled) {
                buttons[10] = {
                    image: {
                        normal: this.images.alphaJump
                    },
                    action: this.events.onAlphaJump
                };
            }
            return buttons;
        },

        isAlphaJumpEnabled: function (items) {

            items = _.isArray(items) ? items : [];
            var stationListTypes = ['getLiveStationsCitiesMenu', 'getLiveStationsByCityMenu'],
                itemsPerPage = 4;
            return items.length > itemsPerPage && items.some(function (item) {
                return _.contains(stationListTypes, utils.resolve(item, 'commands.select.cmd'));
            });
        },

        getItems: function (items) {
            return items ? items.map(function (item) {
                var commands = item.commands || {},
                    action = _.intersection(this.events, _.keys(item.commands))[0],
                    hasChildren = commands.select;
                return {
                    text: item.text,
                    image1: hasChildren ? this.images.folder : '',
                    action: action,
                    value: item
                };
            }, this) : [{
                text: $.t('loading')
            }];
        },

        goBack: function () {
            this.trigger('goBack');
        }
    });
});