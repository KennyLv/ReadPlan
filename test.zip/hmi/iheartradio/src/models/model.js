define(['iheartradio/models/extension'], function (Extension) {
    'use strict';

    return Extension.extend({

        init: function (options) {
            options = options || {};
            this._data = options.data || {};
            this._super(options);
        },

        set: function (key, val) {
            if (_.isObject(key) && !val) {
                _.each(key, function (value, fieldName) {
                    this._data[fieldName] = value;
                }, this);

                if (key.noRender) {
                    return;
                }

            } else {
                this._data[key] = val;
            }

            this.trigger('changed');
        },

        get: function (key) {
            return this._data[key];
        },

        reset: function () {
            this._data = {};
            this.resetProgressCounter();
            this.trigger('reset');
        },

        /**
         * Check if station is set
         * @returns {boolean}
         */
        isStationSelected: function () {
            return !!this.get('station');
        },

        isPlaying: function () {
            return this.get('isPlaying');
        },

        isPlayOnStartup: function(){
            return this.get('isPlayOnStartup');
        },

        /**
         *
         * @returns {String} 'custom' or 'live' or 'talk' or 'default'
         */
        getStationType: function () {
            return this.get('station') ? this.get('station').type : (this.get('stationType') || 'default');
        },

        getStationId: function () {
            return this.get('station') && this.get('station').id;
        },

        getButtonState: function () {
            var postfix = 'Player',
                stationType = this.getStationType(),
                type = stationType === 'talk' ? 'customTalkPlayer' : stationType + postfix,
                state = this.get('buttonState');
            return state ? state[type] : false;
        },

        getStationName: function () {
            return this.get('station') ? this.get('station').name : '';
        },

        /**
         * customTalkPlayer: Episode Date / Episode Name
         * livePlayer: Song / Artist information
         * customPlayer Song / Artist information
         * @returns {string[]}
         */
        getStationTextInfo: function () {
            var stationType = this.getStationType(),
                textInfo;
            switch (stationType) {
            case 'custom':
                textInfo = {
                    text1: this.get('track') ? this.get('track').title : '',
                    text2: this.get('track') ? this.get('track').artistName : ''
                };
                break;
            case 'live':
                textInfo = {
                    text1: this.get('track') ? this.get('track').songTitle : '',
                    text2: this.get('track') ? this.get('track').artistName : ''
                };
                break;
            case 'talk':
                textInfo = {
                    text1: this.get('track') ? this.get('track').title : '',
                    text2: this.get('track') ? this.get('track').showName : ''
                };
                break;
            default:
                textInfo = {
                    text1: '',
                    text2: ''
                };
            }

            return [textInfo.text1, textInfo.text2];
        },

        isLiveStation: function () {
            return this.getStationType() === 'live';
        },

        getTrackDuration: function () {
            return this._getTrackDuration() || 0;
        },

        getTrackElapsedTime: function () {
            return this._getTrackElapsedTime() || 0;
        },

        getImageCommand: function () {
            var track = this.get('track'),
                station = this.get('station');
            return (track && track.imageCommand) || (station && station.imageCommand);
        }
    });

});