define(['aq/eventEmitter', 'aq/utils', 'aq/dic'], function (EventEmitter, utils, aq) {
    'use strict';

    var ProgressCounter = aq.get('progressCounter'),
        progressCounter = new ProgressCounter();

    return EventEmitter.extend({

        events: {
            onReadyStateChanged: 'onReadyStateChanged',

            // play/pause
            onPlayerStateChanged: 'onPlayerStateChanged',

            // custom and talk stations
            onTrackChanged: 'onTrackChanged',
            onStationChanged: 'onStationChanged',

            // only for live player
            onMetadataChanged: 'onMetadataChanged',
            onImage: 'image/png',
            onScanAvailableChanged: 'onScanAvailableChanged',

            // any skip limit reached
            onDMCASkipFail: 'onDMCASkipFail',

            // "networkState": "(connected|disconnected)"
            onNetworkStateChanged: 'onNetworkStateChanged',

            onPlayerError: 'onPlayerError',

            // notifies that an iHRCP session is going to end/disconnect
            onEndSession: 'onEndSession',
            //TODO: enable if async elapsed time notification is needed
            //onElapsedTime: 'onElapsedTime'
            onBufferingStart: 'onBufferingStart',
            onBufferingEnd: 'onBufferingEnd',

            //system notifications
            onMute: "mute",
            onUnMute: "unmute",
        },

        statusCodes: {
            ok: 0,
            noFavorites: 1,
            notLoggedIn: 2,
            noStations: 5,
            maxFavoritesReached: 6,
            invalidPresetPosition: 8
        },

        errorStatusCodes: {
            noResponse: -1,

            /**
             * We can identify auth fail only by pair of code and description
             * Error code 504 is also used for other types of errors
             */
            authFail: {
                code: 504,
                description: /auth/
            }
        },

        successStatusCodes: {
            ok: 0,
            authSuccess: 4,
            presetAlreadySet: 7,
            elapsedTimeNA: 9,
            noRecentStations: 5
        },

        responseStatus: {
            success: "success",
            fail: "fail"
        },

        scannablePlayerTypes: ["livePlayer"],

        _isPlayingBufferedState: false,

        /**
         * Used for all subsequent api calls
         *
         * @var String
         * @protected
         */
        sessionId: null,

        init: function (options) {
            this.config = options.config;
            this.commandControl = new options.commandControl();
        },

        startListening: function() {
            this.listenTo(this.commandControl, this.events.onPlayerStateChanged, this.onPlayerStateChanged);
            this.listenTo(this.commandControl, this.events.onMetadataChanged, this.onMetadataChanged);
            this.listenTo(this.commandControl, this.events.onTrackChanged, this.onTrackChanged);
            this.listenTo(this.commandControl, this.events.onStationChanged, this.onStationChanged);
            this.listenTo(this.commandControl, this.events.onImage, this.onImage);
            this.listenTo(this.commandControl, this.events.onDMCASkipFail, this.onDMCASkipFail);
            this.listenTo(this.commandControl, this.events.onElapsedTime, this.onElapsedTime);
            this.listenTo(this.commandControl, this.events.onNetworkStateChanged, this.onNetworkStateChanged);
            this.listenTo(this.commandControl, this.events.onReadyStateChanged, this.onReadyStateChanged);
            this.listenTo(this.commandControl, this.events.onBufferingEnd, this.onBufferingEnd);
            this.listenTo(this.commandControl, this.events.onBufferingStart, this.onBufferingStart);
            //system listens
            this.listenTo(this.commandControl, this.events.onMute, this.onMute);
            this.listenTo(this.commandControl, this.events.onUnMute, this.onUnMute);
        },

        close: function() {
            if(this.isPlaying()) {
                this.pause()
                    .done(this.endSession.bind(this));
            }
            else  {
                this.endSession();
            }
            this.stopListening();
        },

        /**
         *
         * @param data
         * @param data.buttonState
         * @param data.eventData
         * @param data.eventId
         */
        onPlayerStateChanged: function (data) {
            var isPlaying = this.get('isPlaying'),
            newData = {};
            
            data = this._validateStateInScanMode(data);
            this._isPlayingBufferedState = isPlaying;

            if (data.eventData && data.eventData.isPlayerPlaying !== isPlaying) {
                newData.isPlaying = data.eventData.isPlayerPlaying || false;
            }
            newData.buttonState = data.buttonState;
            newData.noRender = this._triggerRenderChange();
            
            this.set(newData);
        },

        onReadyStateChanged: function (data) {
            var readyState = data.eventData.readyState && data.eventData.readyState.state,
                prevState = this.get('readyState'),
                reasonCode = data.eventData.readyState && data.eventData.readyState.reasonCode,
                playOnReconnect = false;

            this.set({
                readyState: readyState,
                reasonCode: reasonCode
            });

            // call init session if readyState changed from 0 to 1
            if (readyState === '1' && readyState !== prevState && !!prevState) {
                this.initSession();
            }

            if (readyState === '1' && reasonCode === '0') {
                playOnReconnect = this._isPlayingBufferedState &&
                this._isPlayingBufferedState !== this.get('isPlaying');
            }

            this.trigger('onReadyStateChanged', data, prevState, playOnReconnect);
        },

        /**
         *
         * @param data
         * @param data.buttonState
         * @param data.eventData
         * @param data.eventId
         */
        onStationChanged: function (data) {
            data = this._validateStateInScanMode(data);
            
            if(!_.isEqual(data.eventData.station, this.get('station'))) {
                this.resetProgressCounter();

                this.set({
                    station: data.eventData.station,
                    track: null,
                    image: null,
                    buttonState: data.buttonState
                });
            }
        },

        startProgressCounter: function(data) {
            this.resetProgressCounter();

            if (data.track || data.episode) {
                var mediaLength = data.track ?
                    data.track.trackLength : data.episode.episodeLength;

                var elapsedTime = +arguments[1] || +data.elapsedTime;

                progressCounter.start({
                    elapsedTime: elapsedTime,
                    totalTime: mediaLength
                });
            }
        },

        resetProgressCounter: function() {
            progressCounter.reset();
        },

        /**
         *
         * @param data
         * @param data.buttonState
         * @param data.eventData
         * @param data.eventId
         */
        onMetadataChanged: function (data) {
            //while scanning IHR can send an invalid state
            // of thumbs up and thumbs down while scanning
            // TODO should be removed once IHR fixes it's API response handling
            // check CV-2226
            data = this._validateStateInScanMode(data);

            this.set({
                track: data.eventData.liveMetadata,
                buttonState: data.buttonState
            });
        },

        _validateStateInScanMode: function (data) {
            //while scanning IHR can send an invalid state
            // of thumbs up and thumbs down while scanning
            // TODO should be removed once IHR fixes it's API response handling
            // check CV-2440 && CV-2226
            if (this._isScanning) {
                _.each(this.scannablePlayerTypes, function(playerType){
                    
                    //In between songs, play state is invalid to us.
                    if(data.eventData && 
                            data.eventData.hasOwnProperty('isPlayerPlaying') && 
                            !data.eventData.isPlayerPlaying){
                        data.eventData.isPlayerPlaying = true;
                    }
                    
                    if(data.buttonState.hasOwnProperty(playerType)){
                        
                        data.buttonState[playerType].thumbsUp = 2;
                        data.buttonState[playerType].thumbsDown = 2;
                        
                        if(data.buttonState[playerType].scan === 0){
                            data.buttonState[playerType].scan = 1;
                        }  
                    }
                }.bind(this));
            }

            return data;
        },
        
        /**
         *
         * @param data
         * @param data.buttonState
         * @param data.eventData
         * @param data.eventId
         */
        onTrackChanged: function (data) {
            $.when(this._getElapsedTimeCommand()
                ).done( function(getElapsedTimeResponse){
                this.set({
                    //works for custom player(track) or talk player(episode)
                    track: data.eventData.track || data.eventData.episode,
                    buttonState: data.buttonState,
                    elapsedTime: +getElapsedTimeResponse.elapsedTime
                });

                this.startProgressCounter(data.eventData, +getElapsedTimeResponse.elapsedTime);
            }.bind(this));
        },

        _getTrackDuration: function() {
            return progressCounter.getTotalTime() || 0;
        },

        _getTrackElapsedTime: function() {
            return progressCounter.getElapsedTime() || 0;
        },

        /**
         *
         * @param data {String} base64
         */
        onImage: function(data) {
            this.set({
                image: data,
                noRender: this._triggerRenderChange()
            });
        },

        /**
         *
         * @param data.eventData.networkState {String} connected | disconnected
         */
        onNetworkStateChanged: function(data) {
            if(data.eventData.networkState === 'connected' && !this.isConnectedToNetwork()) {
                this.getElapsedTime();
            }
            if(data.eventData.networkState === 'disconnected') {
                this.resetProgressCounter();
            }

            this.set({
                networkState: data.eventData.networkState,
                noRender: true
            });
            this.trigger('onNetworkState', data);
        },

        /**
         *
         * @param data.eventData.bufferingState.isBuffering {Boolean}
         */
        onBufferingStart: function(data) {
            this.set({
                bufferingState: data.eventData.bufferingState.isBuffering
            });
        },

        /**
         *
         * @param data.eventData.bufferingState.isBuffering {Boolean}
         */
        onBufferingEnd: function(data) {
            this.set({
                bufferingState: data.eventData.bufferingState.isBuffering
            });
        },

        onUnMute: function(){
            if (!this.isPlaying()) {
                this.play();
            }
        },

        onMute: function(){
            if (this.isPlaying()) {
                this.pause();
            }
        },

        /**
         *  Standard iHR response object
         * {
         *    ihrcp: "2.0",
         *    status: {
         *      description":"OK",
         *      code: 0
         *    }
         * }
         *
         * Success codes: 0 - 499
         * Error codes: > 500
         *
         * @param data
         * @returns {$.Deferred}
         */
        sendData: function (data) {
            var noResponseStatusCode = this.errorStatusCodes.noResponse;

            return this.commandControl.sendCommand(data).then(function (response) {
                response = _.isString(response) ? utils.parseJSON(response) : response;
                response = response || {};
                return response;
            }, function (response) {
                response = _.isString(response) ? utils.parseJSON(response) : response;
                response = response || {};
                response.statusCode = utils.resolve(response, 'status.code') || noResponseStatusCode;
                return response;
            });
        },

        _isAuthError: function (statusCode, response) {
            var authFail = this.errorStatusCodes.authFail;
            return (statusCode === authFail.code &&
                authFail.description.test(utils.resolve(response, 'status.description')));
        },

        _onSendDataRespond: function(status, dfd, response) {
            var successStatusCodes = _.values(this.successStatusCodes),
                isConnectedToNetwork = this.isConnectedToNetwork.bind(this),
                pseudoResponse = this._buildPseudoResponce('NoNetworkConnection'),
                initSession = this.initSession.bind(this),
                statusCode = utils.resolve(response, 'status.code'),
                onError = this._onError.bind(this, dfd),
                isError = _.isNumber(statusCode) && !_.contains(successStatusCodes, statusCode);
            var isAuthError = this._isAuthError(statusCode, response);

            if (status === this.responseStatus.success) {
                response.statusCode = statusCode;
            }

            if (isAuthError){
                initSession();
            } else if(!isConnectedToNetwork()) {
                return onError(pseudoResponse);
            } else if (status === this.responseStatus.fail) {
                return onError(response);
            } else {
                return isError ? onError(response) : dfd.resolve(response);
            }
        },

        /**
         *
         * Call API with the passed data/command
         *
         * @return {$.Deferred}
         */
        exec: function (cmd) {
            var dfd = $.Deferred(),
                promise = this.sendData(cmd);

            promise
                .done(this._onSendDataRespond.bind(this, this.responseStatus.success , dfd))
                .fail(this._onSendDataRespond.bind(this, this.responseStatus.fail, dfd));

            return dfd;
        },

        isConnectedToNetwork: function () {
            return this.get('networkState') !== 'disconnected';
        },

        isScanning: function() {
            return this._isScanning;
        },

        onDMCASkipFail: function (data) {
            this.trigger('onDMCASkipFail', data);
        },

        _onError: function (dfd, response) {
            // gets iHR ReadyState status
            var notReadyState = this._getReadyStatus();
            var error = {
                code: response.statusCode,
                title: notReadyState ? notReadyState.title : this._getErrorTitle(response),
                message: notReadyState ? notReadyState.message : this._getErrorMessage(response)
            };

            this.trigger('error', error, response);
            dfd.reject(error, response);
        },

        _getErrorMessage: function (response) {
            response = response || {};
            return response.modalScreen ?
                $.t('error.' + response.modalScreen.key + '.message') :
                $.t('error.generic.message');
        },

        _getErrorTitle: function (response) {
            response = response || {};
            return response.modalScreen ?
                $.t('error.' + response.modalScreen.key + '.title') :
                $.t('error.generic.title');
        },

        /*
        *  Done for a need on CV-2298
        *  to check iHR's ReadyState status
        *  additional return values may be added in future
        */
        _getReadyStatus: function() {
            // readyState === '0' - Application layer is not ready to respond to and process commands.
            // reasonCode === '3' - User requested disconnect
            var notReadyState = (this.get('readyState') === '0' &&
                (this.get('reasonCode') === '1' || this.get('reasonCode') === '3'));
            if (notReadyState) {
                return {
                    title: $.t('status.2.title'),
                    message: $.t('status.2.message')
                };
            }
            else {
                return false;
            }
        },

        _buildPseudoResponce: function(responseKey) {
            return {
                    modalScreen: {
                            key: responseKey
                        }
                    };
        },

        _triggerRenderChange: function () {
            return this.isScanning() && this.isConnectedToNetwork();
        },

        initSession: function () {
            return this.exec({
                cmd: "auth",
                args: {
                    clientId: this.config.clientId,
                    ihrcp: this.config.apiVersion,
                    profile: this.config.profileName
                }
            }).done(function (response) {
                // have to call setSysInfo CV-1381 Iheart
                this.setSysInfo();
                this.setProfileOptions();
                this.sessionId = response.sessionId;
            }.bind(this));
        },


        /**
         *
         * @returns {$.Deferred}
         */
        setSysInfo: function () {
            return this.exec({
                cmd: "setSysInfo",
                //todo tmp solution
                args: {
                    COUNTRY :"USA"
                }
            });
        },

        endSession: function () {
            return this.exec({
                cmd: "endSession",
                args: {
                    sessionId: this.sessionId
                }
            }).done(function () {
                this.sessionId = null;
                this.set('readyState', 0);
            }.bind(this));
        },

        /**
         * @returns {$.Deferred}
         */
        setProfileOptions: function () {
            return this.exec({
                cmd: "setOptions",
                args: this.config.profileOptions
            });
        },

        /**
         *
         * @param localeId {String} fr_CA, en_US, es_MX
         * @returns {$.Deferred}
         */
        setLocale: function (localeId) {
            return this.exec({
                cmd: "setLocale",
                args: {
                    localeId: localeId
                }
            });
        },

        getMainMenu: function () {
            return this.exec({
                cmd: "getMainMenu"
            });
        },

        /**
         * Get live radio menu
         * Items: Near You, By Location, Talk Radio, Music & Entertainment
         * Until we see select in commands for each item - we can go deeper
         *
         * Response format:
         * {
         *   menu: [
         *     {
         *       commands: {
         *         select: {cmd: "COMMAND"},
         *         args: {} / optional /
         *       },
         *       key: "KEY"
         *       text: "TEXT"
         *     }, ...
         *   ],
         *   status: {Object}
         * }
         *
         * @returns {$.Deferred}
         */
        getLiveRadioMenu: function () {
            return this.exec({cmd: "getLiveRadioMenu"});
        },

        getCreateStationMenu: function () {
            return this.exec({cmd: "getFeaturedStationsGenresMenu"});
        },

        getShowsMenu: function () {
            return this.exec({cmd: "getTalkCategoryMenu"});
        },

        getRecentStations: function () {
            var dfrd = new $.Deferred(),
                onError = this._onError.bind(this, dfrd);
            this.exec({cmd: "getRecentStationsMenu"}).done(function(data) {
                if (data.menu && data.menu.length >= 1) {
                    dfrd.resolve(data);
                } else {
                    var pseudoResponse = this._buildPseudoResponce('NoRecentStations');
                    onError(pseudoResponse);
                }
            }.bind(this)).fail(function(error, response){
                dfrd.reject(error, response);
            });
            return dfrd;
        },

        getLastRecentStations: function () {
            var dfrd = new $.Deferred();

            this.exec({cmd: "getRecentStationsMenu", "args":{"pageNum":1, "pageSize":1}}).done(function(data) {
                dfrd.resolve(data);
            }).fail(function(error, response){
                dfrd.reject(error, response);
            });
            return dfrd;
        },

        /**
         * Only for authorized users
         * For non-authorized users returns statusCode 2 and
         * pass modalScreen object with all the related info: message, description, etc
         *
         * @returns {$.Deferred}
         */
        getFavoritesStations: function () {
            return this.exec({cmd: "getFavoritesMenu"});
        },

        /**
         * response:
         * {
         *   playerState: {
         *     isPlayerPlaying: <Boolean>,
         *     liveMetadata: {},
         *     station: {}
         *   },
         *   buttonState: {}
         * }
         * @returns {*}
         */
        getPlayerState: function () {
            return $.when(
                    this.exec({cmd: "getPlayerState"}),
                    this._getElapsedTimeCommand()
                ).done(function(getPlayerStateResponse, getElapsedTimeResponse) {
                    var playerState = getPlayerStateResponse.playerState || {};
                    this.set({
                            isPlaying: playerState.isPlayerPlaying || false,
                            station: playerState.station,
                            track: playerState.liveMetadata ||
                                playerState.track ||
                                playerState.episode,
                            buttonState: getPlayerStateResponse.buttonState,
                            elapsedTime: +getElapsedTimeResponse.elapsedTime
                        });
                }.bind(this));
        },

        /**
         * response:
         * {
         *    "ihrcp":"2.0",
         *    "isPlayOnStartup":true
         * }
         * @returns {*}
         */
        getUserSettings: function () {
            return this.exec({
                'cmd' : 'getUserSettings',
                'args': {"keys":["playOnStartup"]}
            }).done(function (response) {
                this.set({isPlayOnStartup: response.isPlayOnStartup});
            }.bind(this));
        },

        getBufferingState: function() {
            return this.get('bufferingState');
        },

        getElapsedTime: function () {
            return this.exec({
                'cmd' : 'getPlayerElapsedTime'
            }).done(function (data) {
                this.startProgressCounter(data);
                if (_.isNumber(data.elapsedTime)) {
                    this.set('elapsedTime', data.elapsedTime);
                }
            }.bind(this));
        },

        _getElapsedTimeCommand: function() {
            return this.exec({
                'cmd' : 'getPlayerElapsedTime'
            });
        },

        onElapsedTime: function (data) {
            this.set('elapsedTime', data.elapsedTime);
        },

        getImage: function (cmd) {
            this.commandControl.sendCommand(cmd)
                .done(function (response) {
                    var isImage = _.isString(response);
                    if (isImage) this.onImage(response);
                }.bind(this));
        },

        /**
         *
         * @param options {Object} station type and id, optional arg
         * @param options.stationId {String}
         * @param options.stationType {String}
         *
         * @returns {$.Deferred}
         */
        play: function (options) {
            var data = {cmd: "play"};
            if (this._isScanning) this._isScanning = false;
            if (options) data.args = options;
            return this.exec(data);
        },

        pause: function () {
            if (this._isScanning) {
                this._isScanning = false;
            }
            progressCounter.off();

            return this.exec({cmd: "pause"});
        },

        skipSong: function () {
            return this.exec({cmd: "skipSong"});
        },
        
        /**
         * Get user favorite stations, play the first one in the list.
         * 
         * If current station happens to be in the list, 
         * then play the next one down from the list.
         * 
         * If current station happens to be the last in the list,
         * then play the first one in the list.
         */
        playNextInFav: function(){
            this.getFavoritesStations().done(function(data){
                if(data.menu && data.menu.length){
                    
                    //Default to first item in the list
                    var nextStation = data.menu[0].commands.play.args,
                        currStationId = this.getStationId(),
                        foundCurrStation = false;
                    
                    //If current station is in the list, but not the last one,
                    //play the next one down.
                    for(var i in data.menu){
                        var station = data.menu[i];
                        var stationId = station.commands.play.args.stationId;
                        if(stationId === currStationId){
                            foundCurrStation = true;
                        } else if(foundCurrStation){
                            nextStation = station.commands.play.args;
                            break;
                        }
                    }
                    
                    this.play(nextStation);
                }
            }.bind(this));
        },

        scan: function () {
            this._isScanning = true;
            return this.exec({cmd: "scanLiveStation"});
        },

        scrubBackward: function () {
            return this.exec({
                cmd: "scrubBackward",
                args: {
                    stationType: "talk"
                }
            }).done(function(){
                this.getElapsedTime();
            }.bind(this));
        },

        scrubForward: function () {
            return this.exec({
                cmd: "scrubForward",
                args: {
                    stationType: "talk"
                }
            }).done(function(){
                this.getElapsedTime();
            }.bind(this));
        },

        createStation: function () {
            var data = {
                cmd: 'createCustomStation',
                args: { playStation: false }
            };

            var track = this.get('track');

            //Live Station
            if(track.songId){
                data.args.songId = track.songId;

            //Custom Station
            } else if(track.id){
                data.args.songId = track.id;

            } else {
                data.args.artistId = track.artistId;
            }
            return this.exec(data);
        },

        thumbs: function (cmd) {
            var data = {
                cmd: cmd,
                args: {
                    stationType: this.getStationType()
                }
            };

            if (this.isLiveStation()) {
                //these values need to be in string and not int,
                // or Invalid parameter is returned
                data.args.songId = this.get('track').songId.toString();
                data.args.radioId = this.get('station').id.toString();
            }

            return this.exec(data);
        },

        thumbsDown: function () {
            var buttonState = this.getButtonState();
            buttonState.thumbsUp = 0;
            buttonState.thumbsDown = 1;

            return this.thumbs("thumbsDown").fail(function(){
                var buttonState = this.getButtonState();
                buttonState.thumbsUp = 0;
                buttonState.thumbsDown = 0;
            }.bind(this));
        },

        thumbsUp: function () {
            return this.thumbs("thumbsUp").done(function(){
                var buttonState = this.getButtonState();
                buttonState.thumbsUp = 1;
                buttonState.thumbsDown = 0;
            }.bind(this));
        },

        favorite: function (cmd) {
            var data = {
                cmd: cmd,
                args: {
                    stationId: this.getStationId()
                }
            };

            return this.exec(data);
        },

        addFavorite: function () {
            return this.favorite("addFavorite").done(function () {
                var buttonState = this.getButtonState();
                buttonState.addToFavorites = 1;
            }.bind(this));
        },

        removeFavorite: function () {
            return this.favorite("removeFavorite").done(function () {
                var buttonState = this.getButtonState();
                buttonState.addToFavorites = 0;
            }.bind(this));
        },

        getDiscoveryMenu: function () {
            return this.exec({cmd: "getDiscoveryMenu"});
        }
    });
});
