var path = require('path');

module.exports = function(grunt) {
    "use strict";

    grunt.file.expand('../node_modules/grunt-*/tasks').forEach(grunt.loadTasks);

    var platform = grunt.option("platform") || "vp2c";
    var version = process.env.iheartradio ? ['', process.env.iheartradio] :
            (process.env.versions || "").match(/iheartradio=([^;]+)/),
        manifestVersion = version ? version[1] : "0.0.0";

    var checkCircularDependencies = function (data) {
        var madge = require("madge"),
            circular = madge([data.path], {
                format: "amd",
                optimized: true
            }).circular(),
            isCyclic = circular.getArray().length;

        if (isCyclic) {
            circular.getArray().forEach(function (path) {
                path.forEach(function (module, idx) {
                    if (idx) {
                        process.stdout.write(" -> ");
                    }
                    process.stdout.write(module);
                });
                process.stdout.write("\n");
            });
            grunt.fail.fatal("Circular dependencies detected");
        }
    };

    var extendWithVP4Commands = function (commandsSequenceArray, platform) {
        if (platform === 'vp4') {
            //pushing VP4 release commands to commands array
            commandsSequenceArray.splice(
                commandsSequenceArray.indexOf("clean:assets") + 1,
                0,
                "casper:signJar:--jarFilePath=" + grunt.config.get('archiveFilePath'));
        }

        return commandsSequenceArray;
    };

    var b2bConfig = {
            b2bRegions: {
                NORTH_AMERICA_USA: { text: 'United States',
                                     env: process.env.us,
                                     toProcess: (process.env.us !== "false")},
                NORTH_AMERICA_CA:  { text: 'Canada',
                                     env: process.env.ca,
                                     toProcess: (process.env.ca !== "false")},
                MEXICO:            { text: 'Mexico',
                                     env: process.env.mx,
                                     toProcess: (process.env.mx !== "false")}
            },
            hupVersion: process.env.hupVersion || '2.0'
    };

    var config = grunt.initConfig({

        app: grunt.file.readJSON("../platform/" + platform + "/hmiapps/iheartradio/resources/app.json"),
        version: "<%= app.version %>",
        appId: "<%= parseInt(app.appId, 10) %>",
        imageVersion: "<%= parseInt(app.imageVersion, 10) %>",

        buildFolder: "../dist",

        moduleName: "iheartradio",
        moduleFileName: "app.js",
        moduleFolder: "<%= buildFolder %>/<%= moduleName %>",
        moduleMetadata: 'metadata',
        assetsDirName: 'assets',
        archiveType: (platform !== 'vp4') ? 'zip' : 'jar',
        archiveFilePath: "<%= buildFolder %>/<%= moduleName %>/<%= assetsDirName %>_<%= appId %>" +
            "<%= imageVersion %>.<%= archiveType %>",

        jshint: {
            options: {
                jshintrc: "../.jshintrc"
            },
            all: [
                "src/**/*.js"
            ]
        },

        copy: {
            resources: {
                files: [
                    {
                        expand: true,
                        cwd: "../platform/" + platform + "/hmiapps/<%= moduleName %>/resources/",
                        src: ["**"],
                        dest: "<%= moduleFolder %>/"
                    }
                ]
            },
            release: {
                flatten: true,
                expand: true,
                src: [
                    "<%= moduleFolder %>.zip",
                    "../platform/" + platform + "/hmiapps/<%= moduleName %>/<%= moduleMetadata %>/*"
                ],
                dest: "<%= moduleFolder %>/"
            }
        },

        replace: {
            release: {
                src: ["<%= moduleFolder %>/MANIFEST.txt"],
                overwrite: true,
                replacements: [{
                    from: "<VERSION>",
                    to: manifestVersion
                },
                {
                    from: "<REGIONS_KEYS>",

                    to: function() {
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey);
                            }
                        }

                        return replaceWith.join(',');
                    }
                },
                {
                    from: "<REGIONS>",
                    to: function(){
                        var replaceWith = [];

                        for (var regionKey in b2bConfig.b2bRegions) {
                            if(b2bConfig.b2bRegions.hasOwnProperty(regionKey) &&
                                b2bConfig.b2bRegions[regionKey].toProcess) {
                                replaceWith.push(regionKey + ':' + b2bConfig.b2bRegions[regionKey].text);
                            }
                        }

                        return replaceWith.join('\n');
                    }
                },
                {
                    from: "<HUP_VERSION>",
                    to: b2bConfig.hupVersion
                }]
            },
            //adds app's version to every log output
            // works only with release task
            releaseWithAppVersionInLogs: {
                src: ["<%= moduleFolder %>/<%= moduleFileName %>"],
                overwrite: true,
                replacements: [{
                    from: /WEB_VIEW","/g,
                    to: function(match){
                            return match.replace(/"$/, '"[' + manifestVersion + ']');
                        }
                }]
            }
        },

        requirejs: {
            release: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    optimize: "uglify",
                    paths: {
                        "iheartradio_di": "../platform/" + platform + "/hmiapps/<%= moduleName %>/di"
                    }
                }
            },
            dev: {
                options: {
                    mainConfigFile: "requirejs.config.js",
                    include: ["<%= moduleName %>"],
                    out: "<%= moduleFolder %>/<%= moduleFileName %>",
                    onModuleBundleComplete: checkCircularDependencies,
                    logLevel: 2,
                    generateSourceMaps: true,
                    optimize: "none",
                    paths: {
                        "iheartradio_di": "../platform/" + platform + "/hmiapps/<%= moduleName %>/di"
                    }
                }
            }
        },

        compress: {
            module: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %>.zip",
                    mode: "zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= buildFolder %>/",
                    src: "<%= moduleName %>/**"
                }]
            },
            release: {
                options: {
                    archive: "<%= buildFolder %>/<%= moduleName %><%= version %>.zip"
                },
                files: [{
                    expand: true,
                    cwd: "<%= moduleFolder %>",
                    src: "**"
                }]
            },
            assets: {
                options: {
                    archive: "<%= archiveFilePath %>",
                    mode: "zip"
                },
                files: [{
                    filter: "isFile",
                    expand: true,
                    cwd: "<%= moduleFolder %>/<%= assetsDirName %>/",
                    src: "**",
                    dest: "./"
                }]
            }
        },

        watch: {
            src: {
                files: ['**/*.js'],
                tasks: ["dev"],
                options: {
                    debounceDelay: 500
                }
            }
        },

        clean: {
            options: {
                force: true
            },
            before: ["<%= moduleFolder %>"],
            assets: ["<%= moduleFolder %>/<%= assetsDirName %>", "<%= moduleFolder %>/xlet.properties"],
            after: ["<%= moduleFolder %>.zip"]
        },

        casper: {
            options : {
                test : false,
                args: [] // NOTE: We need this to be able to pass option to casper
            },
            signJar: {
                src: ["../tools/sign_archive.js"]
            }
        }
    });

    grunt.registerTask("assets", "Prepares jar file with resources (static assets)", function () {
        var imageMap = config.app.images,
            moduleFolder = path.join(config.buildFolder, config.moduleName),
            resourcesDistDir = path.join(moduleFolder, config.assetsDirName),
            imageIds = Object.keys(imageMap),
            fileList = [];

        grunt.file.mkdir(resourcesDistDir);

        for (var i = 0, l = imageIds.length; i < l; i++) {
            var imgId = imageIds[i],
                imgPath = imageMap[imgId],
                fileExtension = imgPath.split(".").pop(),
                newFileName = parseInt(config.app.appId + imgId, 10) + "." + fileExtension,
                newFilePath = path.join(resourcesDistDir, "images", newFileName);

            imgPath = imgPath.replace("file:///", config.buildFolder + "/");
            // Because now we have a copy-paste (from VP2C) issues in platform's app.json file, check if file exist
            if (grunt.file.exists(imgPath)) {
                grunt.file.copy(imgPath, newFilePath);
                fileList.push("images/" + newFileName);
            } else {
                console.log("FILE DOES NOT EXIST!", imgPath);
            }
        }

        if (platform === "vp4") {
            grunt.file.copy("../platform/" + platform + "/hmiapps/" + config.moduleName + "/resources/xlet.properties",
                resourcesDistDir + "/xlet.properties");
            grunt.file.write(resourcesDistDir + "/manifest.txt", fileList.join("\n"));
        }

        grunt.task.run(["compress:assets"]);
    });

    grunt.registerTask("default", ["release"]);
    grunt.registerTask("dev", ["jshint", "copy:resources", "assets", "requirejs:dev", "clean:assets"]);

    grunt.registerTask("release", (extendWithVP4Commands)([
        "jshint", "copy:resources", "assets", "requirejs:release", "clean:assets",
        "replace:releaseWithAppVersionInLogs", "compress:module", "clean:before", "copy:release", "replace:release",
        "compress:release", "clean:before", "clean:after"], platform));
    grunt.registerTask("release-pretty", (extendWithVP4Commands)([
        "jshint", "copy:resources", "assets", "requirejs:dev", "clean:assets",
        "compress:module", "clean:before", "copy:release", "replace:release", "compress:release", "clean:after"
    ],platform));

    grunt.event.on('watch', function(action, filepath, target) {
        grunt.log.writeln(target + ': ' + filepath + ' has ' + action);
    });

};
