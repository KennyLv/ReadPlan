iHeartRadio handset application

- Application wireframes can be found here - https://airbiq.atlassian.net/wiki/display/SVP2C/VP2C+iHeart+Requirement
- Applications images can be found here - https://airbiq.atlassian.net/wiki/display/SVP2C/VPC2+Application+Art

- 3rd party application, API docs can be found here - https://airbiq.atlassian.net/wiki/download/attachments/7504238/iHRCP%202.0%20Beta%203.zip?api=v2

****

Airbiquity Beta Build 3
 
Improvements
Added auth key for Chrysler.
Included iHeartAutoHU for demo purposes.
Fixed live Radio menu ordering.
New app layer and connection layer to support the new multi brand multi service connection system.
Backwards compatibility additions to continue supporting Nissan/Infiniti on older airbiquity clients.
Ready State changes for Chrysler's connection classes.  user login is not a requirement for 2.0.
Documentation
https://www.dropbox.com/s/7h64xf6z4xeo2s4/iHRCP%202.0%20beta%20App%20Layer%20API%20Reference%20-%20Beta%203.pdf
Note: Status Codes on pg 245
 
iHeartConnect
http://dl-thumbplay.clearchannel.com/office/android/ihrc/1.5.0/airbiquity/b3/iHeartRadioConnect-airbiquity_beta3.apk
 
iHeartAutoDemo
http://dl-thumbplay.clearchannel.com/office/android/ihrc/1.5.0/airbiquity/b3/iHeartAutoDemo-airbiquity_beta3.apk
 
iHeartAutoHU
http://dl-thumbplay.clearchannel.com/office/android/ihrc/1.5.0/airbiquity/b3/iHeartAutoHU-airbiquity_beta3.apk
 
 
Auto HU directions
Localhost TCP/IP instructions:
1) To install and test you will need a single android device.
 
2) Install iHeartAutoDemo, iHeartAutoHU and iHeartConnect via adb install command.
 
3) Start iHeartConnect on your handset.  Log in with your heart account if you wish to test authenticated mode.
 
4) Start iHeartAutoDemo click the car icon in the upper left.
Select api version 2.0
Select Profile Type DA
Select Connection Type TCP/IP
Select Back
Start iHeartAuthoHU by selecting the iHeartRadio icon
 
Bluetooth Instructions:
1) To install and test you will need two android devices.  
 
  Install the apk’s as follows.
 
  Device one:
  iHeartConnectAPI
 
  Device two (client preferably a tablet):
  iHeartAutoDemo and iHeartAutoHU
 
2) Log in to iHeartRadio with device one.
 
3) make sure bluetooth is turned on for both devices.
 
4) Pair each device with one another.
 
5) Start the iHeartAutoHU app on device two.
 
6) Configure settings.  
  * Click the car icon in the upper right to do initial configuration.
    
  * Settings
    * Application Layer = Demo 
    * Select API Version = 2.0
    * Profile Type = DA 
    * Connection Type = Bluetooth
7) Pick your desired paired bluetooth device.
 
8) Press Back
 
9) Select iHearRadio icon.  It should initiate the process.